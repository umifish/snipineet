import axios from 'axios'
import type { AxiosRequestConfig, AxiosResponse } from 'axios'

/**
 * 主工程通用请求封装。
 *
 * - i18n-sdk 等内部模块通过此函数发起 HTTP 请求，避免在各处直接依赖 axios。
 * - 默认返回 `response.data`，调用方根据自身类型约束进行断言。
 */
export async function request<T = any>(
  url: string,
  config?: AxiosRequestConfig,
): Promise<T> {
  const response: AxiosResponse<T> = await axios({
    url,
    method: 'GET',
    ...(config || {}),
  })
  return response.data
}
