import type { DefineComponent } from 'vue'
import type { I18nEditorCore, EditorLocaleItem, PhraseEntry, I18nFieldRules } from '@supernova/i18n-editor'

export type {
  I18nEditorCore,
  EditorLocaleItem,
  PhraseEntry,
  I18nFieldRules,
}
export type {
  PhraseQuery,
  PhrasePageResult,
  PhraseCreateParams,
  PhraseUpdateParams,
  PhraseApiAdapter,
  I18nEditorConfig,
  EditorEventType,
  EditorEventMap,
  I18nValidationRule,
} from '@supernova/i18n-editor'

export interface I18nFieldWrapperProps {
  modelValue?: string
  i18nCode?: string
  translations?: Record<string, string>
  i18nPrefix?: string
  editor?: I18nEditorCore
  locale?: string
  disabled?: boolean
  showPrefixIcon?: boolean
  showSuffixIcon?: boolean
  prefixIconSize?: number
  prefixIconColor?: string
  suffixIconSize?: number
  suffixIconColor?: string
  rules?: I18nFieldRules
  innerValidator?: (value: string) => string | null | Promise<string | null>
}

export interface I18nFieldWrapperExposed {
  validate: () => Promise<string | null>
  clearValidate: () => void
}

export interface PhraseDialogProps {
  modelValue: boolean
  editor: I18nEditorCore
  locales: EditorLocaleItem[]
}

export interface PhraseEditPanelProps {
  entry: PhraseEntry | null
  locales: EditorLocaleItem[]
  loading?: boolean
}

export interface I18nIconProps {
  size?: number
  color?: string
  disabled?: boolean
}

export interface ClearIconProps {
  size?: number
  color?: string
  visible?: boolean
  disabled?: boolean
}

export declare const I18nFieldWrapper: DefineComponent<I18nFieldWrapperProps>
export declare const PhraseDialog: DefineComponent<PhraseDialogProps>
export declare const PhraseEditPanel: DefineComponent<PhraseEditPanelProps>
export declare const I18nIcon: DefineComponent<I18nIconProps>
export declare const ClearIcon: DefineComponent<ClearIconProps>
