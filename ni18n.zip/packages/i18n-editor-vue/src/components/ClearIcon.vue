<script lang="ts">
/**
 * 清除图标 — 用于 I18nFieldWrapper suffix 插槽
 */
export default {}
</script>

<script setup lang="ts">
defineOptions({ name: 'ClearIcon' })
withDefaults(defineProps<{
  size?: number
  color?: string
  visible?: boolean
  disabled?: boolean
}>(), {
  size: 14,
  color: '#c0c4cc',
  visible: true,
  disabled: false,
})

const emit = defineEmits<{ click: [] }>()
</script>

<template>
  <span
    v-if="visible"
    class="i18n-editor-clear"
    :class="{ 'is-disabled': disabled }"
    :style="{ cursor: disabled ? 'not-allowed' : 'pointer', color, lineHeight: 1, display: 'inline-flex', alignItems: 'center' }"
    @click.stop="!disabled && emit('click')"
  >
    <slot>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        :width="size"
        :height="size"
        viewBox="0 0 24 24"
        fill="currentColor"
      >
        <path d="M12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2zm5 13.59L15.59 17 12 13.41 8.41 17 7 15.59 10.59 12 7 8.41 8.41 7 12 10.59 15.59 7 17 8.41 13.41 12 17 15.59z" />
      </svg>
    </slot>
  </span>
</template>
