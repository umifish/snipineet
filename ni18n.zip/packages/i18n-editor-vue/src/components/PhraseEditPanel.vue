<script lang="ts">
/**
 * 文案编辑面板 — 编辑某条文案的所有语言翻译
 */
export default {}
</script>

<script setup lang="ts">
import { ref, watch } from 'vue'
import { ElButton, ElInput, ElForm, ElFormItem } from 'element-plus'
import type { EditorLocaleItem, PhraseEntry } from '@supernova/i18n-editor'

defineOptions({ name: 'PhraseEditPanel' })

const props = defineProps<{
  entry: PhraseEntry | null
  locales: EditorLocaleItem[]
  loading?: boolean
}>()

const emit = defineEmits<{
  back: []
  save: [data: { key: string; translations: Record<string, string> }]
}>()

const editKey = ref('')
const editTranslations = ref<Record<string, string>>({})

watch(() => props.entry, (val) => {
  if (val) {
    editKey.value = val.key
    editTranslations.value = { ...val.translations }
  }
  else {
    editKey.value = ''
    editTranslations.value = {}
  }
  for (const locale of props.locales) {
    if (!(locale.code in editTranslations.value)) {
      editTranslations.value[locale.code] = ''
    }
  }
}, { immediate: true })

function handleSave() {
  emit('save', {
    key: editKey.value,
    translations: { ...editTranslations.value },
  })
}
</script>

<template>
  <div class="i18n-edit-panel">
    <div class="i18n-edit-panel__header">
      <ElButton text @click="emit('back')">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 4px;">
          <path d="M15 18l-6-6 6-6" />
        </svg>
        返回
      </ElButton>
      <span class="i18n-edit-panel__title">{{ entry ? '编辑文案' : '新增文案' }}</span>
    </div>

    <div class="i18n-edit-panel__body">
      <ElForm label-position="right" label-width="80px">
        <ElFormItem label="Key">
          <ElInput v-model="editKey" placeholder="请输入文案 Key" :disabled="!!entry" />
        </ElFormItem>
        <ElFormItem v-for="locale in locales" :key="locale.code" :label="locale.label">
          <ElInput
            v-model="editTranslations[locale.code]"
            :placeholder="`请输入 ${locale.label} 翻译`"
            type="textarea"
            :autosize="{ minRows: 2, maxRows: 4 }"
          />
        </ElFormItem>
      </ElForm>
    </div>

    <div class="i18n-edit-panel__footer">
      <ElButton @click="emit('back')">
        取消
      </ElButton>
      <ElButton type="primary" :loading="loading" @click="handleSave">
        保存并使用
      </ElButton>
    </div>
  </div>
</template>

<style scoped>
.i18n-edit-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
}
.i18n-edit-panel__header {
  display: flex;
  align-items: center;
  padding: 12px 16px;
  border-bottom: 1px solid var(--el-border-color-light, #e4e7ed);
  gap: 8px;
}
.i18n-edit-panel__title {
  font-size: 16px;
  font-weight: 500;
}
.i18n-edit-panel__body {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
}
.i18n-edit-panel__footer {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  padding: 12px 16px;
  border-top: 1px solid var(--el-border-color-light, #e4e7ed);
}
</style>
