<script lang="ts">
/**
 * 国际化文案图标 — 用于 I18nFieldWrapper prefix 插槽
 */
export default {}
</script>

<script setup lang="ts">
defineOptions({ name: 'I18nIcon' })
withDefaults(defineProps<{
  size?: number
  color?: string
  disabled?: boolean
}>(), {
  size: 16,
  color: '#409eff',
  disabled: false,
})

const emit = defineEmits<{ click: [] }>()
</script>

<template>
  <span
    class="i18n-editor-icon"
    :class="{ 'is-disabled': disabled }"
    :style="{ cursor: disabled ? 'not-allowed' : 'pointer', color, lineHeight: 1, display: 'inline-flex', alignItems: 'center' }"
    @click.stop="!disabled && emit('click')"
  >
    <slot>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        :width="size"
        :height="size"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
      >
        <path d="M5 8l6 0" />
        <path d="M4 12l7 0" />
        <path d="M4 16l6 0" />
        <path d="M13 4l-1 16" />
        <path d="M16 4l4 12" />
        <path d="M15 13l5 0" />
      </svg>
    </slot>
  </span>
</template>
