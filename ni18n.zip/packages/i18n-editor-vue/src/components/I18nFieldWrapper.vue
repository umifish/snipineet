<script lang="ts">
/**
 * I18nFieldWrapper — 国际化文案选择器包裹组件
 *
 * 用 slot 包裹任意输入组件（如 ElInput），在 prefix/suffix 注入国际化图标和清除图标。
 * 点击国际化图标打开文案库弹窗，选择后将 key 写入 modelValue。
 *
 * 自动将 wrapper 上的额外属性（如 placeholder、type、rows）和 modelValue 注入到
 * 插槽内的子组件，无需手动绑定。
 *
 * 选中文案后自动更新三组数据：
 * - `v-model` — 当前语言的显示文案
 * - `v-model:i18n-code` — 国际化编码（如 @i18n.xxx.ccc）
 * - `v-model:translations` — 所有语言翻译 { 'zh-CN': '张三', 'en-US': 'Zhang San' }
 *
 * ```vue
 * <I18nFieldWrapper
 *   v-model="form.name"
 *   v-model:i18n-code="form.i18nCode.name"
 *   v-model:translations="form.i18n.name"
 *   locale="zh-CN"
 *   placeholder="请输入姓名"
 * >
 *   <ElInput />
 * </I18nFieldWrapper>
 * ```
 */
export default {
  inheritAttrs: false,
}
</script>

<script setup lang="ts">
import { ref, computed, watch, useAttrs, useSlots, cloneVNode, mergeProps as vueMergeProps, Fragment, Comment, Text, onMounted, onBeforeUnmount, type VNode } from 'vue'
import { I18nEditorCore, validateField, createDefaultPhraseApi, DEFAULT_LOCALES } from '@supernova/i18n-editor'
import type { PhraseEntry, I18nFieldRules, I18nFieldValue } from '@supernova/i18n-editor'
import I18nIcon from './I18nIcon.vue'
import ClearIcon from './ClearIcon.vue'
import PhraseDialog from './PhraseDialog.vue'

defineOptions({ name: 'I18nFieldWrapper' })

const props = withDefaults(defineProps<{
  /** 绑定值（当前语言的显示文案） */
  modelValue?: string
  /** 国际化编码（如 @i18n.common.name） */
  i18nCode?: string
  /** 所有语言翻译 { 'zh-CN': '张三', 'en-US': 'Zhang San' } */
  translations?: Record<string, string>
  /** 国际化编码前缀，默认 '@i18n.' */
  i18nPrefix?: string
  /** 编辑器核心实例（不传则使用内置默认实例） */
  editor?: I18nEditorCore
  /** 当前语言，用于回填翻译文案 */
  locale?: string
  /** 是否禁用 */
  disabled?: boolean
  /** 是否显示前缀国际化图标 */
  showPrefixIcon?: boolean
  /** 是否显示后缀清除图标 */
  showSuffixIcon?: boolean
  /** 前缀图标大小 */
  prefixIconSize?: number
  /** 前缀图标颜色 */
  prefixIconColor?: string
  /** 后缀图标大小 */
  suffixIconSize?: number
  /** 后缀图标颜色 */
  suffixIconColor?: string
  /** 按语言映射的校验规则 */
  rules?: I18nFieldRules
  /** 内部组件/表单自身的校验函数，返回错误消息或 null */
  innerValidator?: (value: string) => string | null | Promise<string | null>
}>(), {
  modelValue: '',
  i18nCode: '',
  i18nPrefix: '@i18n.',
  locale: '',
  disabled: false,
  showPrefixIcon: true,
  showSuffixIcon: true,
  prefixIconSize: 16,
  prefixIconColor: '#409eff',
  suffixIconSize: 14,
  suffixIconColor: '#c0c4cc',
})

const emit = defineEmits<{
  'update:modelValue': [val: string]
  'update:i18nCode': [val: string]
  'update:translations': [val: Record<string, string>]
  'select': [entry: PhraseEntry]
  'clear': []
}>()

// ─── 默认编辑器（懒初始化单例） ───

let _defaultEditor: I18nEditorCore | null = null

function getDefaultEditor(): I18nEditorCore {
  if (!_defaultEditor) {
    _defaultEditor = new I18nEditorCore({
      api: createDefaultPhraseApi(),
      locales: DEFAULT_LOCALES,
    })
  }
  return _defaultEditor
}

const resolvedEditor = computed(() => props.editor ?? getDefaultEditor())

/** 当前字段的完整国际化状态，传递给弹窗 */
const currentFieldValue = computed<I18nFieldValue>(() => ({
  displayText: props.modelValue,
  i18nCode: props.i18nCode,
  translations: props.translations,
}))

// ─── 自动注入 attrs + modelValue 到插槽子组件 ───

const attrs = useAttrs()
const slots = useSlots()

/** 渲染默认插槽 — 通过 cloneVNode 注入 attrs 和 modelValue，子组件自身 props 优先 */
const SlotRenderer = () => {
  const vnodes = slots.default?.()
  if (!vnodes?.length) return null

  const injectedProps: Record<string, any> = {
    ...attrs,
    modelValue: props.modelValue,
    'onUpdate:modelValue': (v: any) => {
      emit('update:modelValue', v)
      // value 更新时，将当前 locale 在 translations 中的对应项同步为 value
      if (props.locale != null && props.translations !== undefined) {
        emit('update:translations', { ...props.translations, [props.locale]: v })
      }
    },
  }

  // 递归寻找第一个真实的组件/元素节点并注入 props
  const injectPropsToFirstValidVNode = (nodes: VNode[]): VNode[] => {
    let hasInjected = false

    return nodes.map((vnode) => {
      if (hasInjected) return vnode

      if (vnode.type === Fragment && Array.isArray(vnode.children)) {
        return cloneVNode(vnode, {
          children: injectPropsToFirstValidVNode(vnode.children as VNode[])
        })
      }

      if (vnode.type === Comment || (vnode.type === Text && typeof vnode.children === 'string' && vnode.children.trim() === '')) {
        return vnode
      }

      if (typeof vnode.type === 'string' || typeof vnode.type === 'object' || typeof vnode.type === 'function') {
        hasInjected = true
        const merged = vueMergeProps(injectedProps, vnode.props || {})
        return cloneVNode(vnode, merged, true)
      }

      return vnode
    })
  }

  return injectPropsToFirstValidVNode(vnodes)
}

const dialogVisible = ref(false)
const contentRef = ref<HTMLElement>()
const isMultiline = ref(false)
const iconAlignPadding = ref('')
const hasInnerSuffix = ref(false)

function syncIconAlignment() {
  const el = contentRef.value
  if (!el) return
  const textarea = el.querySelector('textarea')
  if (textarea) {
    isMultiline.value = true
    iconAlignPadding.value = getComputedStyle(textarea).paddingTop
  } else {
    isMultiline.value = false
    iconAlignPadding.value = ''
  }

  hasInnerSuffix.value = !!el.querySelector('.el-input__suffix')
}

let observer: MutationObserver | null = null

onMounted(() => {
  syncIconAlignment()
  if (contentRef.value) {
    observer = new MutationObserver(syncIconAlignment)
    observer.observe(contentRef.value, { childList: true, subtree: true })
  }
})

onBeforeUnmount(() => {
  observer?.disconnect()
})

function openDialog() {
  if (props.disabled) return
  dialogVisible.value = true
}

function handleConfirm(entry: PhraseEntry) {
  const displayText = (props.locale && entry.translations[props.locale]) || entry.key
  emit('update:modelValue', displayText)
  emit('update:i18nCode', `${props.i18nPrefix}${entry.key}`)
  emit('update:translations', { ...entry.translations })
  emit('select', entry)
}

function handleClear() {
  emit('update:modelValue', '')
  emit('update:i18nCode', '')
  emit('update:translations', {})
  emit('clear')
}

// ─── 校验逻辑 ───
const error = ref<string | null>(null)

async function validate(): Promise<string | null> {
  if (props.innerValidator) {
    const innerMsg = await props.innerValidator(props.modelValue)
    if (innerMsg) {
      error.value = innerMsg
      return innerMsg
    }
  }

  if (!props.rules || !props.locale) {
    error.value = null
    return null
  }
  const msg = await validateField(props.modelValue, props.locale, props.rules)
  error.value = msg
  return msg
}

function clearValidate() {
  error.value = null
}

watch(() => [props.modelValue, props.locale], () => {
  if ((props.rules && props.locale) || props.innerValidator) {
    validate()
  }
})

defineExpose({ validate, clearValidate })
</script>

<template>
  <div class="i18n-field-wrapper-outer">
    <div class="i18n-field-wrapper" :class="{ 'is-disabled': disabled, 'is-multiline': isMultiline, 'is-error': !!error }">
    <!-- Prefix: 国际化图标 -->
    <span v-if="showPrefixIcon" class="i18n-field-wrapper__prefix" :style="isMultiline ? { paddingTop: iconAlignPadding } : undefined">
      <slot name="prefix-icon">
        <I18nIcon
          :size="prefixIconSize"
          :color="prefixIconColor"
          :disabled="disabled"
          @click="openDialog"
        />
      </slot>
    </span>

    <!-- 包裹的输入组件（自动注入 attrs + modelValue） -->
    <div ref="contentRef" class="i18n-field-wrapper__content">
      <SlotRenderer />
    </div>

    <!-- Suffix: 清除图标 -->
    <span
      v-if="showSuffixIcon"
      class="i18n-field-wrapper__suffix"
      :class="{ 'with-inner-suffix': hasInnerSuffix }"
      :style="isMultiline ? { paddingTop: iconAlignPadding } : undefined"
    >
      <slot name="suffix-icon">
        <ClearIcon
          :size="suffixIconSize"
          :color="suffixIconColor"
          :visible="!!modelValue"
          :disabled="disabled"
          @click="handleClear"
        />
      </slot>
    </span>

    <!-- 弹窗 -->
    <PhraseDialog
      v-model="dialogVisible"
      :editor="resolvedEditor"
      :locales="resolvedEditor.locales"
      :initial-value="currentFieldValue"
      @confirm="handleConfirm"
    />
  </div>
  <div v-if="error" class="i18n-field-wrapper__error">{{ error }}</div>
  </div>
</template>

<style scoped>
.i18n-field-wrapper-outer {
  width: 100%;
}
.i18n-field-wrapper {
  display: inline-flex;
  align-items: center;
  width: 100%;
  box-sizing: border-box;
  position: relative;
  border: 1px solid var(--el-border-color, #dcdfe6);
  border-radius: var(--el-border-radius-base, 4px);
  background: var(--el-fill-color-blank, #fff);
  transition: border-color 0.2s;
  padding: 0 8px;
}
.i18n-field-wrapper:hover {
  border-color: var(--el-border-color-hover, #c0c4cc);
}
.i18n-field-wrapper:focus-within {
  border-color: var(--el-color-primary, #409eff);
}
.i18n-field-wrapper.is-disabled {
  opacity: 0.6;
  cursor: not-allowed;
  background: var(--el-disabled-bg-color, #f5f7fa);
}
.i18n-field-wrapper__content {
  flex: 1;
  min-width: 0;
}
.i18n-field-wrapper__content :deep(.el-input__wrapper) {
  box-shadow: none !important;
  background: transparent !important;
  padding-left: 0;
  padding-right: 0;
}
.i18n-field-wrapper__content :deep(.el-textarea__inner) {
  box-shadow: none !important;
  background: transparent !important;
  padding-left: 0;
  padding-right: 0;
}
.i18n-field-wrapper.is-multiline {
  align-items: flex-start;
}
.i18n-field-wrapper__prefix,
.i18n-field-wrapper__suffix {
  flex-shrink: 0;
  display: inline-flex;
  align-items: center;
  line-height: 1;
}
.i18n-field-wrapper__prefix {
  margin-right: 4px;
}
.i18n-field-wrapper__suffix {
  margin-left: 4px;
}
.i18n-field-wrapper__suffix.with-inner-suffix {
  position: absolute;
  right: 28px;
}
.i18n-field-wrapper.is-error {
  border-color: var(--el-color-danger, #f56c6c);
}
.i18n-field-wrapper.is-error:hover,
.i18n-field-wrapper.is-error:focus-within {
  border-color: var(--el-color-danger, #f56c6c);
}
.i18n-field-wrapper__error {
  color: var(--el-color-danger, #f56c6c);
  font-size: 12px;
  line-height: 20px;
  margin-top: 2px;
}
</style>
