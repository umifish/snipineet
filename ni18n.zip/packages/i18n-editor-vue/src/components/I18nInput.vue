<script setup lang="ts">
import { computed } from 'vue'
import type { I18nEditorCore, PhraseEntry, I18nFieldRules } from '@supernova/i18n-editor'
import I18nFieldWrapper from './I18nFieldWrapper.vue'
import ElInput from 'element-plus/es/components/input/index.mjs'

const props = withDefaults(defineProps<{
  /** 绑定值（当前语言的显示文案） */
  modelValue?: string
  /** 国际化编码（如 @i18n.common.name） */
  i18nCode?: string
  /** 所有语言翻译 { 'zh-CN': '张三', 'en-US': 'Zhang San' } */
  translations?: Record<string, string>
  /** 当前语言，用于回填翻译文案 */
  locale?: string
  /** 文案库编辑器实例，不传则使用内置默认实例 */
  editor?: I18nEditorCore
  /** 是否禁用 */
  disabled?: boolean
  /** 多语言校验规则 */
  rules?: I18nFieldRules
  /** 内部组件/表单自身的校验函数，返回错误消息或 null */
  innerValidator?: (value: string) => string | null | Promise<string | null>
  /** 从文案库选中文案时回调 */
  onSelect?: (entry: PhraseEntry) => void
  /** 清除时回调 */
  onClear?: () => void
  /** 是否多行（渲染为 textarea） */
  multiline?: boolean
  /** 多行时 textarea 行数 */
  rows?: number
  /** 占位符 */
  placeholder?: string
  /** 是否显示前缀国际化图标 */
  showPrefixIcon?: boolean
  /** 是否显示后缀清除图标 */
  showSuffixIcon?: boolean
}>(), {
  modelValue: '',
  i18nCode: '',
  locale: '',
  disabled: false,
  multiline: false,
  rows: 4,
  showPrefixIcon: true,
  showSuffixIcon: true,
})

const emit = defineEmits<{
  'update:modelValue': [val: string]
  'update:i18nCode': [val: string]
  'update:translations': [val: Record<string, string>]
  'select': [entry: PhraseEntry]
  'clear': []
}>()

const inputType = computed(() => (props.multiline ? 'textarea' : 'text'))
</script>

<template>
  <I18nFieldWrapper
    :model-value="modelValue"
    :i18n-code="i18nCode"
    :translations="translations"
    :locale="locale"
    :editor="editor"
    :disabled="disabled"
    :rules="rules"
    :inner-validator="innerValidator"
    :show-prefix-icon="showPrefixIcon"
    :show-suffix-icon="showSuffixIcon"
    :placeholder="placeholder"
    @update:modelValue="val => emit('update:modelValue', val)"
    @update:i18nCode="val => emit('update:i18nCode', val)"
    @update:translations="val => emit('update:translations', val)"
    @select="entry => emit('select', entry)"
    @clear="() => emit('clear')"
  >
    <ElInput
      v-if="inputType === 'text'"
      :placeholder="placeholder"
    />
    <ElInput
      v-else
      type="textarea"
      :rows="rows"
      :placeholder="placeholder"
    />
  </I18nFieldWrapper>
</template>
