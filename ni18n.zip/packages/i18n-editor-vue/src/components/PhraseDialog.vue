<script lang="ts">
/**
 * 文案库弹窗 — 虚拟表格 + 分页加载 + 编辑面板
 */
export default {}
</script>

<script setup lang="ts">
import { ref, computed, watch, h, onBeforeUnmount } from 'vue'
import {
  ElDialog,
  ElButton,
  ElInput,
  ElCheckbox,
  ElCheckboxGroup,
  ElPopover,
  ElEmpty,
  ElAutoResizer,
  ElTableV2,
  ElMessageBox,
} from 'element-plus'
import type { Column } from 'element-plus'
import type { I18nEditorCore, EditorLocaleItem, PhraseEntry, I18nFieldValue } from '@supernova/i18n-editor'
import PhraseEditPanel from './PhraseEditPanel.vue'

defineOptions({ name: 'PhraseDialog' })

const props = defineProps<{
  modelValue: boolean
  editor: I18nEditorCore
  locales: EditorLocaleItem[]
  initialValue?: I18nFieldValue
}>()

const emit = defineEmits<{
  'update:modelValue': [val: boolean]
  'confirm': [entry: PhraseEntry]
}>()

const keyword = ref('')
const selectedLocaleCodes = ref<string[]>([])
const list = ref<PhraseEntry[]>([])
const total = ref(0)
const page = ref(1)
const loading = ref(false)
const hasMore = computed(() => list.value.length < total.value)

const selectedEntry = ref<PhraseEntry | null>(null)

const editMode = ref(false)
const editingEntry = ref<PhraseEntry | null>(null)
const saveLoading = ref(false)

async function doQuery(reset = false) {
  if (reset) {
    page.value = 1
    list.value = []
  }
  loading.value = true
  try {
    const result = await props.editor.query({
      keyword: keyword.value,
      page: page.value,
      pageSize: props.editor.pageSize,
    })
    if (reset) {
      list.value = result.list
    }
    else {
      list.value = [...list.value, ...result.list]
    }
    total.value = result.total
  }
  finally {
    loading.value = false
  }
}

function loadMore() {
  if (loading.value || !hasMore.value) return
  page.value++
  doQuery()
}

watch(() => props.modelValue, (val) => {
  if (val) {
    keyword.value = ''
    selectedLocaleCodes.value = props.locales.map(l => l.code)
    selectedEntry.value = null
    editMode.value = false
    doQuery(true).then(() => {
      if (props.initialValue?.i18nCode) {
        const key = props.initialValue.i18nCode.replace(/^@i18n\./, '')
        const match = list.value.find(item => item.key === key)
        if (match) selectedEntry.value = match
      }
    })
  }
})

let searchTimer: ReturnType<typeof setTimeout>

function onLocaleToggle(codes: string[]) {
  if (codes.length === 0) return
  selectedLocaleCodes.value = codes
}

function onSearchInput() {
  clearTimeout(searchTimer)
  searchTimer = setTimeout(() => doQuery(true), 300)
}

const ROW_HEIGHT = 40
const TABLE_HEIGHT = 360

const columns = computed<Column<any>[]>(() => {
  const cols: Column<any>[] = [
    {
      key: 'key',
      dataKey: 'key',
      title: 'Key',
      width: 180,
    },
    ...displayLocales.value.map(locale => ({
      key: locale.code,
      dataKey: locale.code,
      title: locale.label,
      width: 0,
      cellRenderer: ({ rowData }: { rowData: PhraseEntry }) =>
        h('span', { title: rowData.translations[locale.code] }, rowData.translations[locale.code] || '—'),
    })),
    {
      key: '_action',
      title: '操作',
      width: 120,
      cellRenderer: ({ rowData }: { rowData: PhraseEntry }) =>
        h('div', { style: 'display:flex;gap:4px' }, [
          h(ElButton, { text: true, size: 'small', type: 'primary', onClick: (e: Event) => { e.stopPropagation(); openEdit(rowData) } }, () => '编辑'),
          h(ElButton, { text: true, size: 'small', type: 'danger', onClick: (e: Event) => { e.stopPropagation(); handleDelete(rowData) } }, () => '删除'),
        ]),
    },
  ]
  return cols
})

const columnsWithWidth = computed(() => {
  const containerWidth = 752
  const fixedWidth = 180 + 120
  const flexCols = columns.value.filter(c => c.width === 0)
  const flexWidth = flexCols.length > 0 ? Math.floor((containerWidth - fixedWidth) / flexCols.length) : 150
  return columns.value.map(c => c.width === 0 ? { ...c, width: flexWidth } : c)
})

function rowClass({ rowData }: { rowData: PhraseEntry }) {
  return selectedEntry.value?.id === rowData.id ? 'i18n-row-selected' : ''
}

function onTableEndReached() {
  if (!loading.value && hasMore.value) {
    loadMore()
  }
}

onBeforeUnmount(() => {
  clearTimeout(searchTimer)
})

function selectRow(entry: PhraseEntry) {
  selectedEntry.value = entry
}

function handleConfirm() {
  if (selectedEntry.value) {
    emit('confirm', selectedEntry.value)
    emit('update:modelValue', false)
  }
}

function openEdit(entry: PhraseEntry) {
  editingEntry.value = entry
  editMode.value = true
}

function openCreate() {
  editingEntry.value = null
  editMode.value = true
}

async function handleSave(data: { key: string; translations: Record<string, string> }) {
  saveLoading.value = true
  try {
    let saved: PhraseEntry
    if (editingEntry.value) {
      saved = await props.editor.update({
        id: editingEntry.value.id,
        key: data.key,
        translations: data.translations,
      })
    }
    else {
      saved = await props.editor.create({
        key: data.key,
        translations: data.translations,
      })
    }
    emit('confirm', saved)
    emit('update:modelValue', false)
  }
  finally {
    saveLoading.value = false
  }
}

async function handleDelete(entry: PhraseEntry) {
  try {
    await ElMessageBox.confirm(`确认删除 "${entry.key}" 吗？`, '删除确认', {
      confirmButtonText: '删除',
      cancelButtonText: '取消',
      type: 'warning',
    })
  }
  catch {
    return
  }
  await props.editor.remove(entry.id)
  doQuery(true)
}

function handleClose() {
  emit('update:modelValue', false)
}

const displayLocales = computed(() => {
  if (selectedLocaleCodes.value.length > 0 && selectedLocaleCodes.value.length < props.locales.length) {
    return props.locales.filter(l => selectedLocaleCodes.value.includes(l.code))
  }
  return props.locales
})
</script>

<template>
  <ElDialog
    :model-value="modelValue"
    title="多语言文案库"
    width="800px"
    :close-on-click-modal="false"
    destroy-on-close
    @update:model-value="handleClose"
  >
    <div class="i18n-dialog-container" :class="{ 'show-edit': editMode }">
      <div class="i18n-dialog-list">
        <div class="i18n-dialog-toolbar">
          <ElInput
            v-model="keyword"
            placeholder="搜索 Key 或翻译内容"
            clearable
            style="flex: 1;"
            @input="onSearchInput"
            @clear="doQuery(true)"
          />
          <ElPopover
            trigger="click"
            placement="bottom-start"
            :width="180"
          >
            <template #reference>
              <ElButton :icon="undefined" style="padding: 8px;">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M4 5h7" />
                  <path d="M9 3v2c0 4.418-2.239 8-5 8" />
                  <path d="M5 9c0 2.144 2.952 3.908 6.7 4" />
                  <path d="M12 20l4-9 4 9" />
                  <path d="M19.1 18h-6.2" />
                </svg>
              </ElButton>
            </template>
            <ElCheckboxGroup
              :model-value="selectedLocaleCodes"
              style="display: flex; flex-direction: column; gap: 8px;"
              @update:model-value="onLocaleToggle"
            >
              <ElCheckbox
                v-for="locale in locales"
                :key="locale.code"
                :label="locale.label"
                :value="locale.code"
              />
            </ElCheckboxGroup>
          </ElPopover>
          <ElButton type="primary" @click="openCreate">
            添加文案
          </ElButton>
        </div>

        <div v-if="list.length" class="i18n-table-v2-wrap">
          <ElAutoResizer>
            <template #default="{ width }">
              <ElTableV2
                :columns="columnsWithWidth"
                :data="list"
                :width="width"
                :height="TABLE_HEIGHT"
                :row-height="ROW_HEIGHT"
                :header-height="ROW_HEIGHT"
                :row-class="rowClass"
                :row-event-handlers="{ onClick: (e: { rowData: PhraseEntry }) => selectRow(e.rowData) }"
                @end-reached="onTableEndReached"
                fixed
              />
            </template>
          </ElAutoResizer>
          <div v-if="loading" class="i18n-table-loading">加载中...</div>
          <div v-if="!hasMore && list.length" class="i18n-table-end">—— 已加载全部 ——</div>
        </div>
        <ElEmpty v-else-if="!loading" description="暂无数据" />
        <div v-else class="i18n-table-loading">加载中...</div>
      </div>

      <div class="i18n-dialog-edit">
        <PhraseEditPanel
          v-if="editMode"
          :entry="editingEntry"
          :locales="locales"
          :loading="saveLoading"
          @back="editMode = false"
          @save="handleSave"
        />
      </div>
    </div>

    <template #footer>
      <template v-if="!editMode">
        <ElButton @click="handleClose">
          取消
        </ElButton>
        <ElButton type="primary" :disabled="!selectedEntry" @click="handleConfirm">
          确认
        </ElButton>
      </template>
    </template>
  </ElDialog>
</template>

<style scoped>
.i18n-dialog-container {
  position: relative;
  overflow: hidden;
  min-height: 400px;
}
.i18n-dialog-list,
.i18n-dialog-edit {
  position: absolute;
  inset: 0;
  transition: transform 0.3s ease;
}
.i18n-dialog-list {
  display: flex;
  flex-direction: column;
  transform: translateX(0);
}
.i18n-dialog-edit {
  transform: translateX(100%);
}
.i18n-dialog-container.show-edit .i18n-dialog-list {
  transform: translateX(-100%);
}
.i18n-dialog-container.show-edit .i18n-dialog-edit {
  transform: translateX(0);
}

.i18n-dialog-toolbar {
  display: flex;
  gap: 8px;
  padding-bottom: 12px;
}

.i18n-table-v2-wrap {
  flex: 1;
  min-height: 360px;
}
.i18n-table-v2-wrap :deep(.el-table-v2__row) {
  cursor: pointer;
}
.i18n-table-v2-wrap :deep(.i18n-row-selected) {
  background: var(--el-color-primary-light-9, #ecf5ff) !important;
}
.i18n-table-v2-wrap :deep(.i18n-row-selected:hover) {
  background: var(--el-color-primary-light-8, #d9ecff) !important;
}

.i18n-table-loading,
.i18n-table-end {
  text-align: center;
  padding: 12px;
  color: var(--el-text-color-secondary, #909399);
  font-size: 13px;
}
</style>
