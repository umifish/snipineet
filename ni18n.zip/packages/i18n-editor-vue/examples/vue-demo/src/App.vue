<script setup lang="ts">
import { ref, reactive } from 'vue'
import { ElInput, ElButton, ElCard, ElDivider, ElMessage } from 'element-plus'
import { I18nEditorCore, I18nFieldWrapper, I18nInput, PhraseDialog, createDefaultPhraseApi } from '@supernova/i18n-editor-vue'
import type { PhraseEntry, PhraseApiAdapter, I18nFieldValue, I18nFieldRules } from '@supernova/i18n-editor-vue'

const customApi: PhraseApiAdapter = {
  async query(params) {
    const qs = new URLSearchParams({
      keyword: params.keyword ?? '',
      page: String(params.page ?? 1),
      pageSize: String(params.pageSize ?? 20),
    })
    const res = await fetch(`/api/phrases?${qs}`)
    return res.json()
  },
  async create(params) {
    const res = await fetch('/api/phrases/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    })
    return res.json()
  },
  async update(params) {
    const res = await fetch('/api/phrases/update', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    })
    return res.json()
  },
  async remove(id) {
    await fetch(`/api/phrases/delete?id=${encodeURIComponent(id)}`, { method: 'DELETE' })
  },
}

const customEditor = new I18nEditorCore({
  api: customApi,
  locales: [
    { code: 'zh-CN', label: '中文' },
    { code: 'en-US', label: 'English' },
    { code: 'ja-JP', label: '日本語' },
  ],
  pageSize: 10,
})

const form = reactive({
  name: '',
  desc: '',
  i18nCode: { name: '', desc: '' } as Record<string, string>,
  i18n: {} as Record<string, Record<string, string>>,
})

const i18nInputForm = reactive({
  value: '',
  i18nCode: '',
  i18n: {} as Record<string, string>,
})

const lastNameInput = ref('')

function onTitleSelect(entry: PhraseEntry) {
  ElMessage.success(`选中: ${entry.key}`)
}

function onTitleClear() {}

function onTitleInput(val: string) {
  ElMessage.success(`输入值: ${val}`)
  lastNameInput.value = val
}

function onTitleChange(val: string) {
  ElMessage.success(`改变值: ${val}`)
  lastNameInput.value = val
}

function onDescSelect(entry: PhraseEntry) {
  ElMessage.success(`选中: ${entry.key}`)
}

function onDescClear() {}

const dialogVisible = ref(false)
const dialogResult = ref<PhraseEntry | null>(null)
const dialogI18n = reactive<I18nFieldValue>({
  displayText: '',
  i18nCode: '',
  translations: {},
})

function onDialogConfirm(entry: PhraseEntry) {
  dialogResult.value = entry
  dialogI18n.displayText = entry.translations['zh-CN'] || entry.key
  dialogI18n.i18nCode = `@i18n.${entry.key}`
  dialogI18n.translations = { ...entry.translations }
  ElMessage.success(`选中: ${entry.key}`)
}

const validateWrapperRef = ref<any>(null)
const validateForm = reactive({
  title: '',
  i18nCode: '',
  i18n: {} as Record<string, string>,
})

const validationRules: I18nFieldRules = {
  '*': [
    {
      required: true,
      message: '多语言必填（任意语言都需要填写）',
    },
  ],
  'en-US': [
    {
      min: 3,
      message: '英文至少 3 个字符',
    },
  ],
}

function innerLengthValidator(value: string): string | null {
  if (!value) return null
  if (value.length > 10) {
    return '内部校验：长度不能超过 10 个字符'
  }
  return null
}

async function handleValidateClick() {
  const msg = await validateWrapperRef.value?.validate?.()
  if (!msg) {
    ElMessage.success('校验通过')
  }
}

function handleClearValidate() {
  validateWrapperRef.value?.clearValidate?.()
}
</script>

<template>
  <div style="max-width: 800px; margin: 40px auto; padding: 0 20px;">
    <h1 style="margin-bottom: 8px;">🌐 i18n-editor-vue Demo</h1>
    <p style="color: #909399; margin-bottom: 32px;">
      国际化文案编辑器 — Vue3 + Element Plus 组件演示
    </p>

    <ElCard shadow="hover" style="margin-bottom: 24px;">
      <template #header>
        <strong>示例 1：简洁用法 — 完整国际化数据</strong>
      </template>

      <p style="color: #606266; margin-bottom: 16px;">
        选中文案后自动更新三组数据：显示值、i18nCode、全语言翻译。
      </p>

      <I18nFieldWrapper
        v-model="form.name"
        v-model:i18n-code="form.i18nCode.name"
        v-model:translations="form.i18n.name"
        locale="zh-CN"
        placeholder="请输入姓名（点击左侧图标选择文案）"
        @select="onTitleSelect"
        @clear="onTitleClear"
      >
        <ElInput @input="onTitleInput" @change="onTitleChange" />
      </I18nFieldWrapper>

      <ElDivider />

      <div style="font-size: 13px; color: #909399;">
        <p><strong>显示值：</strong> {{ form.name || '（空）' }}</p>
        <p><strong>i18nCode：</strong> {{ form.i18nCode.name || '（空）' }}</p>
        <p><strong>当前 locale 对应词条（随 value 同步）：</strong><code>translations["zh-CN"]</code> = {{ form.i18n.name?.['zh-CN'] ?? '（空）' }}</p>
        <p><strong>最近 input 事件值（通过包裹组件监听）：</strong> {{ lastNameInput || '（空）' }}</p>
        <p><strong>最近 change 事件值（通过包裹组件监听）：</strong> {{ lastNameInput || '（空）' }}</p>
        <template v-if="form.i18n.name">
          <p><strong>全量翻译：</strong></p>
          <ul style="margin: 4px 0 0 20px;">
            <li v-for="(val, code) in form.i18n.name" :key="code">
              {{ code }}: {{ val }}
            </li>
          </ul>
        </template>
      </div>
    </ElCard>

    <ElCard shadow="hover" style="margin-bottom: 24px;">
      <template #header>
        <strong>示例 1b：使用 I18nInput 组件</strong>
      </template>

      <p style="color: #606266; margin-bottom: 16px;">
        使用包内导出的 <code>I18nInput</code>，内置 <code>I18nFieldWrapper</code> + <code>ElInput</code>
      </p>

      <I18nInput
        v-model="i18nInputForm.value"
        v-model:i18n-code="i18nInputForm.i18nCode"
        v-model:translations="i18nInputForm.i18n"
        locale="zh-CN"
        placeholder="请输入姓名（使用 I18nInput 组件）"
      />

      <ElDivider />

      <div style="font-size: 13px; color: #909399;">
        <p><strong>显示值：</strong> {{ i18nInputForm.value || '（空）' }}</p>
        <p><strong>i18nCode：</strong> {{ i18nInputForm.i18nCode || '（空）' }}</p>
        <p><strong>当前 locale 对应词条（随 value 同步）：</strong><code>translations["zh-CN"]</code> = {{ i18nInputForm.i18n?.['zh-CN'] ?? '（空）' }}</p>
        <template v-if="Object.keys(i18nInputForm.i18n).length">
          <p><strong>全量翻译：</strong></p>
          <ul style="margin: 4px 0 0 20px;">
            <li v-for="(val, code) in i18nInputForm.i18n" :key="code">
              {{ code }}: {{ val }}
            </li>
          </ul>
        </template>
      </div>
    </ElCard>

    <ElCard shadow="hover" style="margin-bottom: 24px;">
      <template #header>
        <strong>示例 2：自定义 Editor + Textarea</strong>
      </template>

      <p style="color: #606266; margin-bottom: 16px;">
        手动传入自定义 <code>editor</code>，多行文本场景，同样支持完整国际化数据。
      </p>

      <I18nFieldWrapper
        v-model="form.desc"
        v-model:i18n-code="form.i18nCode.desc"
        v-model:translations="form.i18n.desc"
        :editor="customEditor"
        locale="zh-CN"
        @select="onDescSelect"
        @clear="onDescClear"
      >
        <ElInput
          type="textarea"
          :rows="4"
          placeholder="请输入描述（点击左侧图标选择文案）"
        />
      </I18nFieldWrapper>

      <ElDivider />

      <div style="font-size: 13px; color: #909399;">
        <p><strong>显示值：</strong> {{ form.desc || '（空）' }}</p>
        <p><strong>i18nCode：</strong> {{ form.i18nCode.desc || '（空）' }}</p>
        <p><strong>当前 locale 对应词条（随 value 同步）：</strong><code>translations["zh-CN"]</code> = {{ form.i18n.desc?.['zh-CN'] ?? '（空）' }}</p>
        <template v-if="form.i18n.desc">
          <p><strong>全量翻译：</strong></p>
          <ul style="margin: 4px 0 0 20px;">
            <li v-for="(val, code) in form.i18n.desc" :key="code">
              {{ code }}: {{ val }}
            </li>
          </ul>
        </template>
      </div>
    </ElCard>

    <ElCard shadow="hover">
      <template #header>
        <strong>示例 3：单独使用 PhraseDialog</strong>
      </template>

      <p style="color: #606266; margin-bottom: 16px;">
        通过按钮手动打开文案库弹窗，支持搜索、语言筛选、分页加载、编辑/新增/删除。
      </p>

      <ElButton type="primary" @click="dialogVisible = true">
        打开文案库
      </ElButton>

      <PhraseDialog
        v-model="dialogVisible"
        :editor="customEditor"
        :locales="customEditor.locales"
        :initial-value="dialogI18n"
        @confirm="onDialogConfirm"
      />

      <template v-if="dialogResult">
        <ElDivider />
        <div style="font-size: 13px; color: #909399;">
          <p><strong>显示值：</strong> {{ dialogI18n.displayText }}</p>
          <p><strong>i18nCode：</strong> {{ dialogI18n.i18nCode }}</p>
          <template v-if="dialogI18n.translations">
            <p><strong>翻译：</strong></p>
            <ul style="margin: 4px 0 0 20px;">
              <li v-for="(val, code) in dialogI18n.translations" :key="code">
                {{ code }}: {{ val }}
              </li>
            </ul>
          </template>
        </div>
      </template>
    </ElCard>

    <ElCard shadow="hover" style="margin-top: 24px;">
      <template #header>
        <strong>示例 4：多语言规则 + innerValidator 组合校验</strong>
      </template>

      <p style="color: #606266; margin-bottom: 16px;">
        同时使用内部组件/表单的 <code>innerValidator</code> 和 i18n 多语言规则：
        先跑内部校验（长度限制），再跑英文最少 3 个字符的规则。
      </p>

      <I18nFieldWrapper
        ref="validateWrapperRef"
        v-model="validateForm.title"
        v-model:i18n-code="validateForm.i18nCode"
        v-model:translations="validateForm.i18n"
        locale="en-US"
        :rules="validationRules"
        :inner-validator="innerLengthValidator"
        placeholder="请输入英文标题（内外校验组合示例）"
      >
        <ElInput />
      </I18nFieldWrapper>

      <div style="margin-top: 12px; display: flex; gap: 8px;">
        <ElButton size="small" type="primary" @click="handleValidateClick">
          手动触发校验
        </ElButton>
        <ElButton size="small" @click="handleClearValidate">
          清除错误
        </ElButton>
      </div>

      <ElDivider />

      <div style="font-size: 13px; color: #909399;">
        <p><strong>显示值：</strong> {{ validateForm.title || '（空）' }}</p>
        <p><strong>i18nCode：</strong> {{ validateForm.i18nCode || '（空）' }}</p>
        <p><strong>当前 locale 对应词条（随 value 同步）：</strong><code>translations["en-US"]</code> = {{ validateForm.i18n?.['en-US'] ?? '（空）' }}</p>
        <template v-if="validateForm.i18n">
          <p><strong>全量翻译：</strong></p>
          <ul style="margin: 4px 0 0 20px;">
            <li v-for="(val, code) in validateForm.i18n" :key="code">
              {{ code }}: {{ val }}
            </li>
          </ul>
        </template>
      </div>
    </ElCard>

    <ElCard shadow="hover" style="margin-top: 24px;">
      <template #header>
        <strong>表单完整数据（实时）</strong>
      </template>
      <pre style="font-size: 13px; background: #f5f7fa; padding: 16px; border-radius: 4px; overflow: auto;">{{ JSON.stringify(form, null, 2) }}</pre>
    </ElCard>
  </div>
</template>
