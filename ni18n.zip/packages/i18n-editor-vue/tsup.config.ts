import { defineConfig } from 'tsup'
import vue from 'esbuild-plugin-vue3'

export default defineConfig({
  entry: { index: 'src/index.ts' },
  format: ['esm', 'cjs'],
  outExtension: ({ format }) => ({ js: format === 'esm' ? '.mjs' : '.cjs' }),
  dts: false,
  treeshake: true,
  splitting: false,
  external: ['vue', 'element-plus', '@supernova/i18n-editor'],
  esbuildPlugins: [vue()],
})
