# @supernova/i18n-sdk

国际化多语言 SDK，采用**三层架构**设计，支持作为独立 SDK 分别使用。

## 架构

```
@supernova/i18n-sdk          ← Core (通用内核，框架无关)
@supernova/i18n-sdk/vue      ← Vue3 集成 (vue-i18n)
@supernova/i18n-sdk/react    ← React18+ 集成 (react-i18next)
```

## 核心特性

| 特性 | 说明 |
|------|------|
| **API 驱动** | 语言列表、语言包、用户偏好均通过接口获取，支持 `baseURL` 统一配置 |
| **按需加载** | 命名空间级别懒加载，首屏只加载 `common` |
| **多级缓存** | Memory / LocalStorage / IndexedDB，localStorage 和 indexedDB 自动开启双层缓存（内存 L1 + 持久化 L2） |
| **语言检测** | 优先级：用户个人信息 > URL `lang` 参数 > 缓存 > 浏览器语言 |
| **语言规范化** | 自动标准化为 BCP 47 格式（`zh_cn` → `zh-CN`，`en` → `en-US`） |
| **请求拦截** | 自动向 Fetch/XHR 注入 `X-Lang`、`X-Timezone` 及自定义请求头 |
| **语言切换回滚** | 新语言加载失败自动保持当前语言 |
| **跨标签页同步** | BroadcastChannel 自动同步语言切换 |
| **生命周期钩子** | 全部支持 async，`before*` 钩子返回 `false` 可取消操作 |
| **事件系统** | `localeChange` / `namespaceLoaded` / `error` |
| **网络重试** | 可配置重试次数（默认 2 次） |
| **集中配置** | 所有默认值通过 `I18N_DEFAULTS` 集中管理 |

## 安装

```bash
pnpm add @supernova/i18n-sdk
```

根据使用的框架，安装对应的 peer dependency：

```bash
# Vue3
pnpm add vue-i18n

# React18+
pnpm add i18next react-i18next
```

## 使用方式

### 1. 仅使用 Core（框架无关）

```ts
import { I18nCore } from '@supernova/i18n-sdk'

const core = new I18nCore({
  defaultLocale: 'zh-CN',
  fallbackLocale: 'en-US',
  baseURL: '/api',
  endpoints: {
    list: '/locales',
    message: (locale, ns) => `/messages/${locale}/${ns}`,
    userInfo: '/user/profile',
  },
  storage: { type: 'localStorage', keyPrefix: 'app_i18n', maxAge: 3600000 },
  interceptor: { enabled: true },
})

await core.init()

// 语言切换
await core.switchLocale('en-US')

// 按需加载命名空间
await core.loadNamespace('en-US', 'dashboard')

// 自定义请求头
core.setHeader('Authorization', 'Bearer token')
core.setHeaders({ 'X-Tenant-Id': '12345' })
core.removeHeader('Authorization')

// 事件监听
const off = core.on('localeChange', ({ locale, previous }) => {
  console.log(`${previous} → ${locale}`)
})
off() // 取消监听

// 销毁
core.destroy()
```

### 2. Vue3

```ts
// main.ts
import { createApp } from 'vue'
import { createI18n } from '@supernova/i18n-sdk/vue'
import App from './App.vue'

async function bootstrap() {
  const app = createApp(App)

  const i18n = createI18n({
    defaultLocale: 'zh-CN',
    fallbackLocale: 'en-US',
    baseURL: '/api',
    endpoints: {
      list: '/locales',
      message: (locale, ns) => `/messages/${locale}/${ns}`,
      userInfo: '/user/profile',
    },
    storage: { type: 'localStorage', keyPrefix: 'app_i18n', maxAge: 3600000 },
    interceptor: { enabled: true },
  })

  await i18n.install(app)
  app.mount('#app')
}

bootstrap()
```

```vue
<!-- 组件中使用 -->
<script setup>
import { useTranslation, useLocale, useI18nManager, useI18nNamespace } from '@supernova/i18n-sdk/vue'

// 翻译函数（封装 vue-i18n 的 useI18n）
const { t } = useTranslation()

// 响应式当前语言 + 切换方法
const { locale, switchLocale } = useLocale()

// 管理器实例（访问 core、supportedLocales 等）
const manager = useI18nManager()

// 按需加载命名空间
const { ready } = useI18nNamespace('dashboard')
</script>

<template>
  <div v-if="ready">{{ t('hello') }}</div>
</template>
```

### 3. React18+

```tsx
// main.tsx
import { createRoot } from 'react-dom/client'
import { createI18n, I18nProvider } from '@supernova/i18n-sdk/react'
import App from './App'

async function bootstrap() {
  const manager = createI18n({
    defaultLocale: 'zh-CN',
    fallbackLocale: 'en-US',
    baseURL: '/api',
    endpoints: {
      list: '/locales',
      message: (locale, ns) => `/messages/${locale}/${ns}`,
      userInfo: '/user/profile',
    },
    storage: { type: 'localStorage', keyPrefix: 'app_i18n', maxAge: 3600000 },
    interceptor: { enabled: true },
  })

  await manager.init()

  createRoot(document.getElementById('root')!).render(
    <I18nProvider manager={manager}>
      <App />
    </I18nProvider>
  )
}

bootstrap()
```

```tsx
// 组件中使用
import { useTranslation, useLocale, useI18nManager, useI18nNamespace } from '@supernova/i18n-sdk/react'

function Dashboard() {
  const { t } = useTranslation()
  const { locale, switchLocale } = useLocale()
  const manager = useI18nManager()
  const { ready } = useI18nNamespace('dashboard')

  if (!ready) return <div>Loading...</div>

  return (
    <div>
      <h1>{t('hello')}</h1>
      <p>当前语言: {locale}</p>
      <button onClick={() => switchLocale('en-US')}>English</button>
    </div>
  )
}
```

## 配置参考

```ts
interface I18nCoreConfig {
  /** 默认语言 */
  defaultLocale: string
  /** 回退语言 */
  fallbackLocale: string
  /** 接口基础地址，所有 endpoints 中的相对路径会自动拼接此前缀 */
  baseURL?: string
  /** 接口端点 */
  endpoints: {
    /** 语言列表接口 URL */
    list: string
    /** 语言包接口（根据 locale + namespace 返回 URL） */
    message: (locale: string, ns: string) => string
    /** 用户信息接口 URL（用于读取用户偏好语言） */
    userInfo?: string
  }
  /** 语言管理配置 */
  locale?: {
    /** 支持的语言列表，未配置则使用默认 ['zh-CN', 'en', 'ko'] + 浏览器语言 */
    supported?: string[]
    /** 语言列表接口适配器 */
    adapter?: (data: any) => LocaleInfo[]
    /** 从 LocaleInfo[] 提取默认语言 */
    resolveDefault?: (locales: LocaleInfo[]) => string | undefined
  }
  /** 缓存配置 */
  storage: {
    type?: 'memory' | 'localStorage' | 'indexedDB'  // 默认 'memory'
    keyPrefix: string
    maxAge: number
  }
  /** 数据适配器 */
  adapters?: {
    /** 语言包数据适配 */
    message?: (data: any) => Record<string, any>
    /** 用户信息数据适配（提取用户偏好语言） */
    userInfo?: (data: any) => string | undefined
  }
  /** 默认命名空间（默认 'common'） */
  defaultNamespace?: string
  /** 网络请求重试次数（默认 2） */
  retries?: number
  /** 是否启用跨标签页同步（默认 true） */
  enableSync?: boolean
  /** 请求拦截器配置 */
  interceptor?: {
    enabled?: boolean     // 默认 true
    rules?: Array<string | RegExp | ((url: string) => boolean)>
    negate?: boolean      // true = 排除模式
    langHeader?: string   // 默认 'X-Lang'
    timezoneHeader?: string // 默认 'X-Timezone'
  }
}
```

## 生命周期钩子

所有钩子均支持 `async`，`before*` 钩子返回 `false` 可取消对应操作。

```ts
interface I18nHooks {
  // 语言列表
  beforeFetchLocales?: (url: string) => HookResult
  afterFetchLocales?: (locales: string[], defaultLocale?: string) => void | Promise<void>

  // 加载文案
  beforeLoad?: (locale: string, ns: string) => HookResult
  beforeFetchMessages?: (locale: string, ns: string, url: string) => HookResult
  afterFetchMessages?: (locale: string, ns: string, messages: MessageResource) => void | Promise<void>
  afterLoad?: (locale: string, ns: string) => void | Promise<void>
  onLoadError?: (error: unknown, locale: string, ns: string) => void | Promise<void>

  // 语言切换
  beforeSwitch?: (oldLocale: string, newLocale: string) => HookResult
  afterSwitch?: (locale: string) => void | Promise<void>
}
```

使用示例：

```ts
// Vue
await i18n.install(app, {
  hooks: {
    beforeSwitch: (old, next) => {
      console.log(`即将从 ${old} 切换到 ${next}`)
      // 返回 false 可取消切换
    },
    afterFetchMessages: (locale, ns, msgs) => {
      console.log(`已加载 ${locale}/${ns}，共 ${Object.keys(msgs).length} 条`)
    },
  },
})

// React
await manager.init({
  beforeFetchLocales: (url) => {
    console.log('正在请求语言列表:', url)
  },
})
```

## 语言规范化

SDK 自带 BCP 47 语言代码规范化，所有输入/输出自动标准化：

```ts
import { normalizeLocale, isStandardLocale } from '@supernova/i18n-sdk'

normalizeLocale('zh_CN')    // → 'zh-CN'
normalizeLocale('en_us')    // → 'en-US'
normalizeLocale('ZH-cn')    // → 'zh-CN'
normalizeLocale('zh')       // → 'zh-CN' (自动补全地区)
normalizeLocale('en')       // → 'en-US'
normalizeLocale('zh-Hans')  // → 'zh-Hans' (4字母 script 码保持 Titlecase)

isStandardLocale('zh-CN')   // → true
isStandardLocale('zh_cn')   // → false
```

## Demo

项目内置了可直接运行的 Vue 和 React 示例应用：

```bash
# Vue Demo
cd examples/vue-demo
pnpm install
pnpm dev

# React Demo
cd examples/react-demo
pnpm install
pnpm dev
```

Demo 内置 Mock API 插件，无需后端服务即可运行，支持中/英/韩三语切换。

## API 导出一览

### `@supernova/i18n-sdk` (Core)

| 导出 | 类型 | 说明 |
|------|------|------|
| `I18nCore` | class | 框架无关核心引擎 |
| `CacheAdapter` | class | 缓存适配器（Memory + L2 持久化） |
| `RequestInterceptor` | class | 请求拦截器 |
| `LocaleManager` | class | 语言管理器 |
| `I18N_DEFAULTS` | object | 集中管理的默认配置值 |
| `resolveConfig` | function | 合并用户配置与默认值 |
| `normalizeLocale` | function | BCP 47 语言代码规范化 |
| `isStandardLocale` | function | 检测语言代码是否标准 |

### `@supernova/i18n-sdk/vue`

| 导出 | 类型 | 说明 |
|------|------|------|
| `createI18n` | function | 创建 Vue i18n 实例（Vue 插件） |
| `useTranslation` | composable | 获取翻译函数 `t`（封装 vue-i18n） |
| `useLocale` | composable | 响应式当前语言 + `switchLocale` |
| `useI18nManager` | composable | 获取 Manager 实例 |
| `useI18nNamespace` | composable | 按需加载命名空间 |

### `@supernova/i18n-sdk/react`

| 导出 | 类型 | 说明 |
|------|------|------|
| `createI18n` | function | 创建 React i18n 管理器 |
| `I18nProvider` | component | Provider 组件 |
| `useTranslation` | hook | 获取翻译函数 `t`（re-export react-i18next） |
| `useLocale` | hook | 当前语言 + `switchLocale` |
| `useI18nManager` | hook | 获取 Manager 实例 |
| `useI18nNamespace` | hook | 按需加载命名空间 |

> Vue 和 React 入口均 re-export 了核心工具（`I18nCore`、`I18N_DEFAULTS`、`normalizeLocale` 等），使用时无需额外导入 Core。
