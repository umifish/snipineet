import { resolve } from 'path'
import { defineConfig } from 'vite'
import dts from 'vite-plugin-dts'

// shim for __dirname in ESM
// eslint-disable-next-line n/no-unsupported-features/node-builtins
const __dirname = new URL('.', import.meta.url).pathname

// Vite library build for @supernova/i18n-sdk (core only)
export default defineConfig({
  resolve: {
    alias: {
      '@': resolve(__dirname, '../../src'),
    },
  },
  build: {
    lib: {
      entry: {
        'core/index': resolve(__dirname, 'src/core/index.ts'),
      },
      formats: ['es', 'cjs'],
      fileName: (format, entryName) => {
        const ext = format === 'es' ? '.mjs' : '.cjs'
        return `${entryName}${ext}`
      },
    },
    rollupOptions: {
      external: ['axios'],
    },
    sourcemap: true,
  },
  plugins: [
    dts({
      entryRoot: 'src',
      outDir: 'dist',
      tsconfigPath: 'tsconfig.json',
      rollupTypes: true,
    }),
  ],
})

