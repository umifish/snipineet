export { I18nCore } from './I18nCore'
export { CacheAdapter, IndexedDBProvider, LocalStorageProvider, MemoryStorage } from './storage/index'
export { RequestInterceptor } from './interceptor'
export { LocaleManager, isStandardLocale, normalizeLocale } from './locale-manager'
export { I18N_DEFAULTS, resolveConfig } from './defaults'
export type { I18nResolvedConfig } from './defaults'
export type { InterceptorConfig, InterceptorRule } from './interceptor'
export type { LocaleInfo, LocaleManagerConfig } from './locale-manager'
export type {
  I18nCoreConfig,
  I18nEventListener,
  I18nEventMap,
  I18nEventType,
  I18nHooks,
  IStorage,
  MessageResource,
  StorageType,
} from './types'
