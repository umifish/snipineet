import type { IStorage, StorageType } from '../types'
import { I18N_DEFAULTS } from '../defaults'
import { IndexedDBProvider } from './IndexedDBProvider'
import { LocalStorageProvider } from './LocalStorageProvider'
import { MemoryStorage } from './MemoryStorage'

/**
 * 缓存适配器 — 对外统一操作接口，抹平不同缓存类型差异
 *
 * 策略：
 * - `memory`：纯内存缓存，页面刷新即丢失
 * - `localStorage`：内存 L1 + LocalStorage L2 双层缓存
 * - `indexedDB`：内存 L1 + IndexedDB L2 双层缓存
 *
 * localStorage / indexedDB 模式下：
 *   读：先查内存，未命中再查持久化层（命中后回填内存）
 *   写：同时写入内存和持久化层
 */
export class CacheAdapter implements IStorage {
  private _type: StorageType
  private _memory: MemoryStorage
  private _persist: IStorage | null

  constructor(type: StorageType = 'memory') {
    this._type = type
    this._memory = new MemoryStorage()

    switch (type) {
      case 'localStorage':
        this._persist = new LocalStorageProvider()
        break
      case 'indexedDB':
        this._persist = new IndexedDBProvider()
        break
      default:
        this._persist = null
    }
  }

  /** 当前缓存类型 */
  get type(): StorageType {
    return this._type
  }

  async get(key: string): Promise<any> {
    if (this._persist) {
      // L1: 内存
      const memValue = await this._memory.get(key)
      if (memValue !== null)
        return memValue

      // L2: 持久化层 → 命中后回填内存（使用会话级 TTL，重启后重新从 L2 读取）
      const persistValue = await this._persist.get(key)
      if (persistValue !== null)
        await this._memory.set(key, persistValue, I18N_DEFAULTS.sessionCacheTTL)
      return persistValue
    }

    // memory 模式
    return this._memory.get(key)
  }

  async set(key: string, value: any, ttl: number): Promise<void> {
    if (this._persist) {
      // 双写：内存 + 持久化层（内存也使用相同 TTL）
      await Promise.all([
        this._memory.set(key, value, ttl),
        this._persist.set(key, value, ttl),
      ])
      return
    }

    await this._memory.set(key, value, ttl)
  }

  async remove(key: string): Promise<void> {
    if (this._persist) {
      await Promise.all([
        this._memory.remove(key),
        this._persist.remove(key),
      ])
      return
    }

    await this._memory.remove(key)
  }

  /**
   * 清空内存层缓存（不影响持久化层）
   */
  clearMemory(): void {
    this._memory.clear()
  }
}
