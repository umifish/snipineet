import type { IStorage } from '../types'
import { I18N_DEFAULTS } from '../defaults'

/**
 * IndexedDB 存储
 */
export class IndexedDBProvider implements IStorage {
  private dbName = I18N_DEFAULTS.indexedDB.dbName
  private storeName = I18N_DEFAULTS.indexedDB.storeName
  /** 缓存的数据库连接 Promise，避免重复 open */
  private _dbPromise: Promise<IDBDatabase> | null = null

  private getDB(): Promise<IDBDatabase> {
    if (this._dbPromise)
      return this._dbPromise

    this._dbPromise = new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open(this.dbName, 1)
      request.onupgradeneeded = () => {
        const db = request.result
        if (!db.objectStoreNames.contains(this.storeName)) {
          db.createObjectStore(this.storeName)
        }
      }
      request.onsuccess = () => resolve(request.result)
      request.onerror = () => {
        this._dbPromise = null
        reject(request.error)
      }
    })

    return this._dbPromise
  }

  async get(key: string) {
    const db = await this.getDB()
    return new Promise((resolve) => {
      const tx = db.transaction(this.storeName, 'readwrite')
      const store = tx.objectStore(this.storeName)
      const request = store.get(key)
      request.onsuccess = () => {
        const res = request.result
        if (res && (res.expiry <= 0 || res.expiry > Date.now())) {
          resolve(res.value)
        }
        else {
          // 清理过期条目
          if (res) {
            store.delete(key)
          }
          resolve(null)
        }
      }
      request.onerror = () => resolve(null)
    })
  }

  async set(key: string, value: any, ttl: number) {
    const db = await this.getDB()
    const tx = db.transaction(this.storeName, 'readwrite')
    tx.objectStore(this.storeName).put({
      value,
      expiry: ttl > 0 ? Date.now() + ttl : 0,
    }, key)
  }

  async remove(key: string) {
    const db = await this.getDB()
    const tx = db.transaction(this.storeName, 'readwrite')
    tx.objectStore(this.storeName).delete(key)
  }
}
