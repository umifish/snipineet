import type { IStorage } from '../types'

/**
 * LocalStorage 存储
 */
export class LocalStorageProvider implements IStorage {
  async get(key: string) {
    const raw = localStorage.getItem(key)
    if (!raw)
      return null
    try {
      const item = JSON.parse(raw)
      if (item.expiry > 0 && item.expiry < Date.now()) {
        localStorage.removeItem(key)
        return null
      }
      return item.value
    }
    catch {
      return null
    }
  }

  async set(key: string, value: any, ttl: number) {
    localStorage.setItem(key, JSON.stringify({
      value,
      expiry: ttl > 0 ? Date.now() + ttl : 0,
    }))
  }

  async remove(key: string) {
    localStorage.removeItem(key)
  }
}
