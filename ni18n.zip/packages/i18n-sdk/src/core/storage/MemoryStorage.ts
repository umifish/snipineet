import type { IStorage } from '../types'

/**
 * 内存存储
 */
export class MemoryStorage implements IStorage {
  private store = new Map<string, { value: any, expiry: number }>()

  async get(key: string) {
    const item = this.store.get(key)
    if (!item)
      return null
    if (item.expiry > 0 && item.expiry < Date.now()) {
      this.store.delete(key)
      return null
    }
    return item.value
  }

  async set(key: string, value: any, ttl: number) {
    this.store.set(key, {
      value,
      expiry: ttl > 0 ? Date.now() + ttl : 0,
    })
  }

  async remove(key: string) {
    this.store.delete(key)
  }

  clear(): void {
    this.store.clear()
  }
}
