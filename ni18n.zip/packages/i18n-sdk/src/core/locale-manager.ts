// 使用主工程中的通用请求封装（通过别名 '@/src/utils/request' 引用）
import { request } from '@/utils/request'
import { I18N_DEFAULTS } from './defaults'
import type { I18nResolvedConfig } from './defaults'
import type { CacheAdapter } from './storage/CacheAdapter'

/**
 * 语言信息（接口返回的语言条目）
 */
export interface LocaleInfo {
  /** 语言代码，如 'zh-CN', 'en', 'ko' */
  code: string
  /** 显示名称，如 '简体中文', 'English' */
  label?: string
  /** 是否为接口指定的默认语言 */
  isDefault?: boolean
  /** 其他扩展字段 */
  [key: string]: any
}

/**
 * 语言管理器配置
 */
export interface LocaleManagerConfig {
  /** 初始化时配置的支持语言列表。未配置则使用默认: ['zh-CN', 'en', 'ko'] + 浏览器语言 */
  supportedLocales?: string[]
  /** 语言列表接口 URL */
  listUrl?: string
  /** 语言列表接口适配器：将接口原始数据转换为 LocaleInfo[] */
  adapter?: (data: any) => LocaleInfo[]
  /** 从 LocaleInfo[] 中提取默认语言的逻辑，默认取 isDefault=true 的第一个 */
  resolveDefault?: (locales: LocaleInfo[]) => string | undefined
  /** 用户信息接口适配器：从接口响应中提取用户偏好语言代码 */
  userInfoAdapter?: (data: any) => string | undefined
}

/** 内置默认支持语言（引用集中配置） */
const BUILTIN_LOCALES = I18N_DEFAULTS.supportedLocales as unknown as string[]

/**
 * BCP 47 标准语言代码正则：language[-REGION]
 * 合法格式: zh-CN, en-US, ko-KR, en, zh
 */
const STANDARD_LOCALE_RE = /^[a-z]{2,3}(-[A-Z][a-zA-Z]{1,3})?$/

/**
 * 常见纯语言代码到「语言-地区」的映射表
 * 用于将不带地区的语言代码补全为标准格式
 */
const LANGUAGE_REGION_MAP: Record<string, string> = {
  zh: 'zh-CN',
  en: 'en-US',
  ko: 'ko-KR',
  ja: 'ja-JP',
  fr: 'fr-FR',
  de: 'de-DE',
  es: 'es-ES',
  pt: 'pt-BR',
  ru: 'ru-RU',
  it: 'it-IT',
  ar: 'ar-SA',
  th: 'th-TH',
  vi: 'vi-VN',
  id: 'id-ID',
  ms: 'ms-MY',
  nl: 'nl-NL',
  pl: 'pl-PL',
  tr: 'tr-TR',
  uk: 'uk-UA',
  sv: 'sv-SE',
  da: 'da-DK',
  fi: 'fi-FI',
  nb: 'nb-NO',
  cs: 'cs-CZ',
  el: 'el-GR',
  he: 'he-IL',
  hi: 'hi-IN',
  hu: 'hu-HU',
  ro: 'ro-RO',
  sk: 'sk-SK',
  bg: 'bg-BG',
  hr: 'hr-HR',
  ca: 'ca-ES',
  lt: 'lt-LT',
  sl: 'sl-SI',
  et: 'et-EE',
  lv: 'lv-LV',
}

/**
 * 检测语言代码是否符合标准 BCP 47 模式 (language-REGION)
 */
export function isStandardLocale(locale: string): boolean {
  return STANDARD_LOCALE_RE.test(locale)
}

/**
 * 将非标准语言代码规范化为 BCP 47 标准格式 (language-REGION)
 *
 * 处理规则：
 * 1. 移除首尾空白
 * 2. 将下划线替换为连字符: zh_CN → zh-CN
 * 3. 修正大小写: ZH-cn → zh-CN, EN-US → en-US
 * 4. 纯语言代码补全地区: zh → zh-CN, en → en-US
 * 5. 已标准则原样返回
 *
 * @example
 * normalizeLocale('zh_CN')    // 'zh-CN'
 * normalizeLocale('en_us')    // 'en-US'
 * normalizeLocale('ZH-cn')    // 'zh-CN'
 * normalizeLocale('zh')       // 'zh-CN'
 * normalizeLocale('en')       // 'en-US'
 * normalizeLocale('en-US')    // 'en-US' (已标准，原样返回)
 */
export function normalizeLocale(locale: string): string {
  if (!locale)
    return locale

  let normalized = locale.trim()

  // 下划线转连字符
  normalized = normalized.replace(/_/g, '-')

  const parts = normalized.split('-')

  if (parts.length === 1) {
    // 纯语言代码：尝试映射到语言-地区
    const lang = parts[0].toLowerCase()
    return LANGUAGE_REGION_MAP[lang] ?? lang
  }

  if (parts.length === 2) {
    const lang = parts[0].toLowerCase()
    const sub = parts[1]
    // 2 字母 → 地区码 (UPPERCASE: CN, US)；4 字母 → 文字码 (Titlecase: Hans, Hant)
    const normalized2 = sub.length === 2
      ? sub.toUpperCase()
      : sub.charAt(0).toUpperCase() + sub.slice(1).toLowerCase()
    return `${lang}-${normalized2}`
  }

  if (parts.length >= 3) {
    // language-Script-REGION，如 zh-Hans-CN
    const lang = parts[0].toLowerCase()
    const script = parts[1].charAt(0).toUpperCase() + parts[1].slice(1).toLowerCase()
    const region = parts[2].toUpperCase()
    return `${lang}-${script}-${region}`
  }

  return normalized
}

/**
 * 语言（语种）管理器
 *
 * 职责：
 * 1. 管理支持的语言列表（配置 + 浏览器检测 + 接口动态更新）
 * 2. 通过 axios 请求语言列表接口，从接口数据中解析默认语言
 * 3. 提供语言切换入口
 */
export class LocaleManager {
  /** 当前支持的语言列表 */
  private _locales: string[] = []
  /** 接口返回的完整语言信息 */
  private _localeInfoList: LocaleInfo[] = []
  /** 语言管理配置 */
  private _localeConfig: LocaleManagerConfig

  constructor(localeConfig: LocaleManagerConfig = {}) {
    this._localeConfig = localeConfig
    this._locales = this._buildInitialLocales(localeConfig.supportedLocales)
  }

  /**
   * 规范化语言代码（静态方法，方便外部直接调用）
   */
  static normalize(locale: string): string {
    return normalizeLocale(locale)
  }

  /**
   * 检测语言代码是否为标准 BCP 47 格式
   */
  static isStandard(locale: string): boolean {
    return isStandardLocale(locale)
  }

  /** 当前支持的语言代码列表 */
  get locales(): string[] {
    return [...this._locales]
  }

  /** 接口返回的完整语言信息列表 */
  get localeInfoList(): LocaleInfo[] {
    return [...this._localeInfoList]
  }

  /**
   * 从接口查询语言列表，更新支持的语言，并返回接口指定的默认语言
   */
  async fetchLocales(
    url: string,
    storage: CacheAdapter,
    config: I18nResolvedConfig,
  ): Promise<{ locales: string[], defaultLocale: string | undefined }> {
    const cacheKey = `${config.storage.keyPrefix}${I18N_DEFAULTS.cacheKeys.localeList}`

    // 1. 尝试读缓存
    let rawData: any = await storage.get(cacheKey)

    // 2. 缓存未命中，使用统一 request 封装发起请求
    if (!rawData) {
      rawData = await request(url)
      await storage.set(cacheKey, rawData, config.storage.maxAge)
    }

    // 3. 适配器转换
    const adapter = this._localeConfig.adapter
    this._localeInfoList = adapter ? adapter(rawData) : this._defaultAdapter(rawData)

    // 4. 规范化所有语言代码
    for (const info of this._localeInfoList) {
      info.code = normalizeLocale(info.code)
    }

    // 5. 提取语言代码列表，与已有 locales 合并
    const remoteCodes = this._localeInfoList.map(item => item.code)
    this._mergeLocales(remoteCodes)

    // 6. 解析默认语言
    const resolver = this._localeConfig.resolveDefault ?? this._defaultResolveDefault
    const rawDefault = resolver(this._localeInfoList)
    const defaultLocale = rawDefault ? normalizeLocale(rawDefault) : undefined

    return { locales: this.locales, defaultLocale }
  }

  /**
   * 判断某语言是否在支持列表中
   */
  isSupported(locale: string): boolean {
    const normalized = normalizeLocale(locale)
    return this._locales.includes(normalized)
  }

  /**
   * 查询用户个人信息接口，提取用户设置的偏好语言
   */
  async fetchUserLocale(
    url: string,
    storage: CacheAdapter,
    config: I18nResolvedConfig,
  ): Promise<string | undefined> {
    const cacheKey = `${config.storage.keyPrefix}${I18N_DEFAULTS.cacheKeys.userInfo}`

    // 1. 尝试读缓存
    let rawData: any = await storage.get(cacheKey)

    // 2. 缓存未命中，使用统一 request 封装发起请求
    if (!rawData) {
      rawData = await request(url)
      await storage.set(cacheKey, rawData, config.storage.maxAge)
    }

    // 3. 适配器提取语言
    const adapter = this._localeConfig.userInfoAdapter
    const raw = adapter ? adapter(rawData) : this._defaultUserInfoAdapter(rawData)
    return raw ? normalizeLocale(raw) : undefined
  }

  /**
   * 从当前 URL 的查询参数中获取 lang 值
   */
  getUrlLocale(): string | undefined {
    if (typeof window === 'undefined' || !window.location)
      return undefined
    const params = new URLSearchParams(window.location.search)
    const lang = params.get(I18N_DEFAULTS.urlLangParam)
    return lang ? normalizeLocale(lang) : undefined
  }

  /**
   * 动态添加一个支持的语言
   */
  addLocale(locale: string): void {
    const normalized = normalizeLocale(locale)
    if (!this._locales.includes(normalized)) {
      this._locales.push(normalized)
    }
  }

  /**
   * 获取浏览器当前语言
   */
  getBrowserLocale(): string | undefined {
    if (typeof navigator === 'undefined')
      return undefined
    return normalizeLocale(navigator.language)
  }

  // ─── 内部方法 ───

  /**
   * 构建初始语言列表
   */
  private _buildInitialLocales(configured?: string[]): string[] {
    const raw = configured && configured.length > 0
      ? configured
      : BUILTIN_LOCALES

    const base = raw.map(l => normalizeLocale(l))

    // 若浏览器语言不在列表中，动态加入
    const browserLocale = this.getBrowserLocale()
    if (browserLocale && !base.includes(browserLocale)) {
      base.push(browserLocale)
    }

    return base
  }

  /**
   * 将接口返回的语言合并到当前列表中（去重）
   */
  private _mergeLocales(remoteCodes: string[]): void {
    for (const code of remoteCodes) {
      const normalized = normalizeLocale(code)
      if (!this._locales.includes(normalized)) {
        this._locales.push(normalized)
      }
    }
  }

  /**
   * 默认适配器：兼容 string[] 或 { code, label, isDefault }[] 两种格式
   */
  private _defaultAdapter(data: any): LocaleInfo[] {
    if (Array.isArray(data)) {
      return data.map((item: any) => {
        if (typeof item === 'string')
          return { code: item }
        return item as LocaleInfo
      })
    }
    // 若接口返回带 data 包裹
    if (data?.data && Array.isArray(data.data)) {
      return this._defaultAdapter(data.data)
    }
    return []
  }

  /**
   * 默认解析默认语言：取 isDefault=true 的第一个
   */
  private _defaultResolveDefault(locales: LocaleInfo[]): string | undefined {
    return locales.find(l => l.isDefault)?.code
  }

  /**
   * 默认用户信息适配器：尝试从常见字段中提取语言设置
   * 兼容 { lang }, { locale }, { language }, { data: { lang } } 等格式
   */
  private _defaultUserInfoAdapter(data: any): string | undefined {
    if (!data)
      return undefined
    // 直接取常见字段
    const directFields = ['lang', 'locale', 'language']
    for (const field of directFields) {
      if (typeof data[field] === 'string' && data[field])
        return data[field]
    }
    // 带 data 包裹
    if (data.data && typeof data.data === 'object') {
      return this._defaultUserInfoAdapter(data.data)
    }
    return undefined
  }
}
