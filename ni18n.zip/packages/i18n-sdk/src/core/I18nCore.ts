import type {
  I18nCoreConfig,
  I18nEventListener,
  I18nEventMap,
  I18nEventType,
  I18nHooks,
  MessageResource,
} from './types'
import type { I18nResolvedConfig } from './defaults'
import { I18N_DEFAULTS, resolveConfig } from './defaults'
import { CacheAdapter } from './storage/CacheAdapter'
import { RequestInterceptor } from './interceptor'
import { LocaleManager, normalizeLocale } from './locale-manager'
import type { LocaleInfo } from './locale-manager'

/**
 * 框架无关的 i18n 核心引擎
 *
 * 负责：语言检测、消息加载与缓存、命名空间管理、
 * 语言切换（含回滚）、跨标签页同步、事件分发。
 *
 * 框架层（Vue / React）基于此内核实现具体集成。
 */
export class I18nCore {
  /** 当前语言 */
  private _locale: string
  /** 全部已加载消息: locale -> namespace -> messages */
  private _messages: Map<string, Map<string, MessageResource>> = new Map()
  /** 已加载的 locale+ns 追踪 */
  private _loadedMap: Map<string, Set<string>> = new Map()
  /** 缓存适配器 */
  private _storage: CacheAdapter
  /** 语言管理器 */
  private _localeManager: LocaleManager
  /** 生命周期钩子 */
  private _hooks: I18nHooks = {}
  /** 事件监听器 */
  private _listeners: Map<I18nEventType, Set<I18nEventListener<any>>> = new Map()
  /** 跨标签页同步通道 */
  private _syncChannel: BroadcastChannel | null = null
  /** 请求拦截器 */
  private _interceptor: RequestInterceptor
  /** 合并后的完整配置 */
  private _config: I18nResolvedConfig
  /** 是否已初始化 */
  private _initialized = false
  /** 正在加载中的命名空间 Promise（避免重复请求） */
  private _pendingLoads: Map<string, Promise<boolean>> = new Map()

  constructor(config: I18nCoreConfig) {
    this._config = resolveConfig(config)
    this._locale = this._config.defaultLocale

    // 初始化缓存适配器
    this._storage = new CacheAdapter(this._config.storage.type)

    // 初始化语言管理器
    this._localeManager = new LocaleManager({
      supportedLocales: this._config.locale?.supported,
      listUrl: this._config.endpoints.list,
      adapter: this._config.locale?.adapter,
      resolveDefault: this._config.locale?.resolveDefault,
      userInfoAdapter: this._config.adapters?.userInfo,
    })

    // 初始化请求拦截器
    this._interceptor = new RequestInterceptor(
      () => this._locale,
      this._config.interceptor,
    )

    // 初始化鉴权头（从配置或 localStorage 读取）
    this._applyInitialAuthToken()
  }

  // ─── 公开属性 ───

  get locale(): string {
    return this._locale
  }

  /** 当前支持的语言列表 */
  get supportedLocales(): string[] {
    return this._localeManager.locales
  }

  /** 接口返回的完整语言信息列表 */
  get localeInfoList(): LocaleInfo[] {
    return this._localeManager.localeInfoList
  }

  get config(): Readonly<I18nResolvedConfig> {
    return this._config
  }

  // ─── 初始化 ───

  /**
   * 初始化核心引擎
   *
   * 流程：
   * 1. 安装请求拦截器
   * 2. 请求语言列表接口，获取系统默认语言
   * 3. 加载系统默认语言的文案资源包并缓存
   * 4. 查询用户个人信息，获取用户偏好语言
   * 5. 决定最终语言：用户个人信息 > URL lang 参数 > 缓存 > 系统检测
   * 6. 若最终语言与系统默认不同，加载该语言的文案资源包并缓存
   * 7. 更新 localStorage 缓存中的语言
   * 8. 开启跨标签页同步
   */
  async init(hooks?: I18nHooks): Promise<void> {
    if (this._initialized)
      return
    this._initialized = true

    if (hooks)
      this._hooks = hooks

    // 1. 安装请求拦截器（需在接口请求前安装，以注入 header）
    this._interceptor.install()

    // 2. 请求语言列表接口，获取系统默认语言（可通过配置/钩子关闭）
    let systemDefaultLocale: string | undefined
    if (!this._config.locale?.disableRemote && this._config.endpoints.list) {
      const shouldFetchLocales = await this._hooks.beforeFetchLocales?.(this._config.endpoints.list)
      if (shouldFetchLocales !== false) {
        try {
          const result = await this._localeManager.fetchLocales(
            this._config.endpoints.list,
            this._storage,
            this._config,
          )
          systemDefaultLocale = result.defaultLocale
          await this._hooks.afterFetchLocales?.(result.locales, result.defaultLocale)
        }
        catch (error) {
          this._emit('error', { error, locale: this._locale })
        }
      }
    }

    // 3. 加载系统默认语言的文案资源包并缓存
    const defaultNs = this._config.defaultNamespace
    const sysLocale = systemDefaultLocale ?? this._config.defaultLocale
    await this.loadNamespace(sysLocale, defaultNs)

    // 4. 查询用户个人信息，获取用户偏好语言（支持自定义 loader 或关闭远程）
    let userLocale: string | undefined
    if (this._config.endpoints.userInfo && !this._config.user?.disableRemote) {
      try {
        const url = this._config.endpoints.userInfo

        if (this._config.user?.loader) {
          // 自定义用户信息加载函数，由外部决定如何请求 & 处理错误
          const raw = await this._config.user.loader(url)
          const adapter = this._config.adapters?.userInfo
          const lang = adapter ? adapter(raw) : undefined
          userLocale = lang ? normalizeLocale(lang) : undefined
        }
        else {
          // 默认行为：由 LocaleManager 使用 axios + 缓存加载用户信息
          userLocale = await this._localeManager.fetchUserLocale(
            url,
            this._storage,
            this._config,
          )
        }
      }
      catch (error) {
        this._emit('error', { error, locale: this._locale })
      }
    }

    // 5. 决定最终语言：用户个人信息 > URL(lang) > 缓存 > 系统检测
    this._locale = await this._detectLocale(userLocale, systemDefaultLocale)

    // 6. 若最终语言与系统默认不同，加载该语言的文案资源包并缓存
    if (this._locale !== sysLocale) {
      await this.loadNamespace(this._locale, defaultNs)
    }

    // 设置 HTML lang 属性
    if (typeof document !== 'undefined') {
      document.documentElement.lang = this._locale
    }

    // 7. 持久化当前语言到缓存
    await this._persistLocale(this._locale)

    if (this._config.enableSync) {
      this._setupSync()
    }
  }

  // ─── 命名空间加载 ───

  /**
   * 按需加载指定 locale 的命名空间消息
   */
  async loadNamespace(locale: string, ns: string): Promise<boolean> {
    locale = normalizeLocale(locale)
    if (this._loadedMap.get(locale)?.has(ns))
      return true

    // 去重：若同一 locale+ns 正在加载中，直接复用 Promise
    const pendingKey = `${locale}:${ns}`
    const pending = this._pendingLoads.get(pendingKey)
    if (pending)
      return pending

    const promise = this._doLoadNamespace(locale, ns)
    this._pendingLoads.set(pendingKey, promise)
    try {
      return await promise
    }
    finally {
      this._pendingLoads.delete(pendingKey)
    }
  }

  private async _doLoadNamespace(locale: string, ns: string): Promise<boolean> {
    const cacheKey = `${this._config.storage.keyPrefix}_${locale}_${ns}`

    try {
      // beforeLoad 返回 false 则跳过
      const shouldLoad = await this._hooks.beforeLoad?.(locale, ns)
      if (shouldLoad === false)
        return false

      // 1. 尝试读缓存
      let msgs: MessageResource | null = await this._storage.get(cacheKey)

      // 2. 缓存未命中，优先使用本地或自定义 loader，最后才发起网络请求
      if (!msgs) {
        const url = this._config.endpoints.message(locale, ns)

        // 2.1 本地预置消息
        const localMsgs = this._config.messages?.local?.[locale]?.[ns]
        if (localMsgs) {
          msgs = localMsgs
        }
        else {
          // 2.2 beforeFetchMessages 返回 false 则取消本次加载
          const shouldFetch = await this._hooks.beforeFetchMessages?.(locale, ns, url)
          if (shouldFetch === false)
            return false

          // 2.3 使用自定义 loader 或默认网络请求
          if (this._config.messages?.loader) {
            msgs = await this._config.messages.loader(locale, ns, url)
          }
          else if (!this._config.messages?.disableRemote) {
            msgs = await this._fetchWithRetry(url, this._config.retries)
          }
          else {
            // 已禁用远程且未配置 loader，本次加载视为无内容
            msgs = {}
          }

          if (this._config.adapters?.message) {
            msgs = this._config.adapters.message(msgs)
          }

          await this._hooks.afterFetchMessages?.(locale, ns, msgs!)
          await this._storage.set(cacheKey, msgs!, this._config.storage.maxAge)
        }
      }

      // 3. 合并到内存
      this._mergeMessages(locale, ns, msgs!)

      if (!this._loadedMap.has(locale))
        this._loadedMap.set(locale, new Set())
      this._loadedMap.get(locale)!.add(ns)

      await this._hooks.afterLoad?.(locale, ns)
      this._emit('namespaceLoaded', { locale, ns })
      return true
    }
    catch (error) {
      await this._hooks.onLoadError?.(error, locale, ns)
      this._emit('error', { error, locale, ns })
      return false
    }
  }

  // ─── 鉴权 Token 管理 ───

  /**
   * 初始化时应用鉴权 Token：
   * - 优先使用 config.auth.token
   * - 否则在浏览器环境下尝试从 localStorage[auth.tokenStorageKey] 读取
   */
  private _applyInitialAuthToken(): void {
    const auth = this._config.auth
    if (!auth)
      return

    const headerName = auth.headerName
    let token = auth.token

    if (!token && auth.tokenStorageKey && typeof localStorage !== 'undefined') {
      try {
        const stored = localStorage.getItem(auth.tokenStorageKey)
        if (stored)
          token = stored
      }
      catch {
        // 访问 localStorage 失败时静默忽略
      }
    }

    if (token) {
      this._interceptor.setHeader(headerName, token)
      // 缓存到配置中，便于后续读取
      if (this._config.auth)
        this._config.auth.token = token
    }
  }

  /**
   * 运行时设置鉴权 Token
   *
   * @param token   新的 token 值
   * @param persist 是否持久化到 localStorage（需要配置 tokenStorageKey）
   */
  setAuthToken(token: string, persist = false): void {
    if (!this._config.auth) {
      this._config.auth = {
        headerName: I18N_DEFAULTS.auth.headerName,
        token,
      }
    }
    else {
      this._config.auth.token = token
    }

    const headerName = this._config.auth.headerName ?? I18N_DEFAULTS.auth.headerName
    this._interceptor.setHeader(headerName, token)

    if (persist && this._config.auth.tokenStorageKey && typeof localStorage !== 'undefined') {
      try {
        localStorage.setItem(this._config.auth.tokenStorageKey, token)
      }
      catch {
        // 持久化失败时静默忽略
      }
    }
  }

  /**
   * 清除当前鉴权 Token
   *
   * @param clearStorage 同时清除 localStorage 中的持久化 Token
   */
  clearAuthToken(clearStorage = false): void {
    const auth = this._config.auth
    if (!auth)
      return

    auth.token = undefined
    const headerName = auth.headerName ?? I18N_DEFAULTS.auth.headerName
    this._interceptor.removeHeader(headerName)

    if (clearStorage && auth.tokenStorageKey && typeof localStorage !== 'undefined') {
      try {
        localStorage.removeItem(auth.tokenStorageKey)
      }
      catch {
        // 静默忽略
      }
    }
  }

  // ─── 语言切换 ───

  /**
   * 切换语言
   *
   * 先加载默认命名空间，成功才切换，否则回滚。
   * 若目标语言不在支持列表中，会自动添加。
   */
  async switchLocale(newLocale: string): Promise<boolean> {
    newLocale = normalizeLocale(newLocale)
    if (newLocale === this._locale)
      return true

    const oldLocale = this._locale

    // beforeSwitch 返回 false 则取消切换
    const shouldSwitch = await this._hooks.beforeSwitch?.(oldLocale, newLocale)
    if (shouldSwitch === false)
      return false

    // 动态添加到支持列表
    this._localeManager.addLocale(newLocale)

    const defaultNs = this._config.defaultNamespace
    const success = await this.loadNamespace(newLocale, defaultNs)

    if (success) {
      this._locale = newLocale
      await this._persistLocale(newLocale)

      if (typeof document !== 'undefined') {
        document.documentElement.lang = newLocale
      }

      this._syncChannel?.postMessage({ type: 'LOCALE_UPDATE', locale: newLocale })
      await this._hooks.afterSwitch?.(newLocale)
      this._emit('localeChange', { locale: newLocale, previous: oldLocale })
      return true
    }

    return false
  }

  // ─── 消息读取 ───

  /**
   * 获取指定 locale 的所有已合并消息
   */
  getMessages(locale?: string): MessageResource {
    const target = locale ?? this._locale
    const nsMap = this._messages.get(target)
    if (!nsMap)
      return {}
    const merged: MessageResource = {}
    for (const msgs of nsMap.values()) {
      Object.assign(merged, msgs)
    }
    return merged
  }

  /**
   * 获取所有已加载 locale 的消息 (vue-i18n / i18next 可直接消费)
   */
  getAllMessages(): Record<string, MessageResource> {
    const result: Record<string, MessageResource> = {}
    for (const locale of this._messages.keys()) {
      result[locale] = this.getMessages(locale)
    }
    return result
  }

  /**
   * 判断某 locale + ns 是否已加载
   */
  isNamespaceLoaded(locale: string, ns: string): boolean {
    return this._loadedMap.get(locale)?.has(ns) ?? false
  }

  // ─── 事件系统 ───

  on<T extends I18nEventType>(event: T, listener: I18nEventListener<T>): () => void {
    if (!this._listeners.has(event))
      this._listeners.set(event, new Set())
    this._listeners.get(event)!.add(listener)
    return () => this._listeners.get(event)?.delete(listener)
  }

  off<T extends I18nEventType>(event: T, listener: I18nEventListener<T>): void {
    this._listeners.get(event)?.delete(listener)
  }

  // ─── 钩子管理 ───

  setHooks(hooks: Partial<I18nHooks>): void {
    Object.assign(this._hooks, hooks)
  }

  // ─── 请求头管理 ───

  /**
   * 设置自定义请求头（会注入到所有被拦截的请求中）
   *
   * @example
   * ```ts
   * // 登录后设置 token
   * i18n.setHeader('Authorization', 'Bearer xxx')
   * ```
   */
  setHeader(name: string, value: string): void {
    this._interceptor.setHeader(name, value)
  }

  /**
   * 移除自定义请求头
   */
  removeHeader(name: string): void {
    this._interceptor.removeHeader(name)
  }

  /**
   * 批量设置自定义请求头
   *
   * @example
   * ```ts
   * i18n.setHeaders({
   *   'Authorization': 'Bearer xxx',
   *   'X-Tenant-Id': '12345',
   * })
   * ```
   */
  setHeaders(headers: Record<string, string>): void {
    this._interceptor.setHeaders(headers)
  }

  // ─── 销毁 ───

  destroy(): void {
    this._interceptor.uninstall()
    this._syncChannel?.close()
    this._syncChannel = null
    this._listeners.clear()
    this._loadedMap.clear()
    this._messages.clear()
    this._hooks = {}
    this._pendingLoads.clear()
    this._storage.clearMemory()
    this._initialized = false
  }

  // ─── 内部方法 ───

  private _mergeMessages(locale: string, ns: string, msgs: MessageResource): void {
    if (!this._messages.has(locale))
      this._messages.set(locale, new Map())
    this._messages.get(locale)!.set(ns, msgs)
  }

  private _emit<T extends I18nEventType>(event: T, payload: I18nEventMap[T]): void {
    this._listeners.get(event)?.forEach(fn => fn(payload))
  }

  /**
   * 决定当前使用语言
   * 优先级：用户个人信息设置 > URL lang 参数 > 缓存 > 系统检测的当前语言
   */
  private async _detectLocale(userLocale?: string, systemDefaultLocale?: string): Promise<string> {
    const cacheKey = `${this._config.storage.keyPrefix}${I18N_DEFAULTS.cacheKeys.userLang}`
    const supported = this._localeManager.locales

    // 1. 用户个人信息中设置的语言（最高优先级）
    if (userLocale && supported.includes(userLocale))
      return userLocale

    // 2. URL 中的 lang 参数
    const urlLocale = this._localeManager.getUrlLocale()
    if (urlLocale && supported.includes(urlLocale))
      return urlLocale

    // 3. 缓存中的用户选择
    const cached = await this._storage.get(cacheKey)
    if (cached && supported.includes(cached))
      return cached

    // 4. 系统检测：接口默认 → 浏览器语言 → 配置默认
    if (systemDefaultLocale && supported.includes(systemDefaultLocale))
      return systemDefaultLocale

    const browserLocale = this._localeManager.getBrowserLocale()
    if (browserLocale && supported.includes(browserLocale))
      return browserLocale

    return this._config.defaultLocale
  }

  /**
   * 持久化当前语言到 localStorage 缓存
   */
  private async _persistLocale(locale: string): Promise<void> {
    const cacheKey = `${this._config.storage.keyPrefix}${I18N_DEFAULTS.cacheKeys.userLang}`
    await this._storage.set(cacheKey, locale, I18N_DEFAULTS.localePersistTTL)
  }

  private async _fetchWithRetry(url: string, retries: number): Promise<any> {
    try {
      const res = await fetch(url)
      if (!res.ok)
        throw new Error(`HTTP ${res.status}`)
      return await res.json()
    }
    catch (e) {
      if (retries > 0)
        return this._fetchWithRetry(url, retries - 1)
      throw e
    }
  }

  private _setupSync(): void {
    if (typeof BroadcastChannel === 'undefined')
      return
    this._syncChannel = new BroadcastChannel(I18N_DEFAULTS.syncChannelName)
    this._syncChannel.onmessage = async (e) => {
      if (e.data?.type === 'LOCALE_UPDATE' && typeof e.data.locale === 'string') {
        const newLocale = e.data.locale
        if (newLocale === this._locale)
          return
        const previous = this._locale

        // 先加载目标语言的默认命名空间消息
        await this.loadNamespace(newLocale, this._config.defaultNamespace)

        this._locale = newLocale
        this._emit('localeChange', { locale: newLocale, previous })
      }
    }
  }
}
