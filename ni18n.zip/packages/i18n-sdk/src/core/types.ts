/**
 * 存储类型
 */
export type StorageType = 'memory' | 'localStorage' | 'indexedDB'

/**
 * 存储接口
 */
export interface IStorage {
  get: (key: string) => Promise<any>
  set: (key: string, value: any, ttl: number) => Promise<void>
  remove: (key: string) => Promise<void>
}

/**
 * 消息资源对象 (嵌套的 key-value)
 */
export type MessageResource = Record<string, any>

/**
 * i18n-sdk 核心配置
 */
export interface I18nCoreConfig {
  /** 默认语言 */
  defaultLocale: string
  /** 回退语言 */
  fallbackLocale: string
  /** 接口基础地址，所有 endpoints 中的相对路径会自动拼接此前缀 */
  baseURL?: string
  /** 接口端点（可使用相对路径，配合 baseURL 使用） */
  endpoints: {
    /** 获取支持的语言列表接口 URL */
    list: string
    /** 根据 locale + namespace 获取语言包 */
    message: (locale: string, ns: string) => string
    /** 获取当前用户个人信息接口 URL（用于读取用户偏好语言） */
    userInfo?: string
  }
  /** 语言（语种）管理配置 */
  locale?: {
    /** 初始化时配置的支持语言列表。未配置则使用默认: ['zh-CN', 'en', 'ko'] + 浏览器语言 */
    supported?: string[]
    /** 语言列表接口适配器：将接口原始数据转换为 LocaleInfo[] */
    adapter?: (data: any) => import('./locale-manager').LocaleInfo[]
    /** 从 LocaleInfo[] 中提取默认语言的逻辑，默认取 isDefault=true 的第一个 */
    resolveDefault?: (locales: import('./locale-manager').LocaleInfo[]) => string | undefined
    /**
     * 是否禁用远程语言列表请求。
     *
     * - true  时：跳过 endpoints.list 接口调用，仅使用 supported 配置和浏览器语言。
     * - false 时：按默认流程先请求语言列表接口。
     */
    disableRemote?: boolean
  }
  /**
   * 文案资源加载配置
   */
  messages?: {
    /**
     * 预置本地消息资源（不走接口）。
     * 结构：locale -> namespace -> MessageResource
     */
    local?: Record<string, Record<string, MessageResource>>
    /**
     * 是否禁用远程文案请求。
     *
     * - true  时：不会调用 endpoints.message 发起网络请求，仅使用 local 或 loader。
     * - false 时：按默认流程在缓存未命中时发起网络请求。
     */
    disableRemote?: boolean
    /**
     * 自定义文案资源加载函数。
     *
     * - 若配置，则在缓存未命中时优先使用该函数加载文案资源。
     * - 可以在外部自行请求接口，再将结果返回给 SDK，替代内部 fetch 实现。
     */
    loader?: (locale: string, ns: string, url: string) => Promise<MessageResource>
  }
  /** 缓存配置 */
  storage: {
    /** 缓存类型，默认 'memory'。选择 'localStorage' 时自动启用 内存 + LocalStorage 双层缓存 */
    type?: StorageType
    /** 缓存 key 前缀 */
    keyPrefix: string
    /** 缓存有效期 (ms) */
    maxAge: number
    /** 存储上限控制 */
    quota?: number
  }
  /** 数据适配器 */
  adapters?: {
    /** 语言包接口数据适配 */
    message?: (data: any) => MessageResource
    /** 用户信息接口适配：从接口响应中提取用户偏好语言代码 */
    userInfo?: (data: any) => string | undefined
  }
  /** 初始加载的默认命名空间 */
  defaultNamespace?: string
  /** 网络请求重试次数 */
  retries?: number
  /** 是否启用跨标签页同步 */
  enableSync?: boolean
  /** 请求拦截器配置 */
  interceptor?: {
    /** 是否启用拦截器，默认 true */
    enabled?: boolean
    /** 拦截规则列表，未配置则拦截所有请求 */
    rules?: Array<string | RegExp | ((url: string) => boolean)>
    /** 规则取反：true 表示不拦截匹配规则的请求（排除模式），默认 false */
    negate?: boolean
    /** 自定义语言请求头名，默认 'X-Lang' */
    langHeader?: string
    /** 自定义时区请求头名，默认 'X-Timezone' */
    timezoneHeader?: string
  }
  /**
   * 用户信息加载配置（用于获取用户偏好语言）
   */
  user?: {
    /**
     * 是否禁用远程用户信息请求。
     *
     * - true  时：跳过 endpoints.userInfo 接口调用，仅使用本地逻辑/默认语言。
     * - false 时：按默认流程加载用户信息。
     */
    disableRemote?: boolean
    /**
     * 自定义用户信息加载函数。
     *
     * - 若配置，则优先使用该函数加载用户信息（替代内部 axios 调用）。
     * - 返回值会交由 adapters.userInfo 适配为语言代码。
     */
    loader?: (url: string) => Promise<any>
  }
  /**
   * 鉴权配置（用于为所有请求统一注入 token 等头信息）
   */
  auth?: {
    /**
     * 鉴权头名，默认为 'Authorization'
     *
     * 例如：'Authorization' 或 'X-Auth-Token'
     */
    headerName?: string
    /**
     * 初始化时直接传入的 token 值
     *
     * 例如：'Bearer xxx'
     */
    token?: string
    /**
     * 从 localStorage 读取 token 时使用的 key
     *
     * - 若同时配置 token 与 tokenStorageKey，则优先使用显式传入的 token；
     * - 否则会尝试从 localStorage[tokenStorageKey] 读取。
     */
    tokenStorageKey?: string
  }
}

/** 钩子返回值：返回 false 取消后续操作，其他值继续 */
type HookResult = void | boolean | Promise<void | boolean>

/**
 * 生命周期钩子
 *
 * 所有钩子均支持异步 (返回 Promise)。
 * before* 钩子返回 `false` 可取消对应操作。
 */
export interface I18nHooks {
  // ─── 加载语言列表 ───

  /** 请求语言列表接口之前。返回 false 跳过请求，使用本地配置 */
  beforeFetchLocales?: (url: string) => HookResult
  /** 请求语言列表接口之后 */
  afterFetchLocales?: (locales: string[], defaultLocale: string | undefined) => void | Promise<void>

  // ─── 加载文案资源包 ───

  /** 加载命名空间文案之前。返回 false 跳过本次加载 */
  beforeLoad?: (locale: string, ns: string) => HookResult
  /** 网络请求文案资源之前（缓存未命中时触发）。返回 false 取消请求 */
  beforeFetchMessages?: (locale: string, ns: string, url: string) => HookResult
  /** 网络请求文案资源之后（可对原始数据做自定义处理） */
  afterFetchMessages?: (locale: string, ns: string, messages: MessageResource) => void | Promise<void>
  /** 加载命名空间文案之后 */
  afterLoad?: (locale: string, ns: string) => void | Promise<void>
  /** 加载失败 */
  onLoadError?: (error: unknown, locale: string, ns: string) => void | Promise<void>

  // ─── 切换语言 ───

  /** 语言切换之前。返回 false 取消切换 */
  beforeSwitch?: (oldLocale: string, newLocale: string) => HookResult
  /** 语言切换之后 */
  afterSwitch?: (locale: string) => void | Promise<void>
}

/**
 * 事件类型
 */
export type I18nEventType = 'localeChange' | 'namespaceLoaded' | 'error'

/**
 * 事件回调映射
 */
export interface I18nEventMap {
  localeChange: { locale: string, previous: string }
  namespaceLoaded: { locale: string, ns: string }
  error: { error: unknown, locale: string, ns?: string }
}

/**
 * 事件监听器
 */
export type I18nEventListener<T extends I18nEventType> = (payload: I18nEventMap[T]) => void
