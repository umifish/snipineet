import type { I18nCoreConfig, StorageType } from './types'
import type { InterceptorConfig } from './interceptor'

/**
 * 所有可选配置的默认值
 */
export const I18N_DEFAULTS = {
  /** 默认缓存类型 */
  storageType: 'memory' as StorageType,
  /** 默认命名空间 */
  defaultNamespace: 'common',
  /** 默认网络请求重试次数 */
  retries: 2,
  /** 默认启用跨标签页同步 */
  enableSync: true,
  /** 默认支持的语言列表 */
  supportedLocales: ['zh-CN', 'en', 'ko'],
  /** 拦截器默认配置 */
  interceptor: {
    enabled: true,
    negate: false,
    langHeader: 'X-Lang',
    timezoneHeader: 'X-Timezone',
  } satisfies Required<Omit<InterceptorConfig, 'rules'>>,
  /** 缓存 key 后缀 */
  cacheKeys: {
    /** 用户语言偏好 */
    userLang: '_user_lang',
    /** 语言列表 */
    localeList: '_locale_list',
    /** 用户信息 */
    userInfo: '_user_info',
  },
  /** 用户语言持久化 TTL (ms)，默认 1 年 */
  localePersistTTL: 365 * 24 * 60 * 60 * 1000,
  /** 内存 L1 缓存回填 TTL (ms)，默认 30 分钟 */
  sessionCacheTTL: 30 * 60 * 1000,
  /** 跨标签页同步频道名 */
  syncChannelName: 'i18n_sync',
  /** URL 中语言参数名 */
  urlLangParam: 'lang',
  /** IndexedDB 配置 */
  indexedDB: {
    /** 数据库名称 */
    dbName: 'I18N_CACHE',
    /** 对象存储名称 */
    storeName: 'messages',
  },
  /** 鉴权默认配置 */
  auth: {
    headerName: 'Authorization',
  },
} as const

/**
 * 完整初始化配置示例（React 侧，可作为参考）
 *
 * 示例仅为文档用途，不会参与运行时逻辑。
 *
 * ```ts
 * import { createI18n } from '@supernova/i18n-sdk/react'
 * import type { MessageResource } from '@supernova/i18n-sdk/core'
 *
 * const localMessages: Record<string, Record<string, MessageResource>> = {
 *   'zh-CN': {
 *     common: {
 *       hello: '你好',
 *       submit: '提交',
 *     },
 *   },
 *   'en-US': {
 *     common: {
 *       hello: 'Hello',
 *       submit: 'Submit',
 *     },
 *   },
 * }
 *
 * export const i18nManager = createI18n({
 *   defaultLocale: 'zh-CN',
 *   fallbackLocale: 'en-US',
 *   baseURL: '/api',
 *   endpoints: {
 *     list: '/locales',
 *     message: (locale, ns) => `/messages/${locale}/${ns}`,
 *     userInfo: '/user/profile',
 *   },
 *   locale: {
 *     supported: ['zh-CN', 'en-US', 'ja-JP'],
 *     // disableRemote: true, // 仅使用本地 supported 列表时可开启
 *     adapter: (data: any) => {
 *       const list = Array.isArray(data?.locales) ? data.locales : []
 *       return list.map((item: any) => ({
 *         code: item.code,
 *         label: item.name,
 *         isDefault: item.isDefault,
 *       }))
 *     },
 *     resolveDefault: (locales) => locales.find(l => l.isDefault)?.code,
 *   },
 *   messages: {
 *     local: localMessages,
 *     disableRemote: false,
 *     // loader: async (locale, ns, url) => {
 *     //   const res = await myRequest(url, { method: 'GET' })
 *     //   return res.data as MessageResource
 *     // },
 *   },
 *   storage: {
 *     type: 'localStorage',
 *     keyPrefix: 'app_i18n',
 *     maxAge: 24 * 60 * 60 * 1000,
 *     quota: 500,
 *   },
 *   adapters: {
 *     message: (data: any): MessageResource => {
 *       if (data?.data && typeof data.data === 'object') return data.data
 *       return data
 *     },
 *     userInfo: (data: any) => data?.language ?? data?.lang,
 *   },
 *   defaultNamespace: 'common',
 *   retries: 2,
 *   enableSync: true,
 *   interceptor: {
 *     enabled: true,
 *     // rules: ['/api/messages', '/api/locales'],
 *     negate: false,
 *     langHeader: 'X-Lang',
 *     timezoneHeader: 'X-Timezone',
 *   },
 *   auth: {
 *     headerName: 'Authorization',
 *     tokenStorageKey: 'APP_TOKEN',
 *     // token: 'Bearer xxx',
 *   },
 *   i18nextOptions: {
 *     // 自定义 i18next 选项
 *   },
 * })
 * ```
 */

/**
 * 完整初始化配置示例（Vue 侧，可作为参考）
 *
 * 示例仅为文档用途，不会参与运行时逻辑。
 *
 * ```ts
 * // i18n.ts
 * import { createApp } from 'vue'
 * import { createI18n as createVueI18n } from 'vue-i18n'
 * import { installI18n } from '@supernova/i18n-sdk/vue'
 * import type { MessageResource } from '@supernova/i18n-sdk/core'
 * import App from './App.vue'
 *
 * const localMessages: Record<string, Record<string, MessageResource>> = {
 *   'zh-CN': {
 *     common: { hello: '你好', submit: '提交' },
 *   },
 *   'en-US': {
 *     common: { hello: 'Hello', submit: 'Submit' },
 *   },
 * }
 *
 * async function bootstrap() {
 *   const app = createApp(App)
 *
 *   // 创建 Vue I18n 实例（可根据需要自定义）
 *   const vueI18n = createVueI18n({
 *     legacy: false,
 *     locale: 'zh-CN',
 *     fallbackLocale: 'en-US',
 *     messages: {}, // 由 SDK 在运行时填充
 *   })
 *
 *   app.use(vueI18n)
 *
 *   // 安装 SDK（内部会创建 I18nCore 并绑定到 Vue I18n 上）
 *   await installI18n(app, {
 *     defaultLocale: 'zh-CN',
 *     fallbackLocale: 'en-US',
 *     baseURL: '/api',
 *     endpoints: {
 *       list: '/locales',
 *       message: (locale, ns) => `/messages/${locale}/${ns}`,
 *       userInfo: '/user/profile',
 *     },
 *     locale: {
 *       supported: ['zh-CN', 'en-US', 'ja-JP'],
 *       // disableRemote: true,
 *       adapter: (data: any) => {
 *         const list = Array.isArray(data?.locales) ? data.locales : []
 *         return list.map((item: any) => ({
 *           code: item.code,
 *           label: item.name,
 *           isDefault: item.isDefault,
 *         }))
 *       },
 *       resolveDefault: (locales) => locales.find(l => l.isDefault)?.code,
 *     },
 *     messages: {
 *       local: localMessages,
 *       disableRemote: false,
 *       // loader: async (locale, ns, url) => {
 *       //   const res = await myRequest(url, { method: 'GET' })
 *       //   return res.data as MessageResource
 *       // },
 *     },
 *     storage: {
 *       type: 'localStorage',
 *       keyPrefix: 'app_i18n',
 *       maxAge: 24 * 60 * 60 * 1000,
 *       quota: 500,
 *     },
 *     adapters: {
 *       message: (data: any): MessageResource => {
 *         if (data?.data && typeof data.data === 'object') return data.data
 *         return data
 *       },
 *       userInfo: (data: any) => data?.language ?? data?.lang,
 *     },
 *     defaultNamespace: 'common',
 *     retries: 2,
 *     enableSync: true,
 *     interceptor: {
 *       enabled: true,
 *       // rules: ['/api/messages', '/api/locales'],
 *       negate: false,
 *       langHeader: 'X-Lang',
 *       timezoneHeader: 'X-Timezone',
 *     },
 *     auth: {
 *       headerName: 'Authorization',
 *       tokenStorageKey: 'APP_TOKEN',
 *       // token: 'Bearer xxx',
 *     },
 *   })
 *
 *   app.mount('#app')
 * }
 *
 * bootstrap()
 * ```
 */

/**
 * 合并后的完整配置类型（所有可选字段已填充默认值）
 */
export interface I18nResolvedConfig extends I18nCoreConfig {
  storage: Required<Pick<I18nCoreConfig['storage'], 'type' | 'keyPrefix' | 'maxAge'>> & Pick<I18nCoreConfig['storage'], 'quota'>
  defaultNamespace: string
  retries: number
  enableSync: boolean
  interceptor: Required<Omit<InterceptorConfig, 'rules'>> & Pick<InterceptorConfig, 'rules'>
  auth?: {
    headerName: string
    token?: string
    tokenStorageKey?: string
  }
}

/**
 * 拼接 baseURL 和路径，处理 / 衔接
 */
function joinURL(base: string, path: string): string {
  if (!base)
    return path
  // 如果 path 已经是完整 URL，不拼接
  if (/^https?:\/\//.test(path))
    return path
  const normalizedBase = base.endsWith('/') ? base.slice(0, -1) : base
  const normalizedPath = path.startsWith('/') ? path : `/${path}`
  return `${normalizedBase}${normalizedPath}`
}

/**
 * 将用户传入的部分配置与默认值合并，返回完整配置
 */
export function resolveConfig(config: I18nCoreConfig): I18nResolvedConfig {
  const base = config.baseURL ?? ''
  const originalMessage = config.endpoints.message

  return {
    ...config,
    baseURL: base,
    endpoints: {
      ...config.endpoints,
      list: joinURL(base, config.endpoints.list),
      message: (locale: string, ns: string) => joinURL(base, originalMessage(locale, ns)),
      userInfo: config.endpoints.userInfo ? joinURL(base, config.endpoints.userInfo) : undefined,
    },
    storage: {
      ...config.storage,
      type: config.storage.type ?? I18N_DEFAULTS.storageType,
    },
    defaultNamespace: config.defaultNamespace ?? I18N_DEFAULTS.defaultNamespace,
    retries: config.retries ?? I18N_DEFAULTS.retries,
    enableSync: config.enableSync ?? I18N_DEFAULTS.enableSync,
    interceptor: {
      ...I18N_DEFAULTS.interceptor,
      ...config.interceptor,
    },
    auth: config.auth
      ? {
          ...I18N_DEFAULTS.auth,
          ...config.auth,
        }
      : undefined,
  }
}
