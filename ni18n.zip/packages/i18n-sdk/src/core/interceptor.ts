/**
 * 拦截规则匹配模式
 * - string: URL 包含该字符串则匹配
 * - RegExp: URL 匹配该正则则匹配
 * - (url: string) => boolean: 自定义匹配函数
 */
export type InterceptorRule = string | RegExp | ((url: string) => boolean)

/**
 * 拦截器配置
 */
export interface InterceptorConfig {
  /** 是否启用拦截器，默认 true */
  enabled?: boolean
  /** 拦截规则列表，未配置则拦截所有请求 */
  rules?: InterceptorRule[]
  /** 规则取反：true 表示不拦截匹配规则的请求（排除模式），默认 false */
  negate?: boolean
  /** 自定义请求头名，默认 'X-Lang' */
  langHeader?: string
  /** 自定义时区请求头名，默认 'X-Timezone' */
  timezoneHeader?: string
}

/**
 * 请求拦截器 — 自动向 XHR 和 Fetch 请求注入语言 & 时区请求头
 *
 * 策略：
 * - 无 rules：拦截所有请求
 * - 有 rules + negate=false（默认）：仅拦截匹配规则的请求
 * - 有 rules + negate=true：拦截不匹配规则的请求（排除模式）
 */
export class RequestInterceptor {
  private _config: Required<Omit<InterceptorConfig, 'rules'>> & Pick<InterceptorConfig, 'rules'>
  private _getLocale: () => string
  private _originalFetch: typeof fetch | null = null
  private _originalXHROpen: typeof XMLHttpRequest.prototype.open | null = null
  private _installed = false
  /** 用户自定义请求头（可在初始化后动态修改） */
  private _customHeaders: Map<string, string> = new Map()

  constructor(getLocale: () => string, config: Required<Omit<InterceptorConfig, 'rules'>> & Pick<InterceptorConfig, 'rules'>) {
    this._getLocale = getLocale
    this._config = config
  }

  /**
   * 安装拦截器（劫持 fetch 和 XMLHttpRequest）
   */
  install(): void {
    if (!this._config.enabled || this._installed)
      return
    if (typeof globalThis === 'undefined')
      return

    this._installFetch()
    this._installXHR()
    this._installed = true
  }

  /**
   * 卸载拦截器（恢复原始 fetch 和 XMLHttpRequest）
   */
  uninstall(): void {
    if (!this._installed)
      return

    if (this._originalFetch) {
      globalThis.fetch = this._originalFetch
      this._originalFetch = null
    }

    if (this._originalXHROpen) {
      XMLHttpRequest.prototype.open = this._originalXHROpen
      this._originalXHROpen = null
    }

    this._installed = false
  }

  /**
   * 设置自定义请求头（会注入到所有被拦截的请求中）
   *
   * @example
   * // 设置 Authorization
   * interceptor.setHeader('Authorization', 'Bearer xxx')
   */
  setHeader(name: string, value: string): void {
    this._customHeaders.set(name, value)
  }

  /**
   * 移除自定义请求头
   */
  removeHeader(name: string): void {
    this._customHeaders.delete(name)
  }

  /**
   * 批量设置自定义请求头（会与已有的合并，相同 key 会覆盖）
   */
  setHeaders(headers: Record<string, string>): void {
    for (const [key, value] of Object.entries(headers)) {
      this._customHeaders.set(key, value)
    }
  }

  /**
   * 获取当前所有自定义请求头的快照
   */
  getCustomHeaders(): Record<string, string> {
    return Object.fromEntries(this._customHeaders)
  }

  /**
   * 判断指定 URL 是否需要拦截
   */
  shouldIntercept(url: string): boolean {
    const { rules, negate } = this._config

    // 无规则 → 全部拦截
    if (!rules || rules.length === 0)
      return true

    const matched = rules.some((rule) => {
      if (typeof rule === 'string')
        return url.includes(rule)
      if (rule instanceof RegExp)
        return rule.test(url)
      if (typeof rule === 'function')
        return rule(url)
      return false
    })

    // negate=true：匹配的不拦截，不匹配的拦截
    return negate ? !matched : matched
  }

  // ─── 内部方法 ───

  private _getHeaders(): Record<string, string> {
    return {
      [this._config.langHeader]: this._getLocale(),
      [this._config.timezoneHeader]: Intl.DateTimeFormat().resolvedOptions().timeZone,
      ...Object.fromEntries(this._customHeaders),
    }
  }

  private _installFetch(): void {
    if (typeof globalThis.fetch === 'undefined')
      return

    this._originalFetch = globalThis.fetch

    const self = this
    const originalFetch = this._originalFetch

    globalThis.fetch = function (input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
      const url = typeof input === 'string'
        ? input
        : input instanceof URL
          ? input.href
          : input instanceof Request
            ? input.url
            : String(input)

      if (self.shouldIntercept(url)) {
        const headers = new Headers(init?.headers)
        const extraHeaders = self._getHeaders()
        for (const [key, value] of Object.entries(extraHeaders)) {
          if (!headers.has(key))
            headers.set(key, value)
        }
        init = { ...init, headers }
      }

      return originalFetch.call(globalThis, input, init)
    }
  }

  private _installXHR(): void {
    if (typeof XMLHttpRequest === 'undefined')
      return

    this._originalXHROpen = XMLHttpRequest.prototype.open

    const self = this
    const originalOpen = this._originalXHROpen

    XMLHttpRequest.prototype.open = function (this: XMLHttpRequest, ...args: any[]) {
      const url = String(args[1] ?? '')

      if (self.shouldIntercept(url)) {
        const originalSend = this.send

        this.send = function (body?: XMLHttpRequestBodyInit | Document | null) {
          // 在 send 时获取最新 headers（而非 open 时），确保 locale 变更后注入最新值
          const extraHeaders = self._getHeaders()
          for (const [key, value] of Object.entries(extraHeaders)) {
            try {
              this.setRequestHeader(key, value)
            }
            catch {
              // 部分状态下无法设置 header，静默忽略
            }
          }
          return originalSend.call(this, body)
        }
      }

      return originalOpen.apply(this, args as any)
    }
  }
}
