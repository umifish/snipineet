import { defineConfig } from 'tsup'

export default defineConfig([
  // Core (通用部分) — 无外部框架依赖
  {
    entry: { 'core/index': 'src/core/index.ts' },
    format: ['esm', 'cjs'],
    outExtension: ({ format }) => ({ js: format === 'esm' ? '.mjs' : '.cjs' }),
    dts: true,
    clean: true,
    treeshake: true,
    splitting: false,
  },
  // Vue3 版本
  {
    entry: { 'vue/index': 'src/vue/index.ts' },
    format: ['esm', 'cjs'],
    outExtension: ({ format }) => ({ js: format === 'esm' ? '.mjs' : '.cjs' }),
    dts: true,
    treeshake: true,
    splitting: false,
    external: ['vue', 'vue-i18n'],
  },
  // React18+ 版本
  {
    entry: { 'react/index': 'src/react/index.ts' },
    format: ['esm', 'cjs'],
    outExtension: ({ format }) => ({ js: format === 'esm' ? '.mjs' : '.cjs' }),
    dts: true,
    treeshake: true,
    splitting: false,
    external: ['react', 'react-dom', 'i18next', 'react-i18next'],
  },
])
