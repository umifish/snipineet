# @supernova/i18n-editor

国际化多语言文案编辑器 SDK — 通用内核 + Vue3 (Element Plus) + React (Semi Design) 三端支持。

提供开箱即用的文案库 CRUD 弹窗组件和输入框包裹组件，可快速嵌入任何管理系统。

## 特性

- **框架无关内核**：`I18nEditorCore` 封装文案查询、分页、缓存（LRU + TTL）和 CRUD 事件
- **Vue3 + Element Plus**：5 个开箱即用的组件，支持 v-model 双向绑定
- **React + Semi Design**：5 个对等的 React 组件，使用 callback props
- **接口适配器模式**：通过 `PhraseApiAdapter` 对接任意后端 API
- **无滚动位移**：IntersectionObserver 驱动的无限滚动加载
- **编辑面板**：滑入式编辑/新增面板，支持多语言文本同时编辑
- **零运行时依赖**：核心包无第三方依赖，框架包仅 peer 依赖

## 安装

```bash
pnpm add @supernova/i18n-editor
```

按需安装框架 peer 依赖：

```bash
# Vue3
pnpm add vue element-plus

# React
pnpm add react react-dom @douyinfe/semi-ui
```

## 快速上手

### 1. 实现 API 适配器

```ts
import type { PhraseApiAdapter } from '@supernova/i18n-editor'

const api: PhraseApiAdapter = {
  async query(params) {
    const res = await fetch(`/api/phrases?keyword=${params.keyword}&page=${params.page}&pageSize=${params.pageSize}`)
    return res.json()
  },
  async create(params) {
    const res = await fetch('/api/phrases', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(params) })
    return res.json()
  },
  async update(params) {
    const res = await fetch(`/api/phrases/${params.id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(params) })
    return res.json()
  },
  async remove(id) {
    await fetch(`/api/phrases/${id}`, { method: 'DELETE' })
  },
}
```

### 2. 创建编辑器实例

```ts
import { I18nEditorCore } from '@supernova/i18n-editor'

const editor = new I18nEditorCore({
  api,
  locales: [
    { code: 'zh-CN', label: '中文' },
    { code: 'en-US', label: 'English' },
    { code: 'ja-JP', label: '日本語' },
  ],
  pageSize: 20,       // 默认 20
  cacheMaxSize: 200,  // LRU 缓存上限，默认 200
  cacheTTL: 300000,   // 缓存 TTL，默认 5 分钟
})
```

### 3. Vue3 用法

```vue
<script setup lang="ts">
import { ref } from 'vue'
import { I18nFieldWrapper } from '@supernova/i18n-editor/vue'
import type { PhraseEntry } from '@supernova/i18n-editor/vue'

const formTitle = ref('')

function onSelect(entry: PhraseEntry) {
  console.log('选中文案:', entry.key, entry.translations)
}
</script>

<template>
  <I18nFieldWrapper v-model="formTitle" :editor="editor" @select="onSelect">
    <ElInput v-model="formTitle" placeholder="请输入标题" />
  </I18nFieldWrapper>
</template>
```

也可以单独使用弹窗组件：

```vue
<script setup lang="ts">
import { ref } from 'vue'
import { PhraseDialog } from '@supernova/i18n-editor/vue'

const visible = ref(false)
</script>

<template>
  <ElButton @click="visible = true">打开文案库</ElButton>
  <PhraseDialog v-model="visible" :editor="editor" :locales="editor.locales" @confirm="onConfirm" />
</template>
```

### 4. React 用法

```tsx
import { useState } from 'react'
import { I18nFieldWrapper } from '@supernova/i18n-editor/react'
import { Input } from '@douyinfe/semi-ui'
import type { PhraseEntry } from '@supernova/i18n-editor/react'

function MyForm() {
  const [title, setTitle] = useState('')

  const handleSelect = (entry: PhraseEntry) => {
    console.log('选中文案:', entry.key, entry.translations)
  }

  return (
    <I18nFieldWrapper value={title} editor={editor} onChange={setTitle} onSelect={handleSelect}>
      <Input value={title} onChange={setTitle} placeholder="请输入标题" />
    </I18nFieldWrapper>
  )
}
```

单独使用弹窗：

```tsx
import { useState } from 'react'
import { PhraseDialog } from '@supernova/i18n-editor/react'

function App() {
  const [visible, setVisible] = useState(false)
  return (
    <>
      <Button onClick={() => setVisible(true)}>打开文案库</Button>
      <PhraseDialog
        visible={visible}
        editor={editor}
        locales={editor.locales}
        onClose={() => setVisible(false)}
        onConfirm={(entry) => console.log(entry)}
      />
    </>
  )
}
```

## API

### I18nEditorCore

| 方法 | 说明 |
|------|------|
| `query(params)` | 分页查询，优先命中缓存 |
| `create(params)` | 新增文案，自动失效缓存 |
| `update(params)` | 更新文案，自动失效缓存 |
| `remove(id)` | 删除文案，自动失效缓存 |
| `on(event, fn)` | 监听事件 (`select` / `create` / `update` / `delete` / `error`) |
| `off(event, fn)` | 移除监听 |
| `clearCache()` | 手动清空缓存 |
| `destroy()` | 销毁实例，清空缓存和事件 |

### Vue 组件

| 组件 | 说明 |
|------|------|
| `I18nFieldWrapper` | 输入框包裹器，slot 模式。支持 `v-model`、`@select`、`@clear` |
| `PhraseDialog` | 文案库弹窗：搜索 + 语言列筛选 + 无限滚动 + 选中确认 + 编辑/新增/删除 |
| `PhraseEditPanel` | 编辑/新增面板（通常内嵌在 PhraseDialog 中） |
| `I18nIcon` | 国际化 SVG 图标 |
| `ClearIcon` | 清除 SVG 图标 |

### React 组件

| 组件 | 说明 |
|------|------|
| `I18nFieldWrapper` | 输入框包裹器，children 组合模式。通过 `onChange`、`onSelect`、`onClear` 回调传值 |
| `PhraseDialog` | 文案库弹窗，同 Vue 版功能 |
| `PhraseEditPanel` | 编辑/新增面板 |
| `I18nIcon` | 国际化 SVG 图标 |
| `ClearIcon` | 清除 SVG 图标 |

### 类型

```ts
interface PhraseEntry {
  id: string
  key: string
  translations: Record<string, string>
  createdAt?: string
  updatedAt?: string
}

interface PhraseApiAdapter {
  query(params: PhraseQuery): Promise<PhrasePageResult>
  create(params: PhraseCreateParams): Promise<PhraseEntry>
  update(params: PhraseUpdateParams): Promise<PhraseEntry>
  remove(id: string): Promise<void>
}

interface I18nEditorConfig {
  api: PhraseApiAdapter
  locales: EditorLocaleItem[]
  pageSize?: number       // 默认 20
  cacheMaxSize?: number   // 默认 200
  cacheTTL?: number       // 默认 300000 (5 分钟)
}

interface EditorLocaleItem {
  code: string   // 'zh-CN'
  label: string  // '中文'
}
```

## 构建

```bash
pnpm --filter @supernova/i18n-editor build
```

产物：
- `dist/core/` — 框架无关核心（ESM + CJS + DTS）
- `dist/vue/` — Vue3 组件（ESM + CJS + CSS + DTS）
- `dist/react/` — React 组件（ESM + CJS + DTS）

## License

MIT
