import type { I18nFieldRules, I18nValidationRule } from './types'

/**
 * 执行字段校验
 *
 * 按顺序依次执行通用规则（'*'）和当前 locale 规则，
 * 遇到第一条不通过的规则即返回错误信息。
 *
 * @returns 错误信息字符串，校验通过返回 null
 */
export async function validateField(
  value: string,
  locale: string,
  rules: I18nFieldRules,
): Promise<string | null> {
  // 通用规则 + 当前语言规则
  const combined: I18nValidationRule[] = [
    ...(rules['*'] || []),
    ...(locale && rules[locale] ? rules[locale] : []),
  ]

  for (const rule of combined) {
    const msg = await checkRule(rule, value, locale)
    if (msg) return msg
  }

  return null
}

async function checkRule(
  rule: I18nValidationRule,
  value: string,
  locale: string,
): Promise<string | null> {
  if (rule.required && (!value || !value.trim())) {
    return rule.message || '此字段为必填项'
  }

  // 非必填且为空时跳过后续校验
  if (!value) return null

  if (rule.min != null && value.length < rule.min) {
    return rule.message || `最少 ${rule.min} 个字符`
  }

  if (rule.max != null && value.length > rule.max) {
    return rule.message || `最多 ${rule.max} 个字符`
  }

  if (rule.pattern && !rule.pattern.test(value)) {
    return rule.message || '格式不正确'
  }

  if (rule.validator) {
    const result = await rule.validator(value, locale)
    if (result === false) return rule.message || '校验失败'
    if (typeof result === 'string') return result
  }

  return null
}
