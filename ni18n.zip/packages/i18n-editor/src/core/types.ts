/**
 * 单条文案记录
 */
export interface PhraseEntry {
  /** 文案唯一 ID */
  id: string
  /** 文案 key（如 'common.submit'） */
  key: string
  /** 各语言翻译 { 'zh-CN': '提交', 'en-US': 'Submit' } */
  translations: Record<string, string>
  /** 创建时间 ISO */
  createdAt?: string
  /** 更新时间 ISO */
  updatedAt?: string
}

/**
 * 文案查询参数
 */
export interface PhraseQuery {
  /** 搜索关键词（匹配 key 或任意语言的翻译内容） */
  keyword?: string
  /** 按语言筛选 */
  locale?: string
  /** 分页: 当前页码 (从 1 开始) */
  page?: number
  /** 分页: 每页大小 */
  pageSize?: number
}

/**
 * 分页查询结果
 */
export interface PhrasePageResult {
  /** 文案列表 */
  list: PhraseEntry[]
  /** 总条数 */
  total: number
  /** 当前页码 */
  page: number
  /** 每页大小 */
  pageSize: number
}

/**
 * 新增文案参数
 */
export interface PhraseCreateParams {
  key: string
  translations: Record<string, string>
}

/**
 * 更新文案参数
 */
export interface PhraseUpdateParams {
  id: string
  key?: string
  translations?: Record<string, string>
}

/**
 * 文案库 API 适配器 — 对接后端接口
 */
export interface PhraseApiAdapter {
  /** 分页查询文案 */
  query(params: PhraseQuery): Promise<PhrasePageResult>
  /** 新增文案 */
  create(params: PhraseCreateParams): Promise<PhraseEntry>
  /** 更新文案 */
  update(params: PhraseUpdateParams): Promise<PhraseEntry>
  /** 删除文案 */
  remove(id: string): Promise<void>
}

/**
 * 编辑器配置
 */
export interface I18nEditorConfig {
  /** 文案库 API 适配器 */
  api: PhraseApiAdapter
  /** 支持的语言列表 */
  locales: EditorLocaleItem[]
  /** 默认每页大小 */
  pageSize?: number
  /** 缓存最大条数 (0 = 不限) */
  cacheMaxSize?: number
  /** 缓存过期时间 (ms), 默认 5 分钟 */
  cacheTTL?: number
}

/**
 * 语言条目（用于下拉选择和编辑表单标签）
 */
export interface EditorLocaleItem {
  /** 语言标识，如 'zh-CN' */
  code: string
  /** 显示名称，如 '中文' */
  label: string
}

/**
 * 国际化字段完整值 — 打开弹窗时传入 / 选中文案后输出
 *
 * @example
 * ```ts
 * {
 *   displayText: '张三',
 *   i18nCode: '@i18n.common.name',
 *   translations: { 'zh-CN': '张三', 'en-US': 'Zhang San' }
 * }
 * ```
 */
export interface I18nFieldValue {
  /** 当前语言的显示文案 */
  displayText?: string
  /** 国际化编码（如 @i18n.common.name） */
  i18nCode?: string
  /** 所有语言翻译 */
  translations?: Record<string, string>
}

/**
 * 编辑器事件类型
 */
export type EditorEventType = 'select' | 'create' | 'update' | 'delete' | 'error'

/**
 * 事件回调映射
 */
export interface EditorEventMap {
  select: { entry: PhraseEntry }
  create: { entry: PhraseEntry }
  update: { entry: PhraseEntry }
  delete: { id: string }
  error: { error: unknown; action: string }
}

// ─── 校验规则 ───

/**
 * 单条校验规则
 */
export interface I18nValidationRule {
  /** 是否必填 */
  required?: boolean
  /** 最小长度 */
  min?: number
  /** 最大长度 */
  max?: number
  /** 正则校验 */
  pattern?: RegExp
  /** 自定义校验函数，返回 true 表示通过，返回 string 表示错误信息 */
  validator?: (value: string, locale: string) => boolean | string | Promise<boolean | string>
  /** 错误提示信息 */
  message?: string
}

/**
 * 按语言映射的校验规则
 *
 * - 以 locale code 为键（如 'zh-CN'、'en-US'）配置对应规则
 * - 特殊键 '*' 表示对所有语言生效的通用规则
 *
 * @example
 * ```ts
 * const rules: I18nFieldRules = {
 *   '*': [{ required: true, message: '不能为空' }],
 *   'zh-CN': [{ max: 10, message: '中文最多10个字符' }],
 *   'en-US': [{ pattern: /^[a-zA-Z\s]+$/, message: 'English only' }],
 * }
 * ```
 */
export type I18nFieldRules = Record<string, I18nValidationRule[]>
