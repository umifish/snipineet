import type {
  PhraseApiAdapter,
  PhraseCreateParams,
  PhraseEntry,
  PhrasePageResult,
  PhraseQuery,
  PhraseUpdateParams,
} from './types'

/**
 * 创建默认的 PhraseApiAdapter（基于标准 REST 接口）
 *
 * 默认接口约定：
 * - GET    {baseUrl}?keyword=&page=&pageSize=&locale=  → PhrasePageResult
 * - POST   {baseUrl}/create                            → PhraseEntry
 * - PUT    {baseUrl}/update                             → PhraseEntry
 * - DELETE {baseUrl}/delete?id=                         → void
 *
 * @param baseUrl 接口基础路径，默认 '/api/phrases'
 */
export function createDefaultPhraseApi(baseUrl = '/api/phrases'): PhraseApiAdapter {
  return {
    async query(params: PhraseQuery): Promise<PhrasePageResult> {
      const qs = new URLSearchParams({
        keyword: params.keyword ?? '',
        page: String(params.page ?? 1),
        pageSize: String(params.pageSize ?? 20),
      })
      if (params.locale) qs.set('locale', params.locale)
      const res = await fetch(`${baseUrl}?${qs}`)
      if (!res.ok) throw new Error(`Query failed: ${res.status}`)
      return res.json()
    },

    async create(params: PhraseCreateParams): Promise<PhraseEntry> {
      const res = await fetch(`${baseUrl}/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      })
      if (!res.ok) throw new Error(`Create failed: ${res.status}`)
      return res.json()
    },

    async update(params: PhraseUpdateParams): Promise<PhraseEntry> {
      const res = await fetch(`${baseUrl}/update`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      })
      if (!res.ok) throw new Error(`Update failed: ${res.status}`)
      return res.json()
    },

    async remove(id: string): Promise<void> {
      const res = await fetch(`${baseUrl}/delete?id=${encodeURIComponent(id)}`, { method: 'DELETE' })
      if (!res.ok) throw new Error(`Delete failed: ${res.status}`)
    },
  }
}

/** 默认语言列表 */
export const DEFAULT_LOCALES = [
  { code: 'zh-CN', label: '中文' },
  { code: 'en-US', label: 'English' },
]
