import type {
  EditorEventMap,
  EditorEventType,
  I18nEditorConfig,
  EditorLocaleItem,
  PhraseCreateParams,
  PhraseEntry,
  PhrasePageResult,
  PhraseQuery,
  PhraseUpdateParams,
} from './types'
import { PhraseCache } from './cache'

/**
 * i18n 文案编辑器核心引擎（框架无关）
 *
 * 职责：
 * - 文案库 CRUD 操作
 * - 查询分页 + 缓存
 * - 事件分发
 */
export class I18nEditorCore {
  private _config: Required<Pick<I18nEditorConfig, 'pageSize' | 'cacheMaxSize' | 'cacheTTL'>> & I18nEditorConfig
  private _cache: PhraseCache
  private _listeners: Map<EditorEventType, Set<(payload: any) => void>> = new Map()

  constructor(config: I18nEditorConfig) {
    this._config = {
      pageSize: 20,
      cacheMaxSize: 200,
      cacheTTL: 5 * 60 * 1000,
      ...config,
    }
    this._cache = new PhraseCache(this._config.cacheMaxSize, this._config.cacheTTL)
  }

  // ─── 属性 ───

  get locales(): EditorLocaleItem[] {
    return this._config.locales
  }

  get pageSize(): number {
    return this._config.pageSize
  }

  // ─── 查询 ───

  /**
   * 分页查询文案，优先读缓存
   */
  async query(params: PhraseQuery): Promise<PhrasePageResult> {
    const keyword = params.keyword ?? ''
    const page = params.page ?? 1
    const pageSize = params.pageSize ?? this._config.pageSize

    // 读缓存
    const cached = this._cache.get(keyword, page)
    if (cached) {
      return { list: cached.data, total: cached.total, page, pageSize }
    }

    try {
      const result = await this._config.api.query({ keyword, page, pageSize, locale: params.locale })
      this._cache.set(keyword, page, result.total, result.list)
      return result
    }
    catch (error) {
      this._emit('error', { error, action: 'query' })
      throw error
    }
  }

  // ─── 新增 ───

  async create(params: PhraseCreateParams): Promise<PhraseEntry> {
    try {
      const entry = await this._config.api.create(params)
      // 新增后使缓存失效
      this._cache.invalidate()
      this._emit('create', { entry })
      return entry
    }
    catch (error) {
      this._emit('error', { error, action: 'create' })
      throw error
    }
  }

  // ─── 更新 ───

  async update(params: PhraseUpdateParams): Promise<PhraseEntry> {
    try {
      const entry = await this._config.api.update(params)
      this._cache.invalidate()
      this._emit('update', { entry })
      return entry
    }
    catch (error) {
      this._emit('error', { error, action: 'update' })
      throw error
    }
  }

  // ─── 删除 ───

  async remove(id: string): Promise<void> {
    try {
      await this._config.api.remove(id)
      this._cache.invalidate()
      this._emit('delete', { id })
    }
    catch (error) {
      this._emit('error', { error, action: 'remove' })
      throw error
    }
  }

  // ─── 事件 ───

  on<T extends EditorEventType>(event: T, listener: (payload: EditorEventMap[T]) => void): () => void {
    if (!this._listeners.has(event))
      this._listeners.set(event, new Set())
    this._listeners.get(event)!.add(listener)
    return () => this._listeners.get(event)?.delete(listener)
  }

  off<T extends EditorEventType>(event: T, listener: (payload: EditorEventMap[T]) => void): void {
    this._listeners.get(event)?.delete(listener)
  }

  private _emit<T extends EditorEventType>(event: T, payload: EditorEventMap[T]): void {
    this._listeners.get(event)?.forEach(fn => fn(payload))
  }

  // ─── 缓存控制 ───

  clearCache(): void {
    this._cache.clear()
  }

  destroy(): void {
    this._cache.clear()
    this._listeners.clear()
  }
}
