import type { PhraseEntry } from './types'

interface CacheItem {
  data: PhraseEntry[]
  keyword: string
  page: number
  total: number
  timestamp: number
}

/**
 * 文案库缓存管理
 *
 * - LRU 淘汰策略
 * - 过期自动清除
 * - 按关键词+页码缓存查询结果
 */
export class PhraseCache {
  private _cache: Map<string, CacheItem> = new Map()
  private _maxSize: number
  private _ttl: number

  constructor(maxSize = 200, ttl = 5 * 60 * 1000) {
    this._maxSize = maxSize
    this._ttl = ttl
  }

  private _key(keyword: string, page: number): string {
    return `${keyword}::${page}`
  }

  /**
   * 读取缓存
   */
  get(keyword: string, page: number): CacheItem | null {
    const key = this._key(keyword, page)
    const item = this._cache.get(key)
    if (!item) return null

    // 过期
    if (this._ttl > 0 && Date.now() - item.timestamp > this._ttl) {
      this._cache.delete(key)
      return null
    }

    // LRU: 移到末尾
    this._cache.delete(key)
    this._cache.set(key, item)
    return item
  }

  /**
   * 写入缓存
   */
  set(keyword: string, page: number, total: number, data: PhraseEntry[]): void {
    const key = this._key(keyword, page)

    // LRU 淘汰
    if (this._maxSize > 0 && this._cache.size >= this._maxSize) {
      const oldest = this._cache.keys().next().value!
      this._cache.delete(oldest)
    }

    this._cache.set(key, {
      data,
      keyword,
      page,
      total,
      timestamp: Date.now(),
    })
  }

  /**
   * 使指定关键词的所有页缓存失效
   */
  invalidate(keyword?: string): void {
    if (keyword === undefined) {
      this._cache.clear()
      return
    }
    for (const [key] of this._cache) {
      if (key.startsWith(`${keyword}::`)) {
        this._cache.delete(key)
      }
    }
  }

  /**
   * 清空全部缓存
   */
  clear(): void {
    this._cache.clear()
  }

  get size(): number {
    return this._cache.size
  }
}
