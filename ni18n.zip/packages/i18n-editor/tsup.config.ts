import { defineConfig } from 'tsup'

export default defineConfig({
  entry: { 'core/index': 'src/core/index.ts' },
  format: ['esm', 'cjs'],
  outExtension: ({ format }) => ({ js: format === 'esm' ? '.mjs' : '.cjs' }),
  dts: true,
  treeshake: true,
  splitting: false,
})
