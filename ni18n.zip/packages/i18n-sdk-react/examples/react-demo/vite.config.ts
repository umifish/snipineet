import { resolve } from 'path'
import { fileURLToPath } from 'url'
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

const __dirname = fileURLToPath(new URL('.', import.meta.url))

function mockApiPlugin() {
  const locales = [
    { code: 'zh-CN', label: '简体中文', isDefault: true },
    { code: 'en-US', label: 'English', isDefault: false },
    { code: 'ko-KR', label: '한국어', isDefault: false },
  ]

  const messages: Record<string, Record<string, Record<string, string>>> = {
    'zh-CN': {
      common: {
        greeting: '你好，世界！',
        welcome: '欢迎使用 i18n SDK',
        switchLang: '切换语言',
        currentLang: '当前语言',
        supportedLangs: '支持的语言',
        description: '这是一个国际化多语言 SDK 演示',
        inputPlaceholder: '请输入内容...',
        submit: '提交',
      },
    },
    'en-US': {
      common: {
        greeting: 'Hello, World!',
        welcome: 'Welcome to i18n SDK',
        switchLang: 'Switch Language',
        currentLang: 'Current Language',
        supportedLangs: 'Supported Languages',
        description: 'This is an i18n SDK demonstration',
        inputPlaceholder: 'Enter something...',
        submit: 'Submit',
      },
    },
    'ko-KR': {
      common: {
        greeting: '안녕하세요, 세계!',
        welcome: 'i18n SDK에 오신 것을 환영합니다',
        switchLang: '언어 전환',
        currentLang: '현재 언어',
        supportedLangs: '지원 언어',
        description: '이것은 국제화 다국어 SDK 데모입니다',
        inputPlaceholder: '내용을 입력하세요...',
        submit: '제출',
      },
    },
  }

  const userInfo = { lang: 'zh-CN', name: 'Demo User' }

  return {
    name: 'mock-api',
    configureServer(server: any) {
      server.middlewares.use('/api/locales', (_req: any, res: any) => {
        res.setHeader('Content-Type', 'application/json')
        res.end(JSON.stringify(locales))
      })

      server.middlewares.use('/api/user/profile', (_req: any, res: any) => {
        res.setHeader('Content-Type', 'application/json')
        res.end(JSON.stringify(userInfo))
      })

      server.middlewares.use((req: any, res: any, next: any) => {
        const match = req.url?.match(/^\/api\/messages\/([^/]+)\/([^/]+)/)
        if (match) {
          const [, locale, ns] = match
          const data = messages[locale]?.[ns] ?? {}
          res.setHeader('Content-Type', 'application/json')
          res.end(JSON.stringify(data))
        }
        else {
          next()
        }
      })
    },
  }
}

export default defineConfig({
  plugins: [react(), mockApiPlugin()],
  resolve: {
    alias: {
      '@supernova/i18n-sdk-react': resolve(__dirname, '../../src/index.ts'),
    },
  },
  server: {
    port: 5372,
    host: true,
  },
})
