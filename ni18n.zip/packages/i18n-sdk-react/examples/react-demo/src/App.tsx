import { useTranslation, useLocale, useI18nManager } from '@supernova/i18n-sdk-react'

export default function App() {
  const { t } = useTranslation()
  const { locale, switchLocale } = useLocale()
  const manager = useI18nManager()

  const supportedLocales = manager.core.supportedLocales
  const localeInfoList = manager.core.localeInfoList

  return (
    <div style={styles.app}>
      <h1 style={styles.h1}>🌍 {t('greeting')}</h1>
      <p style={styles.desc}>{t('description')}</p>

      <div style={styles.card}>
        <h2 style={styles.h2}>{t('welcome')}</h2>

        <div style={styles.info}>
          <p style={styles.infoP}>
            <strong>{t('currentLang')}:</strong> {locale}
          </p>
          <p style={styles.infoP}>
            <strong>{t('supportedLangs')}:</strong> {supportedLocales.join(', ')}
          </p>
        </div>

        <div>
          <h3 style={styles.h3}>{t('switchLang')}</h3>
          <div style={styles.buttons}>
            {localeInfoList.map((info) => (
              <button
                key={info.code}
                style={{
                  ...styles.button,
                  ...(locale === info.code ? styles.buttonActive : {}),
                }}
                onClick={() => switchLocale(info.code)}
              >
                {info.label || info.code}
              </button>
            ))}
          </div>
        </div>

        <div style={styles.formDemo}>
          <input style={styles.input} placeholder={t('inputPlaceholder')} />
          <button style={styles.submit}>{t('submit')}</button>
        </div>
      </div>
    </div>
  )
}

const styles: Record<string, React.CSSProperties> = {
  app: {
    maxWidth: 600,
    margin: '40px auto',
    padding: 20,
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    color: '#333',
  },
  h1: {
    textAlign: 'center',
    fontSize: '2em',
    marginBottom: 8,
  },
  desc: {
    textAlign: 'center',
    color: '#666',
    marginBottom: 24,
  },
  card: {
    background: '#fff',
    borderRadius: 12,
    padding: 24,
    boxShadow: '0 2px 12px rgba(0, 0, 0, 0.08)',
  },
  h2: {
    marginBottom: 16,
    color: '#1a73e8',
  },
  info: {
    background: '#f8f9fa',
    padding: '12px 16px',
    borderRadius: 8,
    marginBottom: 20,
  },
  infoP: {
    margin: '4px 0',
    fontSize: 14,
  },
  h3: {
    marginBottom: 12,
    fontSize: 16,
  },
  buttons: {
    display: 'flex',
    gap: 8,
    flexWrap: 'wrap',
    marginBottom: 20,
  },
  button: {
    padding: '8px 20px',
    borderWidth: 2,
    borderStyle: 'solid',
    borderColor: '#e0e0e0',
    borderRadius: 8,
    background: '#fff',
    cursor: 'pointer',
    fontSize: 14,
    transition: 'all 0.2s',
  },
  buttonActive: {
    borderColor: '#1a73e8',
    color: '#1a73e8',
    background: '#e8f0fe',
  },
  formDemo: {
    display: 'flex',
    gap: 8,
    marginTop: 8,
  },
  input: {
    flex: 1,
    padding: '8px 12px',
    border: '2px solid #e0e0e0',
    borderRadius: 8,
    fontSize: 14,
    outline: 'none',
  },
  submit: {
    padding: '8px 24px',
    background: '#1a73e8',
    color: '#fff',
    border: 'none',
    borderRadius: 8,
    cursor: 'pointer',
    fontSize: 14,
  },
}
