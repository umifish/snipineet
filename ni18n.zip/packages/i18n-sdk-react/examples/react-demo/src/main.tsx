import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { createI18n, I18nProvider } from '@supernova/i18n-sdk-react'
import type { MessageResource } from '@supernova/i18n-sdk-react'
import App from './App'

const localMessages: Record<string, Record<string, MessageResource>> = {
  'zh-CN': {
    common: {
      greeting: '你好，React Demo！',
      description: '这是一个使用 @supernova/i18n-sdk-react 的简单示例。',
      welcome: '欢迎使用 i18n-sdk',
      currentLang: '当前语言',
      supportedLangs: '支持的语言',
      switchLang: '切换语言',
      inputPlaceholder: '请输入一些内容...',
      submit: '提交',
    },
  },
  'en-US': {
    common: {
      greeting: 'Hello, React Demo!',
      description: 'A simple example powered by @supernova/i18n-sdk-react.',
      welcome: 'Welcome to i18n-sdk',
      currentLang: 'Current language',
      supportedLangs: 'Supported languages',
      switchLang: 'Switch language',
      inputPlaceholder: 'Type something...',
      submit: 'Submit',
    },
  },
}

async function bootstrap() {
  const manager = createI18n({
    defaultLocale: 'zh-CN',
    fallbackLocale: 'en-US',
    baseURL: '/api',
    endpoints: {
      list: '/locales',
      message: (locale, ns) => `/messages/${locale}/${ns}`,
      userInfo: '/user/profile',
    },
    adapters: {
      message: (data: any): MessageResource => {
        if (data?.data && typeof data.data === 'object') return data.data
        const locale = data?.locale as string | undefined
        if (locale && localMessages[locale]?.common)
          return localMessages[locale].common
        return data
      },
    },
    storage: {
      type: 'localStorage',
      keyPrefix: 'react_demo_i18n',
      maxAge: 60 * 60 * 1000,
    },
    interceptor: {
      enabled: true,
    },
  })

  await manager.init()

  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <I18nProvider manager={manager}>
        <App />
      </I18nProvider>
    </StrictMode>,
  )
}

bootstrap()
