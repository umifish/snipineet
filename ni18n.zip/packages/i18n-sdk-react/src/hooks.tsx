import React, { createContext, useCallback, useContext, useEffect, useState } from 'react'
import { I18nextProvider, useTranslation } from 'react-i18next'
import type { I18nReactManager } from './adapter'

export { useTranslation }

const I18nManagerContext = createContext<I18nReactManager | null>(null)

export function I18nProvider({ manager, children }: { manager: I18nReactManager, children: React.ReactNode }) {
  return (
    <I18nManagerContext.Provider value={manager}>
      <I18nextProvider i18n={manager.i18next}>
        {children}
      </I18nextProvider>
    </I18nManagerContext.Provider>
  )
}

export function useI18nManager(): I18nReactManager {
  const manager = useContext(I18nManagerContext)
  if (!manager) {
    throw new Error('[i18n-sdk] I18nReactManager not found. Did you wrap with <I18nProvider>?')
  }
  return manager
}

export function useLocale(): { locale: string, switchLocale: (locale: string) => Promise<boolean> } {
  const manager = useI18nManager()
  const [locale, setLocale] = useState(manager.core.locale)

  useEffect(() => {
    return manager.core.on('localeChange', ({ locale: newLocale }) => {
      setLocale(newLocale)
    })
  }, [manager])

  const switchLocale = useCallback(
    (newLocale: string) => manager.switchLocale(newLocale),
    [manager],
  )

  return { locale, switchLocale }
}

export function useI18nNamespace(ns: string): { ready: boolean, load: () => Promise<boolean>, manager: I18nReactManager } {
  const manager = useI18nManager()
  const [locale, setLocale] = useState(manager.core.locale)
  const [ready, setReady] = useState(() => manager.core.isNamespaceLoaded(locale, ns))

  useEffect(() => {
    return manager.core.on('localeChange', ({ locale: newLocale }) => {
      setLocale(newLocale)
      const loaded = manager.core.isNamespaceLoaded(newLocale, ns)
      setReady(loaded)
    })
  }, [manager, ns])

  const load = useCallback(async () => {
    const success = await manager.loadNamespace(locale, ns)
    setReady(success)
    return success
  }, [manager, locale, ns])

  useEffect(() => {
    if (!manager.core.isNamespaceLoaded(locale, ns)) {
      load()
    }
  }, [locale, ns, load])

  return { ready, load, manager }
}
