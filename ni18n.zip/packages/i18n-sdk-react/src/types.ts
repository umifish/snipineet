import type { I18nCoreConfig } from '@supernova/i18n-sdk'
import type { ReactNode } from 'react'
import type { I18nReactManager } from './adapter'

export interface I18nReactConfig extends I18nCoreConfig {
  /** 回退语言（与 I18nCoreConfig.fallbackLocale 一致，便于类型解析） */
  fallbackLocale: string
  i18nextOptions?: Record<string, any>
}

export interface I18nReactProviderProps {
  manager: I18nReactManager
  children: ReactNode
}
