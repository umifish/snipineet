import i18next from 'i18next'
import type { i18n as I18NextInstance } from 'i18next'
import { initReactI18next } from 'react-i18next'
import { I18nCore } from '@supernova/i18n-sdk'
import type { I18nHooks, LocaleInfo } from '@supernova/i18n-sdk'
import type { I18nReactConfig } from './types'

let _instance: I18nReactManager | null = null

export class I18nReactManager {
  readonly core: I18nCore
  private _i18next!: I18NextInstance
  private _config: I18nReactConfig
  private _unsubscribers: Array<() => void> = []
  private _initialized = false

  constructor(config: I18nReactConfig) {
    this._config = config
    this.core = new I18nCore(config)
  }

  get i18next(): I18NextInstance {
    return this._i18next
  }

  get initialized(): boolean {
    return this._initialized
  }

  get supportedLocales(): string[] {
    return this.core.supportedLocales
  }

  get localeInfoList(): LocaleInfo[] {
    return this.core.localeInfoList
  }

  get locale(): string {
    return this.core.locale
  }

  setAuthToken(token: string, persist = false): void {
    this.core.setAuthToken(token, persist)
  }

  clearAuthToken(clearStorage = false): void {
    this.core.clearAuthToken(clearStorage)
  }

  t(key: string, options?: Record<string, any>): string {
    return this._i18next.t(key, options)
  }

  async init(hooks?: I18nHooks): Promise<I18NextInstance> {
    if (_instance && _instance !== this) {
      _instance.destroy()
    }

    await this.core.init(hooks)

    this._i18next = i18next.createInstance()

    await this._i18next
      .use(initReactI18next)
      .init({
        lng: this.core.locale,
        fallbackLng: this._config.fallbackLocale,
        resources: this._buildResources(),
        interpolation: { escapeValue: false },
        react: { useSuspense: true },
        ...this._config.i18nextOptions,
      })

    const offLocale = this.core.on('localeChange', ({ locale }) => {
      const msgs = this.core.getMessages(locale)
      this._i18next.addResourceBundle(locale, 'translation', msgs, true, true)
      this._i18next.changeLanguage(locale)
    })

    const offNs = this.core.on('namespaceLoaded', ({ locale, ns }) => {
      const msgs = this.core.getMessages(locale)
      this._i18next.addResourceBundle(locale, 'translation', msgs, true, true)
    })

    this._unsubscribers.push(offLocale, offNs)
    this._initialized = true
    _instance = this

    return this._i18next
  }

  async switchLocale(locale: string): Promise<boolean> {
    return this.core.switchLocale(locale)
  }

  async loadNamespace(locale: string, ns: string): Promise<boolean> {
    return this.core.loadNamespace(locale, ns)
  }

  destroy(): void {
    this._unsubscribers.forEach(fn => fn())
    this._unsubscribers = []
    this.core.destroy()
    this._initialized = false
    if (_instance === this)
      _instance = null
  }

  private _buildResources(): Record<string, { translation: Record<string, any> }> {
    const allMsgs = this.core.getAllMessages()
    const resources: Record<string, { translation: Record<string, any> }> = {}
    for (const [locale, msgs] of Object.entries(allMsgs)) {
      resources[locale] = { translation: msgs as Record<string, any> }
    }
    return resources
  }
}

export function createI18n(config: I18nReactConfig): I18nReactManager {
  return new I18nReactManager(config)
}

export function getI18nManager(): I18nReactManager {
  if (!_instance)
    throw new Error('[i18n-sdk] I18nReactManager not initialized. Call manager.init() first.')
  return _instance
}
