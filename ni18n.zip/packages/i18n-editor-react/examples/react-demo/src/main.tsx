// React 19 下 Semi 需要先注入 createRoot，必须在最顶部、任何 Semi 组件之前
import '@douyinfe/semi-ui/react19-adapter'

import { createRoot } from 'react-dom/client'
import '@douyinfe/semi-ui/dist/css/semi.min.css'
import './index.css'
import App from './App'

createRoot(document.getElementById('root')!).render(<App />)
