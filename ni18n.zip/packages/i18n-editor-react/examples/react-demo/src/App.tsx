import { useState, useMemo, useRef } from 'react'
import { Input, Button, Card, Divider, Toast, TextArea } from '@douyinfe/semi-ui'
import { I18nEditorCore, I18nFieldWrapper, I18nInput, PhraseDialog } from '@supernova/i18n-editor-react'
import type { PhraseEntry, PhraseApiAdapter, I18nFieldRules, I18nFieldWrapperRef } from '@supernova/i18n-editor-react'

// ─── API 适配器（对接 mock server） ───

const api: PhraseApiAdapter = {
  async query(params) {
    const qs = new URLSearchParams({
      keyword: params.keyword ?? '',
      page: String(params.page ?? 1),
      pageSize: String(params.pageSize ?? 20),
    })
    const res = await fetch(`/api/phrases?${qs}`)
    return res.json()
  },
  async create(params) {
    const res = await fetch('/api/phrases/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    })
    return res.json()
  },
  async update(params) {
    const res = await fetch('/api/phrases/update', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    })
    return res.json()
  },
  async remove(id) {
    await fetch(`/api/phrases/delete?id=${encodeURIComponent(id)}`, { method: 'DELETE' })
  },
}

// ─── App ───

export default function App() {
  const editor = useMemo(() => new I18nEditorCore({
    api,
    locales: [
      { code: 'zh-CN', label: '中文' },
      { code: 'en-US', label: 'English' },
      { code: 'ja-JP', label: '日本語' },
    ],
    pageSize: 10,
  }), [])

  // 示例 1: I18nFieldWrapper（value + translations + i18nCode）
  const [formTitle, setFormTitle] = useState('')
  const [formTitleI18nCode, setFormTitleI18nCode] = useState('')
  const [formTitleTranslations, setFormTitleTranslations] = useState<Record<string, string>>({})
  const [selectedPhrase, setSelectedPhrase] = useState<PhraseEntry | null>(null)
  const [lastInputValue, setLastInputValue] = useState('')

  const handleTitleSelect = (entry: PhraseEntry) => {
    setSelectedPhrase(entry)
    setFormTitleI18nCode(`@i18n.${entry.key}`)
    setFormTitleTranslations({ ...entry.translations })
    Toast.success(`选中: ${entry.key}`)
  }
  const handleTitleClear = () => {
    setSelectedPhrase(null)
    setFormTitleI18nCode('')
    setFormTitleTranslations({})
  }

  const handleTitleInput = (val: string) => {
    setLastInputValue(val)
  }

  // 示例 1b: 使用 I18nInput 组件（从 @supernova/i18n-editor-react 导出）
  const [i18nInputValue, setI18nInputValue] = useState('')
  const [i18nInputI18nCode, setI18nInputI18nCode] = useState('')
  const [i18nInputTranslations, setI18nInputTranslations] = useState<Record<string, string>>({})

  const handleI18nInputSelect = (entry: PhraseEntry) => {
    setI18nInputI18nCode(`@i18n.${entry.key}`)
    setI18nInputTranslations({ ...entry.translations })
    Toast.success(`选中: ${entry.key}`)
  }
  const handleI18nInputClear = () => {
    setI18nInputI18nCode('')
    setI18nInputTranslations({})
  }

  // 示例 2: I18nFieldWrapper 包裹 TextArea
  const [formDesc, setFormDesc] = useState('')
  const [formDescI18nCode, setFormDescI18nCode] = useState('')
  const [formDescTranslations, setFormDescTranslations] = useState<Record<string, string>>({})
  const [selectedDescPhrase, setSelectedDescPhrase] = useState<PhraseEntry | null>(null)

  const handleDescSelect = (entry: PhraseEntry) => {
    setSelectedDescPhrase(entry)
    setFormDescI18nCode(`@i18n.${entry.key}`)
    setFormDescTranslations({ ...entry.translations })
    Toast.success(`选中: ${entry.key}`)
  }
  const handleDescClear = () => {
    setSelectedDescPhrase(null)
    setFormDescI18nCode('')
    setFormDescTranslations({})
  }

  // 示例 4: 多语言规则 + innerValidator 组合校验
  const validateWrapperRef = useRef<I18nFieldWrapperRef | null>(null)
  const [validateTitle, setValidateTitle] = useState('')
  const [validateTranslations, setValidateTranslations] = useState<Record<string, string>>({})

  const validationRules: I18nFieldRules = {
    '*': [
      {
        required: true,
        message: '多语言必填（任意语言都需要填写）',
      },
    ],
    'en-US': [
      {
        min: 3,
        message: '英文至少 3 个字符',
      },
    ],
  }

  const innerLengthValidator = (value: string): string | null => {
    if (!value) return null
    if (value.length > 10) {
      return '内部校验：长度不能超过 10 个字符'
    }
    return null
  }

  const handleValidateClick = async () => {
    const msg = await validateWrapperRef.current?.validate()
    if (!msg) {
      Toast.success('校验通过')
    }
  }

  const handleClearValidate = () => {
    validateWrapperRef.current?.clearValidate()
  }

  // 示例 3: PhraseDialog
  const [dialogVisible, setDialogVisible] = useState(false)
  const [dialogResult, setDialogResult] = useState<PhraseEntry | null>(null)

  const handleDialogConfirm = (entry: PhraseEntry) => {
    setDialogResult(entry)
    Toast.success(`选中: ${entry.key}`)
  }

  return (
    <div style={{ maxWidth: 800, margin: '40px auto', padding: '0 20px' }}>
      <h1 style={{ marginBottom: 8 }}>🌐 i18n-editor-react Demo</h1>
      <p style={{ color: '#86909c', marginBottom: 32 }}>
        国际化文案编辑器 — React + Semi Design 组件演示
      </p>

      {/* ─── 示例 1：简洁用法 — 透传属性 ─── */}
      <Card
        title="示例 1：简洁用法 — 透传属性"
        style={{ marginBottom: 24 }}
      >
        <p style={{ color: '#4e5969', marginBottom: 16 }}>
          <code>placeholder</code>、<code>className</code> 等写在 wrapper 上会透传到内部 <code>&lt;Input&gt;</code>，
          子组件只需写 <code>&lt;Input /&gt;</code>，value/onChange 由 wrapper 注入。不传 <code>editor</code> 时使用默认实现。
        </p>

        <I18nFieldWrapper
          value={formTitle}
          locale="zh-CN"
          translations={formTitleTranslations}
          onTranslationsChange={setFormTitleTranslations}
          onChange={val => { setFormTitle(val); handleTitleInput(val) }}
          onSelect={handleTitleSelect}
          onClear={handleTitleClear}
          placeholder="请输入标题（点击左侧图标选择文案）"
        >
          <Input />
        </I18nFieldWrapper>

        <Divider />

        <div style={{ fontSize: 13, color: '#86909c' }}>
          <p><strong>显示值：</strong>{formTitle || '（空）'}</p>
          <p><strong>i18nCode：</strong>{formTitleI18nCode || '（空）'}</p>
          <p><strong>最近 input 事件值（通过包裹组件监听）：</strong>{lastInputValue || '（空）'}</p>
          <p><strong>当前 locale 对应词条（随 value 同步）：</strong><code>translations[&quot;zh-CN&quot;]</code> = {formTitleTranslations['zh-CN'] ?? '（空）'}</p>
          {Object.keys(formTitleTranslations).length > 0 && (
            <>
              <p><strong>全量翻译：</strong></p>
              <ul style={{ margin: '4px 0 0 20px' }}>
                {Object.entries(formTitleTranslations).map(([code, val]) => (
                  <li key={code}>{code}: {val}</li>
                ))}
              </ul>
            </>
          )}
        </div>
      </Card>

      {/* ─── 示例 1b：使用 I18nInput 组件 ─── */}
      <Card
        title="示例 1b：使用 I18nInput 组件"
        style={{ marginBottom: 24 }}
      >
        <p style={{ color: '#4e5969', marginBottom: 16 }}>
          使用包内导出的 <code>I18nInput</code>，无需手写 <code>I18nFieldWrapper</code> + <code>Input</code>
        </p>

        <I18nInput
          value={i18nInputValue}
          locale="zh-CN"
          translations={i18nInputTranslations}
          onTranslationsChange={setI18nInputTranslations}
          onChange={setI18nInputValue}
          onSelect={handleI18nInputSelect}
          onClear={handleI18nInputClear}
          placeholder="请输入（使用 I18nInput 组件）"
        />

        <Divider />

        <div style={{ fontSize: 13, color: '#86909c' }}>
          <p><strong>显示值：</strong>{i18nInputValue || '（空）'}</p>
          <p><strong>i18nCode：</strong>{i18nInputI18nCode || '（空）'}</p>
          <p><strong>当前 locale 对应词条（随 value 同步）：</strong><code>translations[&quot;zh-CN&quot;]</code> = {i18nInputTranslations['zh-CN'] ?? '（空）'}</p>
          {Object.keys(i18nInputTranslations).length > 0 && (
            <>
              <p><strong>全量翻译：</strong></p>
              <ul style={{ margin: '4px 0 0 20px' }}>
                {Object.entries(i18nInputTranslations).map(([code, val]) => (
                  <li key={code}>{code}: {val}</li>
                ))}
              </ul>
            </>
          )}
        </div>
      </Card>

      {/* ─── 示例 2：自定义 Editor + Textarea ─── */}
      <Card
        title="示例 2：自定义 Editor + Textarea"
        style={{ marginBottom: 24 }}
      >
        <p style={{ color: '#4e5969', marginBottom: 16 }}>
          手动传入 <code>editor</code>，多行文本场景。<code>placeholder</code> 写在 wrapper 上透传，子组件只需 <code>&lt;TextArea rows=&#123;4&#125; /&gt;</code>。
        </p>

        <I18nFieldWrapper
          value={formDesc}
          editor={editor}
          locale="zh-CN"
          translations={formDescTranslations}
          onTranslationsChange={setFormDescTranslations}
          onChange={setFormDesc}
          onSelect={handleDescSelect}
          onClear={handleDescClear}
          placeholder="请输入描述（点击左侧图标选择文案）"
        >
          <TextArea rows={4} />
        </I18nFieldWrapper>

        <Divider />

        <div style={{ fontSize: 13, color: '#86909c' }}>
          <p><strong>显示值：</strong>{formDesc || '（空）'}</p>
          <p><strong>i18nCode：</strong>{formDescI18nCode || '（空）'}</p>
          <p><strong>当前 locale 对应词条：</strong> <code>translations[&quot;zh-CN&quot;]</code> = {formDescTranslations['zh-CN'] ?? '（空）'}</p>
          {Object.keys(formDescTranslations).length > 0 && (
            <>
              <p><strong>全量翻译：</strong></p>
              <ul style={{ margin: '4px 0 0 20px' }}>
                {Object.entries(formDescTranslations).map(([code, val]) => (
                  <li key={code}>{code}: {val}</li>
                ))}
              </ul>
            </>
          )}
        </div>
      </Card>

      {/* ─── 示例 3：单独使用 PhraseDialog ─── */}
      <Card
        title="示例 3：单独使用 PhraseDialog"
        style={{ marginBottom: 24 }}
      >
        <p style={{ color: '#4e5969', marginBottom: 16 }}>
          通过按钮手动打开文案库弹窗，支持搜索、语言筛选、分页加载、编辑/新增/删除。
        </p>

        <Button theme="solid" type="primary" onClick={() => setDialogVisible(true)}>
          打开文案库
        </Button>

        <PhraseDialog
          visible={dialogVisible}
          editor={editor}
          locales={editor.locales}
          onClose={() => setDialogVisible(false)}
          onConfirm={handleDialogConfirm}
        />

        {dialogResult && (
          <>
            <Divider />
            <div style={{ fontSize: 13, color: '#86909c' }}>
              <p><strong>确认选中：</strong></p>
              <p>Key: {dialogResult.key}</p>
              <ul style={{ margin: '4px 0 0 20px' }}>
                {Object.entries(dialogResult.translations).map(([code, val]) => (
                  <li key={code}>{code}: {val}</li>
                ))}
              </ul>
            </div>
          </>
        )}
      </Card>

      {/* ─── 示例 4：多语言规则 + innerValidator 组合校验 ─── */}
      <Card
        title="示例 4：多语言规则 + innerValidator 组合校验"
        style={{ marginBottom: 24 }}
      >
        <p style={{ color: '#4e5969', marginBottom: 16 }}>
          同时使用内部组件/表单的 <code>innerValidator</code> 和 i18n 多语言规则：
          先跑内部校验（长度限制），再跑英文最少 3 个字符的规则。<code>placeholder</code> 写在 wrapper 上透传。
        </p>

        <I18nFieldWrapper
          ref={validateWrapperRef}
          value={validateTitle}
          editor={editor}
          locale="en-US"
          translations={validateTranslations}
          onTranslationsChange={setValidateTranslations}
          rules={validationRules}
          innerValidator={innerLengthValidator}
          onChange={setValidateTitle}
          placeholder="请输入英文标题（内外校验组合示例）"
        >
          <Input />
        </I18nFieldWrapper>

        <div style={{ marginTop: 12, display: 'flex', gap: 8 }}>
          <Button size="small" theme="solid" type="primary" onClick={handleValidateClick}>
            手动触发校验
          </Button>
          <Button size="small" onClick={handleClearValidate}>
            清除错误
          </Button>
        </div>
      </Card>

      {/* ─── 表单完整数据（实时） ─── */}
      <Card title="表单完整数据（实时）" style={{ marginTop: 24 }}>
        <pre style={{ fontSize: 13, background: '#f5f7fa', padding: 16, borderRadius: 4, overflow: 'auto' }}>
          {JSON.stringify({
            formTitle,
            formTitleI18nCode,
            formTitleTranslations,
            i18nInputValue,
            i18nInputI18nCode,
            i18nInputTranslations,
            formDesc,
            formDescI18nCode,
            formDescTranslations,
            validateTitle,
            validateTranslations,
            selectedPhraseKey: selectedPhrase?.key ?? null,
            selectedDescPhraseKey: selectedDescPhrase?.key ?? null,
          }, null, 2)}
        </pre>
      </Card>
    </div>
  )
}
