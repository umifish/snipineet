import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { resolve } from 'path'

// Mock API 插件：模拟文案库后端接口
function mockPhraseApiPlugin() {
  const phrases: Array<{ id: string; key: string; translations: Record<string, string>; createdAt: string; updatedAt: string }> = []
  let nextId = 1

  const demoEntries = [
    { key: 'common.submit', translations: { 'zh-CN': '提交', 'en-US': 'Submit', 'ja-JP': '送信' } },
    { key: 'common.cancel', translations: { 'zh-CN': '取消', 'en-US': 'Cancel', 'ja-JP': 'キャンセル' } },
    { key: 'common.confirm', translations: { 'zh-CN': '确认', 'en-US': 'Confirm', 'ja-JP': '確認' } },
    { key: 'common.delete', translations: { 'zh-CN': '删除', 'en-US': 'Delete', 'ja-JP': '削除' } },
    { key: 'common.edit', translations: { 'zh-CN': '编辑', 'en-US': 'Edit', 'ja-JP': '編集' } },
    { key: 'common.save', translations: { 'zh-CN': '保存', 'en-US': 'Save', 'ja-JP': '保存' } },
    { key: 'common.search', translations: { 'zh-CN': '搜索', 'en-US': 'Search', 'ja-JP': '検索' } },
    { key: 'common.reset', translations: { 'zh-CN': '重置', 'en-US': 'Reset', 'ja-JP': 'リセット' } },
    { key: 'common.back', translations: { 'zh-CN': '返回', 'en-US': 'Back', 'ja-JP': '戻る' } },
    { key: 'common.next', translations: { 'zh-CN': '下一步', 'en-US': 'Next', 'ja-JP': '次へ' } },
    { key: 'common.previous', translations: { 'zh-CN': '上一步', 'en-US': 'Previous', 'ja-JP': '前へ' } },
    { key: 'common.loading', translations: { 'zh-CN': '加载中...', 'en-US': 'Loading...', 'ja-JP': '読み込み中...' } },
    { key: 'common.noData', translations: { 'zh-CN': '暂无数据', 'en-US': 'No Data', 'ja-JP': 'データなし' } },
    { key: 'common.success', translations: { 'zh-CN': '操作成功', 'en-US': 'Success', 'ja-JP': '成功' } },
    { key: 'common.error', translations: { 'zh-CN': '操作失败', 'en-US': 'Error', 'ja-JP': 'エラー' } },
    { key: 'user.name', translations: { 'zh-CN': '用户名', 'en-US': 'Username', 'ja-JP': 'ユーザー名' } },
    { key: 'user.email', translations: { 'zh-CN': '邮箱', 'en-US': 'Email', 'ja-JP': 'メールアドレス' } },
    { key: 'user.password', translations: { 'zh-CN': '密码', 'en-US': 'Password', 'ja-JP': 'パスワード' } },
    { key: 'user.login', translations: { 'zh-CN': '登录', 'en-US': 'Login', 'ja-JP': 'ログイン' } },
    { key: 'user.logout', translations: { 'zh-CN': '退出登录', 'en-US': 'Logout', 'ja-JP': 'ログアウト' } },
    { key: 'user.register', translations: { 'zh-CN': '注册', 'en-US': 'Register', 'ja-JP': '登録' } },
    { key: 'nav.home', translations: { 'zh-CN': '首页', 'en-US': 'Home', 'ja-JP': 'ホーム' } },
    { key: 'nav.settings', translations: { 'zh-CN': '设置', 'en-US': 'Settings', 'ja-JP': '設定' } },
    { key: 'nav.profile', translations: { 'zh-CN': '个人中心', 'en-US': 'Profile', 'ja-JP': 'プロフィール' } },
    { key: 'nav.about', translations: { 'zh-CN': '关于', 'en-US': 'About', 'ja-JP': '概要' } },
  ]
  const now = new Date().toISOString()
  for (const e of demoEntries) {
    phrases.push({ id: String(nextId++), ...e, createdAt: now, updatedAt: now })
  }

  return {
    name: 'mock-phrase-api',
    configureServer(server: any) {
      server.middlewares.use('/api/phrases', (req: any, res: any, next: any) => {
        if (req.method !== 'GET') return next()
        const url = new URL(req.url!, `http://${req.headers.host}`)
        const keyword = url.searchParams.get('keyword') || ''
        const page = Number(url.searchParams.get('page')) || 1
        const pageSize = Number(url.searchParams.get('pageSize')) || 20

        let filtered = phrases
        if (keyword) {
          const kw = keyword.toLowerCase()
          filtered = phrases.filter(p =>
            p.key.toLowerCase().includes(kw) ||
            Object.values(p.translations).some(v => v.toLowerCase().includes(kw)),
          )
        }

        const total = filtered.length
        const list = filtered.slice((page - 1) * pageSize, page * pageSize)
        res.setHeader('Content-Type', 'application/json')
        res.end(JSON.stringify({ list, total, page, pageSize }))
      })

      server.middlewares.use('/api/phrases/create', (req: any, res: any, next: any) => {
        if (req.method !== 'POST') return next()
        let body = ''
        req.on('data', (chunk: string) => { body += chunk })
        req.on('end', () => {
          const data = JSON.parse(body)
          const entry = { id: String(nextId++), key: data.key, translations: data.translations, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }
          phrases.push(entry)
          res.setHeader('Content-Type', 'application/json')
          res.end(JSON.stringify(entry))
        })
      })

      server.middlewares.use('/api/phrases/update', (req: any, res: any, next: any) => {
        if (req.method !== 'PUT') return next()
        let body = ''
        req.on('data', (chunk: string) => { body += chunk })
        req.on('end', () => {
          const data = JSON.parse(body)
          const entry = phrases.find(p => p.id === data.id)
          if (!entry) { res.statusCode = 404; res.end('Not found'); return }
          if (data.key) entry.key = data.key
          if (data.translations) entry.translations = data.translations
          entry.updatedAt = new Date().toISOString()
          res.setHeader('Content-Type', 'application/json')
          res.end(JSON.stringify(entry))
        })
      })

      server.middlewares.use('/api/phrases/delete', (req: any, res: any, next: any) => {
        if (req.method !== 'DELETE') return next()
        const url = new URL(req.url!, `http://${req.headers.host}`)
        const id = url.searchParams.get('id')
        const idx = phrases.findIndex(p => p.id === id)
        if (idx >= 0) phrases.splice(idx, 1)
        res.setHeader('Content-Type', 'application/json')
        res.end(JSON.stringify({ success: true }))
      })
    },
  }
}

export default defineConfig({
  plugins: [react(), mockPhraseApiPlugin()],
  resolve: {
    alias: {
      '@supernova/i18n-editor-react': resolve(import.meta.dirname, '../../src/index.ts'),
      '@douyinfe/semi-ui/dist/css/semi.min.css': resolve(
        import.meta.dirname, 'node_modules/@douyinfe/semi-ui/dist/css/semi.min.css'
      ),
    },
  },
  server: {
    port: 5191,
    host: true,
  },
})
