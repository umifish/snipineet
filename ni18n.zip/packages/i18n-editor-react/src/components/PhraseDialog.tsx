import React, { useState, useCallback, useEffect, useRef, useMemo } from 'react'
import { Modal, Input, Button, Empty, Checkbox, CheckboxGroup, Popover, Table } from '@douyinfe/semi-ui'
import type { ColumnProps } from '@douyinfe/semi-ui/lib/es/table/interface'
import type { I18nEditorCore, EditorLocaleItem, PhraseEntry } from '@supernova/i18n-editor'
import { PhraseEditPanel } from './PhraseEditPanel'

export interface PhraseDialogProps {
  visible: boolean
  editor: I18nEditorCore
  locales: EditorLocaleItem[]
  onClose: () => void
  onConfirm: (entry: PhraseEntry) => void
}

export const PhraseDialog: React.FC<PhraseDialogProps> = ({
  visible,
  editor,
  locales,
  onClose,
  onConfirm,
}) => {
  const [keyword, setKeyword] = useState('')
  const [selectedLocaleCodes, setSelectedLocaleCodes] = useState<string[]>([])
  const [list, setList] = useState<PhraseEntry[]>([])
  const [total, setTotal] = useState(0)
  const pageRef = useRef(1)
  const [loading, setLoading] = useState(false)
  const loadingRef = useRef(false)
  const [selectedEntry, setSelectedEntry] = useState<PhraseEntry | null>(null)
  const [editMode, setEditMode] = useState(false)
  const [editingEntry, setEditingEntry] = useState<PhraseEntry | null>(null)
  const [saveLoading, setSaveLoading] = useState(false)
  const searchTimerRef = useRef<ReturnType<typeof setTimeout>>(undefined)
  const keywordRef = useRef('')

  const hasMore = list.length < total

  const doQuery = useCallback(async (reset: boolean) => {
    const page = reset ? 1 : pageRef.current
    if (reset) pageRef.current = 1
    setLoading(true)
    loadingRef.current = true
    try {
      const result = await editor.query({
        keyword: keywordRef.current,
        page,
        pageSize: editor.pageSize,
      })
      if (reset) {
        setList(result.list)
      }
      else {
        setList(prev => [...prev, ...result.list])
      }
      setTotal(result.total)
    }
    finally {
      setLoading(false)
      loadingRef.current = false
    }
  }, [editor])

  const loadMore = useCallback(() => {
    if (loadingRef.current) return
    pageRef.current++
    doQuery(false)
  }, [doQuery])

  // 弹窗打开时重置
  useEffect(() => {
    if (visible) {
      setKeyword('')
      keywordRef.current = ''
      setSelectedLocaleCodes(locales.map(l => l.code))
      setSelectedEntry(null)
      setEditMode(false)
      pageRef.current = 1
      doQuery(true)
    }
  }, [visible, doQuery])

  // 组件卸载时清除搜索防抖
  useEffect(() => {
    return () => clearTimeout(searchTimerRef.current)
  }, [])

  // 搜索防抖
  const handleSearchChange = (val: string) => {
    setKeyword(val)
    keywordRef.current = val
    clearTimeout(searchTimerRef.current)
    searchTimerRef.current = setTimeout(() => {
      pageRef.current = 1
      doQuery(true)
    }, 300)
  }

  const handleLocaleToggle = (codes: string[]) => {
    if (codes.length === 0) return // 至少保留 1 个
    setSelectedLocaleCodes(codes)
  }

  // 确认
  const handleConfirm = () => {
    if (selectedEntry) {
      onConfirm(selectedEntry)
      onClose()
    }
  }

  // 编辑
  const openEdit = (entry: PhraseEntry) => {
    setEditingEntry(entry)
    setEditMode(true)
  }

  const openCreate = () => {
    setEditingEntry(null)
    setEditMode(true)
  }

  const handleSave = async (data: { key: string; translations: Record<string, string> }) => {
    setSaveLoading(true)
    try {
      let saved: PhraseEntry
      if (editingEntry) {
        saved = await editor.update({ id: editingEntry.id, key: data.key, translations: data.translations })
      }
      else {
        saved = await editor.create({ key: data.key, translations: data.translations })
      }
      onConfirm(saved)
      onClose()
    }
    finally {
      setSaveLoading(false)
    }
  }

  // 删除
  const handleDelete = async (entry: PhraseEntry) => {
    if (!window.confirm(`确认删除 "${entry.key}" 吗？`)) return
    await editor.remove(entry.id)
    doQuery(true)
  }

  // 显示的语言列
  const displayLocales = useMemo(() => {
    if (selectedLocaleCodes.length > 0 && selectedLocaleCodes.length < locales.length) {
      return locales.filter(l => selectedLocaleCodes.includes(l.code))
    }
    return locales
  }, [locales, selectedLocaleCodes])

  // Semi Table 列定义
  const tableColumns = useMemo<ColumnProps<PhraseEntry>[]>(() => {
    return [
      {
        title: 'Key',
        dataIndex: 'key',
        width: 180,
        ellipsis: true,
      },
      ...displayLocales.map(locale => ({
        title: locale.label,
        dataIndex: locale.code,
        ellipsis: true,
        render: (_: unknown, record: PhraseEntry) => record.translations[locale.code] || '—',
      })),
      {
        title: '操作',
        dataIndex: '_action',
        width: 120,
        render: (_: unknown, record: PhraseEntry) => (
          <div style={{ display: 'flex', gap: 4 }}>
            <Button theme="borderless" size="small" type="primary" onClick={(e) => { e.stopPropagation(); openEdit(record) }}>编辑</Button>
            <Button theme="borderless" size="small" type="danger" onClick={(e) => { e.stopPropagation(); handleDelete(record) }}>删除</Button>
          </div>
        ),
      },
    ]
  }, [displayLocales])

  // 触底加载：直接监听 react-window 滚动容器（.semi-table-body）
  const tableWrapRef = useRef<HTMLDivElement>(null)
  const listLenRef = useRef(0)
  const totalRef = useRef(0)
  listLenRef.current = list.length
  totalRef.current = total

  useEffect(() => {
    const wrap = tableWrapRef.current
    if (!wrap || !visible) return

    let scrollEl: HTMLElement | null = null
    let scrollFn: (() => void) | null = null

    const tryAttach = () => {
      if (scrollEl) return
      const el = wrap.querySelector('.semi-table-body') as HTMLElement
      if (!el) return
      scrollEl = el
      scrollFn = () => {
        const { scrollTop, scrollHeight, clientHeight } = el
        if (scrollHeight - scrollTop - clientHeight < 100
          && !loadingRef.current
          && listLenRef.current < totalRef.current) {
          pageRef.current++
          doQuery(false)
        }
      }
      el.addEventListener('scroll', scrollFn)
    }

    const timer = setTimeout(tryAttach, 100)
    const mo = new MutationObserver(tryAttach)
    mo.observe(wrap, { childList: true, subtree: true })

    return () => {
      clearTimeout(timer)
      mo.disconnect()
      if (scrollEl && scrollFn) scrollEl.removeEventListener('scroll', scrollFn)
    }
  }, [visible, doQuery])

  // 内容不足填满视口时自动加载更多
  useEffect(() => {
    if (loading || !visible) return
    if (listLenRef.current === 0 || listLenRef.current >= totalRef.current) return
    const wrap = tableWrapRef.current
    if (!wrap) return
    const t = setTimeout(() => {
      const el = wrap.querySelector('.semi-table-body') as HTMLElement
      if (el && el.scrollHeight <= el.clientHeight) {
        pageRef.current++
        doQuery(false)
      }
    }, 150)
    return () => clearTimeout(t)
  }, [loading, visible, doQuery])

  return (
    <Modal
      title="多语言文案库"
      visible={visible}
      onCancel={onClose}
      width={800}
      maskClosable={false}
      footer={editMode ? null : (
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
          <Button onClick={onClose}>取消</Button>
          <Button theme="solid" type="primary" disabled={!selectedEntry} onClick={handleConfirm}>确认</Button>
        </div>
      )}
    >
      <div style={{ position: 'relative', overflow: 'hidden', minHeight: 456 }}>
        {/* 列表面板 */}
        <div style={{
          position: 'absolute',
          inset: 0,
          display: 'flex',
          flexDirection: 'column',
          transition: 'transform 0.3s ease',
          transform: editMode ? 'translateX(-100%)' : 'translateX(0)',
        }}>
          {/* 工具栏 */}
          <div style={{ display: 'flex', gap: 8, paddingBottom: 12 }}>
            <Input
              value={keyword}
              onChange={handleSearchChange}
              placeholder="搜索 Key 或翻译内容"
              showClear
              style={{ flex: 1 }}
            />
            <Popover
              trigger="click"
              position="bottomLeft"
              content={
                <div style={{ padding: 8, display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <CheckboxGroup
                    value={selectedLocaleCodes}
                    onChange={handleLocaleToggle as any}
                    direction="vertical"
                  >
                    {locales.map(l => (
                      <Checkbox key={l.code} value={l.code}>{l.label}</Checkbox>
                    ))}
                  </CheckboxGroup>
                </div>
              }
            >
              <span style={{ display: 'inline-block' }}>
                <Button
                  icon={
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                      <path d="M4 5h7" />
                      <path d="M9 3v2c0 4.418-2.239 8-5 8" />
                      <path d="M5 9c0 2.144 2.952 3.908 6.7 4" />
                      <path d="M12 20l4-9 4 9" />
                      <path d="M19.1 18h-6.2" />
                    </svg>
                  }
                  style={{ padding: '0 8px' }}
                />
              </span>
            </Popover>
            <Button theme="solid" type="primary" onClick={openCreate}>添加文案</Button>
          </div>

          {/* 虚拟表格 */}
          <div ref={tableWrapRef} style={{ flex: 1 }}>
            <Table<PhraseEntry>
              columns={tableColumns}
              dataSource={list}
              rowKey="id"
              virtualized
              scroll={{ y: 370 }}
              pagination={false}
              size="small"
              empty={<Empty description="暂无数据" style={{ padding: 40 }} />}
              onRow={(record) => ({
                onClick: () => setSelectedEntry(record ?? null),
                style: {
                  cursor: 'pointer',
                  background: record && selectedEntry?.id === record.id ? '#e8f3ff' : undefined,
                },
              })}
            />
            {loading && <div style={{ textAlign: 'center', padding: 12, color: '#86909c', fontSize: 13 }}>加载中...</div>}
            {!hasMore && list.length > 0 && <div style={{ textAlign: 'center', padding: 12, color: '#86909c', fontSize: 13 }}>—— 已加载全部 ——</div>}
          </div>
        </div>

        {/* 编辑面板 */}
        <div style={{
          position: 'absolute',
          inset: 0,
          transition: 'transform 0.3s ease',
          transform: editMode ? 'translateX(0)' : 'translateX(100%)',
        }}>
          {editMode && (
            <PhraseEditPanel
              entry={editingEntry}
              locales={locales}
              loading={saveLoading}
              onBack={() => setEditMode(false)}
              onSave={handleSave}
            />
          )}
        </div>
      </div>
    </Modal>
  )
}
