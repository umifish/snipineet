import React, { forwardRef } from 'react'
import { Input, TextArea } from '@douyinfe/semi-ui'
import { I18nFieldWrapper } from './I18nFieldWrapper'
import type { I18nEditorCore, PhraseEntry, I18nFieldRules } from '@supernova/i18n-editor'
import type { I18nFieldWrapperRef } from './I18nFieldWrapper'

export interface I18nInputProps {
  /** 当前展示值（当前语言） */
  value?: string
  /** 值变更回调 */
  onChange?: (value: string) => void
  /** 所有语言翻译，value 更新时会同步当前 locale 对应项 */
  translations?: Record<string, string>
  /** 翻译更新回调 */
  onTranslationsChange?: (translations: Record<string, string>) => void
  /** 当前语言 */
  locale?: string
  /** 文案库编辑器实例，不传则使用默认实现 */
  editor?: I18nEditorCore
  /** 占位符 */
  placeholder?: string
  /** 是否禁用 */
  disabled?: boolean
  /** 多语言校验规则 */
  rules?: I18nFieldRules
  /** 内部校验函数（先于 rules 执行） */
  innerValidator?: (value: string) => string | null | Promise<string | null>
  /** 从文案库选中文案时回调 */
  onSelect?: (entry: PhraseEntry) => void
  /** 清除时回调 */
  onClear?: () => void
  /** 是否多行（渲染为 TextArea） */
  multiline?: boolean
  /** 多行时的行数 */
  rows?: number
  /** 是否显示前缀国际化图标 */
  showPrefixIcon?: boolean
  /** 是否显示后缀清除图标 */
  showSuffixIcon?: boolean
  /** 类名 */
  className?: string
  /** 内联样式 */
  style?: React.CSSProperties
}

/**
 * 通用国际化输入组件：内置 I18nFieldWrapper + Semi Input/TextArea，
 * 支持从文案库选择、value 与当前 locale 翻译同步、校验等，可直接从 @supernova/i18n-editor-react 导出使用。
 */
export const I18nInput = forwardRef<I18nFieldWrapperRef, I18nInputProps>((props, ref) => {
  const {
    value = '',
    onChange,
    translations,
    onTranslationsChange,
    locale,
    editor,
    placeholder,
    disabled,
    rules,
    innerValidator,
    onSelect,
    onClear,
    multiline = false,
    rows = 4,
    showPrefixIcon = true,
    showSuffixIcon = true,
    className,
    style
  } = props

  return (
    <I18nFieldWrapper
      ref={ref}
      value={value}
      onChange={onChange}
      translations={translations}
      onTranslationsChange={onTranslationsChange}
      locale={locale}
      editor={editor}
      placeholder={placeholder}
      disabled={disabled}
      rules={rules}
      innerValidator={innerValidator}
      onSelect={onSelect}
      onClear={onClear}
      showPrefixIcon={showPrefixIcon}
      showSuffixIcon={showSuffixIcon}
      className={className}
      style={style}
    >
      {multiline ? <TextArea rows={rows} /> : <Input />}
    </I18nFieldWrapper>
  )
})

I18nInput.displayName = 'I18nInput'
