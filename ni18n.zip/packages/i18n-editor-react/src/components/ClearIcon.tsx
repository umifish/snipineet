import React from 'react'

export interface ClearIconProps {
  size?: number
  color?: string
  visible?: boolean
  disabled?: boolean
  onClick?: () => void
}

export const ClearIcon: React.FC<ClearIconProps> = ({
  size = 14,
  color = '#bbbfc4',
  visible = true,
  disabled = false,
  onClick,
}) => {
  if (!visible) return null

  return (
    <span
      className="i18n-editor-clear"
      style={{
        cursor: disabled ? 'not-allowed' : 'pointer',
        color,
        lineHeight: 1,
        display: 'inline-flex',
        alignItems: 'center',
        opacity: disabled ? 0.5 : 1,
      }}
      onClick={(e) => {
        e.stopPropagation()
        if (!disabled) onClick?.()
      }}
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill="currentColor"
      >
        <path d="M12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2zm5 13.59L15.59 17 12 13.41 8.41 17 7 15.59 10.59 12 7 8.41 8.41 7 12 10.59 15.59 7 17 8.41 13.41 12 17 15.59z" />
      </svg>
    </span>
  )
}
