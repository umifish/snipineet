import React from 'react'

export interface I18nIconProps {
  size?: number
  color?: string
  disabled?: boolean
  onClick?: () => void
}

export const I18nIcon: React.FC<I18nIconProps> = ({
  size = 16,
  color = '#0077fa',
  disabled = false,
  onClick,
}) => {
  return (
    <span
      className="i18n-editor-icon"
      style={{
        cursor: disabled ? 'not-allowed' : 'pointer',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        color,
        opacity: disabled ? 0.5 : 1,
      }}
      onClick={(e) => {
        e.stopPropagation()
        if (!disabled) onClick?.()
      }}
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth={2}
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M5 8l6 6" />
        <path d="M4 14l6-6 2-3" />
        <path d="M2 5h12" />
        <path d="M7 2h1" />
        <path d="M22 22l-5-10-5 10" />
        <path d="M14 18h6" />
      </svg>
    </span>
  )
}
