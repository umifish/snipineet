import React, { useState, useRef, useEffect, useCallback, useImperativeHandle, forwardRef, cloneElement, Children, isValidElement } from 'react'
import {
  I18nEditorCore,
  validateField,
  createDefaultPhraseApi,
  DEFAULT_LOCALES,
  type PhraseEntry,
  type I18nFieldRules,
} from '@supernova/i18n-editor'
import { I18nIcon } from './I18nIcon'
import { ClearIcon } from './ClearIcon'
import { PhraseDialog } from './PhraseDialog'

export interface I18nFieldWrapperProps {
  /** 绑定值（显示文案） */
  value?: string
  /** 编辑器核心实例 */
  editor?: I18nEditorCore
  /** 当前语言，用于回填翻译文案 */
  locale?: string
  /** 是否禁用 */
  disabled?: boolean
  /** 是否显示前缀国际化图标 */
  showPrefixIcon?: boolean
  /** 是否显示后缀清除图标 */
  showSuffixIcon?: boolean
  /** 前缀图标大小 */
  prefixIconSize?: number
  /** 前缀图标颜色 */
  prefixIconColor?: string
  /** 后缀图标大小 */
  suffixIconSize?: number
  /** 后缀图标颜色 */
  suffixIconColor?: string
  /** 包裹的子元素（仅第一个可克隆子元素会接收透传的 props） */
  children?: React.ReactNode
  /** 自定义前缀图标 */
  prefixIcon?: React.ReactNode
  /** 自定义后缀图标 */
  suffixIcon?: React.ReactNode
  /** 按语言映射的校验规则 */
  rules?: I18nFieldRules
  /** 内部组件/表单自身的校验函数，返回错误消息或 null */
  innerValidator?: (value: string) => string | null | Promise<string | null>
  /** 所有语言翻译（与 Vue v-model:translations 对应） */
  translations?: Record<string, string>
  /** 翻译更新回调，value 更新时会同步当前 locale 对应项 */
  onTranslationsChange?: (translations: Record<string, string>) => void
  /** 选中文案回调 */
  onSelect?: (entry: PhraseEntry) => void
  /** 清除回调 */
  onClear?: () => void
  /** 值变更回调 */
  onChange?: (value: string) => void
  /** 透传给子输入组件的属性（如 placeholder、className、style 等） */
  placeholder?: string
  className?: string
  style?: React.CSSProperties
}

export interface I18nFieldWrapperRef {
  /** 手动触发校验，返回错误信息或 null */
  validate: () => Promise<string | null>
  /** 清除校验状态 */
  clearValidate: () => void
}

const WRAPPER_PROPS_KEYS: ReadonlySet<string> = new Set([
  'value', 'editor', 'locale', 'disabled', 'showPrefixIcon', 'showSuffixIcon',
  'prefixIconSize', 'prefixIconColor', 'suffixIconSize', 'suffixIconColor',
  'children', 'prefixIcon', 'suffixIcon', 'rules', 'innerValidator',
  'translations', 'onTranslationsChange', 'onSelect', 'onClear', 'onChange',
])

export const I18nFieldWrapper = forwardRef<I18nFieldWrapperRef, I18nFieldWrapperProps>((props, ref) => {
  const {
    value = '',
    editor,
    locale,
    disabled = false,
    showPrefixIcon = true,
    showSuffixIcon = true,
    prefixIconSize = 16,
    prefixIconColor = '#0077fa',
    suffixIconSize = 14,
    suffixIconColor = '#bbbfc4',
    children,
    prefixIcon,
    suffixIcon,
    rules,
    innerValidator,
    translations,
    onTranslationsChange,
    onSelect,
    onClear,
    onChange,
  } = props

  // 透传属性：除 wrapper 自身占用的 props 外，其余均传给子输入组件（与 Vue 行为一致）
  const passThroughProps: Record<string, unknown> = {}
  const propsWithRest = props as I18nFieldWrapperProps & Record<string, unknown>
  for (const key of Object.keys(propsWithRest)) {
    if (!WRAPPER_PROPS_KEYS.has(key)) (passThroughProps as Record<string, unknown>)[key] = propsWithRest[key]
  }
  const [dialogVisible, setDialogVisible] = useState(false)
  const contentRef = useRef<HTMLDivElement>(null)
  const [isMultiline, setIsMultiline] = useState(false)
  const [iconAlignPadding, setIconAlignPadding] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [hasInnerSuffix, setHasInnerSuffix] = useState(false)

  const runValidate = useCallback(async (val?: string): Promise<string | null> => {
    const currentValue = val ?? value

    // 1. 先执行内部组件/表单自身的校验逻辑（如果提供）
    if (innerValidator) {
      const innerMsg = await innerValidator(currentValue)
      if (innerMsg) {
        setError(innerMsg)
        return innerMsg
      }
    }

    // 2. 再执行多语言规则校验
    if (!rules || !locale) {
      setError(null)
      return null
    }
    const msg = await validateField(currentValue, locale, rules)
    setError(msg)
    return msg
  }, [innerValidator, rules, locale, value])

  useImperativeHandle(ref, () => ({
    validate: () => runValidate(),
    clearValidate: () => setError(null),
  }), [runValidate])

  // 值或语言变化时自动校验
  useEffect(() => {
    if ((rules && locale) || innerValidator) {
      runValidate(value)
    }
  }, [value, locale, innerValidator, runValidate])

  // ─── 默认编辑器（懒初始化单例） ───
  let defaultEditorRef = (I18nFieldWrapper as any)._defaultEditor as I18nEditorCore | null | undefined
  const getDefaultEditor = () => {
    if (!defaultEditorRef) {
      defaultEditorRef = new I18nEditorCore({
        api: createDefaultPhraseApi(),
        locales: DEFAULT_LOCALES,
      })
      ;(I18nFieldWrapper as any)._defaultEditor = defaultEditorRef
    }
    return defaultEditorRef
  }

  const resolvedEditor = editor ?? getDefaultEditor()

  useEffect(() => {
    const el = contentRef.current
    if (!el) return
    const sync = () => {
      const textarea = el.querySelector('textarea')
      if (textarea) {
        setIsMultiline(true)
        setIconAlignPadding(getComputedStyle(textarea).paddingTop)
      } else {
        setIsMultiline(false)
        setIconAlignPadding('')
      }

      // 检测内置输入组件是否存在 suffix 图标（Semi Input 的后缀容器类名）
      const innerSuffix = el.querySelector('.semi-input-suffix, .semi-input-suffix-wrapper') as HTMLElement | null
      if (innerSuffix) {
        setHasInnerSuffix(true)
        // 给 Semi 自身的 suffix 预留出一段右侧空间，避免与包裹组件的 suffix 图标重叠
        innerSuffix.style.marginRight = '24px'
      } else {
        setHasInnerSuffix(false)
        // 恢复默认样式
        const allSuffix = el.querySelectorAll('.semi-input-suffix, .semi-input-suffix-wrapper') as NodeListOf<HTMLElement>
        allSuffix.forEach(node => {
          node.style.marginRight = ''
        })
      }
    }
    sync()
    const observer = new MutationObserver(sync)
    observer.observe(el, { childList: true, subtree: true })
    return () => observer.disconnect()
  }, [])

  const openDialog = () => {
    if (disabled) return
    setDialogVisible(true)
  }

  const handleConfirm = (entry: PhraseEntry) => {
    const displayText = (locale && entry.translations[locale]) || entry.key
    onChange?.(displayText)
    onSelect?.(entry)
  }

  const handleClear = () => {
    onChange?.('')
    onTranslationsChange?.({})
    onClear?.()
  }

  // 仅对第一个可克隆子节点注入 value、onChange 与透传属性，子组件自身 props 优先（与 Vue SlotRenderer 一致）
  const renderedChildren = (() => {
    const list = Children.toArray(children)
    if (list.length !== 1) return children
    const child = list[0]
    if (!isValidElement(child) || child.type === React.Fragment) return children
    const childProps = (child.props || {}) as Record<string, unknown>
    const childOnChange = childProps.onChange as ((v: string) => void) | undefined
    const composedOnChange = (v: string) => {
      childOnChange?.(v)
      onChange?.(v)
      // value 更新时，将当前 locale 在 translations 中的对应项同步为 value
      if (locale != null && translations != null && onTranslationsChange) {
        onTranslationsChange({ ...translations, [locale]: v })
      }
    }
    // 合并顺序：透传 props → 子组件自身 props（子优先）→ value/onChange/disabled/translations/locale（wrapper 控制）
    return cloneElement(child, {
      ...passThroughProps,
      ...childProps,
      value,
      onChange: composedOnChange,
      disabled,
      // 若 wrapper 接收了 translations/locale，一并传给内部组件，便于自定义组件使用
      ...(translations !== undefined && { translations }),
      ...(locale !== undefined && locale !== '' && { locale }),
    } as Record<string, unknown>)
  })()

  const wrapperStyle: React.CSSProperties = {
    display: 'inline-flex',
    alignItems: isMultiline ? 'flex-start' : 'center',
    width: '100%',
    boxSizing: 'border-box',
    position: 'relative',
    border: `1px solid ${error ? '#f93920' : '#e8e8e8'}`,
    borderRadius: 4,
    background: disabled ? '#f5f5f5' : '#fff',
    opacity: disabled ? 0.6 : 1,
    padding: '0 8px',
    transition: 'border-color 0.2s',
  }

  const iconStyle = isMultiline ? { paddingTop: iconAlignPadding } : undefined
  const suffixBaseStyle: React.CSSProperties = {
    flexShrink: 0,
    display: 'inline-flex',
    alignItems: 'center',
    marginLeft: 4,
    ...iconStyle,
  }

  const suffixStyle: React.CSSProperties = hasInnerSuffix
    ? {
      ...suffixBaseStyle,
      position: 'absolute',
      // 将清除图标固定在最右侧，利用上面对 Semi suffix 预留的 marginRight 来避免重叠
      right: 4,
    }
    : suffixBaseStyle

  return (
    <div style={{ width: '100%' }}>
      <div
        className="i18n-field-wrapper"
        style={wrapperStyle}
        onMouseEnter={e => { if (!disabled && !error) (e.currentTarget as HTMLElement).style.borderColor = '#bbbfc4' }}
        onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = error ? '#f93920' : '#e8e8e8' }}
        onFocus={e => { (e.currentTarget as HTMLElement).style.borderColor = error ? '#f93920' : '#0077fa' }}
        onBlur={e => { (e.currentTarget as HTMLElement).style.borderColor = error ? '#f93920' : '#e8e8e8' }}
      >
        {showPrefixIcon && (
          <span style={{ flexShrink: 0, display: 'inline-flex', alignItems: 'center', marginRight: 4, ...iconStyle }}>
            {prefixIcon ?? (
              <I18nIcon size={prefixIconSize} color={prefixIconColor} disabled={disabled} onClick={openDialog} />
            )}
          </span>
        )}

        <div ref={contentRef} style={{ flex: 1, minWidth: 0 }}>
          {renderedChildren}
        </div>

        {showSuffixIcon && (
          <span style={suffixStyle}>
            {suffixIcon ?? (
              <ClearIcon size={suffixIconSize} color={suffixIconColor} visible={!!value} disabled={disabled} onClick={handleClear} />
            )}
          </span>
        )}

        <PhraseDialog
          visible={dialogVisible}
          editor={resolvedEditor}
          locales={resolvedEditor.locales}
          onClose={() => setDialogVisible(false)}
          onConfirm={handleConfirm}
        />
      </div>
      {error && (
        <div style={{ color: '#f93920', fontSize: 12, lineHeight: '20px', marginTop: 2 }}>{error}</div>
      )}
    </div>
  )
})
