import React, { useState, useEffect } from 'react'
import { Button, Input, TextArea } from '@douyinfe/semi-ui'
import type { EditorLocaleItem, PhraseEntry } from '@supernova/i18n-editor'

export interface PhraseEditPanelProps {
  entry: PhraseEntry | null
  locales: EditorLocaleItem[]
  loading?: boolean
  onBack: () => void
  onSave: (data: { key: string; translations: Record<string, string> }) => void
}

export const PhraseEditPanel: React.FC<PhraseEditPanelProps> = ({
  entry,
  locales,
  loading = false,
  onBack,
  onSave,
}) => {
  const [editKey, setEditKey] = useState('')
  const [translations, setTranslations] = useState<Record<string, string>>({})

  useEffect(() => {
    if (entry) {
      setEditKey(entry.key)
      const t = { ...entry.translations }
      for (const locale of locales) {
        if (!(locale.code in t)) t[locale.code] = ''
      }
      setTranslations(t)
    }
    else {
      setEditKey('')
      const t: Record<string, string> = {}
      for (const locale of locales) {
        t[locale.code] = ''
      }
      setTranslations(t)
    }
  }, [entry, locales])

  const handleTranslationChange = (code: string, value: string) => {
    setTranslations(prev => ({ ...prev, [code]: value }))
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', padding: '12px 16px', borderBottom: '1px solid #e8e8e8', gap: 8 }}>
        <Button theme="borderless" onClick={onBack} icon={
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
            <path d="M15 18l-6-6 6-6" />
          </svg>
        }>
          返回
        </Button>
        <span style={{ fontSize: 16, fontWeight: 500 }}>{entry ? '编辑文案' : '新增文案'}</span>
      </div>

      {/* Body */}
      <div style={{ flex: 1, overflowY: 'auto', padding: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', marginBottom: 16, gap: 12 }}>
            <div style={{ flexShrink: 0, width: 80, fontWeight: 500, fontSize: 14, textAlign: 'right' }}>Key</div>
            <Input
              value={editKey}
              onChange={(v) => setEditKey(v)}
              placeholder="请输入文案 Key"
              disabled={!!entry}
              style={{ flex: 1 }}
            />
          </div>
          {locales.map(locale => (
            <div key={locale.code} style={{ display: 'flex', alignItems: 'flex-start', marginBottom: 16, gap: 12 }}>
              <div style={{ flexShrink: 0, width: 80, fontWeight: 500, fontSize: 14, textAlign: 'right', paddingTop: 6 }}>{locale.label}</div>
              <TextArea
                value={translations[locale.code] ?? ''}
                onChange={(v) => handleTranslationChange(locale.code, v)}
                placeholder={`请输入 ${locale.label} 翻译`}
                autosize={{ minRows: 2, maxRows: 4 }}
                style={{ flex: 1 }}
              />
            </div>
          ))}
      </div>

      {/* Footer */}
      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, padding: '12px 16px', borderTop: '1px solid #e8e8e8' }}>
        <Button onClick={onBack}>取消</Button>
        <Button
          theme="solid"
          type="primary"
          loading={loading}
          onClick={() => onSave({ key: editKey, translations: { ...translations } })}
        >
          保存并使用
        </Button>
      </div>
    </div>
  )
}
