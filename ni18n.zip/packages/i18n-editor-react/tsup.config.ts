import { defineConfig } from 'tsup'

export default defineConfig({
  entry: { index: 'src/index.ts' },
  format: ['esm', 'cjs'],
  outExtension: ({ format }) => ({ js: format === 'esm' ? '.mjs' : '.cjs' }),
  dts: true,
  treeshake: true,
  splitting: false,
  external: ['react', 'react-dom', '@douyinfe/semi-ui', '@supernova/i18n-editor'],
})
