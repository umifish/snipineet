<script setup lang="ts">
import { useTranslation, useLocale, useI18nManager } from '@supernova/i18n-sdk-vue'

const { t } = useTranslation()
const { locale, switchLocale } = useLocale()
const manager = useI18nManager()

const supportedLocales = manager.core.supportedLocales
const localeInfoList = manager.core.localeInfoList

async function handleSwitch(code: string) {
  await switchLocale(code)
}
</script>

<template>
  <div class="app">
    <h1>🌍 {{ t('greeting') }}</h1>
    <p class="desc">{{ t('description') }}</p>

    <div class="card">
      <h2>{{ t('welcome') }}</h2>

      <div class="info">
        <p><strong>{{ t('currentLang') }}:</strong> {{ locale }}</p>
        <p><strong>{{ t('supportedLangs') }}:</strong> {{ supportedLocales.join(', ') }}</p>
      </div>

      <div class="actions">
        <h3>{{ t('switchLang') }}</h3>
        <div class="buttons">
          <button
            v-for="info in localeInfoList"
            :key="info.code"
            :class="{ active: locale === info.code }"
            @click="handleSwitch(info.code)"
          >
            {{ info.label || info.code }}
          </button>
        </div>
      </div>

      <div class="form-demo">
        <input :placeholder="t('inputPlaceholder')" />
        <button class="submit">{{ t('submit') }}</button>
      </div>
    </div>
  </div>
</template>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: #f5f5f5;
  color: #333;
}
.app {
  max-width: 600px;
  margin: 40px auto;
  padding: 20px;
}
h1 {
  text-align: center;
  font-size: 2em;
  margin-bottom: 8px;
}
.desc {
  text-align: center;
  color: #666;
  margin-bottom: 24px;
}
.card {
  background: #fff;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
}
.card h2 {
  margin-bottom: 16px;
  color: #1a73e8;
}
.info {
  background: #f8f9fa;
  padding: 12px 16px;
  border-radius: 8px;
  margin-bottom: 20px;
}
.info p {
  margin: 4px 0;
  font-size: 14px;
}
.actions h3 {
  margin-bottom: 12px;
  font-size: 16px;
}
.buttons {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  margin-bottom: 20px;
}
.buttons button {
  padding: 8px 20px;
  border: 2px solid #e0e0e0;
  border-radius: 8px;
  background: #fff;
  cursor: pointer;
  font-size: 14px;
  transition: all 0.2s;
}
.buttons button:hover {
  border-color: #1a73e8;
  color: #1a73e8;
}
.buttons button.active {
  border-color: #1a73e8;
  background: #1a73e8;
  color: #fff;
}
.form-demo {
  display: flex;
  gap: 8px;
}
.form-demo input {
  flex: 1;
  padding: 8px 12px;
  border: 2px solid #e0e0e0;
  border-radius: 8px;
  font-size: 14px;
  outline: none;
}
.form-demo input:focus {
  border-color: #1a73e8;
}
.submit {
  padding: 8px 20px;
  border: none;
  border-radius: 8px;
  background: #1a73e8;
  color: #fff;
  cursor: pointer;
  font-size: 14px;
}
</style>
