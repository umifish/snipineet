import { createApp } from 'vue'
import { createI18n } from '@supernova/i18n-sdk-vue'
import type { MessageResource } from '@supernova/i18n-sdk-vue'
import App from './App.vue'

const localMessages: Record<string, Record<string, MessageResource>> = {
  'zh-CN': {
    common: {
      greeting: '你好，Vue Demo！',
      description: '这是一个使用 @supernova/i18n-sdk-vue 的简单示例。',
      welcome: '欢迎使用 i18n-sdk',
      currentLang: '当前语言',
      supportedLangs: '支持的语言',
      switchLang: '切换语言',
      inputPlaceholder: '请输入一些内容...',
      submit: '提交',
    },
  },
  'en-US': {
    common: {
      greeting: 'Hello, Vue Demo!',
      description: 'A simple example powered by @supernova/i18n-sdk-vue.',
      welcome: 'Welcome to i18n-sdk',
      currentLang: 'Current language',
      supportedLangs: 'Supported languages',
      switchLang: 'Switch language',
      inputPlaceholder: 'Type something...',
      submit: 'Submit',
    },
  },
}

async function bootstrap() {
  const app = createApp(App)

  const i18n = createI18n({
    defaultLocale: 'zh-CN',
    fallbackLocale: 'en-US',
    baseURL: '/api',
    endpoints: {
      list: '/locales',
      message: (locale, ns) => `/messages/${locale}/${ns}`,
      userInfo: '/user/profile',
    },
    adapters: {
      message: (data: any): MessageResource => {
        if (data?.data && typeof data.data === 'object') return data.data
        const locale = data?.locale as string | undefined
        if (locale && localMessages[locale]?.common)
          return localMessages[locale].common
        return data
      },
    },
    storage: {
      type: 'localStorage',
      keyPrefix: 'vue_demo_i18n',
      maxAge: 60 * 60 * 1000,
    },
    interceptor: {
      enabled: true,
    },
  })

  await i18n.install(app)

  app.mount('#app')
}

bootstrap()
