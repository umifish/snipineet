import type { I18nCoreConfig, I18nHooks } from '@supernova/i18n-sdk'

export interface I18nVueConfig extends I18nCoreConfig {
  /** 回退语言（与 I18nCoreConfig.fallbackLocale 一致，便于类型解析） */
  fallbackLocale: string
  datetimeFormats?: Record<string, any>
  numberFormats?: Record<string, any>
  legacy?: boolean
}

export interface I18nVuePluginOptions {
  hooks?: I18nHooks
}
