import type { App, Plugin } from 'vue'
import { createI18n as createVueI18n } from 'vue-i18n'
import type { I18n } from 'vue-i18n'
import { I18nCore } from '@supernova/i18n-sdk'
import type { LocaleInfo } from '@supernova/i18n-sdk'
import type { I18nVueConfig, I18nVuePluginOptions } from './types'

let _instance: I18nVueManager | null = null

export class I18nVueManager {
  readonly core: I18nCore
  private _i18n!: I18n
  private _config: I18nVueConfig
  private _unsubscribers: Array<() => void> = []
  private _initialized = false

  constructor(config: I18nVueConfig) {
    this._config = config
    this.core = new I18nCore(config)
  }

  get i18n(): I18n {
    return this._i18n
  }

  get supportedLocales(): string[] {
    return this.core.supportedLocales
  }

  get localeInfoList(): LocaleInfo[] {
    return this.core.localeInfoList
  }

  get locale(): string {
    return this.core.locale
  }

  t(key: string, ...args: any[]): string {
    return (this._i18n.global as any).t(key, ...args)
  }

  get initialized(): boolean {
    return this._initialized
  }

  async install(app: App, options?: I18nVuePluginOptions): Promise<void> {
    if (_instance && _instance !== this) {
      _instance.destroy()
    }

    await this.core.init(options?.hooks)

    this._i18n = createVueI18n({
      legacy: this._config.legacy ?? false,
      locale: this.core.locale,
      fallbackLocale: this._config.fallbackLocale,
      datetimeFormats: this._config.datetimeFormats ?? {},
      numberFormats: this._config.numberFormats ?? {},
      messages: this.core.getAllMessages(),
    })

    app.use(this._i18n)

    const offLocale = this.core.on('localeChange', ({ locale }) => {
      const msgs = this.core.getMessages(locale)
      this._i18n.global.setLocaleMessage(locale, msgs)

      if (this._config.legacy) {
        ;(this._i18n.global.locale as unknown as string) = locale
      }
      else {
        (this._i18n.global.locale as any).value = locale
      }
    })

    const offNs = this.core.on('namespaceLoaded', ({ locale, ns }) => {
      const msgs = this.core.getMessages(locale)
      this._i18n.global.setLocaleMessage(locale, msgs)
    })

    this._unsubscribers.push(offLocale, offNs)

    app.provide('i18nVueManager', this)
    app.config.globalProperties.$i18nManager = this

    this._initialized = true
    _instance = this
  }

  async switchLocale(locale: string): Promise<boolean> {
    return this.core.switchLocale(locale)
  }

  async loadNamespace(locale: string, ns: string): Promise<boolean> {
    return this.core.loadNamespace(locale, ns)
  }

  destroy(): void {
    this._unsubscribers.forEach(fn => fn())
    this._unsubscribers = []
    this.core.destroy()
    this._initialized = false
    if (_instance === this)
      _instance = null
  }
}

export function createI18n(config: I18nVueConfig): I18nVueManager & Plugin {
  const manager = new I18nVueManager(config)
  const plugin = manager as I18nVueManager & Plugin
  plugin.install = manager.install.bind(manager)
  return plugin
}

export function getI18nManager(): I18nVueManager {
  if (!_instance)
    throw new Error('[i18n-sdk] I18nVueManager not initialized. Call i18n.install(app) first.')
  return _instance
}
