export { createI18n, getI18nManager, I18nVueManager } from './plugin'
export { useI18nManager, useI18nNamespace, useLocale, useTranslation } from './composables'
export type { I18nVueConfig, I18nVuePluginOptions } from './types'

export {
  I18nCore,
  I18N_DEFAULTS,
  LocaleManager,
  normalizeLocale,
  isStandardLocale,
  resolveConfig,
} from '@supernova/i18n-sdk'
export type {
  I18nCoreConfig,
  I18nHooks,
  I18nResolvedConfig,
  LocaleInfo,
  MessageResource,
} from '@supernova/i18n-sdk'
