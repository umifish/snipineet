import { inject, onUnmounted, ref } from 'vue'
import type { Ref } from 'vue'
import { useI18n } from 'vue-i18n'
import type { UseI18nOptions, Composer } from 'vue-i18n'
import type { I18nVueManager } from './plugin'

export function useTranslation(options?: UseI18nOptions): Composer {
  return useI18n(options) as Composer
}

export function useI18nManager(): I18nVueManager {
  const manager = inject<I18nVueManager>('i18nVueManager')
  if (!manager)
    throw new Error('[i18n-sdk] I18nVueManager not found. Did you install the plugin?')
  return manager
}

export function useLocale(): { locale: Ref<string>, switchLocale: (locale: string) => Promise<boolean> } {
  const manager = useI18nManager()
  const locale = ref(manager.core.locale)

  const off = manager.core.on('localeChange', ({ locale: newLocale }) => {
    locale.value = newLocale
  })

  onUnmounted(off)

  const switchLocale = (newLocale: string) => manager.switchLocale(newLocale)

  return { locale, switchLocale }
}

export function useI18nNamespace(ns: string): { ready: Ref<boolean>, load: () => Promise<boolean>, manager: I18nVueManager } {
  const manager = useI18nManager()
  const ready = ref(manager.core.isNamespaceLoaded(manager.core.locale, ns))

  const load = async () => {
    const success = await manager.loadNamespace(manager.core.locale, ns)
    ready.value = success
    return success
  }

  if (!ready.value)
    load()

  const off = manager.core.on('localeChange', ({ locale }) => {
    const loaded = manager.core.isNamespaceLoaded(locale, ns)
    ready.value = loaded
    if (!loaded)
      load()
  })

  onUnmounted(off)

  return { ready, load, manager }
}
