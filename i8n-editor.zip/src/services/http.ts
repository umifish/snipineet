import type { RequestActionConfig, RequestMethod } from '../types'

const methodsWithBody = new Set<RequestMethod>(['POST', 'PUT', 'PATCH', 'DELETE'])

export async function executeActionRequest<TInput, TOutput>(
  actionConfig: RequestActionConfig<TInput, TOutput>,
  input: TInput,
  defaultHeaders?: Record<string, string>,
): Promise<TOutput> {
  const method = actionConfig.method || 'GET'
  const endpoint = resolveEndpoint(actionConfig.endpoint, input)
  const query = actionConfig.queryBuilder?.(input)
  const requester = actionConfig.requester || getDefaultRequester()

  const headers = {
    ...(defaultHeaders || {}),
    ...(actionConfig.headers || {}),
  }

  const init: RequestInit = {
    method,
    headers,
  }

  if (methodsWithBody.has(method)) {
    const body = actionConfig.bodyBuilder ? actionConfig.bodyBuilder(input) : input
    if (body !== undefined) {
      if (!headers['Content-Type']) {
        headers['Content-Type'] = 'application/json'
      }

      init.body = typeof body === 'string' ? body : JSON.stringify(body)
    }
  }

  const url = buildUrl(endpoint, actionConfig.baseUrl, query)
  const response = await requester(url, init)
  if (!response.ok) {
    throw new Error(`[I18n Editor Error]: Request failed with status ${response.status}.`)
  }

  const payload = await parseResponsePayload(response)
  const adapter = actionConfig.responseAdapter || ((raw: unknown) => raw as TOutput)
  return adapter(payload, input)
}

function resolveEndpoint<TInput>(endpoint: string | ((input: TInput) => string), input: TInput): string {
  return typeof endpoint === 'function' ? endpoint(input) : endpoint
}

function buildUrl(endpoint: string, baseUrl?: string, query?: Record<string, unknown>): string {
  const url = resolveAbsoluteUrl(endpoint, baseUrl)
  if (!query || Object.keys(query).length === 0) {
    return url
  }

  const parsed = new URL(url)
  for (const [key, value] of Object.entries(query)) {
    if (value === undefined || value === null || value === '') {
      continue
    }

    parsed.searchParams.set(key, String(value))
  }

  return parsed.toString()
}

function resolveAbsoluteUrl(endpoint: string, baseUrl?: string): string {
  try {
    return new URL(endpoint).toString()
  }
  catch {
    return new URL(endpoint, getBaseUrl(baseUrl)).toString()
  }
}

function getBaseUrl(baseUrl?: string): string {
  if (baseUrl) {
    return baseUrl
  }

  const globalScope = globalThis as {
    location?: { origin?: string }
  }

  return globalScope.location?.origin || 'http://localhost'
}

async function parseResponsePayload(response: Response): Promise<unknown> {
  const contentType = response.headers.get('content-type') || ''
  if (contentType.includes('application/json')) {
    return response.json()
  }

  const text = await response.text()
  try {
    return JSON.parse(text)
  }
  catch {
    return text
  }
}

function getDefaultRequester(): (input: string, init?: RequestInit) => Promise<Response> {
  const globalScope = globalThis as {
    fetch?: (input: string, init?: RequestInit) => Promise<Response>
  }

  if (!globalScope.fetch) {
    throw new Error('[I18n Editor Error]: No fetch implementation found. Please provide request requester.')
  }

  return globalScope.fetch
}
