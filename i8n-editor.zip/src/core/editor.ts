import type {
  CreateEntryInput,
  I18nEditorConfig,
  I18nEditorEntry,
  QueryEntriesInput,
  RequestActionConfig,
  UpdateEntryInput,
} from '../types'
import { executeActionRequest } from '../services/http'

const DEFAULT_QUERY_ENDPOINT = '/api/i18n/editor/entries'
const DEFAULT_CREATE_ENDPOINT = '/api/i18n/editor/entries'
const DEFAULT_UPDATE_ENDPOINT = '/api/i18n/editor/entries'

export class I18nEditorClient {
  private config: RequiredPick<I18nEditorConfig, 'defaultHeaders'> & I18nEditorConfig

  constructor(config: I18nEditorConfig = {}) {
    this.config = {
      ...config,
      defaultHeaders: config.defaultHeaders || {},
      queryRequest: createQueryRequest(config),
      createRequest: createCreateRequest(config),
      updateRequest: createUpdateRequest(config),
    }
  }

  public async queryEntries(input: QueryEntriesInput = {}): Promise<I18nEditorEntry[]> {
    return executeActionRequest(this.config.queryRequest!, input, this.config.defaultHeaders)
  }

  public async createEntry(input: CreateEntryInput): Promise<I18nEditorEntry> {
    return executeActionRequest(this.config.createRequest!, input, this.config.defaultHeaders)
  }

  public async updateEntry(input: UpdateEntryInput): Promise<I18nEditorEntry> {
    return executeActionRequest(this.config.updateRequest!, input, this.config.defaultHeaders)
  }

  public async getEntry(key: string, lang: string, namespace?: string): Promise<I18nEditorEntry | undefined> {
    const result = await this.queryEntries({
      key,
      lang,
      namespace,
      page: 1,
      pageSize: 1,
    })

    return result[0]
  }
}

type RequiredPick<T, K extends keyof T> = T & Required<Pick<T, K>>

function createQueryRequest(config: I18nEditorConfig): RequestActionConfig<QueryEntriesInput, I18nEditorEntry[]> {
  return {
    baseUrl: config.baseUrl,
    bodyBuilder: input => input,
    endpoint: DEFAULT_QUERY_ENDPOINT,
    method: 'GET',
    queryBuilder: input => input,
    responseAdapter: defaultQueryResponseAdapter,
    ...config.queryRequest,
  }
}

function createCreateRequest(config: I18nEditorConfig): RequestActionConfig<CreateEntryInput, I18nEditorEntry> {
  return {
    baseUrl: config.baseUrl,
    bodyBuilder: input => input,
    endpoint: DEFAULT_CREATE_ENDPOINT,
    method: 'POST',
    responseAdapter: defaultEntryResponseAdapter,
    ...config.createRequest,
  }
}

function createUpdateRequest(config: I18nEditorConfig): RequestActionConfig<UpdateEntryInput, I18nEditorEntry> {
  return {
    baseUrl: config.baseUrl,
    bodyBuilder: input => input,
    endpoint: input => input.id ? `${DEFAULT_UPDATE_ENDPOINT}/${encodeURIComponent(input.id)}` : DEFAULT_UPDATE_ENDPOINT,
    method: 'PUT',
    responseAdapter: defaultEntryResponseAdapter,
    ...config.updateRequest,
  }
}

function defaultQueryResponseAdapter(payload: unknown): I18nEditorEntry[] {
  if (Array.isArray(payload)) {
    return payload as I18nEditorEntry[]
  }

  if (payload && typeof payload === 'object') {
    const record = payload as Record<string, unknown>
    const candidates = [record.data, record.items, record.list]
    for (const candidate of candidates) {
      if (Array.isArray(candidate)) {
        return candidate as I18nEditorEntry[]
      }
    }
  }

  throw new TypeError('[I18n Editor Error]: queryRequest response adapter must return entry array.')
}

function defaultEntryResponseAdapter(payload: unknown): I18nEditorEntry {
  if (isEntry(payload)) {
    return payload
  }

  if (payload && typeof payload === 'object') {
    const record = payload as Record<string, unknown>
    const candidate = record.data
    if (isEntry(candidate)) {
      return candidate
    }
  }

  throw new TypeError('[I18n Editor Error]: create/update response adapter must return one entry object.')
}

function isEntry(value: unknown): value is I18nEditorEntry {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    return false
  }

  const record = value as Record<string, unknown>
  return typeof record.key === 'string'
    && typeof record.lang === 'string'
    && typeof record.value === 'string'
}
