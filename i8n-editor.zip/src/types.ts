export type RequestMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE'

export interface I18nEditorEntry {
  id?: string
  key: string
  lang: string
  value: string
  namespace?: string
  metadata?: Record<string, unknown>
  [extra: string]: unknown
}

export interface QueryEntriesInput {
  key?: string
  lang?: string
  namespace?: string
  page?: number
  pageSize?: number
  [extra: string]: unknown
}

export interface CreateEntryInput {
  key: string
  lang: string
  value: string
  namespace?: string
  metadata?: Record<string, unknown>
  [extra: string]: unknown
}

export interface UpdateEntryInput {
  id?: string
  key: string
  lang: string
  value: string
  namespace?: string
  metadata?: Record<string, unknown>
  [extra: string]: unknown
}

export interface RequestActionConfig<TInput, TOutput> {
  endpoint: string | ((input: TInput) => string)
  method?: RequestMethod
  headers?: Record<string, string>
  baseUrl?: string
  requester?: (input: string, init?: RequestInit) => Promise<Response>
  queryBuilder?: (input: TInput) => Record<string, unknown>
  bodyBuilder?: (input: TInput) => unknown
  responseAdapter?: (payload: unknown, input: TInput) => TOutput
}

export interface I18nEditorConfig {
  baseUrl?: string
  defaultHeaders?: Record<string, string>
  queryRequest?: RequestActionConfig<QueryEntriesInput, I18nEditorEntry[]>
  createRequest?: RequestActionConfig<CreateEntryInput, I18nEditorEntry>
  updateRequest?: RequestActionConfig<UpdateEntryInput, I18nEditorEntry>
}

export interface I18nEditorFieldState {
  value: string
  loading: boolean
  saving: boolean
  error?: Error
}
