export { I18nEditorField } from './integrations/vue3'
export { default as I18nElementInputEditor } from './integrations/vue3-element-plus.vue'
