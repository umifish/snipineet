<script lang="ts">
import type { PropType, VNode } from 'vue'
import type { I18nEditorClient } from '../core/editor'
import type { I18nEditorEntry, QueryEntriesInput } from '../types'
import { CollectionTag } from '@element-plus/icons-vue'
import { ElButton, ElDialog, ElInput, ElTableV2 } from 'element-plus'
import { computed, defineComponent, h, ref, useAttrs, watch } from 'vue'

interface I18nEditorTableColumn {
  key: string
  dataKey: string
  title: string
  width: number
}

export default defineComponent({
  name: 'I18nElementInputEditor',
  inheritAttrs: false,
  props: {
    client: {
      type: Object as PropType<I18nEditorClient>,
      required: true,
    },
    modelValue: {
      type: [String, Number] as PropType<string | number>,
      default: '',
    },
    enableI18n: {
      type: Boolean,
      default: true,
    },
    dialogTitle: {
      type: String,
      default: '国际化文案编辑器',
    },
    dialogWidth: {
      type: [Number, String] as PropType<number | string>,
      default: 980,
    },
    queryInput: {
      type: Object as PropType<Omit<QueryEntriesInput, 'key'>>,
      default: () => ({}),
    },
    queryKeyResolver: {
      type: Function as PropType<(value: string) => string>,
      default: undefined,
    },
    tableHeight: {
      type: Number,
      default: 420,
    },
    tableWidth: {
      type: Number,
      default: 920,
    },
    wrappedInput: {
      type: [String, Object] as PropType<string | object>,
      default: 'el-input',
    },
  },
  emits: ['update:modelValue', 'change', 'query'],
  setup(props, { emit, slots }) {
    const attrs = useAttrs()
    const dialogVisible = ref(false)
    const querying = ref(false)
    const queryError = ref<Error | undefined>()
    const rows = ref<I18nEditorEntry[]>([])
    const currentValue = ref(String(props.modelValue ?? ''))

    const columns = computed<I18nEditorTableColumn[]>(() => [
      { dataKey: 'key', key: 'key', title: 'Key', width: 260 },
      { dataKey: 'lang', key: 'lang', title: '语种', width: 120 },
      { dataKey: 'namespace', key: 'namespace', title: '命名空间', width: 150 },
      { dataKey: 'value', key: 'value', title: '文案值', width: Math.max(props.tableWidth - 530, 360) },
    ])

    watch(
      () => props.modelValue,
      (next) => {
        currentValue.value = String(next ?? '')
      },
    )

    const queryByInputValue = async () => {
      const rawKey = currentValue.value
      const key = props.queryKeyResolver ? props.queryKeyResolver(rawKey) : rawKey

      if (!key.trim()) {
        rows.value = []
        return
      }

      querying.value = true
      queryError.value = undefined
      emit('query', key)

      try {
        const list = await props.client.queryEntries({
          ...props.queryInput,
          key,
        })
        rows.value = list
      }
      catch (error) {
        queryError.value = error as Error
      }
      finally {
        querying.value = false
      }
    }

    const openDialog = async () => {
      if (!props.enableI18n) {
        return
      }

      dialogVisible.value = true
      await queryByInputValue()
    }

    const interceptInputValue = (nextValue: unknown) => {
      const normalizedValue = normalizeInputValue(nextValue)
      currentValue.value = normalizedValue
      emit('update:modelValue', normalizedValue)
      emit('change', normalizedValue)

      callMaybeFunction(attrs['onUpdate:modelValue'], normalizedValue)
      callMaybeFunction(attrs.onInput, nextValue)
      callMaybeFunction(attrs.onChange, normalizedValue)
    }

    const renderPrefix = (): VNode => h(
      'span',
      {
        class: 'supernova-i18n-editor-prefix',
        onClick: () => {
          void openDialog()
        },
        onMousedown: (event: MouseEvent) => {
          event.preventDefault()
          event.stopPropagation()
        },
      },
      [h(CollectionTag, { style: 'width: 1em; height: 1em;' })],
    )

    const renderInput = (): VNode => {
      const inputProps = {
        ...attrs,
        'modelValue': currentValue.value,
        'onUpdate:modelValue': interceptInputValue,
      }

      if (slots.default) {
        return h('div', [
          slots.default({
            attrs: inputProps,
            openEditor: openDialog,
            value: currentValue.value,
          }),
        ])
      }

      const targetInput = props.wrappedInput === 'el-input' ? ElInput : props.wrappedInput
      return h(targetInput as string | object, inputProps, {
        ...slots,
        prefix: () => {
          if (!props.enableI18n) {
            return slots.prefix?.()
          }

          return [
            renderPrefix(),
            ...(slots.prefix?.() || []),
          ]
        },
      })
    }

    const renderDialog = (): VNode => h(ElDialog, {
      'appendToBody': true,
      'modelValue': dialogVisible.value,
      'onUpdate:modelValue': (next: boolean) => {
        dialogVisible.value = next
      },
      'title': props.dialogTitle,
      'width': props.dialogWidth,
    }, {
      default: () => [
        h('div', { style: 'display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;' }, [
          h('div', { style: 'font-size:13px;color:#6b7280;' }, `查询 Key: ${currentValue.value || '-'}`),
          h(ElButton, {
            loading: querying.value,
            type: 'primary',
            onClick: () => {
              void queryByInputValue()
            },
          }, () => '重新查询'),
        ]),
        queryError.value
          ? h('div', { style: 'color:#dc2626;margin-bottom:8px;' }, queryError.value.message)
          : null,
        h(ElTableV2, {
          columns: columns.value,
          data: rows.value,
          height: props.tableHeight,
          width: props.tableWidth,
        }),
      ],
    })

    return (): VNode => h('div', { class: 'supernova-i18n-editor-input' }, [
      renderInput(),
      renderDialog(),
    ])
  },
})

function callMaybeFunction(handler: unknown, value: unknown): void {
  if (Array.isArray(handler)) {
    for (const item of handler) {
      if (typeof item === 'function') {
        item(value)
      }
    }

    return
  }

  if (typeof handler === 'function') {
    handler(value)
  }
}

function normalizeInputValue(value: unknown): string {
  if (value && typeof value === 'object' && 'target' in value) {
    const target = (value as { target?: { value?: unknown } }).target
    if (target && 'value' in target) {
      return String(target.value ?? '')
    }
  }

  return String(value ?? '')
}
</script>
