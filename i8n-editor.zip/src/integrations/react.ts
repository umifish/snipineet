import type React from 'react'
import type { I18nEditorClient } from '../core/editor'
import { cloneElement, createElement, isValidElement, useEffect, useState } from 'react'

interface FieldRenderContext {
  error?: Error
  loading: boolean
  saving: boolean
  updateValue: (value: unknown) => Promise<void>
  value: string
}

export interface I18nEditorFieldProps {
  as?: React.ElementType
  children?: React.ReactNode | ((context: FieldRenderContext) => React.ReactNode)
  client: I18nEditorClient
  keyName: string
  lang: string | (() => string)
  namespace?: string
  valueProp?: string
  changeProp?: string
  [extra: string]: unknown
}

export function I18nEditorField(props: I18nEditorFieldProps): React.ReactElement {
  const {
    as,
    changeProp = 'onChange',
    children,
    client,
    keyName,
    lang,
    namespace,
    valueProp = 'value',
    ...passthroughProps
  } = props

  const [value, setValue] = useState('')
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<Error | undefined>(undefined)
  const [entryId, setEntryId] = useState<string | undefined>(undefined)

  const resolveLang = (): string => typeof lang === 'function' ? lang() : lang

  useEffect(() => {
    let cancelled = false

    const load = async () => {
      setLoading(true)
      setError(undefined)
      try {
        const entry = await client.getEntry(keyName, resolveLang(), namespace)
        if (!cancelled) {
          setValue(entry?.value || '')
          setEntryId(entry?.id ? String(entry.id) : undefined)
        }
      }
      catch (err) {
        if (!cancelled) {
          setError(err as Error)
        }
      }
      finally {
        if (!cancelled) {
          setLoading(false)
        }
      }
    }

    void load()
    return () => {
      cancelled = true
    }
  }, [client, keyName, namespace])

  const save = async (nextValue: unknown): Promise<void> => {
    const normalizedValue = normalizeInputValue(nextValue)
    setValue(normalizedValue)
    setSaving(true)
    setError(undefined)

    try {
      if (entryId) {
        const updated = await client.updateEntry({
          id: entryId,
          key: keyName,
          lang: resolveLang(),
          namespace,
          value: normalizedValue,
        })

        if (updated.id) {
          setEntryId(String(updated.id))
        }
      }
      else {
        const created = await client.createEntry({
          key: keyName,
          lang: resolveLang(),
          namespace,
          value: normalizedValue,
        })

        if (created.id) {
          setEntryId(String(created.id))
        }
      }
    }
    catch (err) {
      setError(err as Error)
    }
    finally {
      setSaving(false)
    }
  }

  const fieldState: FieldRenderContext = {
    error,
    loading,
    saving,
    updateValue: save,
    value,
  }

  if (typeof children === 'function') {
    return createElement('div', {}, children(fieldState))
  }

  const targetProps = {
    ...passthroughProps,
    [changeProp]: save,
    [valueProp]: value,
  }

  if (isValidElement(children)) {
    return cloneElement(children, targetProps)
  }

  return createElement(as || 'input', targetProps, children)
}

function normalizeInputValue(value: unknown): string {
  if (value && typeof value === 'object' && 'target' in value) {
    const target = (value as { target?: { value?: unknown } }).target
    if (target && 'value' in target) {
      return String(target.value ?? '')
    }
  }

  return String(value ?? '')
}
