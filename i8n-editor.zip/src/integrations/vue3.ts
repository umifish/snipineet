import type { Component, VNode } from 'vue'
import type { I18nEditorClient } from '../core/editor'
import { defineComponent, h, onMounted, ref, useAttrs } from 'vue'

type FieldLanguageResolver = string | (() => string)

export const I18nEditorField = defineComponent({
  name: 'I18nEditorField',
  inheritAttrs: false,
  props: {
    as: {
      type: [String, Object] as unknown as () => string | Component,
      default: 'input',
    },
    client: {
      type: Object as () => I18nEditorClient,
      required: true,
    },
    keyName: {
      type: String,
      required: true,
    },
    lang: {
      type: [String, Function] as unknown as () => FieldLanguageResolver,
      required: true,
    },
    namespace: {
      type: String,
      required: false,
      default: undefined,
    },
    modelProp: {
      type: String,
      default: 'modelValue',
    },
    changeEvent: {
      type: String,
      default: 'onUpdate:modelValue',
    },
  },
  setup(props, { slots }) {
    const attrs = useAttrs()
    const value = ref('')
    const loading = ref(false)
    const saving = ref(false)
    const entryId = ref<string | undefined>()
    const error = ref<Error | undefined>()

    const resolveLang = (): string => typeof props.lang === 'function' ? props.lang() : props.lang

    const load = async () => {
      loading.value = true
      error.value = undefined
      try {
        const entry = await props.client.getEntry(props.keyName, resolveLang(), props.namespace)
        value.value = entry?.value || ''
        entryId.value = entry?.id ? String(entry.id) : undefined
      }
      catch (err) {
        error.value = err as Error
      }
      finally {
        loading.value = false
      }
    }

    const save = async (nextValue: unknown) => {
      const normalizedValue = String(nextValue ?? '')
      value.value = normalizedValue
      saving.value = true
      error.value = undefined
      try {
        if (entryId.value) {
          const updated = await props.client.updateEntry({
            id: entryId.value,
            key: props.keyName,
            lang: resolveLang(),
            namespace: props.namespace,
            value: normalizedValue,
          })
          entryId.value = updated.id ? String(updated.id) : entryId.value
        }
        else {
          const created = await props.client.createEntry({
            key: props.keyName,
            lang: resolveLang(),
            namespace: props.namespace,
            value: normalizedValue,
          })
          entryId.value = created.id ? String(created.id) : undefined
        }
      }
      catch (err) {
        error.value = err as Error
      }
      finally {
        saving.value = false
      }
    }

    onMounted(load)

    return (): VNode => {
      if (slots.default) {
        return h('div', [
          slots.default({
            attrs,
            error: error.value,
            loading: loading.value,
            saving: saving.value,
            updateValue: save,
            value: value.value,
          }),
        ])
      }

      const componentProps = {
        ...attrs,
        [props.changeEvent]: save,
        [props.modelProp]: value.value,
      }

      return h(props.as as string | Component, componentProps, slots)
    }
  },
})
