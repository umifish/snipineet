import { fileURLToPath } from 'node:url'
import vue from '@vitejs/plugin-vue'
import { defineConfig } from 'vite'

const entries = {
  index: fileURLToPath(new URL('./src/index.ts', import.meta.url)),
  react: fileURLToPath(new URL('./src/react.ts', import.meta.url)),
  vue3: fileURLToPath(new URL('./src/vue3.ts', import.meta.url)),
}

export default defineConfig({
  plugins: [vue()],
  build: {
    lib: {
      entry: entries,
      name: 'SupernovaI18nEditor',
      formats: ['es', 'cjs'],
      fileName: (format, entryName) => `${entryName}.${format === 'es' ? 'js' : 'cjs'}`,
    },
    sourcemap: true,
    emptyOutDir: true,
    rollupOptions: {
      external: [
        '@element-plus/icons-vue',
        'element-plus',
        'react',
        'vue',
      ],
    },
  },
})
