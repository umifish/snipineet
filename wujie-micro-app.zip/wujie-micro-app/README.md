# wujie-micro-app

传输无关的**前端微服务通信协议工具包** + 既可做主也可做子的**应用模板**。

协议核心（`@intelli/protocol-core`）**零 wujie 依赖**，wujie 仅作为其中一种传输适配器。
支持多层嵌套拓扑（`host a → b（主+子）→ c`）下的点对点 / 广播 / 主子 / 子主 / 子子通信。

## 包总览

| 包 | 作用 | 依赖 wujie |
| --- | --- | --- |
| `@intelli/protocol-core` | 类型 / Envelope / 路由 / 事件 / request-response / 握手注册（纯消息） | 否 |
| `@intelli/context` | 可选的共享状态薄层（快照 + 订阅 + 变更广播） | 否 |
| `@intelli/transport-memory` | 进程内传输，用于单测 / 同页演示 | 否 |
| `@intelli/transport-postmessage` | postMessage 传输，用于 iframe / 跨窗口 | 否 |
| `@intelli/transport-broadcastchannel` | BroadcastChannel 传输，用于跨标签页 | 否 |
| `@intelli/wujie-transport` | wujie bus 适配 + 配置映射 | **是** |
| `@intelli/app-kit` | 框架无关运行时（角色识别 / 链路装配 / 预加载策略） | 否 |
| `@intelli/react` | React 适配（基于 wujie-react） | 是（间接） |

## 设计要点

- **多层路由**：每个 `ProtocolNode` 持 `uplink`（父级总线参与者）与 `downlink`（自身总线 hub），跨层消息逐跳中继。
- **寻址**：`unicast | broadcast | parent | children | subtree | ancestors`，带 ttl / hop 去重防环。
- **初始状态**：经 wujie props 同步注入（首帧无闪烁）；后续变更走消息。
- **解耦**：核心只依赖抽象 `Transport` 接口。

## 常用脚本

```bash
pnpm install
pnpm -r build       # 全包构建
pnpm -r test        # 单测
pnpm typecheck
pnpm lint
```

执行进度见 [docs/EXECUTION_PLAN.md](docs/EXECUTION_PLAN.md)。
