/**
 * dev-matrix：一键拉起三层联调矩阵（Host A → App B → App C）。
 *
 * 端口：host-a 4310 / app-b 4311 / app-c 4312（避开 5173/5174）。
 * 先构建 @intelli/* 库包（供 demo 经 exports 解析 dist），再并行启动三个 vite dev server。
 */
import { spawn } from 'node:child_process'
import process from 'node:process'

const PNPM = process.platform === 'win32' ? 'pnpm.cmd' : 'pnpm'

const APPS = [
  { name: 'host-a', filter: '@intelli/demo-host-a', color: 36 },
  { name: 'app-b ', filter: '@intelli/demo-app-b', color: 33 },
  { name: 'app-c ', filter: '@intelli/demo-app-c', color: 35 },
]

function prefixWrite(prefix, chunk, stream) {
  const text = chunk.toString()
  for (const line of text.split('\n')) {
    if (line.length > 0) {
      stream.write(`${prefix} ${line}\n`)
    }
  }
}

function run(args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(PNPM, args, { stdio: 'inherit', ...options })
    child.on('exit', (code) => (code === 0 ? resolve() : reject(new Error(`pnpm ${args.join(' ')} exited ${code}`))))
  })
}

async function main() {
  console.log('▶ 构建 @intelli/* 库包…')
  await run(['--filter', './packages/*', '-r', 'build'])

  console.log('▶ 启动三层联调矩阵…')
  const children = APPS.map((app) => {
    const child = spawn(PNPM, ['--filter', app.filter, 'dev'], { stdio: ['ignore', 'pipe', 'pipe'] })
    const prefix = `\x1B[${app.color}m[${app.name}]\x1B[0m`
    child.stdout.on('data', (chunk) => prefixWrite(prefix, chunk, process.stdout))
    child.stderr.on('data', (chunk) => prefixWrite(prefix, chunk, process.stderr))
    return child
  })

  const shutdown = () => {
    for (const child of children) {
      child.kill('SIGINT')
    }
    process.exit(0)
  }
  process.on('SIGINT', shutdown)
  process.on('SIGTERM', shutdown)
}

main().catch((error) => {
  console.error(error)
  process.exit(1)
})
