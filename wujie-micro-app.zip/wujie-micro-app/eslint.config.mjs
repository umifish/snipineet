/**
 * ESLint Flat Config —— 基础规则集来自 `@antfu/eslint-config`。
 * 本文件只写本仓库的 ignores 与必要覆盖，对齐 supernova 的工程约定。
 */
import antfu from '@antfu/eslint-config'

export default antfu({
  ignores: [
    '**/node_modules/**',
    '**/.pnpm/**',
    '**/dist/**',
    '**/build/**',
    '**/coverage/**',
    '**/*.min.js',
  ],
  rules: {
    'no-console': 'off',
    'style/arrow-parens': ['error', 'always'],
    'style/brace-style': ['error', '1tbs'],
    'curly': ['error', 'all'],
  },
})
