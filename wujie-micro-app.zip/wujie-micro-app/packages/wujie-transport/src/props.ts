/**
 * props 注入：宿主把身份与初始上下文经 wujie props 同步传给子应用，首帧无闪烁。
 */
import type { ContextSnapshot, MicroAppConfig } from '@intelli/protocol-core'
import { getWujieProps } from './bus'

/** 注入 props 中协议数据的键名。 */
export const INTELLI_PROPS_KEY = '__intelli__'

/** 被注入到子应用的协议数据。 */
export interface IntelliInjectedProps {
  id: string
  name?: string
  parentId?: string
  snapshot?: ContextSnapshot
  extra?: Record<string, unknown>
}

/** 从配置中提取初始上下文快照。 */
export function pickContext(config: MicroAppConfig): ContextSnapshot {
  const snapshot: ContextSnapshot = {}
  if (config.theme !== undefined) {
    snapshot.theme = config.theme
  }
  if (config.language !== undefined) {
    snapshot.language = config.language
  }
  if (config.timezone !== undefined) {
    snapshot.timezone = config.timezone
  }
  if (config.token !== undefined) {
    snapshot.token = config.token
  }
  return snapshot
}

/** 构造传给 wujie 的 props 对象。 */
export function buildInjectedProps(
  config: MicroAppConfig,
  options?: { parentId?: string, snapshot?: ContextSnapshot },
): Record<string, unknown> {
  const injected: IntelliInjectedProps = {
    id: config.id,
    name: config.name,
    parentId: options?.parentId,
    snapshot: options?.snapshot ?? pickContext(config),
    extra: config.extra,
  }
  return {
    ...(config.extra ?? {}),
    [INTELLI_PROPS_KEY]: injected,
  }
}

/** 在子应用中读取被注入的协议数据。 */
export function readInjectedProps(): IntelliInjectedProps | undefined {
  const props = getWujieProps()
  return props?.[INTELLI_PROPS_KEY] as IntelliInjectedProps | undefined
}
