/**
 * wujie 生命周期封装（本包是唯一依赖 wujie 运行时的地方）。
 */
import type { MicroAppConfig } from '@intelli/protocol-core'
import type { WujieBusLike } from './bus'
import type { MapOptions, WujiePreloadOptions, WujieStartOptions } from './config'
import * as wujieModule from 'wujie'
import { toWujiePreloadOptions, toWujieStartOptions } from './config'

interface WujieApi {
  startApp: (options: WujieStartOptions) => Promise<void | (() => void)>
  preloadApp: (options: WujiePreloadOptions) => void
  destroyApp: (name: string) => void
  bus: WujieBusLike
}

// wujie 以命名导出提供这些 API；用最小接口转换以避免耦合其具体类型声明。
const api = wujieModule as unknown as WujieApi

/** 宿主侧 bus（作为 downlink 接入协议节点）。 */
export function hostBus(): WujieBusLike {
  return api.bus
}

/** 挂载子应用。 */
export function mountApp(config: MicroAppConfig, options: MapOptions): Promise<void | (() => void)> {
  return api.startApp(toWujieStartOptions(config, options))
}

/** 预加载子应用。 */
export function preloadMicroApp(config: MicroAppConfig, options: MapOptions = {}): void {
  api.preloadApp(toWujiePreloadOptions(config, options))
}

/** 销毁子应用。 */
export function destroyMicroApp(idOrConfig: string | MicroAppConfig): void {
  const name = typeof idOrConfig === 'string' ? idOrConfig : idOrConfig.id
  api.destroyApp(name)
}
