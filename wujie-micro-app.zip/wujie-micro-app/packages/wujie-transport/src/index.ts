/**
 * @intelli/wujie-transport —— wujie bus 适配 + 配置映射 + 生命周期封装。
 * 本包是工具集中唯一依赖 wujie 的部分。
 */
export type { WujieBusLike } from './bus'
export { createWujieTransport, DEFAULT_WUJIE_EVENT, getWujieProps, getWujieSubBus, isPoweredByWujie } from './bus'
export type { MapOptions, WujiePreloadOptions, WujieStartOptions } from './config'
export { toWujiePreloadOptions, toWujieStartOptions } from './config'
export { destroyMicroApp, hostBus, mountApp, preloadMicroApp } from './lifecycle'
export type { IntelliInjectedProps } from './props'
export { buildInjectedProps, INTELLI_PROPS_KEY, pickContext, readInjectedProps } from './props'
