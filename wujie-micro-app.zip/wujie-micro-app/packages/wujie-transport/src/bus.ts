/**
 * wujie bus 适配。把协议信封承载在单个 bus 事件上。
 *
 * wujie 的 bus 是按宿主共享的实例：宿主侧将其作为 downlink，注入到各子应用作为 uplink。
 * bus.$emit 会触发同一 bus 上所有 $on（含发送者自身），自回声由协议节点的去重缓存丢弃。
 */
import type { Envelope, Transport } from '@intelli/protocol-core'

/** 承载协议信封的 bus 事件名。 */
export const DEFAULT_WUJIE_EVENT = '__intelli_wujie__'

/** wujie bus 的最小接口（避免耦合 wujie 具体类型）。 */
export interface WujieBusLike {
  $on: (event: string, fn: (...args: unknown[]) => void) => void
  $off: (event: string, fn: (...args: unknown[]) => void) => void
  $emit: (event: string, ...args: unknown[]) => void
}

interface WujieGlobal {
  bus?: WujieBusLike
  props?: Record<string, unknown>
}

/** 基于给定 bus 创建传输。宿主侧传入 wujie 的 bus；子侧传入 window.$wujie.bus。 */
export function createWujieTransport(bus: WujieBusLike, eventName: string = DEFAULT_WUJIE_EVENT): Transport {
  let handler: ((...args: unknown[]) => void) | undefined

  return {
    kind: 'wujie',
    send(envelope: Envelope) {
      bus.$emit(eventName, envelope)
    },
    subscribe(onEnvelope) {
      handler = (...args: unknown[]) => {
        onEnvelope(args[0] as Envelope)
      }
      bus.$on(eventName, handler)
      return () => {
        if (handler) {
          bus.$off(eventName, handler)
          handler = undefined
        }
      }
    },
    close() {
      if (handler) {
        bus.$off(eventName, handler)
        handler = undefined
      }
    },
  }
}

/** 在子应用中读取被注入的 bus（window.$wujie.bus）。 */
export function getWujieSubBus(): WujieBusLike | undefined {
  return (globalThis as { $wujie?: WujieGlobal }).$wujie?.bus
}

/** 是否运行在 wujie 子应用环境中。 */
export function isPoweredByWujie(): boolean {
  return Boolean((globalThis as { __POWERED_BY_WUJIE__?: boolean }).__POWERED_BY_WUJIE__)
}

/** 读取 wujie 注入的 props。 */
export function getWujieProps(): Record<string, unknown> | undefined {
  return (globalThis as { $wujie?: WujieGlobal }).$wujie?.props
}
