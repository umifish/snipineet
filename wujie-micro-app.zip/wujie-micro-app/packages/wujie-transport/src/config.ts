/**
 * MicroAppConfig → wujie startApp/preloadApp 选项映射。
 *
 * 注意：preloadApp 不接受 sync 字段，仅 startApp 使用 sync。
 */
import type { ContextSnapshot, MicroAppConfig } from '@intelli/protocol-core'
import { buildInjectedProps } from './props'

/** startApp 选项（子集）。 */
export interface WujieStartOptions {
  name: string
  url: string
  el?: string | HTMLElement
  alive?: boolean
  sync?: boolean
  attrs?: Record<string, unknown>
  props?: Record<string, unknown>
}

/** preloadApp 选项（子集，无 sync）。 */
export interface WujiePreloadOptions {
  name: string
  url: string
  alive?: boolean
  attrs?: Record<string, unknown>
  props?: Record<string, unknown>
}

/** 映射参数。 */
export interface MapOptions {
  /** 挂载容器（startApp 用）。 */
  el?: string | HTMLElement
  /** 父应用 id。 */
  parentId?: string
  /** 初始上下文快照（默认从 config 提取）。 */
  snapshot?: ContextSnapshot
}

/** 映射为 startApp 选项。wujie 的 name 必须唯一，故用 config.id。 */
export function toWujieStartOptions(config: MicroAppConfig, options: MapOptions = {}): WujieStartOptions {
  return {
    name: config.id,
    url: config.url,
    el: options.el,
    alive: config.alive,
    sync: config.sync,
    attrs: config.attrs,
    props: buildInjectedProps(config, { parentId: options.parentId, snapshot: options.snapshot }),
  }
}

/** 映射为 preloadApp 选项（不含 sync）。 */
export function toWujiePreloadOptions(config: MicroAppConfig, options: MapOptions = {}): WujiePreloadOptions {
  return {
    name: config.id,
    url: config.url,
    alive: config.alive,
    attrs: config.attrs,
    props: buildInjectedProps(config, { parentId: options.parentId, snapshot: options.snapshot }),
  }
}
