/**
 * @intelli/context —— 可选的共享状态薄层，建在 protocol-core 的消息之上。
 *
 * 设计：
 * - 单 owner（根 host）持有权威状态；
 * - 初始值经构造入参注入（来自 wujie props / 握手快照），首帧无闪烁；
 * - owner.set 会向 subtree 广播 context_changed 与对应的 *_changed 事件；
 * - 非 owner.set 转为向 owner（ancestors）发起变更请求，由 owner 决策后广播；
 * - 后代收到广播后更新本地缓存并通知订阅者，不重复广播（subtree 中继已覆盖传播）。
 *
 * protocol-core 不依赖本包。
 */
import type { ContextSnapshot, ProtocolNode } from '@intelli/protocol-core'
import { BuiltinEvents } from '@intelli/protocol-core'

/** 非 owner 发起变更请求用的系统消息名。 */
const CTX_REQUEST = '__ctx_request__'

/** 已知键 → 对应的专用事件名。 */
const KEY_EVENT: Record<string, string> = {
  theme: BuiltinEvents.ThemeChanged,
  language: BuiltinEvents.LanguageChanged,
  timezone: BuiltinEvents.TimezoneChanged,
  token: BuiltinEvents.TokenChanged,
}

/** 订阅回调。 */
export type ContextSubscriber<V = unknown> = (value: V, key: string) => void

/** ContextStore 选项。 */
export interface ContextStoreOptions {
  /** 是否为权威持有者（根 host）。 */
  owner?: boolean
  /** 初始值（props / 握手快照）。 */
  initial?: ContextSnapshot
}

interface ContextChangePayload {
  key: string
  value: unknown
}

export class ContextStore {
  private readonly node: ProtocolNode
  private readonly owner: boolean
  private readonly state: Record<string, unknown>
  private readonly subs = new Map<string, Set<ContextSubscriber>>()
  private readonly disposers: Array<() => void> = []

  constructor(node: ProtocolNode, options: ContextStoreOptions = {}) {
    this.node = node
    this.owner = options.owner ?? false
    this.state = { ...(options.initial ?? {}) }

    // 后代：监听权威广播，更新缓存并通知本地订阅者。
    this.disposers.push(
      node.on<ContextChangePayload>(BuiltinEvents.ContextChanged, ({ key, value }) => {
        this.applyLocal(key, value)
      }),
    )

    // owner：响应非 owner 的变更请求。
    if (this.owner) {
      this.disposers.push(
        node.on<ContextChangePayload>(CTX_REQUEST, ({ key, value }) => {
          this.set(key, value)
        }),
      )
    }
  }

  /** 读取某个键的当前值。 */
  get<V = unknown>(key: string): V | undefined {
    return this.state[key] as V | undefined
  }

  /** 当前完整快照（用于注入子应用初始状态）。 */
  snapshot(): ContextSnapshot {
    return { ...this.state }
  }

  /** 用快照播种本地状态（不广播），用于握手/props 提供的初始值。 */
  seed(snapshot: ContextSnapshot): void {
    for (const [key, value] of Object.entries(snapshot)) {
      this.applyLocal(key, value)
    }
  }

  /**
   * 设置某个键。
   * - owner：本地落库 + 向 subtree 广播；
   * - 非 owner：向 owner 发起变更请求（最终一致）。
   */
  set(key: string, value: unknown): void {
    if (this.owner) {
      this.applyLocal(key, value)
      this.broadcast(key, value)
    } else {
      this.node.send({ mode: 'ancestors' }, CTX_REQUEST, { key, value } satisfies ContextChangePayload, 'system')
    }
  }

  /** 显式向 owner 请求变更（语义同非 owner 的 set）。 */
  requestChange(key: string, value: unknown): void {
    this.node.send({ mode: 'ancestors' }, CTX_REQUEST, { key, value } satisfies ContextChangePayload, 'system')
  }

  /** 订阅某个键的变化，可选立即用当前值触发一次。返回取消订阅函数。 */
  subscribe<V = unknown>(key: string, subscriber: ContextSubscriber<V>, options?: { immediate?: boolean }): () => void {
    let set = this.subs.get(key)
    if (!set) {
      set = new Set()
      this.subs.set(key, set)
    }
    const wrapped = subscriber as ContextSubscriber
    set.add(wrapped)
    if (options?.immediate && this.state[key] !== undefined) {
      subscriber(this.state[key] as V, key)
    }
    return () => {
      set.delete(wrapped)
    }
  }

  /** 释放订阅。 */
  dispose(): void {
    for (const dispose of this.disposers) {
      dispose()
    }
    this.subs.clear()
  }

  private applyLocal(key: string, value: unknown): void {
    this.state[key] = value
    const set = this.subs.get(key)
    if (set) {
      for (const subscriber of [...set]) {
        subscriber(value, key)
      }
    }
  }

  private broadcast(key: string, value: unknown): void {
    this.node.emit(BuiltinEvents.ContextChanged, { key, value } satisfies ContextChangePayload, { mode: 'subtree' })
    const eventName = KEY_EVENT[key]
    if (eventName) {
      const payload = key === 'token' ? { token: value } : { [key]: value }
      this.node.emit(eventName, payload, { mode: 'subtree' })
    }
  }
}
