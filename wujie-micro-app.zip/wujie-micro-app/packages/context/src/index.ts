/**
 * @intelli/context —— 共享状态薄层。
 */
export type { ContextStoreOptions, ContextSubscriber } from './context-store'
export { ContextStore } from './context-store'
