import { attachHandshake, ProtocolNode } from '@intelli/protocol-core'
import { MemoryBus } from '@intelli/transport-memory'
import { describe, expect, it } from 'vitest'
import { ContextStore } from './context-store'

function buildTree() {
  const busA = new MemoryBus()
  const busB = new MemoryBus()
  const a = new ProtocolNode({ id: 'a', downlink: busA.connect() })
  const b = new ProtocolNode({ id: 'b', uplink: busA.connect(), downlink: busB.connect() })
  const c = new ProtocolNode({ id: 'c', uplink: busB.connect() })
  attachHandshake(a)
  attachHandshake(b).announce()
  attachHandshake(c).announce()
  return { a, b, c }
}

describe('contextStore', () => {
  it('owner broadcasts changes down the subtree', () => {
    const { a, b, c } = buildTree()
    const owner = new ContextStore(a, { owner: true, initial: { theme: 'light' } })
    const subB = new ContextStore(b)
    const subC = new ContextStore(c)

    owner.set('theme', 'dark')
    expect(subB.get('theme')).toBe('dark')
    expect(subC.get('theme')).toBe('dark')
  })

  it('notifies subscribers on change', () => {
    const { a, c } = buildTree()
    const owner = new ContextStore(a, { owner: true })
    const subC = new ContextStore(c)
    const seen: unknown[] = []
    subC.subscribe('language', (value) => seen.push(value))
    owner.set('language', 'zh-CN')
    expect(seen).toEqual(['zh-CN'])
  })

  it('emits the matching builtin event (theme_changed) to descendants', () => {
    const { a, c } = buildTree()
    const owner = new ContextStore(a, { owner: true })
    void owner
    const hits: unknown[] = []
    c.on('theme_changed', (payload) => hits.push(payload))
    owner.set('theme', 'dark')
    expect(hits).toEqual([{ theme: 'dark' }])
  })

  it('lets a non-owner request a change that the owner applies', () => {
    const { a, b, c } = buildTree()
    const owner = new ContextStore(a, { owner: true })
    const subB = new ContextStore(b)
    const subC = new ContextStore(c)

    subC.set('timezone', 'Asia/Shanghai')

    expect(owner.get('timezone')).toBe('Asia/Shanghai')
    expect(subB.get('timezone')).toBe('Asia/Shanghai')
    expect(subC.get('timezone')).toBe('Asia/Shanghai')
  })

  it('seeds initial state from snapshot without messaging', () => {
    const { c } = buildTree()
    const subC = new ContextStore(c, { initial: { theme: 'dark', token: 'abc' } })
    expect(subC.get('theme')).toBe('dark')
    expect(subC.snapshot()).toEqual({ theme: 'dark', token: 'abc' })
  })
})
