/**
 * @intelli/transport-broadcastchannel —— 基于 BroadcastChannel 的传输，用于同源跨标签页。
 *
 * BroadcastChannel 天然是共享总线：同名频道的所有其它实例都会收到消息，发送者自身不会收到，
 * 与协议节点对总线「排除自身」的预期一致。不同层级用不同频道名隔离。
 */
import type { Envelope, Transport } from '@intelli/protocol-core'

const TAG = '__intelli_bc__'

interface Wire {
  [TAG]: true
  envelope: Envelope
}

function isWire(data: unknown): data is Wire {
  return typeof data === 'object' && data !== null && (data as Record<string, unknown>)[TAG] === true
}

/** 创建一个基于 BroadcastChannel 的传输。 */
export function createBroadcastChannelTransport(channelName: string): Transport {
  const channel = new BroadcastChannel(channelName)
  let listener: ((event: MessageEvent) => void) | undefined

  return {
    kind: 'broadcastchannel',
    send(envelope: Envelope) {
      channel.postMessage({ [TAG]: true, envelope } satisfies Wire)
    },
    subscribe(handler) {
      listener = (event: MessageEvent) => {
        if (isWire(event.data)) {
          handler(event.data.envelope)
        }
      }
      channel.addEventListener('message', listener)
      return () => {
        if (listener) {
          channel.removeEventListener('message', listener)
          listener = undefined
        }
      }
    },
    close() {
      if (listener) {
        channel.removeEventListener('message', listener)
        listener = undefined
      }
      channel.close()
    },
  }
}
