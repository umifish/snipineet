/**
 * @intelli/transport-postmessage —— 基于 postMessage 的传输，用于 iframe / 跨窗口。
 *
 * 拓扑为星型：父窗口为中心（hub），各子 iframe 为远端端口。
 * - 父侧 PostMessageHub：父节点作为本地端口接入，子窗口通过 addChild 注册；
 *   收到某子窗口的消息时，转发给其它子窗口并投递给本地父节点，语义与共享总线一致。
 * - 子侧 createChildTransport：与父窗口点对点；扇出交给父侧 hub。
 *
 * 安全：默认校验 origin，建议显式传入 acceptOrigin / targetOrigin（OWASP：避免接收任意源消息）。
 */
import type { Envelope, Transport } from '@intelli/protocol-core'

/** 包装标记，用于区分协议消息与页面其它 postMessage。 */
const TAG = '__intelli_pm__'

interface Wire {
  [TAG]: true
  envelope: Envelope
}

function isWire(data: unknown): data is Wire {
  return typeof data === 'object' && data !== null && (data as Record<string, unknown>)[TAG] === true
}

/** origin 校验：字符串精确匹配 / 函数 / '*' 放行。 */
export type OriginCheck = string | ((origin: string) => boolean)

function accept(check: OriginCheck | undefined, origin: string): boolean {
  if (check === undefined || check === '*') {
    return true
  }
  if (typeof check === 'function') {
    return check(origin)
  }
  return check === origin
}

/** 子侧传输选项。 */
export interface ChildTransportOptions {
  /** 目标父窗口，默认 window.parent。 */
  targetWindow?: Window
  /** postMessage 的 targetOrigin，默认 '*'（建议显式指定）。 */
  targetOrigin?: string
  /** 接受的来源 origin，默认放行所有（建议显式指定）。 */
  acceptOrigin?: OriginCheck
  /** 监听消息的窗口，默认当前 window。 */
  listenWindow?: Window
}

/** 创建子侧（指向父窗口）的传输。 */
export function createChildTransport(options: ChildTransportOptions = {}): Transport {
  const target = options.targetWindow ?? window.parent
  const targetOrigin = options.targetOrigin ?? '*'
  const listen = options.listenWindow ?? window

  let onMessage: ((event: MessageEvent) => void) | undefined

  return {
    kind: 'postmessage',
    send(envelope: Envelope) {
      const wire: Wire = { [TAG]: true, envelope }
      target.postMessage(wire, targetOrigin)
    },
    subscribe(handler) {
      onMessage = (event: MessageEvent) => {
        if (!isWire(event.data)) {
          return
        }
        if (!accept(options.acceptOrigin, event.origin)) {
          return
        }
        handler(event.data.envelope)
      }
      listen.addEventListener('message', onMessage)
      return () => {
        if (onMessage) {
          listen.removeEventListener('message', onMessage)
          onMessage = undefined
        }
      }
    },
    close() {
      if (onMessage) {
        listen.removeEventListener('message', onMessage)
        onMessage = undefined
      }
    },
  }
}

interface ChildPort {
  window: Window
  origin: string
}

/** 父侧 hub 选项。 */
export interface PostMessageHubOptions {
  /**
   * 监听消息的窗口，默认当前 window。
   *
   * 注意：在 wujie 等「DOM 投影到宿主 shadow DOM、JS 跑在独立沙箱 iframe」的场景下，
   * 子 iframe 的 `window.parent` 指向宿主窗口而非本沙箱窗口，子级消息会落到宿主窗口。
   * 此时应额外监听宿主窗口（如 `window.parent`）。可传入多个窗口同时监听。
   */
  listenWindow?: Window | Window[]
}

/** 父侧 hub：管理多个子窗口并模拟共享总线扇出。 */
export class PostMessageHub {
  private readonly listens: Window[]
  // 以子窗口为键，保证同一窗口只登记一个端口，避免重复扇出导致的多次投递。
  private readonly children = new Map<Window, ChildPort>()
  private localHandler?: (envelope: Envelope) => void
  private readonly onMessage: (event: MessageEvent) => void
  private readonly seen = new Set<string>()

  constructor(options: PostMessageHubOptions = {}) {
    const listen = options.listenWindow ?? window
    this.listens = (Array.isArray(listen) ? listen : [listen]).filter(
      (win, index, all) => all.indexOf(win) === index,
    )
    this.onMessage = (event: MessageEvent) => {
      if (!isWire(event.data)) {
        return
      }
      const envelope = event.data.envelope
      // 同一信封可能被多个监听窗口收到，按 id 去重一次。
      if (this.seen.has(envelope.id)) {
        return
      }
      this.seen.add(envelope.id)
      if (this.seen.size > 4096) {
        this.seen.delete(this.seen.values().next().value as string)
      }
      const fromWindow = event.source as Window | null
      // 扇出给其它子窗口（兄弟）；无法识别来源时不排除任何子窗口，
      // 由各节点的 seen 去重兜底，避免因窗口引用不一致而丢消息。
      for (const child of this.children.values()) {
        if (child.window !== fromWindow) {
          child.window.postMessage({ [TAG]: true, envelope } satisfies Wire, child.origin)
        }
      }
      // 投递给本地父节点
      this.localHandler?.(envelope)
    }
    for (const win of this.listens) {
      win.addEventListener('message', this.onMessage)
    }
  }

  /** 注册一个子窗口端口。对同一窗口重复调用是幂等的（覆盖 origin）。 */
  addChild(childWindow: Window, origin = '*'): () => void {
    const port: ChildPort = { window: childWindow, origin }
    this.children.set(childWindow, port)
    return () => {
      if (this.children.get(childWindow) === port) {
        this.children.delete(childWindow)
      }
    }
  }

  /** 父节点接入的本地端口（作为 downlink 传给 ProtocolNode）。 */
  connect(): Transport {
    return {
      kind: 'postmessage',
      send: (envelope: Envelope) => {
        for (const child of this.children.values()) {
          child.window.postMessage({ [TAG]: true, envelope } satisfies Wire, child.origin)
        }
      },
      subscribe: (handler) => {
        this.localHandler = handler
        return () => {
          this.localHandler = undefined
        }
      },
    }
  }

  /** 关闭 hub。 */
  close(): void {
    for (const win of this.listens) {
      win.removeEventListener('message', this.onMessage)
    }
    this.children.clear()
    this.localHandler = undefined
  }
}
