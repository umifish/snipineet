/**
 * React hooks：订阅上下文值与协议事件。
 */
import type { MessageContext } from '@intelli/protocol-core'
import { useEffect, useRef, useState } from 'react'
import { useMicroApp } from './context'

/** 订阅某个上下文键，返回响应式当前值。 */
export function useContextValue<V = unknown>(key: string, initial?: V): V | undefined {
  const app = useMicroApp()
  const [value, setValue] = useState<V | undefined>(() => app.getContext<V>(key) ?? initial)

  useEffect(() => {
    return app.subscribeContext<V>(key, (next) => setValue(next), { immediate: true })
  }, [app, key])

  return value
}

/** 返回设置某个上下文键的函数。 */
export function useSetContext(): (key: string, value: unknown) => void {
  const app = useMicroApp()
  return (key, value) => app.setContext(key, value)
}

/** 订阅协议事件，handler 始终使用最新引用。 */
export function useMicroEvent<P = unknown>(name: string, handler: (payload: P, ctx: MessageContext) => void): void {
  const app = useMicroApp()
  const ref = useRef(handler)
  ref.current = handler

  useEffect(() => {
    return app.on<P>(name, (payload, ctx) => ref.current(payload, ctx))
  }, [app, name])
}
