/**
 * <MicroAppMount>：基于 wujie-react 的 <WujieReact> 封装。
 * 把 MicroAppConfig 映射为 wujie 属性，并经 props 注入协议身份与初始上下文（首帧无闪烁）。
 */
import type { ContextSnapshot, MicroAppConfig } from '@intelli/protocol-core'
import type { ReactNode } from 'react'
import { buildInjectedProps } from '@intelli/wujie-transport'
import { createElement } from 'react'
import WujieReact from 'wujie-react'

/** 挂载组件属性。 */
export interface MicroAppMountProps {
  /** 子应用配置。 */
  config: MicroAppConfig
  /** 注入子应用的父级 id（用于握手与拓扑）。 */
  parentId?: string
  /** 覆盖注入的初始上下文快照（默认从 config 推导）。 */
  snapshot?: ContextSnapshot
  /** 容器宽度，默认 100%。 */
  width?: string
  /** 容器高度，默认 100%。 */
  height?: string
  /** 透传给 WujieReact 的额外生命周期回调。 */
  beforeLoad?: (appWindow: Window) => void
  beforeMount?: (appWindow: Window) => void
  afterMount?: (appWindow: Window) => void
  beforeUnmount?: (appWindow: Window) => void
  afterUnmount?: (appWindow: Window) => void
  loadError?: (url: string, error: unknown) => void
}

/** 渲染一个 wujie 子应用并注入协议数据。 */
export function MicroAppMount(props: MicroAppMountProps): ReactNode {
  const { config, parentId, snapshot, width, height, ...lifecycle } = props
  const injected = buildInjectedProps(config, { parentId, snapshot })

  return createElement(WujieReact, {
    width: width ?? '100%',
    height: height ?? '100%',
    name: config.id,
    url: config.url,
    sync: config.sync,
    alive: config.alive,
    attrs: config.attrs,
    props: injected,
    ...lifecycle,
  })
}
