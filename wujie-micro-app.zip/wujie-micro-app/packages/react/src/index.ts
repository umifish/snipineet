/**
 * @intelli/react —— React 适配层：Provider、hooks、wujie 挂载与运行时装配。
 */
export { MicroAppProvider, useMicroApp } from './context'
export { useContextValue, useMicroEvent, useSetContext } from './hooks'
export type { MicroAppMountProps } from './mount'
export { MicroAppMount } from './mount'
export type { HostRuntimeOptions, SubRuntimeOptions } from './runtime'
export { createHostRuntime, createSubRuntime } from './runtime'
