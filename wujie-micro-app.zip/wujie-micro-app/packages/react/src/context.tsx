/**
 * React 上下文：在组件树中提供 MicroAppRuntime。
 */
import type { MicroAppRuntime } from '@intelli/app-kit'
import type { ReactNode } from 'react'
import { createContext, useContext } from 'react'

const MicroAppContext = createContext<MicroAppRuntime | null>(null)

/** 向子树提供运行时。 */
export function MicroAppProvider(props: { runtime: MicroAppRuntime, children: ReactNode }): ReactNode {
  return <MicroAppContext.Provider value={props.runtime}>{props.children}</MicroAppContext.Provider>
}

/** 读取当前运行时（须在 MicroAppProvider 内）。 */
export function useMicroApp(): MicroAppRuntime {
  const runtime = useContext(MicroAppContext)
  if (!runtime) {
    throw new Error('[intelli] useMicroApp 必须在 <MicroAppProvider> 内使用')
  }
  return runtime
}
