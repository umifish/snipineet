import type { MicroAppRuntime } from '@intelli/app-kit'
/**
 * React 侧的 wujie 运行时装配。把 wujie bus 接成 app-kit 的 uplink/downlink。
 *
 * 架构要点（与 wujie bus 共享语义一致）：
 * - 根宿主：downlink = hostBus()；无 uplink；为上下文 owner。
 * - 纯子应用：uplink = getWujieSubBus()（即父注入的 window.$wujie.bus）。
 * - 双重应用（既是子又托管自身子级）：uplink = getWujieSubBus()，downlink = hostBus()。
 *   同一物理 bus 既是父的 downlink，也是其直接子的 uplink；跨层由各节点逐跳中继。
 */
import type { ContextSnapshot } from '@intelli/protocol-core'
import { createMicroApp } from '@intelli/app-kit'
import { createId } from '@intelli/protocol-core'
import { createWujieTransport, getWujieSubBus, hostBus, readInjectedProps } from '@intelli/wujie-transport'

/** 根宿主运行时选项。 */
export interface HostRuntimeOptions {
  id?: string
  name?: string
  initialContext?: ContextSnapshot
}

/** 创建根宿主运行时（应用最外层）。 */
export function createHostRuntime(options: HostRuntimeOptions = {}): MicroAppRuntime {
  return createMicroApp({
    id: options.id ?? 'host',
    name: options.name,
    downlink: createWujieTransport(hostBus()),
    contextOwner: true,
    initialContext: options.initialContext,
  })
}

/** 子应用运行时选项。 */
export interface SubRuntimeOptions {
  /** 本应用是否还会通过 wujie 托管自己的子应用（dual 角色）。 */
  hostsChildren?: boolean
}

/**
 * 创建子应用运行时。自动读取宿主经 props 注入的身份与初始上下文。
 * 若当前并非由 wujie 承载，将回退为独立根宿主。
 */
export function createSubRuntime(options: SubRuntimeOptions = {}): MicroAppRuntime {
  const subBus = getWujieSubBus()
  if (!subBus) {
    return createHostRuntime()
  }

  const injected = readInjectedProps()
  return createMicroApp({
    id: injected?.id ?? createId('app'),
    name: injected?.name,
    uplink: createWujieTransport(subBus),
    downlink: options.hostsChildren ? createWujieTransport(hostBus()) : undefined,
    initialContext: injected?.snapshot,
  })
}
