declare module 'wujie-react' {
  import type { ComponentType } from 'react'

  /** wujie-react 默认导出的子应用挂载组件（该包未自带类型声明）。 */
  const WujieReact: ComponentType<Record<string, unknown>>
  export default WujieReact
}
