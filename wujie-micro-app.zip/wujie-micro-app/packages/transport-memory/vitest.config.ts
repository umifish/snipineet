import { fileURLToPath } from 'node:url'
import { defineConfig } from 'vitest/config'

export default defineConfig({
  resolve: {
    alias: {
      '@intelli/protocol-core': fileURLToPath(new URL('../protocol-core/src/index.ts', import.meta.url)),
    },
  },
})
