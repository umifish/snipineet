import type { MessageContext } from '@intelli/protocol-core'
import { attachHandshake, ProtocolNode } from '@intelli/protocol-core'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { MemoryBus } from './index'

/**
 * 三层拓扑：a（根主）→ b（主+子）→ c（叶子）
 *   busA：a 的 downlink / b 的 uplink
 *   busB：b 的 downlink / c 的 uplink
 */
function buildTree() {
  const busA = new MemoryBus()
  const busB = new MemoryBus()

  const a = new ProtocolNode({ id: 'a', downlink: busA.connect() })
  const b = new ProtocolNode({ id: 'b', uplink: busA.connect(), downlink: busB.connect() })
  const c = new ProtocolNode({ id: 'c', uplink: busB.connect() })

  attachHandshake(a)
  const hb = attachHandshake(b)
  const hc = attachHandshake(c)

  hb.announce()
  hc.announce()

  return { a, b, c, busA, busB }
}

function collect(node: ProtocolNode, name: string) {
  const calls: Array<{ payload: unknown, ctx: MessageContext }> = []
  node.on(name, (payload, ctx) => calls.push({ payload, ctx }))
  return calls
}

describe('handshake builds the routing table', () => {
  it('propagates descendants up to the root', () => {
    const { a, b } = buildTree()
    expect(a.listDescendants().sort()).toEqual(['b', 'c'])
    expect(b.listDescendants()).toEqual(['c'])
  })
})

describe('unicast across levels', () => {
  it('routes c -> a through the relay, without delivering to b', () => {
    const { a, b, c } = buildTree()
    const atHit = collect(a, 'hi')
    const bHit = collect(b, 'hi')
    c.send({ mode: 'unicast', id: 'a' }, 'hi', { v: 1 })
    expect(atHit).toHaveLength(1)
    expect(atHit[0].payload).toEqual({ v: 1 })
    expect(atHit[0].ctx.source).toBe('c')
    expect(bHit).toHaveLength(0)
  })

  it('routes a -> c through the relay', () => {
    const { a, b, c } = buildTree()
    const cHit = collect(c, 'cmd')
    const bHit = collect(b, 'cmd')
    a.send({ mode: 'unicast', id: 'c' }, 'cmd', 42)
    expect(cHit).toHaveLength(1)
    expect(cHit[0].payload).toBe(42)
    expect(bHit).toHaveLength(0)
  })
})

describe('directional addressing', () => {
  it('broadcast reaches every node except the origin, exactly once', () => {
    const { a, b, c } = buildTree()
    const aHit = collect(a, 'evt')
    const bHit = collect(b, 'evt')
    const cHit = collect(c, 'evt')
    a.emit('evt', 'payload')
    expect(aHit).toHaveLength(0)
    expect(bHit).toHaveLength(1)
    expect(cHit).toHaveLength(1)
  })

  it('subtree reaches all descendants', () => {
    const { a, b, c } = buildTree()
    const bHit = collect(b, 'down')
    const cHit = collect(c, 'down')
    a.send({ mode: 'subtree' }, 'down', 'x')
    expect(bHit).toHaveLength(1)
    expect(cHit).toHaveLength(1)
  })

  it('children reaches only direct children', () => {
    const { a, b, c } = buildTree()
    const bHit = collect(b, 'kids')
    const cHit = collect(c, 'kids')
    a.send({ mode: 'children' }, 'kids', 'x')
    expect(bHit).toHaveLength(1)
    expect(cHit).toHaveLength(0)
  })

  it('parent reaches only the direct parent', () => {
    const { a, b, c } = buildTree()
    const aHit = collect(a, 'up1')
    const bHit = collect(b, 'up1')
    c.send({ mode: 'parent' }, 'up1', 'x')
    expect(bHit).toHaveLength(1)
    expect(aHit).toHaveLength(0)
  })

  it('ancestors reaches the whole path to root', () => {
    const { a, b, c } = buildTree()
    const aHit = collect(a, 'upall')
    const bHit = collect(b, 'upall')
    c.send({ mode: 'ancestors' }, 'upall', 'x')
    expect(bHit).toHaveLength(1)
    expect(aHit).toHaveLength(1)
  })
})

describe('sibling communication via the common ancestor', () => {
  it('routes b -> b2 through parent a', () => {
    const { a, b, busA } = buildTree()
    const b2 = new ProtocolNode({ id: 'b2', uplink: busA.connect() })
    attachHandshake(b2).announce()
    expect(a.listDescendants().sort()).toEqual(['b', 'b2', 'c'])

    const b2Hit = collect(b2, 'sib')
    b.send({ mode: 'unicast', id: 'b2' }, 'sib', 'hello')
    expect(b2Hit).toHaveLength(1)
    expect(b2Hit[0].payload).toBe('hello')
  })
})

describe('request/response (RPC) across levels', () => {
  it('resolves a request relayed from c to a', async () => {
    const { a, c } = buildTree()
    a.handle('getTime', () => 12345)
    await expect(c.request({ mode: 'unicast', id: 'a' }, 'getTime')).resolves.toBe(12345)
  })

  it('supports request to the direct parent', async () => {
    const { b, c } = buildTree()
    b.handle('echo', (payload: unknown) => ({ echoed: payload }))
    await expect(c.request({ mode: 'parent' }, 'echo', 'ping')).resolves.toEqual({ echoed: 'ping' })
  })

  it('rejects when there is no handler', async () => {
    const { a, c } = buildTree()
    void a
    await expect(c.request({ mode: 'unicast', id: 'a' }, 'missing', null, { timeout: 200 })).rejects.toThrow()
  })
})

describe('loop prevention', () => {
  let warn: ReturnType<typeof vi.spyOn>
  beforeEach(() => {
    warn = vi.spyOn(console, 'warn').mockImplementation(() => {})
  })

  it('does not deliver the same broadcast more than once per node', () => {
    const { a, c } = buildTree()
    const cHit = collect(c, 'once')
    a.emit('once', 1)
    a.emit('once', 2)
    expect(cHit).toHaveLength(2)
    warn.mockRestore()
  })
})
