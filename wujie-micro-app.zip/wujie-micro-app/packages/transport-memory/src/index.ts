/**
 * @intelli/transport-memory —— 进程内总线，用于单测与同页演示。
 *
 * 一个 MemoryBus 模拟一条共享总线：被父节点当作 downlink、被各子节点当作 uplink。
 * connect() 返回的 Transport 发送时会扇出给除自身外的所有参与者。
 */
import type { Envelope, Transport } from '@intelli/protocol-core'

type PortHandler = (envelope: Envelope) => void

export class MemoryBus {
  private readonly ports = new Map<symbol, PortHandler>()

  /** 接入一个端口，返回对应的 Transport。 */
  connect(): Transport {
    const key = Symbol('port')
    const ports = this.ports
    return {
      kind: 'memory',
      send(envelope: Envelope) {
        for (const [portKey, handler] of ports) {
          if (portKey !== key) {
            handler(envelope)
          }
        }
      },
      subscribe(handler: PortHandler) {
        ports.set(key, handler)
        return () => {
          ports.delete(key)
        }
      },
      close() {
        ports.delete(key)
      },
    }
  }

  /** 当前参与者数量。 */
  get size(): number {
    return this.ports.size
  }
}
