/**
 * 框架无关的微应用运行时。装配 ProtocolNode + ContextStore + 握手，自动识别角色。
 *
 * 传输由调用方注入（uplink/downlink），app-kit 不依赖任何具体传输（含 wujie），保持解耦。
 */
import type {
  AppRole,
  ContextSnapshot,
  Handshake,
  Listener,
  RequestOptions,
  TargetSpec,
  Transport,
} from '@intelli/protocol-core'
import { ContextStore } from '@intelli/context'
import { attachHandshake, BuiltinEvents, ProtocolNode } from '@intelli/protocol-core'

/** 运行时选项。 */
export interface MicroAppRuntimeOptions {
  /** 应用唯一标识。 */
  id: string
  /** 应用名称。 */
  name?: string
  /** 上行总线（存在则本应用是子应用）。 */
  uplink?: Transport
  /** 下行总线（存在则本应用托管子应用）。 */
  downlink?: Transport
  /** 是否为上下文权威持有者，默认根节点（无 uplink）为 true。 */
  contextOwner?: boolean
  /** 初始上下文（来自 props / 快照）。 */
  initialContext?: ContextSnapshot
}

/** 微应用运行时。 */
export interface MicroAppRuntime {
  readonly node: ProtocolNode
  readonly context: ContextStore
  readonly handshake: Handshake
  readonly role: AppRole
  /** 订阅事件。 */
  on: <P = unknown>(name: string, handler: Listener<P>) => () => void
  /** 发布事件（默认广播）。 */
  emit: <P = unknown>(name: string, payload?: P, target?: TargetSpec) => void
  /** 发起请求（RPC）。 */
  request: <R = unknown, P = unknown>(target: TargetSpec, name: string, payload?: P, options?: RequestOptions) => Promise<R>
  /** 注册 RPC 处理器。 */
  handle: <P = unknown, R = unknown>(name: string, handler: (payload: P, ctx: { source: string }) => R | Promise<R>) => () => void
  /** 读取上下文。 */
  getContext: <V = unknown>(key: string) => V | undefined
  /** 设置上下文（owner 直接生效，否则向 owner 请求）。 */
  setContext: (key: string, value: unknown) => void
  /** 订阅上下文变化。 */
  subscribeContext: <V = unknown>(key: string, cb: (value: V) => void, options?: { immediate?: boolean }) => () => void
  /** 就绪：子应用向父注册，并广播 app_ready。 */
  ready: () => void
  /** 释放。 */
  dispose: () => void
}

function resolveRole(options: MicroAppRuntimeOptions): AppRole {
  const hasUp = Boolean(options.uplink)
  const hasDown = Boolean(options.downlink)
  if (hasUp && hasDown) {
    return 'dual'
  }
  if (hasUp) {
    return 'sub'
  }
  return 'host'
}

/** 创建微应用运行时。 */
export function createMicroApp(options: MicroAppRuntimeOptions): MicroAppRuntime {
  const node = new ProtocolNode({
    id: options.id,
    name: options.name,
    uplink: options.uplink,
    downlink: options.downlink,
  })

  const role = resolveRole(options)
  const owner = options.contextOwner ?? node.isRoot

  const context = new ContextStore(node, {
    owner,
    initial: options.initialContext,
  })

  const handshake = attachHandshake(node, {
    getSnapshot: () => context.snapshot(),
    onAck: (ack) => {
      if (ack.snapshot) {
        context.seed(ack.snapshot)
      }
    },
  })

  return {
    node,
    context,
    handshake,
    role,
    on: (name, handler) => node.on(name, handler),
    emit: (name, payload, target) => node.emit(name, payload, target),
    request: (target, name, payload, requestOptions) => node.request(target, name, payload, requestOptions),
    handle: <P = unknown, R = unknown>(name: string, handler: (payload: P, ctx: { source: string }) => R | Promise<R>) =>
      node.handle<P, R>(name, (payload, ctx) => handler(payload, { source: ctx.source })),
    getContext: (key) => context.get(key),
    setContext: (key, value) => context.set(key, value),
    subscribeContext: <V = unknown>(key: string, cb: (value: V) => void, subscribeOptions?: { immediate?: boolean }) =>
      context.subscribe<V>(key, (value) => cb(value), subscribeOptions),
    ready: () => {
      handshake.announce()
      node.emit(BuiltinEvents.AppReady, { id: options.id }, { mode: 'ancestors' })
    },
    dispose: () => {
      handshake.leave()
      handshake.dispose()
      context.dispose()
      node.close()
    },
  }
}
