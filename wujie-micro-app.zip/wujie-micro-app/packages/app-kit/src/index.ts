/**
 * @intelli/app-kit —— 框架无关的微应用运行时与预加载策略。
 */
export type { PreloadScheduleOptions } from './preload'
export { schedulePreload } from './preload'
export type { MicroAppRuntime, MicroAppRuntimeOptions } from './runtime'
export { createMicroApp } from './runtime'
