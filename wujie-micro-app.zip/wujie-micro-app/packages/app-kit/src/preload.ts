/**
 * 预加载策略调度。
 */
import type { PreloadStrategy } from '@intelli/protocol-core'

interface IdleWindow {
  requestIdleCallback?: (cb: () => void) => number
  cancelIdleCallback?: (handle: number) => void
}

/** 预加载调度选项。 */
export interface PreloadScheduleOptions {
  /** visible 策略观察的目标元素。 */
  target?: Element
  /** visible 策略的 IntersectionObserver 选项。 */
  rootMargin?: string
}

/**
 * 按策略调度预加载，返回取消函数。
 * - eager：立即执行
 * - idle：浏览器空闲时执行（无 requestIdleCallback 时退化为 setTimeout）
 * - visible：目标进入视口时执行（需 target）
 * - manual：不自动执行，需手动调用返回对象的 trigger
 */
export function schedulePreload(
  strategy: PreloadStrategy,
  run: () => void,
  options: PreloadScheduleOptions = {},
): { cancel: () => void, trigger: () => void } {
  let done = false
  const once = (): void => {
    if (!done) {
      done = true
      run()
    }
  }

  switch (strategy) {
    case 'eager': {
      once()
      return { cancel: () => {}, trigger: once }
    }

    case 'idle': {
      const idle = globalThis as IdleWindow
      if (typeof idle.requestIdleCallback === 'function') {
        const handle = idle.requestIdleCallback(once)
        return {
          cancel: () => idle.cancelIdleCallback?.(handle),
          trigger: once,
        }
      }
      const timer = setTimeout(once, 0)
      return { cancel: () => clearTimeout(timer), trigger: once }
    }

    case 'visible': {
      if (!options.target || typeof IntersectionObserver === 'undefined') {
        once()
        return { cancel: () => {}, trigger: once }
      }
      const observer = new IntersectionObserver(
        (entries) => {
          if (entries.some((entry) => entry.isIntersecting)) {
            observer.disconnect()
            once()
          }
        },
        { rootMargin: options.rootMargin ?? '0px' },
      )
      observer.observe(options.target)
      return {
        cancel: () => observer.disconnect(),
        trigger: () => {
          observer.disconnect()
          once()
        },
      }
    }

    case 'manual':
    default:
      return { cancel: () => {}, trigger: once }
  }
}
