/**
 * ProtocolNode：协议节点。承载路由中继 + 事件发布订阅 + request/response（RPC）。
 *
 * 每个节点最多接入两条总线：
 * - uplink：与父级（及兄弟）共享的总线，本节点作为参与者；
 * - downlink：本节点作为 hub 的总线，自己的子级接入。
 * 跨层消息由各节点逐跳中继；ttl + hop + 去重缓存共同防止环路。
 */
import type { Envelope, TargetSpec } from './envelope'
import type { LinkSide } from './router'
import type { Transport } from './transport'
import { createEnvelope, DEFAULT_TTL } from './envelope'
import { route } from './router'

/** 消息上下文，传给处理器。 */
export interface MessageContext {
  source: string
  name: string
  envelope: Envelope
}

/** 事件处理器。 */
export type Listener<P = unknown> = (payload: P, ctx: MessageContext) => void
/** 请求处理器（RPC），返回值会作为响应回传。 */
export type RequestListener<P = unknown, R = unknown> = (payload: P, ctx: MessageContext) => R | Promise<R>

/** 请求选项。 */
export interface RequestOptions {
  /** 超时毫秒数，默认 10000。 */
  timeout?: number
}

/** ProtocolNode 构造参数。 */
export interface ProtocolNodeOptions {
  id: string
  name?: string
  uplink?: Transport
  downlink?: Transport
  ttl?: number
  seenCacheSize?: number
}

/** FIFO 去重缓存。 */
class SeenCache {
  private readonly set = new Set<string>()
  constructor(private readonly max: number) {}

  has(id: string): boolean {
    return this.set.has(id)
  }

  add(id: string): void {
    this.set.add(id)
    if (this.set.size > this.max) {
      const first = this.set.values().next().value
      if (first !== undefined) {
        this.set.delete(first)
      }
    }
  }
}

interface PendingRequest {
  resolve: (value: unknown) => void
  reject: (reason: unknown) => void
  timer: ReturnType<typeof setTimeout>
}

export class ProtocolNode {
  readonly id: string
  readonly name?: string
  private readonly ttl: number
  private uplink?: Transport
  private downlink?: Transport
  private unsubUplink?: () => void
  private unsubDownlink?: () => void

  private readonly seen: SeenCache
  private readonly descendants = new Set<string>()
  private readonly listeners = new Map<string, Set<Listener>>()
  private readonly anyListeners = new Set<(envelope: Envelope) => void>()
  private readonly handlers = new Map<string, RequestListener>()
  private readonly pending = new Map<string, PendingRequest>()

  constructor(options: ProtocolNodeOptions) {
    this.id = options.id
    this.name = options.name
    this.ttl = options.ttl ?? DEFAULT_TTL
    this.seen = new SeenCache(options.seenCacheSize ?? 4096)
    if (options.uplink) {
      this.attachUplink(options.uplink)
    }
    if (options.downlink) {
      this.attachDownlink(options.downlink)
    }
  }

  /** 是否为根节点（无父级总线）。 */
  get isRoot(): boolean {
    return !this.uplink
  }

  // ---- 总线接入 ----

  attachUplink(transport: Transport): void {
    this.detachUplink()
    this.uplink = transport
    this.unsubUplink = transport.subscribe((env) => this.ingest(env, 'uplink'))
  }

  attachDownlink(transport: Transport): void {
    this.detachDownlink()
    this.downlink = transport
    this.unsubDownlink = transport.subscribe((env) => this.ingest(env, 'downlink'))
  }

  detachUplink(): void {
    this.unsubUplink?.()
    this.unsubUplink = undefined
    this.uplink = undefined
  }

  detachDownlink(): void {
    this.unsubDownlink?.()
    this.unsubDownlink = undefined
    this.downlink = undefined
  }

  // ---- 拓扑/路由表 ----

  addDescendant(id: string): void {
    this.descendants.add(id)
  }

  removeDescendant(id: string): void {
    this.descendants.delete(id)
  }

  hasDescendant(id: string): boolean {
    return this.descendants.has(id)
  }

  listDescendants(): string[] {
    return [...this.descendants]
  }

  // ---- 订阅 ----

  /** 订阅事件，返回取消订阅函数。 */
  on<P = unknown>(name: string, handler: Listener<P>): () => void {
    let set = this.listeners.get(name)
    if (!set) {
      set = new Set()
      this.listeners.set(name, set)
    }
    const wrapped = handler as Listener
    set.add(wrapped)
    return () => {
      set.delete(wrapped)
    }
  }

  /** 订阅所有到达本节点并本地投递的信封。 */
  onAny(handler: (envelope: Envelope) => void): () => void {
    this.anyListeners.add(handler)
    return () => {
      this.anyListeners.delete(handler)
    }
  }

  /** 注册 RPC 处理器（一个方法名仅一个处理器）。 */
  handle<P = unknown, R = unknown>(name: string, handler: RequestListener<P, R>): () => void {
    this.handlers.set(name, handler as RequestListener)
    return () => {
      if (this.handlers.get(name) === (handler as RequestListener)) {
        this.handlers.delete(name)
      }
    }
  }

  // ---- 发送 ----

  /** 底层发送。 */
  send<P = unknown>(target: TargetSpec, name: string, payload?: P, channel: Envelope['channel'] = 'event'): void {
    const env = createEnvelope<P>({ source: this.id, target, channel, name, payload, ttl: this.ttl })
    this.ingest(env, 'local')
  }

  /** 发布事件，默认全树广播。 */
  emit<P = unknown>(name: string, payload?: P, target: TargetSpec = { mode: 'broadcast' }): void {
    this.send(target, name, payload, 'event')
  }

  /** 仅本地触发监听器（不进入路由），用于本地通知。 */
  notifyLocal<P = unknown>(name: string, payload?: P): void {
    const env = createEnvelope<P>({ source: this.id, target: { mode: 'unicast', id: this.id }, channel: 'event', name, payload })
    this.dispatch(name, payload, env)
  }

  /** 发起请求并等待响应（RPC）。 */
  request<R = unknown, P = unknown>(target: TargetSpec, name: string, payload?: P, options?: RequestOptions): Promise<R> {
    const corr = `${this.id}:${name}`
    const env = createEnvelope<P>({ source: this.id, target, channel: 'request', name, payload, corr: undefined, ttl: this.ttl })
    env.corr = env.id
    return new Promise<R>((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(env.id)
        reject(new Error(`[protocol] request timeout: ${name}`))
      }, options?.timeout ?? 10000)
      this.pending.set(env.id, {
        resolve: resolve as (value: unknown) => void,
        reject,
        timer,
      })
      void corr
      this.ingest(env, 'local')
    })
  }

  // ---- 路由内核 ----

  private ingest(envelope: Envelope, from: LinkSide): void {
    if (this.seen.has(envelope.id)) {
      return
    }
    this.seen.add(envelope.id)

    if (envelope.hop.length >= envelope.ttl) {
      return
    }

    const last = envelope.hop.at(-1)
    const routed: Envelope = last === this.id ? envelope : { ...envelope, hop: [...envelope.hop, this.id] }

    const decision = route(routed, from, {
      selfId: this.id,
      isRoot: this.isRoot,
      hasDescendant: (id) => this.hasDescendant(id),
    })

    if (decision.deliver) {
      this.deliver(routed)
    }
    if (decision.up && this.uplink && from !== 'uplink') {
      this.uplink.send(routed)
    }
    if (decision.down && this.downlink && from !== 'downlink') {
      this.downlink.send(routed)
    }
  }

  private deliver(envelope: Envelope): void {
    if (envelope.channel === 'response') {
      this.resolvePending(envelope)
      return
    }

    if (envelope.channel === 'request') {
      this.handleRequest(envelope)
      return
    }

    this.dispatch(envelope.name, envelope.payload, envelope)
  }

  private dispatch(name: string, payload: unknown, envelope: Envelope): void {
    const ctx: MessageContext = { source: envelope.source, name, envelope }
    const set = this.listeners.get(name)
    if (set) {
      for (const handler of [...set]) {
        handler(payload, ctx)
      }
    }
    for (const handler of [...this.anyListeners]) {
      handler(envelope)
    }
  }

  private handleRequest(envelope: Envelope): void {
    const handler = this.handlers.get(envelope.name)
    const reply = (ok: boolean, payload: unknown): void => {
      const response = createEnvelope({
        source: this.id,
        target: { mode: 'unicast', id: envelope.source },
        channel: 'response',
        name: envelope.name,
        payload,
        corr: envelope.corr,
        ok,
        ttl: this.ttl,
      })
      this.ingest(response, 'local')
    }

    if (!handler) {
      reply(false, `[protocol] no handler for request: ${envelope.name}`)
      return
    }

    const ctx: MessageContext = { source: envelope.source, name: envelope.name, envelope }
    Promise.resolve()
      .then(() => handler(envelope.payload, ctx))
      .then((result) => reply(true, result))
      .catch((error: unknown) => reply(false, error instanceof Error ? error.message : String(error)))
  }

  private resolvePending(envelope: Envelope): void {
    if (!envelope.corr) {
      return
    }
    const pending = this.pending.get(envelope.corr)
    if (!pending) {
      return
    }
    clearTimeout(pending.timer)
    this.pending.delete(envelope.corr)
    if (envelope.ok === false) {
      pending.reject(new Error(typeof envelope.payload === 'string' ? envelope.payload : '[protocol] request failed'))
    } else {
      pending.resolve(envelope.payload)
    }
  }

  /** 释放节点：取消订阅、清理待处理请求。 */
  close(): void {
    this.detachUplink()
    this.detachDownlink()
    for (const pending of this.pending.values()) {
      clearTimeout(pending.timer)
      pending.reject(new Error('[protocol] node closed'))
    }
    this.pending.clear()
    this.listeners.clear()
    this.anyListeners.clear()
    this.handlers.clear()
    this.descendants.clear()
  }
}
