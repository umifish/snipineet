/**
 * 内置系统消息与协议事件定义（需求 2）。
 */

/** 握手 / 拓扑维护用的系统消息名。 */
export const SystemMessages = {
  Register: '__register__',
  RegisterAck: '__register_ack__',
  Unregister: '__unregister__',
  TopologyAdd: '__topology_add__',
  TopologyRemove: '__topology_remove__',
} as const

/** 内置业务/生命周期事件名。 */
export const BuiltinEvents = {
  ThemeChanged: 'theme_changed',
  LanguageChanged: 'language_changed',
  TimezoneChanged: 'timezone_changed',
  TokenChanged: 'token_changed',
  ContextChanged: 'context_changed',
  AppRegistered: 'app_registered',
  AppUnregistered: 'app_unregistered',
  AppReady: 'app_ready',
  TopologyChanged: 'topology_changed',
} as const

/** 内置事件负载类型映射，供类型安全的 on/emit 使用；可通过模块增强扩展。 */
export interface BuiltinEventPayloads {
  theme_changed: { theme: string }
  language_changed: { language: string }
  timezone_changed: { timezone: string }
  token_changed: { token: string | null }
  context_changed: { key: string, value: unknown }
  app_registered: { id: string, name?: string }
  app_unregistered: { id: string }
  app_ready: { id: string }
  topology_changed: { descendants: string[] }
}
