import type { Envelope, TargetSpec } from './envelope'
import { describe, expect, it } from 'vitest'
import { route } from './router'

function env(target: TargetSpec): Envelope {
  return {
    v: 1,
    id: 'x',
    ts: 0,
    source: 's',
    target,
    hop: [],
    ttl: 32,
    channel: 'event',
    name: 'n',
  }
}

const ctx = {
  selfId: 'self',
  isRoot: false,
  hasDescendant: (id: string) => id === 'desc',
}

describe('route: unicast', () => {
  it('delivers to self', () => {
    expect(route(env({ mode: 'unicast', id: 'self' }), 'local', ctx)).toEqual({ deliver: true, up: false, down: false })
  })

  it('routes down to a known descendant', () => {
    expect(route(env({ mode: 'unicast', id: 'desc' }), 'local', ctx)).toEqual({ deliver: false, up: false, down: true })
  })

  it('routes up when target is unknown and not root', () => {
    expect(route(env({ mode: 'unicast', id: 'other' }), 'local', ctx)).toEqual({ deliver: false, up: true, down: false })
  })

  it('drops at root when target unknown', () => {
    expect(route(env({ mode: 'unicast', id: 'other' }), 'local', { ...ctx, isRoot: true })).toEqual({ deliver: false, up: false, down: false })
  })

  it('does not bounce back to the link it came from (uplink)', () => {
    expect(route(env({ mode: 'unicast', id: 'other' }), 'uplink', ctx)).toEqual({ deliver: false, up: false, down: false })
  })
})

describe('route: parent', () => {
  it('forwards up from origin', () => {
    expect(route(env({ mode: 'parent' }), 'local', ctx)).toEqual({ deliver: false, up: true, down: false })
  })
  it('delivers when received from a child bus', () => {
    expect(route(env({ mode: 'parent' }), 'downlink', ctx)).toEqual({ deliver: true, up: false, down: false })
  })
  it('ignores when received from the parent bus', () => {
    expect(route(env({ mode: 'parent' }), 'uplink', ctx)).toEqual({ deliver: false, up: false, down: false })
  })
})

describe('route: children', () => {
  it('forwards down from origin', () => {
    expect(route(env({ mode: 'children' }), 'local', ctx)).toEqual({ deliver: false, up: false, down: true })
  })
  it('delivers to a direct child without re-forwarding', () => {
    expect(route(env({ mode: 'children' }), 'uplink', ctx)).toEqual({ deliver: true, up: false, down: false })
  })
})

describe('route: subtree', () => {
  it('forwards down from origin', () => {
    expect(route(env({ mode: 'subtree' }), 'local', ctx)).toEqual({ deliver: false, up: false, down: true })
  })
  it('delivers and keeps forwarding down', () => {
    expect(route(env({ mode: 'subtree' }), 'uplink', ctx)).toEqual({ deliver: true, up: false, down: true })
  })
})

describe('route: ancestors', () => {
  it('forwards up from origin', () => {
    expect(route(env({ mode: 'ancestors' }), 'local', ctx)).toEqual({ deliver: false, up: true, down: false })
  })
  it('delivers and keeps forwarding up', () => {
    expect(route(env({ mode: 'ancestors' }), 'downlink', ctx)).toEqual({ deliver: true, up: true, down: false })
  })
})

describe('route: broadcast', () => {
  it('floods both directions from origin', () => {
    expect(route(env({ mode: 'broadcast' }), 'local', ctx)).toEqual({ deliver: false, up: true, down: true })
  })
  it('delivers and floods away from the source link (uplink)', () => {
    expect(route(env({ mode: 'broadcast' }), 'uplink', ctx)).toEqual({ deliver: true, up: false, down: true })
  })
  it('delivers and floods away from the source link (downlink)', () => {
    expect(route(env({ mode: 'broadcast' }), 'downlink', ctx)).toEqual({ deliver: true, up: true, down: false })
  })
})
