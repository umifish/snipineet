/**
 * 消息信封（Envelope）与寻址（TargetSpec）。
 */

/** 协议版本。 */
export const PROTOCOL_VERSION = 1 as const

/** 默认最大跳数（防止环路无限转发）。 */
export const DEFAULT_TTL = 32

/**
 * 寻址方式：
 * - unicast：点对点，按 id 路由
 * - broadcast：全树广播
 * - parent：发送者的直接父级
 * - children：发送者的直接子级
 * - subtree：发送者的所有后代
 * - ancestors：发送者到根的所有祖先
 */
export type TargetSpec
  = | { mode: 'unicast', id: string }
    | { mode: 'broadcast' }
    | { mode: 'parent' }
    | { mode: 'children' }
    | { mode: 'subtree' }
    | { mode: 'ancestors' }

/** 消息通道。 */
export type Channel = 'event' | 'request' | 'response' | 'system'

/** 消息信封。字段须 structured-clone 安全（可经 postMessage 传输）。 */
export interface Envelope<P = unknown> {
  /** 协议版本。 */
  v: typeof PROTOCOL_VERSION
  /** 全局唯一消息 id，用于去重与 request/response 关联前缀。 */
  id: string
  /** 创建时间戳。 */
  ts: number
  /** 源应用 id。 */
  source: string
  /** 目标寻址。 */
  target: TargetSpec
  /** 已经过的节点 id 列表（trace + 防环 + ttl 计数）。 */
  hop: string[]
  /** 最大跳数。 */
  ttl: number
  /** 通道。 */
  channel: Channel
  /** 事件名 / 请求方法名。 */
  name: string
  /** 负载。 */
  payload?: P
  /** 关联 id，用于 request/response 配对。 */
  corr?: string
  /** 响应是否成功（channel === 'response' 时有效）。 */
  ok?: boolean
}

let counter = 0

/** 生成全局唯一 id。优先使用 crypto.randomUUID。 */
export function createId(prefix = 'm'): string {
  const cryptoObj = (globalThis as { crypto?: { randomUUID?: () => string } }).crypto
  if (cryptoObj?.randomUUID) {
    return `${prefix}_${cryptoObj.randomUUID()}`
  }
  counter = (counter + 1) % Number.MAX_SAFE_INTEGER
  const rand = Math.random().toString(36).slice(2, 10)
  return `${prefix}_${Date.now().toString(36)}_${counter.toString(36)}_${rand}`
}

/** 创建信封的入参。 */
export interface EnvelopeInit<P = unknown> {
  source: string
  target: TargetSpec
  channel: Channel
  name: string
  payload?: P
  corr?: string
  ok?: boolean
  ttl?: number
  id?: string
}

/** 创建一个新信封（hop 初始为空，由首个节点 ingest 时追加自身）。 */
export function createEnvelope<P = unknown>(init: EnvelopeInit<P>): Envelope<P> {
  return {
    v: PROTOCOL_VERSION,
    id: init.id ?? createId(),
    ts: Date.now(),
    source: init.source,
    target: init.target,
    hop: [],
    ttl: init.ttl ?? DEFAULT_TTL,
    channel: init.channel,
    name: init.name,
    payload: init.payload,
    corr: init.corr,
    ok: init.ok,
  }
}
