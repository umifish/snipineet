/**
 * 传输抽象。协议核心只依赖该接口，不关心底层是 wujie bus / postMessage / 内存。
 *
 * 一个 Transport 代表节点接入的一条「总线」。同一条物理总线被父节点当作
 * downlink、被各子节点当作 uplink；总线负责把消息扇出给除发送者外的所有参与者。
 */
import type { Envelope } from './envelope'

export interface Transport {
  /** 传输类型标识（memory / postmessage / broadcastchannel / wujie）。 */
  readonly kind: string
  /** 发送信封到总线（扇出给其它参与者）。 */
  send: (envelope: Envelope) => void
  /** 订阅来自总线的信封，返回取消订阅函数。 */
  subscribe: (handler: (envelope: Envelope) => void) => () => void
  /** 关闭连接。 */
  close?: () => void
}
