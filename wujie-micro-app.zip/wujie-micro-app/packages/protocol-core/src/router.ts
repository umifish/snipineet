/**
 * 纯路由决策函数。给定一条信封与它的来向，决定：本地投递 / 向上转发 / 向下转发。
 * 不含副作用，便于单测覆盖六种寻址 × 三种来向矩阵。
 */
import type { Envelope } from './envelope'

/** 信封来向：本地产生 / 来自上行总线 / 来自下行总线。 */
export type LinkSide = 'local' | 'uplink' | 'downlink'

/** 路由上下文。 */
export interface RouteContext {
  selfId: string
  /** 是否为根节点（无 uplink）。 */
  isRoot: boolean
  /** 目标 id 是否位于本节点子树内。 */
  hasDescendant: (id: string) => boolean
}

/** 路由决策。 */
export interface RouteDecision {
  deliver: boolean
  up: boolean
  down: boolean
}

const NONE: RouteDecision = { deliver: false, up: false, down: false }

/** 根据寻址与来向计算路由决策。 */
export function route(envelope: Envelope, from: LinkSide, ctx: RouteContext): RouteDecision {
  const target = envelope.target

  switch (target.mode) {
    case 'unicast': {
      if (target.id === ctx.selfId) {
        return { deliver: true, up: false, down: false }
      }
      if (ctx.hasDescendant(target.id) && from !== 'downlink') {
        return { deliver: false, up: false, down: true }
      }
      return { deliver: false, up: !ctx.isRoot && from !== 'uplink', down: false }
    }

    case 'parent': {
      if (from === 'local') {
        return { deliver: false, up: true, down: false }
      }
      if (from === 'downlink') {
        return { deliver: true, up: false, down: false }
      }
      return NONE
    }

    case 'children': {
      if (from === 'local') {
        return { deliver: false, up: false, down: true }
      }
      if (from === 'uplink') {
        return { deliver: true, up: false, down: false }
      }
      return NONE
    }

    case 'subtree': {
      if (from === 'local') {
        return { deliver: false, up: false, down: true }
      }
      if (from === 'uplink') {
        return { deliver: true, up: false, down: true }
      }
      return NONE
    }

    case 'ancestors': {
      if (from === 'local') {
        return { deliver: false, up: true, down: false }
      }
      if (from === 'downlink') {
        return { deliver: true, up: true, down: false }
      }
      return NONE
    }

    case 'broadcast': {
      if (from === 'local') {
        return { deliver: false, up: true, down: true }
      }
      return { deliver: true, up: from !== 'uplink', down: from !== 'downlink' }
    }

    default:
      return NONE
  }
}
