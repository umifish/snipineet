import type { ProtocolNode } from './node'
/**
 * 握手 / 拓扑维护。建立多层路由表，使 unicast 能跨层定位。
 *
 * - 子节点 announce()：向 parent 发 Register；
 * - 父节点收到 Register：记录后代、回 RegisterAck（带初始快照）、向上传 TopologyAdd、本地触发 app_registered；
 * - TopologyAdd 逐层向上传播，使每个祖先都知道新后代位于其子树内；
 * - 子节点 leave()：发 Unregister，逐层剪枝。
 */
import type { ContextSnapshot } from './types'
import { BuiltinEvents, SystemMessages } from './events'

/** RegisterAck 负载。 */
export interface RegisterAck {
  parentId: string
  snapshot?: ContextSnapshot
}

/** 握手选项。 */
export interface HandshakeOptions {
  /** 父节点提供初始上下文快照（用于非 wujie 传输的迟到挂载）。 */
  getSnapshot?: () => ContextSnapshot | undefined
  /** 收到子节点注册回调（父侧）。 */
  onChildRegister?: (child: { id: string, name?: string }) => void
  /** 收到子节点注销回调（父侧）。 */
  onChildUnregister?: (child: { id: string }) => void
  /** 收到 RegisterAck 回调（子侧）。 */
  onAck?: (ack: RegisterAck) => void
}

/** 握手控制器。 */
export interface Handshake {
  /** 子节点向父级注册自身（建立路由链路）。 */
  announce: () => void
  /** 子节点离开。 */
  leave: () => void
  /** 释放监听。 */
  dispose: () => void
}

interface RegisterPayload {
  id: string
  name?: string
}

interface TopologyPayload {
  ids: string[]
}

/** 把握手逻辑挂到节点上。 */
export function attachHandshake(node: ProtocolNode, options: HandshakeOptions = {}): Handshake {
  const disposers: Array<() => void> = []

  disposers.push(
    node.on<RegisterPayload>(SystemMessages.Register, (child) => {
      node.addDescendant(child.id)
      if (!node.isRoot) {
        node.send({ mode: 'parent' }, SystemMessages.TopologyAdd, { ids: [child.id] }, 'system')
      }
      node.send(
        { mode: 'unicast', id: child.id },
        SystemMessages.RegisterAck,
        { parentId: node.id, snapshot: options.getSnapshot?.() } satisfies RegisterAck,
        'system',
      )
      node.notifyLocal(BuiltinEvents.AppRegistered, { id: child.id, name: child.name })
      options.onChildRegister?.(child)
    }),
  )

  disposers.push(
    node.on<TopologyPayload>(SystemMessages.TopologyAdd, (payload) => {
      for (const id of payload.ids) {
        node.addDescendant(id)
      }
      if (!node.isRoot) {
        node.send({ mode: 'parent' }, SystemMessages.TopologyAdd, payload, 'system')
      }
      node.notifyLocal(BuiltinEvents.TopologyChanged, { descendants: node.listDescendants() })
    }),
  )

  disposers.push(
    node.on<RegisterPayload>(SystemMessages.Unregister, (child) => {
      node.removeDescendant(child.id)
      if (!node.isRoot) {
        node.send({ mode: 'parent' }, SystemMessages.TopologyRemove, { ids: [child.id] }, 'system')
      }
      node.notifyLocal(BuiltinEvents.AppUnregistered, { id: child.id })
      options.onChildUnregister?.(child)
    }),
  )

  disposers.push(
    node.on<TopologyPayload>(SystemMessages.TopologyRemove, (payload) => {
      for (const id of payload.ids) {
        node.removeDescendant(id)
      }
      if (!node.isRoot) {
        node.send({ mode: 'parent' }, SystemMessages.TopologyRemove, payload, 'system')
      }
      node.notifyLocal(BuiltinEvents.TopologyChanged, { descendants: node.listDescendants() })
    }),
  )

  disposers.push(
    node.on<RegisterAck>(SystemMessages.RegisterAck, (ack) => {
      options.onAck?.(ack)
    }),
  )

  return {
    announce() {
      if (!node.isRoot) {
        node.send({ mode: 'parent' }, SystemMessages.Register, { id: node.id, name: node.name } satisfies RegisterPayload, 'system')
      }
    },
    leave() {
      if (!node.isRoot) {
        node.send({ mode: 'parent' }, SystemMessages.Unregister, { id: node.id } satisfies RegisterPayload, 'system')
      }
    },
    dispose() {
      for (const dispose of disposers) {
        dispose()
      }
    },
  }
}
