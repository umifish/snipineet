/**
 * 协议公共类型定义。
 */

/** 预加载策略：立即 / 浏览器空闲 / 进入视口 / 手动。 */
export type PreloadStrategy = 'eager' | 'idle' | 'visible' | 'manual'

/** 应用在拓扑中的角色：根主、纯子、既主又子。 */
export type AppRole = 'host' | 'sub' | 'dual'

/**
 * 微应用配置（需求 1）。
 * 传输无关：wujie-transport 会把它映射到 wujie 的 startApp/preloadApp 选项。
 */
export interface MicroAppConfig {
  /** 展示名称。 */
  name: string
  /** 全局唯一标识，用于路由寻址。 */
  id: string
  /** 入口地址。 */
  url: string
  /** 鉴权令牌。 */
  token?: string
  /** 语言（如 zh-CN）。 */
  language?: string
  /** 主题（如 dark/light）。 */
  theme?: string
  /** 时区（如 Asia/Shanghai）。 */
  timezone?: string
  /** 是否预加载。 */
  preload?: boolean
  /** 预加载策略。 */
  preloadStrategy?: PreloadStrategy
  /** 是否保活（keep-alive）。 */
  alive?: boolean
  /** 是否同步路由状态。 */
  sync?: boolean
  /** 挂载容器上的额外属性。 */
  attrs?: Record<string, unknown>
  /** 其他扩展数据。 */
  extra?: Record<string, unknown>
}

/** 节点身份。 */
export interface AppIdentity {
  id: string
  name?: string
}

/** 初始上下文快照（经 props/握手注入）。 */
export interface ContextSnapshot {
  theme?: string
  language?: string
  timezone?: string
  token?: string | null
  [key: string]: unknown
}
