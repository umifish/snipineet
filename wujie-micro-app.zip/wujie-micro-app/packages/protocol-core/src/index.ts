/**
 * @intelli/protocol-core —— 传输无关的微前端通信协议核心（零 wujie 依赖，纯消息）。
 */
export type { Channel, Envelope, EnvelopeInit, TargetSpec } from './envelope'
export { createEnvelope, createId, DEFAULT_TTL, PROTOCOL_VERSION } from './envelope'
export type { BuiltinEventPayloads } from './events'
export { BuiltinEvents, SystemMessages } from './events'
export type { Handshake, HandshakeOptions, RegisterAck } from './handshake'
export { attachHandshake } from './handshake'
export type {
  Listener,
  MessageContext,
  ProtocolNodeOptions,
  RequestListener,
  RequestOptions,
} from './node'
export { ProtocolNode } from './node'
export type { LinkSide, RouteContext, RouteDecision } from './router'
export { route } from './router'
export type { Transport } from './transport'
export type { AppIdentity, AppRole, ContextSnapshot, MicroAppConfig, PreloadStrategy } from './types'
