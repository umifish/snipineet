/**
 * App C：纯裸 iframe，无任何框架。仅用 @intelli/app-kit + postMessage 传输接入协议。
 * 演示「子应用与 wujie 完全解耦」也能参与同一套通信协议（点对点 / 广播 / 主子 / 子主）。
 */
import { createMicroApp } from '@intelli/app-kit'
import { createChildTransport } from '@intelli/transport-postmessage'

const uplink = createChildTransport({
  targetWindow: window.parent,
  targetOrigin: '*',
  acceptOrigin: '*',
})

const app = createMicroApp({
  id: 'app-c',
  name: 'App C (bare iframe)',
  uplink,
})

const root = document.getElementById('app') as HTMLDivElement
const state = { theme: 'light', language: 'zh-CN', events: [] as string[] }

function render(): void {
  const dark = state.theme === 'dark'
  root.style.cssText = `font-family: system-ui; padding: 16px; min-height: 280px; background: ${dark ? '#111' : '#fff'}; color: ${dark ? '#eee' : '#111'};`
  root.innerHTML = `
    <h3>App C（裸 iframe，postMessage）</h3>
    <p>收到上下文 → theme: <b>${state.theme}</b> · language: <b>${state.language}</b></p>
    <button id="req-theme" type="button">由 C 请求切换主题（子 → 根 上行请求，经 B 中继）</button>
    <ul>${state.events.map((line) => `<li>${line}</li>`).join('')}</ul>
  `
  root.querySelector<HTMLButtonElement>('#req-theme')!.onclick = () => {
    app.setContext('theme', state.theme === 'light' ? 'dark' : 'light')
  }
}

// RPC：供 Host A 跨层请求（a → b → c 中继）。
app.handle<void, string>('getTime', () => new Date().toISOString())

// 订阅上下文（由根 owner 广播，经 B 中继到达）。
app.subscribeContext<string>('theme', (value) => {
  state.theme = value
  render()
}, { immediate: true })
app.subscribeContext<string>('language', (value) => {
  state.language = value
  render()
}, { immediate: true })

// 监听来自 B 的 ping（主 → 子）。
app.on<{ from: string }>('ping', (payload) => {
  state.events = [`📨 收到 ${payload.from} 的 ping`, ...state.events].slice(0, 6)
  render()
})

render()
app.ready()
