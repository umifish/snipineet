import { defineConfig } from 'vite'

const PORT = 4312

export default defineConfig({
  server: {
    port: PORT,
    cors: true,
    headers: { 'Access-Control-Allow-Origin': '*' },
    origin: `http://localhost:${PORT}`,
  },
})
