import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

const PORT = 4310

export default defineConfig({
  plugins: [react()],
  server: {
    port: PORT,
    cors: true,
    headers: { 'Access-Control-Allow-Origin': '*' },
    origin: `http://localhost:${PORT}`,
  },
})
