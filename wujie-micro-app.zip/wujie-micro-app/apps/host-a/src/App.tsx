import type { MicroAppRuntime } from '@intelli/app-kit'
import type { MicroAppConfig } from '@intelli/protocol-core'
import type { ReactNode } from 'react'
import { MicroAppMount, MicroAppProvider, useContextValue, useMicroApp, useMicroEvent } from '@intelli/react'
import { useState } from 'react'

const APP_B: MicroAppConfig = {
  id: 'app-b',
  name: 'App B',
  url: 'http://localhost:4311/',
  sync: true,
}

function Panel(): ReactNode {
  const app = useMicroApp()
  const theme = useContextValue<string>('theme')
  const language = useContextValue<string>('language')
  const [log, setLog] = useState<string[]>([])
  const [remoteTime, setRemoteTime] = useState<string>('')

  useMicroEvent<{ id: string }>('app_ready', ({ id }) => {
    setLog((prev) => [`✅ ${id} ready`, ...prev].slice(0, 8))
  })
  useMicroEvent<{ id: string }>('app_registered', ({ id }) => {
    setLog((prev) => [`🔗 ${id} registered`, ...prev].slice(0, 8))
  })

  async function requestTimeFromC(): Promise<void> {
    try {
      const time = await app.request<string>({ mode: 'unicast', id: 'app-c' }, 'getTime')
      setRemoteTime(time)
    } catch (error) {
      setRemoteTime(`error: ${String(error)}`)
    }
  }

  return (
    <div style={{ fontFamily: 'system-ui', padding: 16 }}>
      <h2>Host A（根宿主 / 上下文 owner）</h2>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
        <span>
          theme:
          {' '}
          <b>{theme}</b>
          {' '}
          · language:
          {' '}
          <b>{language}</b>
        </span>
        <button type="button" onClick={() => app.setContext('theme', theme === 'light' ? 'dark' : 'light')}>
          切换主题（广播 a → b → c）
        </button>
        <select value={language} onChange={(event) => app.setContext('language', event.target.value)}>
          <option value="zh-CN">zh-CN</option>
          <option value="en-US">en-US</option>
          <option value="ja-JP">ja-JP</option>
        </select>
        <button type="button" onClick={requestTimeFromC}>
          向 App C 请求时间（a → b → c 中继 RPC）
        </button>
        <span>
          App C 时间：
          <b>{remoteTime || '—'}</b>
        </span>
      </div>
      <ul>{log.map((line, index) => <li key={index}>{line}</li>)}</ul>
      <div style={{ border: '2px solid #4c8bf5', borderRadius: 8, marginTop: 12, height: 520 }}>
        <MicroAppMount config={APP_B} parentId="host-a" />
      </div>
    </div>
  )
}

export function App(props: { runtime: MicroAppRuntime }): ReactNode {
  return (
    <MicroAppProvider runtime={props.runtime}>
      <Panel />
    </MicroAppProvider>
  )
}
