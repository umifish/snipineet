import { createHostRuntime } from '@intelli/react'
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { App } from './App'

// 根宿主：上下文权威 owner，downlink = wujie hostBus()。
const runtime = createHostRuntime({
  id: 'host-a',
  name: 'Host A',
  initialContext: {
    theme: 'light',
    language: 'zh-CN',
    timezone: 'Asia/Shanghai',
  },
})

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App runtime={runtime} />
  </StrictMode>,
)
