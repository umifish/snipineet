import { MicroAppProvider } from '@intelli/react'
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { App } from './App'
import { runtime } from './runtime'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <MicroAppProvider runtime={runtime}>
      <App />
    </MicroAppProvider>
  </StrictMode>,
)
