/**
 * App B 运行时：双重角色。
 * - uplink = wujie 子总线（来自 Host A）；
 * - downlink = PostMessageHub（托管裸 iframe 的 App C）。
 * 混合传输，演示协议与具体传输解耦。
 */
import { createMicroApp } from '@intelli/app-kit'
import { PostMessageHub } from '@intelli/transport-postmessage'
import { createWujieTransport, getWujieSubBus, readInjectedProps } from '@intelli/wujie-transport'

const subBus = getWujieSubBus()
const injected = readInjectedProps()

// wujie 下，App C 的 iframe 元素被投影到宿主 shadow DOM，其 window.parent 指向宿主窗口，
// 子级消息会落在宿主窗口而非本沙箱窗口。因此同时监听本窗口与宿主窗口（window.parent）。
const listenWindow
  = typeof window !== 'undefined' && window.parent && window.parent !== window
    ? [window, window.parent]
    : window

export const hub = new PostMessageHub({ listenWindow })

export const runtime = createMicroApp({
  id: injected?.id ?? 'app-b',
  name: injected?.name ?? 'App B',
  uplink: subBus ? createWujieTransport(subBus) : undefined,
  downlink: hub.connect(),
  initialContext: injected?.snapshot,
})

runtime.ready()
