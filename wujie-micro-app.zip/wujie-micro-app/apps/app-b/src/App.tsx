import type { ReactNode } from 'react'
import { useContextValue, useMicroApp, useMicroEvent } from '@intelli/react'
import { useEffect, useRef, useState } from 'react'
import { hub } from './runtime'

const APP_C_ORIGIN = 'http://localhost:4312'

export function App(): ReactNode {
  const app = useMicroApp()
  const theme = useContextValue<string>('theme')
  const language = useContextValue<string>('language')
  const iframeRef = useRef<HTMLIFrameElement>(null)
  const [log, setLog] = useState<string[]>([])

  useMicroEvent<{ id: string }>('app_ready', ({ id }) => {
    setLog((prev) => [`✅ ${id} ready`, ...prev].slice(0, 6))
  })

  useEffect(() => {
    const iframe = iframeRef.current
    if (!iframe || !iframe.contentWindow) {
      return
    }
    // 早绑定：iframe 的 WindowProxy 在导航后保持同一引用，先注册端口可避免
    // App C 启动即 announce 时父侧尚未登记子窗口而丢失握手的竞态。
    const remove = hub.addChild(iframe.contentWindow, '*')
    setLog((prev) => ['🔌 App C iframe 已接入', ...prev].slice(0, 6))
    return remove
  }, [])

  return (
    <div style={{ fontFamily: 'system-ui', padding: 16, background: theme === 'dark' ? '#222' : '#f6f8fa', color: theme === 'dark' ? '#eee' : '#111' }}>
      <h3>App B（子应用 + 宿主 / dual）</h3>
      <p>
        收到上下文 → theme:
        {' '}
        <b>{theme}</b>
        {' '}
        · language:
        {' '}
        <b>{language}</b>
      </p>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        <button type="button" onClick={() => app.setContext('language', language === 'zh-CN' ? 'en-US' : 'zh-CN')}>
          由 B 请求切换语言（子 → 主 上行请求）
        </button>
        <button
          type="button"
          onClick={() => app.emit('ping', { from: 'app-b', at: Date.now() }, { mode: 'children' })}
        >
          向子级 App C 广播 ping（主 → 子）
        </button>
      </div>
      <ul>{log.map((line, index) => <li key={index}>{line}</li>)}</ul>
      <iframe
        ref={iframeRef}
        title="app-c"
        src={APP_C_ORIGIN}
        style={{ width: '100%', height: 320, border: '2px dashed #f5a623', borderRadius: 8 }}
      />
    </div>
  )
}
