# 执行计划（EXECUTION_PLAN）

> 单一事实来源：每完成一个任务即勾选对应节点。
> 协议核心零 wujie 依赖；初始状态走 wujie props，后续变更走消息。

## P0 脚手架 + 执行文档
- [x] pnpm workspace + 根 package.json（脚本对齐 supernova）
- [x] eslint flat（@antfu）+ prettier + tsconfig base/root
- [x] .gitignore + README
- [x] 本执行文档

## P1 protocol-core + memory 传输 + 单测
- [x] `types.ts`：MicroAppConfig / AppIdentity / PreloadStrategy / Role
- [x] `envelope.ts`：Envelope / TargetSpec / 工厂 + id 生成
- [x] `transport.ts`：Transport 抽象接口
- [x] `router.ts`：ProtocolNode 路由（unicast/broadcast/parent/children/subtree/ancestors + ttl/dedup/防环）
- [x] `messaging.ts`：on/emit/request-response（相关 id 关联）
- [x] `handshake.ts`：register / register_ack / unregister / topology 路由表
- [x] `events.ts`：内置事件类型 + EventMap
- [x] `transport-memory`：进程内 hub
- [x] vitest 路由矩阵单测（router 17 + 集成 13：6 种 target × 环路/ttl/dedup + request/response + 多层中继）

## P2 context 薄层
- [x] `context-store.ts`：get/set/subscribe + 变更广播
- [x] 初值来源：props 快照 / init 握手快照
- [x] 单 owner（根 host），子 requestContextChange 上报
- [x] 单测（5）

## P3 transport-postmessage + transport-broadcastchannel
- [x] postMessage 传输（iframe/跨窗口，含握手与 origin 校验）
- [x] broadcastchannel 传输（跨标签页同源）

## P4 wujie-transport
- [x] bus 适配（host hub / sub uplink）
- [x] MicroAppConfig → wujie startApp/preloadApp 映射
- [x] props 注入桥接（初始状态）

## P5 app-kit
- [x] 角色自识别（host / sub / dual）
- [x] uplink/downlink 装配
- [x] 预加载策略（eager / idle / visible / manual）
- [x] 高层 API（createMicroApp / mount / context / on / request）

## P6 react 适配
- [x] MicroAppProvider
- [x] hooks：useMicroApp / useContextValue / useMicroEvent / useSetContext
- [x] `<MicroAppMount>`（基于 wujie-react `<WujieReact>`，props 传初值）

## P7 demo a→b→c + dev 矩阵脚本
- [x] apps/host-a（React 根主）
- [x] apps/app-b（React，主+子；uplink=wujie，downlink=postMessage）
- [x] apps/app-c（裸 iframe + postMessage）
- [x] scripts/dev-matrix.mjs（端口 4310/4311/4312，避开 5173/5174）

## P8 验证
- [x] `pnpm -r build`（8 库包 + 3 demo 全绿）
- [x] `pnpm -r test`（protocol-core 17 / transport-memory 13 / context 5）
- [x] `pnpm typecheck`
- [x] `pnpm lint`
- [x] 手动 demo 走查（theme 广播 / c→a 中继 / 迟到挂载快照）
  - [x] 广播 a→b→c（主题切换，跨 wujie + postMessage 双传输同步）
  - [x] 跨层 RPC：Host A `request('getTime')` → App C（a→b→c 中继，原路返回）
  - [x] 子→根 上行请求：App C 切换主题（经 B 中继到根 owner，再广播回落）
  - [x] 子→主 上行请求：App B 切换语言（到根 owner 后广播）
  - [x] 主→子：App B 向 App C 广播 ping（精确单次投递）

### 走查中修复
- App C（裸 iframe）在 wujie 下其 DOM 被投影到宿主 shadow DOM，`window.parent` 指向宿主窗口；
  `PostMessageHub` 增加多窗口监听（同时监听本窗口与宿主窗口），修复子→父上行链路丢失。
- `PostMessageHub.addChild` 改为按窗口幂等登记（Map 键），修复 StrictMode/HMR 下重复登记导致的多次扇出投递。
