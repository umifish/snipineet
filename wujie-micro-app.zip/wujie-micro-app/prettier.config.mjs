/** @typedef {import('prettier').Config} PrettierConfig */

/**
 * Prettier 纯格式配置，键值对齐 supernova，避免与 ESLint 拉扯。
 * @type {PrettierConfig}
 */
export default {
  arrowParens: 'always',
  bracketSpacing: true,
  printWidth: 160,
  quoteProps: 'consistent',
  semi: false,
  singleQuote: true,
  tabWidth: 2,
  trailingComma: 'all',
  useTabs: false,
}
