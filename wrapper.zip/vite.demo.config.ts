import { resolve } from 'node:path'

import vue from '@vitejs/plugin-vue'
import svgLoader from 'vite-svg-loader'
import { defineConfig } from 'vite'

/** 本地预览：`pnpm run demo`（不产出 dist、不跑 dts） */
export default defineConfig({
  root: resolve(__dirname, 'demo'),
  plugins: [vue(), svgLoader()],
  resolve: {
    alias: {
      '@supernova/i18n-vue': resolve(__dirname, 'src/index.ts'),
    },
  },
  server: {
    port: 5174,
    open: true,
  },
})
