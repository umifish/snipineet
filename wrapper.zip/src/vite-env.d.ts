/// <reference types="vite/client" />

/**
 * 部分语言服务对仅依赖 `vite/client` 的 `*.vue` 声明解析不稳定，此处再声明一次以消除
 * `.ts` 内 `import Foo from './X.vue'` 的「找不到模块」提示。
 */
declare module '*.vue' {
  import type { DefineComponent } from 'vue'
  const component: DefineComponent<object, object, unknown>
  export default component
}

declare module '*.svg?url' {
  const src: string
  export default src
}

declare module '*.svg?raw' {
  const src: string
  export default src
}

declare module '*.svg?component' {
  import type { Component } from 'vue'
  const comp: Component
  export default comp
}
