import type { VNode } from 'vue'
import {
  cloneVNode,
  Comment,
  Fragment,
  h,
  isVNode,
  mergeProps,
  Text,
} from 'vue'

/** 将任意值规范为与 `v-model` 字符串展示一致的绑定值（可按业务替换） */
export function toBoundString(v: unknown): string {
  return v == null ? '' : String(v)
}

/**
 * 平台通用：在默认插槽中**按深度优先**找到第一个可注入的 vnode（原生标签、组件对象/函数），
 * 注入 Vue 3 标准 `modelValue` + `onUpdate:modelValue`，与具体 UI 库无关。
 *
 * 合并方式：先 `mergeProps(注入对象, 子 vnode.props)`。对一般 prop **后一参数覆盖前一参数**；
 * 对 `onXxx` 监听器 Vue 会**合并调用**（子组件与注入的 `onUpdate:modelValue` 可同时生效）。
 * 若子节点显式写了 `modelValue`，将覆盖注入值，可能导致与外层 `v-model` 脱节，属预期「子优先」语义。
 *
 * **仅当** `extraInjected.prefixIcon` / `extraInjected.suffixIcon` 有值时，会再各执行一次 `mergeProps`，使注入的图标**覆盖**子组件自带的 `prefixIcon` / `suffixIcon`；
 * 未设置对应键时不改动子组件原有区域。使用内置清除后缀时建议关闭输入框自带的 `clearable`，避免重复清除控件。
 *
 * @remarks
 * - 以 `Fragment` 包裹的单子节点会向下递归；**Teleport / 仅 Symbol 类型的内部节点**等不会继续向下解析，
 *   此时注入可能落在外层容器上；插槽宜直接以目标输入组件为首个可注入节点。
 */
export interface SlotModelBindingInput {
  /** `useAttrs()`，不含已声明在包裹组件上的 props */
  attrs: Record<string, unknown>
  getModelValue: () => unknown
  onModelValueUpdate: (v: unknown) => void
  /** 在 attrs 之后、模型字段之前写入同一对象（再与子 props 做 mergeProps） */
  extraInjected?: Record<string, unknown>
}

function buildInjectedProps(b: SlotModelBindingInput): Record<string, unknown> {
  return {
    ...b.attrs,
    ...b.extraInjected,
    'modelValue': b.getModelValue(),
    'onUpdate:modelValue': b.onModelValueUpdate,
  }
}

/** 将 Fragment 的 children 规范为 VNode 数组（兼容单子节点未包成数组的情况） */
function normalizeFragmentChildren(children: unknown): VNode[] {
  if (children == null) {
    return []
  }
  if (Array.isArray(children)) {
    return children as VNode[]
  }
  if (typeof children === 'string' || typeof children === 'number' || typeof children === 'boolean') {
    return []
  }
  if (isVNode(children)) {
    return [children as VNode]
  }

  return []
}

export function injectModelIntoDefaultSlot(
  nodes: VNode[],
  input: SlotModelBindingInput,
): VNode[] {
  let hasInjected = false

  const walk = (list: VNode[]): VNode[] =>
    list.map((vnode) => {
      if (hasInjected) {
        return vnode
      }

      if (vnode.type === Fragment) {
        const ch = normalizeFragmentChildren(vnode.children)

        return cloneVNode(vnode, { children: walk(ch) })
      }

      if (
        vnode.type === Comment
        || (vnode.type === Text
          && typeof vnode.children === 'string'
          && vnode.children.trim() === '')
      ) {
        return vnode
      }

      if (
        typeof vnode.type === 'string'
        || typeof vnode.type === 'object'
        || typeof vnode.type === 'function'
      ) {
        hasInjected = true
        const merged = mergeProps(buildInjectedProps(input), vnode.props ?? {})
        const ex = input.extraInjected
        let finalMerged = merged
        if (ex?.prefixIcon != null) {
          finalMerged = mergeProps(finalMerged, { prefixIcon: ex.prefixIcon })
        }
        if (ex?.suffixIcon != null) {
          finalMerged = mergeProps(finalMerged, { suffixIcon: ex.suffixIcon })
        }

        /** 第三参为 `mergeRef`：与原有 ref 合并，避免克隆后丢失 */
        return cloneVNode(vnode, finalMerged, true)
      }

      return vnode
    })

  return walk(nodes)
}

/** 将注入后的 vnode 列表收敛为单根或 Fragment，便于在 render 中返回 */
export function normalizeInjectedSlotRoots(list: VNode[]): VNode | null {
  if (list.length === 0) {
    return null
  }
  if (list.length === 1) {
    return list[0]
  }

  return h(Fragment, null, list)
}
