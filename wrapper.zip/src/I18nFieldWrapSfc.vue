<script setup lang="ts">
import type { Component, PropType } from 'vue'
import { useSlots } from 'vue'

import type { I18nFieldTranslations } from './i18nFieldTypes'
import { useI18nFieldWrapRender } from './useI18nFieldWrap'

/**
 * 与 `I18nFieldWrap`（.ts）逻辑一致；前缀见 `showI18nPrefixIcon`，后缀清除见 `showI18nClearIcon`。
 * `textarea` 为 true 时使用内置多行壳层，无需默认插槽。
 */
defineOptions({
  name: 'I18nFieldWrapSfc',
  inheritAttrs: false,
})

const props = defineProps({
  modelValue: { type: String, default: '' },
  i18nCode: { type: String, default: '' },
  translations: {
    type: Object as PropType<I18nFieldTranslations | undefined>,
    required: false,
    default: undefined,
  },
  locale: { type: String, default: '' },
  showI18nPrefixIcon: { type: Boolean, default: false },
  i18nPrefixIcon: {
    type: [String, Object, Function] as PropType<string | Component | undefined>,
    required: false,
    default: undefined,
  },
  i18nPrefixIconClickable: { type: Boolean, default: true },
  showI18nClearIcon: { type: Boolean, default: false },
  i18nClearIcon: {
    type: [String, Object, Function] as PropType<string | Component | undefined>,
    required: false,
    default: undefined,
  },
  i18nClearIconAlwaysVisible: { type: Boolean, default: false },
  i18nClearIconClickable: { type: Boolean, default: true },
  textarea: { type: Boolean, default: false },
  i18nTextareaRows: { type: Number, default: 4 },
  i18nTextareaPlaceholder: { type: String, default: '' },
})

const emit = defineEmits<{
  'update:modelValue': [v: string]
  'update:i18nCode': [v: string]
  'update:translations': [v: I18nFieldTranslations]
  'i18nPrefixClick': []
  'i18nClearClick': []
}>()

const slots = useSlots()
const renderRoot = useI18nFieldWrapRender(
  props,
  {
    onTranslationsPatch: (next) => {
      emit('update:translations', next)
    },
    onI18nPrefixClick: () => {
      emit('i18nPrefixClick')
    },
    onI18nCodeClear: () => {
      emit('update:i18nCode', '')
    },
    onI18nClearClick: () => {
      emit('i18nClearClick')
    },
  },
  slots,
)
const Root = renderRoot
</script>

<template>
  <Root />
</template>
