export type I18nFieldTranslations = Record<string, string>
