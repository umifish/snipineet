<script setup lang="ts">
import type { Component } from 'vue'

/**
 * 供 `I18nFieldWrap` 在 `textarea` 模式下使用：内置 prefix/suffix 布局（多行换行后与 prefix 左缘对齐），
 * 使用方无需自行处理 `text-indent` / 绝对定位。
 */
defineOptions({ name: 'I18nFieldTextareaShell' })

const modelValue = defineModel<string>({ default: '' })

withDefaults(
  defineProps<{
    prefixIcon?: string | Component
    suffixIcon?: string | Component
    rows?: number
    placeholder?: string
  }>(),
  {
    rows: 4,
    placeholder: '',
  },
)

function onInput(e: Event) {
  modelValue.value = (e.target as HTMLTextAreaElement).value
}
</script>

<template>
  <div class="i18n-field-textarea-shell">
    <span
      v-if="$props.prefixIcon != null"
      class="i18n-field-textarea-shell__adorn i18n-field-textarea-shell__adorn--prefix"
    >
      <i v-if="typeof $props.prefixIcon === 'string'" :class="$props.prefixIcon" aria-hidden="true" />
      <component :is="$props.prefixIcon" v-else />
    </span>
    <textarea
      :class="[
        'i18n-field-textarea-shell__control',
        $props.prefixIcon != null && 'i18n-field-textarea-shell__control--with-prefix',
        $props.suffixIcon != null && 'i18n-field-textarea-shell__control--with-suffix',
      ]"
      :value="modelValue"
      :rows="rows"
      :placeholder="placeholder"
      @input="onInput"
    />
    <span
      v-if="$props.suffixIcon != null"
      class="i18n-field-textarea-shell__adorn i18n-field-textarea-shell__adorn--suffix"
    >
      <i v-if="typeof $props.suffixIcon === 'string'" :class="$props.suffixIcon" aria-hidden="true" />
      <component :is="$props.suffixIcon" v-else />
    </span>
  </div>
</template>

<style scoped>
.i18n-field-textarea-shell {
  /*
   * 图标垂直居中于「首行行框」：ipy + 半行高 − 半枚图标(1em)。
   * em 相对本壳 font-size，与 textarea inherit 一致。
   */
  --i18n-fts-ipy: 0.375rem;
  --i18n-fts-ipx: 0.35rem;
  --i18n-fts-lh: 1.5;
  --i18n-fts-gap: 0.35rem;
  --i18n-fts-prefix-slot: calc(1em + var(--i18n-fts-gap));
  --i18n-fts-suffix-slot: calc(1em + var(--i18n-fts-gap));

  position: relative;
  box-sizing: border-box;
  width: 100%;
  font-size: 0.875rem;
  line-height: var(--i18n-fts-lh);
  color: #1d2129;
}

.i18n-field-textarea-shell__adorn {
  position: absolute;
  z-index: 1;
  display: inline-flex;
  align-items: center;
  color: #4e5969;

  top: calc(
    var(--i18n-fts-ipy) + (1em * var(--i18n-fts-lh) / 2 - 0.5em)
  );
}

.i18n-field-textarea-shell__adorn--prefix {
  left: var(--i18n-fts-ipx);
}

.i18n-field-textarea-shell__adorn--suffix {
  right: var(--i18n-fts-ipx);
}

.i18n-field-textarea-shell__control {
  display: block;
  box-sizing: border-box;
  width: 100%;
  min-height: 4.5rem;
  margin: 0;
  padding: var(--i18n-fts-ipy) var(--i18n-fts-ipx) 0.35rem;
  border: none;
  outline: none;
  resize: vertical;
  font: inherit;
  line-height: var(--i18n-fts-lh);
  color: inherit;
  background: transparent;
}

.i18n-field-textarea-shell__control--with-prefix {
  text-indent: var(--i18n-fts-prefix-slot);
}

.i18n-field-textarea-shell__control--with-suffix {
  padding-right: calc(var(--i18n-fts-ipx) + var(--i18n-fts-suffix-slot));
}

.i18n-field-textarea-shell__adorn :deep(svg) {
  display: block;
}
</style>
