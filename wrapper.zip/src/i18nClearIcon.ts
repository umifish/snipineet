import type { Component } from 'vue'
import { defineComponent, h } from 'vue'

import { renderIconNode } from './i18nIconNode'

/** 内联清除图标，无 UI 库依赖，作默认后缀「清空」 */
export const DefaultI18nClearIcon = defineComponent({
  name: 'DefaultI18nClearIcon',
  setup() {
    return () =>
      h(
        'svg',
        {
          'xmlns': 'http://www.w3.org/2000/svg',
          'viewBox': '0 0 24 24',
          'width': '1em',
          'height': '1em',
          'fill': 'none',
          'stroke': 'currentColor',
          'stroke-width': '2',
          'stroke-linecap': 'round',
          'stroke-linejoin': 'round',
          'aria-hidden': 'true',
        },
        [
          h('circle', { cx: '12', cy: '12', r: '10' }),
          h('path', { d: 'M15 9l-6 6M9 9l6 6' }),
        ],
      )
  },
})

/**
 * 可点击后缀清除区：清空 `modelValue` 与当前 `locale` 在 `translations` 中的条目由外层处理。
 */
export function wrapI18nClearIconForClick(
  icon: string | Component,
  onClick: () => void,
): Component {
  return defineComponent({
    name: 'I18nFieldWrapClearIcon',
    setup() {
      return () =>
        h(
          'span',
          {
            class: 'i18n-field-wrap__clear-icon',
            style: {
              display: 'inline-flex',
              alignItems: 'center',
              cursor: 'pointer',
            },
            role: 'button',
            tabindex: 0,
            'aria-label': 'Clear',
            onClick: (e: MouseEvent) => {
              e.stopPropagation()
              onClick()
            },
            onKeydown: (e: KeyboardEvent) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault()
                e.stopPropagation()
                onClick()
              }
            },
          },
          [renderIconNode(icon)],
        )
    },
  })
}
