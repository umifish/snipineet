import type { Component } from 'vue'
import { defineComponent, h } from 'vue'

/** 默认国际化前缀图标：`vite-svg-loader` + `*.svg?component`（与 Vite 生态一致） */
import DefaultI18nPrefixSvg from './assets/default-i18n-prefix.svg?component'

import { renderIconNode } from './i18nIconNode'

/**
 * 默认前缀「国际化」图标：来自 `default-i18n-prefix.svg` 的 Vue 组件（内联矢量、`currentColor`）。
 */
export const DefaultI18nPrefixIcon = defineComponent({
  name: 'DefaultI18nPrefixIcon',
  setup() {
    return () =>
      h(DefaultI18nPrefixSvg, {
        'aria-hidden': true,
        style: {
          display: 'block',
          width: '1em',
          height: '1em',
        },
      })
  },
})

/**
 * 包一层可点击、可键盘触发区域，用于在 `prefixIcon` 上打开弹窗等；
 * 由输入框自己的 prefix 区域排布，无额外遮盖层。
 */
export function wrapI18nPrefixIconForClick(
  icon: string | Component,
  onClick: () => void,
): Component {
  return defineComponent({
    name: 'I18nFieldWrapPrefixIcon',
    setup() {
      return () =>
        h(
          'span',
          {
            class: 'i18n-field-wrap__prefix-icon',
            style: {
              display: 'inline-flex',
              alignItems: 'center',
              cursor: 'pointer',
            },
            role: 'button',
            tabindex: 0,
            onClick: (e: MouseEvent) => {
              e.stopPropagation()
              onClick()
            },
            onKeydown: (e: KeyboardEvent) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault()
                e.stopPropagation()
                onClick()
              }
            },
          },
          [renderIconNode(icon)],
        )
    },
  })
}
