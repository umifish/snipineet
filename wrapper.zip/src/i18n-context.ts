import type { InjectionKey } from 'vue'
import { inject, provide } from 'vue'

export type TranslateFn = (key: string, params?: Record<string, unknown>) => string

export const I18N_TRANSLATE_KEY: InjectionKey<TranslateFn> = Symbol('supernova.i18n.translate')

export function provideI18nTranslate(t: TranslateFn): void {
  provide(I18N_TRANSLATE_KEY, t)
}

export function useI18nTranslate(fallback?: TranslateFn): TranslateFn {
  return inject(I18N_TRANSLATE_KEY, fallback ?? ((key: string) => key))
}
