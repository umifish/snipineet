import type { Component, PropType } from 'vue'
import type { I18nFieldTranslations } from './i18nFieldTypes'

import { defineComponent } from 'vue'
import { useI18nFieldWrapRender } from './useI18nFieldWrap'

export type { I18nFieldTranslations }

/**
 * 与 **`I18nFieldWrapSfc`（`.vue`）** 行为相同；`defineComponent` + 渲染函数，适合只引用 JS 产物的场景。
 *
 * **前缀国际化图标**：
 * - `showI18nPrefixIcon` 为 **false**（默认）：不注入、**不改动**子组件原有 `prefixIcon`。
 * - 为 **true**：通过 `prefixIcon` 注入（与 Element Plus `ElInput` 等一致），并**覆盖**子组件上已有 `prefixIcon`；子组件若本不支持该 prop（部分 `textarea` 实现可能忽略），则注入可能无视觉，属 UI 库能力差异。
 * - `i18nPrefixIcon` 可选；不传时使用内置默认图标。点击可触发 `i18nPrefixClick`（见 `i18nPrefixIconClickable`）。
 *
 * **后缀清除图标**：
 * - `showI18nClearIcon` 为 **true** 时通过 `suffixIcon` 注入，**覆盖**子组件已有 `suffixIcon`；点击清空 `modelValue`，并将 `translations[locale]` 置为 `''`（若已绑定 `translations` 且 `locale` 非空），同时 `update:i18nCode` 为空字符串。默认仅在输入非空时显示；`i18nClearIconAlwaysVisible` 可改为始终显示。建议与 EP `ElInput` 联用时关闭其 `clearable`，避免双清除按钮。
 *
 * **内置多行（`textarea`）**：
 * - `textarea` 为 **true** 时使用包内 textarea 壳层（实现细节，不对外导出），**不需要**默认插槽；前后缀注入与单行一致，换行后与 prefix 左缘对齐；图标垂直位置按首行行框居中（`padding-top` + 半行高 − 半枚图标）。
 * - `i18nTextareaRows`、`i18nTextareaPlaceholder` 可选；内置 textarea 样式在构建时注入入口 JS，**无需**单独引入 CSS。
 *
 * ```vue
 * <I18nFieldWrap
 *   v-model="text"
 *   v-model:translations="tr"
 *   :locale="locale"
 *   show-i18n-prefix-icon
 *   @i18n-prefix-click="openDialog"
 * >
 *   <ElInput />
 * </I18nFieldWrap>
 *
 * <I18nFieldWrap
 *   v-model="note"
 *   v-model:translations="tr"
 *   :locale="locale"
 *   textarea
 *   show-i18n-prefix-icon
 *   show-i18n-clear-icon
 * />
 * ```
 */
export const I18nFieldWrap = defineComponent({
  name: 'I18nFieldWrap',
  inheritAttrs: false,
  props: {
    modelValue: {
      type: String,
      default: '',
    },
    i18nCode: {
      type: String,
      default: '',
    },
    translations: {
      type: Object as PropType<I18nFieldTranslations | undefined>,
      required: false,
      default: undefined,
    },
    locale: {
      type: String,
      default: '',
    },
    showI18nPrefixIcon: {
      type: Boolean,
      default: false,
    },
    i18nPrefixIcon: {
      type: [String, Object, Function] as PropType<string | Component>,
      required: false,
      default: undefined,
    },
    i18nPrefixIconClickable: {
      type: Boolean,
      default: true,
    },
    showI18nClearIcon: {
      type: Boolean,
      default: false,
    },
    i18nClearIcon: {
      type: [String, Object, Function] as PropType<string | Component>,
      required: false,
      default: undefined,
    },
    i18nClearIconAlwaysVisible: {
      type: Boolean,
      default: false,
    },
    i18nClearIconClickable: {
      type: Boolean,
      default: true,
    },
    textarea: {
      type: Boolean,
      default: false,
    },
    i18nTextareaRows: {
      type: Number,
      default: 4,
    },
    i18nTextareaPlaceholder: {
      type: String,
      default: '',
    },
  },
  emits: {
    'update:modelValue': (_v: string) => true,
    'update:i18nCode': (_v: string) => true,
    'update:translations': (_v: I18nFieldTranslations) => true,
    'i18nPrefixClick': () => true,
    'i18nClearClick': () => true,
  },
  setup(props, { slots, emit }) {
    return useI18nFieldWrapRender(
      props,
      {
        onTranslationsPatch: (next) => {
          emit('update:translations', next)
        },
        onI18nPrefixClick: () => {
          emit('i18nPrefixClick')
        },
        onI18nCodeClear: () => {
          emit('update:i18nCode', '')
        },
        onI18nClearClick: () => {
          emit('i18nClearClick')
        },
      },
      slots,
    )
  },
})

export default I18nFieldWrap
