import type { Component, Ref, Slots, VNode } from 'vue'
import type { I18nFieldTranslations } from './i18nFieldTypes'

import { h, useAttrs, useModel } from 'vue'

import I18nFieldTextareaShell from './I18nFieldTextareaShell.vue'
import { DefaultI18nClearIcon, wrapI18nClearIconForClick } from './i18nClearIcon'
import { DefaultI18nPrefixIcon, wrapI18nPrefixIconForClick } from './i18nPrefixIcon'
import {
  injectModelIntoDefaultSlot,
  normalizeInjectedSlotRoots,
  toBoundString,
} from './slotModelInject'

/** `useModel` / 注入逻辑用到的 props（可传入含 `i18nCode` 等的完整 props） */
export interface I18nFieldWrapBindProps {
  modelValue: string
  locale: string
  translations?: I18nFieldTranslations
  /** 为 true 时向下注入 `prefixIcon`（如 Element Plus `ElInput`），不额外 DOM 遮盖 */
  showI18nPrefixIcon?: boolean
  /**
   * 与 EP `IconPropType` 类似：Vue 组件，或 **图标字体 class 字符串**；
   * 或是 **SVG 资源 URL**（如 Vite 默认 `import url from './icon.svg'`、`?url`、含 `.svg` 的绝对地址、`data:image/svg`），将按 `<img>` 渲染；
   * 未传且 `showI18nPrefixIcon` 时用内置 `DefaultI18nPrefixIcon`。
   */
  i18nPrefixIcon?: string | Component
  /** 默认 true；为 false 时仅展示图标，不包可点击层、不触发 `i18nPrefixClick` */
  i18nPrefixIconClickable?: boolean
  /** 为 true 时注入 `suffixIcon`（如 Element Plus `ElInput`），点击清空当前文案并同步当前 `locale` 的 `translations` */
  showI18nClearIcon?: boolean
  /** 语义同 `i18nPrefixIcon`；未传且 `showI18nClearIcon` 时用内置 `DefaultI18nClearIcon` */
  i18nClearIcon?: string | Component
  /** 默认 false：仅在有输入内容时显示清除图标 */
  i18nClearIconAlwaysVisible?: boolean
  /** 默认 true；为 false 时仅展示图标，不触发内置清除逻辑 */
  i18nClearIconClickable?: boolean
  /**
   * 为 true 时使用包内 textarea 壳层作为唯一默认子节点（**无需也不应**再写默认插槽），
   * 自动处理多行与前/后缀图标的排版与垂直对齐；仍通过同一套 `prefixIcon` / `suffixIcon` 注入。
   */
  textarea?: boolean
  /** `textarea` 模式下传给内置 shell 的 `rows` */
  i18nTextareaRows?: number
  /** `textarea` 模式下传给内置 shell 的 `placeholder` */
  i18nTextareaPlaceholder?: string
}

export interface I18nFieldWrapRenderOptions {
  onTranslationsPatch: (next: I18nFieldTranslations) => void
  onI18nPrefixClick?: () => void
  /** 清除时同步清空 `i18nCode`（如 `emit('update:i18nCode', '')`） */
  onI18nCodeClear?: () => void
  /** 内置清除完成后回调（如 `emit('i18nClearClick')`） */
  onI18nClearClick?: () => void
}

function buildPrefixExtraInjected(
  props: I18nFieldWrapBindProps,
  onI18nPrefixClick?: () => void,
): Record<string, unknown> | undefined {
  if (!props.showI18nPrefixIcon) {
    return undefined
  }

  const raw: string | Component = props.i18nPrefixIcon ?? DefaultI18nPrefixIcon
  const clickable
    = props.i18nPrefixIconClickable !== false && onI18nPrefixClick != null

  const prefixIcon: string | Component = clickable
    ? wrapI18nPrefixIconForClick(raw, onI18nPrefixClick)
    : raw

  return { prefixIcon }
}

function buildClearSuffixExtraInjected(
  props: I18nFieldWrapBindProps,
  displayText: Ref<string>,
  onClear: () => void,
): Record<string, unknown> | undefined {
  if (!props.showI18nClearIcon) {
    return undefined
  }

  const hasText = toBoundString(displayText.value).trim() !== ''
  if (!props.i18nClearIconAlwaysVisible && !hasText) {
    return undefined
  }

  const raw: string | Component = props.i18nClearIcon ?? DefaultI18nClearIcon
  const clickable = props.i18nClearIconClickable !== false

  const suffixIcon: string | Component = clickable
    ? wrapI18nClearIconForClick(raw, onClear)
    : raw

  return { suffixIcon }
}

function mergeExtraInjected(
  ...parts: (Record<string, unknown> | undefined)[]
): Record<string, unknown> | undefined {
  const merged: Record<string, unknown> = {}
  for (const p of parts) {
    if (p == null) {
      continue
    }
    Object.assign(merged, p)
  }
  return Object.keys(merged).length > 0 ? merged : undefined
}

export function useI18nFieldWrapRender(
  props: I18nFieldWrapBindProps,
  options: I18nFieldWrapRenderOptions,
  slots: Slots,
): () => VNode | null {
  const attrs = useAttrs()
  const displayText = useModel(props, 'modelValue') as Ref<string>

  return () => {
    const raw
      = props.textarea === true
        ? [
            h(I18nFieldTextareaShell, {
              rows: props.i18nTextareaRows ?? 4,
              placeholder: props.i18nTextareaPlaceholder ?? '',
            }),
          ]
        : (slots.default?.() ?? [])

    const onClear = () => {
      displayText.value = ''
      const loc = props.locale.trim()
      if (loc !== '' && props.translations !== undefined) {
        options.onTranslationsPatch({ ...props.translations, [loc]: '' })
      }
      options.onI18nCodeClear?.()
      options.onI18nClearClick?.()
    }

    const extraInjected = mergeExtraInjected(
      buildPrefixExtraInjected(props, options.onI18nPrefixClick),
      buildClearSuffixExtraInjected(props, displayText, onClear),
    )

    const list = injectModelIntoDefaultSlot(raw, {
      attrs: attrs as Record<string, unknown>,
      getModelValue: () => displayText.value,
      onModelValueUpdate: (v: unknown) => {
        const s = toBoundString(v)
        displayText.value = s
        const loc = props.locale.trim()

        if (loc !== '' && props.translations !== undefined) {
          options.onTranslationsPatch({ ...props.translations, [loc]: s })
        }
      },
      extraInjected,
    })

    return normalizeInjectedSlotRoots(list)
  }
}
