import type { Component, VNode } from 'vue'
import { h } from 'vue'

/**
 * 将 `i18nPrefixIcon` / `i18nClearIcon` 的 `string | Component` 落成 VNode。
 *
 * - **Component**：直接 `h(icon)`（适合 `vite-svg-loader`、SVG 作为 SFC、或 `?component` 导入的组件）。
 * - **string**：默认当作 **CSS class** 用在 `<i class>`（图标字体等）。
 * - **string 且像 SVG 资源**（`*.svg` URL、`data:image/svg…`）：用 `<img src>`（适合 Vite 默认 `import url from './x.svg'`）。
 */
function isLikelySvgAssetRef(s: string): boolean {
  const t = s.trim()
  if (t.startsWith('data:image/svg')) {
    return true
  }
  if (/^https?:\/\//i.test(t)) {
    return /\.svg(\?|#|$)/i.test(t)
  }
  return /\.svg(\?|#|$)/i.test(t)
}

export function renderIconNode(icon: string | Component): VNode {
  if (typeof icon === 'string') {
    if (isLikelySvgAssetRef(icon)) {
      return h('img', {
        src: icon,
        alt: '',
        'aria-hidden': true,
        draggable: false,
        style: {
          display: 'block',
          width: '1em',
          height: '1em',
          objectFit: 'contain',
        },
      })
    }

    return h('i', { 'class': icon, 'aria-hidden': true })
  }

  return h(icon)
}
