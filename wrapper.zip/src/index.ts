import type { ComputedRef, MaybeRefOrGetter } from 'vue'

import type { TranslateFn } from './i18n-context'
import type { I18nFieldTranslations } from './i18nFieldTypes'

import { helloI18n } from '@supernova/i18n'
import { computed, toValue } from 'vue'
import {
  I18N_TRANSLATE_KEY,
  provideI18nTranslate,
  useI18nTranslate,
} from './i18n-context'
import I18nFieldWrap from './I18nFieldWrap'
import I18nFieldWrapSfc from './I18nFieldWrapSfc.vue'
import { DefaultI18nClearIcon, wrapI18nClearIconForClick } from './i18nClearIcon'
import { DefaultI18nPrefixIcon, wrapI18nPrefixIconForClick } from './i18nPrefixIcon'

/** 由构建打入本包，使用方无需再安装 `@supernova/i18n`。 */
export { helloI18n }

export {
  DefaultI18nClearIcon,
  DefaultI18nPrefixIcon,
  I18N_TRANSLATE_KEY,
  I18nFieldWrap,
  I18nFieldWrapSfc,
  provideI18nTranslate,
  useI18nTranslate,
  wrapI18nClearIconForClick,
  wrapI18nPrefixIconForClick,
}
export type { I18nFieldTranslations, TranslateFn }
export {
  injectModelIntoDefaultSlot,
  normalizeInjectedSlotRoots,
  toBoundString,
} from './slotModelInject'
export type { SlotModelBindingInput } from './slotModelInject'
export type { I18nFieldWrapBindProps, I18nFieldWrapRenderOptions } from './useI18nFieldWrap'

/**
 * Vue 3 示例：基于核心 `@supernova/i18n` 的 composable（可按项目替换为真实 i18n）。
 * `locale` 支持 ref、getter 或普通字符串（与 `toValue` 语义一致）。
 */
export function useHelloI18n(locale: MaybeRefOrGetter<string>): ComputedRef<string> {
  return computed(() => {
    return helloI18n(toValue(locale))
  })
}
