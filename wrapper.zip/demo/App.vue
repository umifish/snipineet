<script setup lang="ts">
import type { I18nFieldTranslations } from '@supernova/i18n-vue'
import { ref, watch } from 'vue'

import { I18nFieldWrapSfc } from '@supernova/i18n-vue'
import InputWithIcons from './InputWithIcons.vue'

const locale = ref('zh-CN')
const locales = ['zh-CN', 'en-US'] as const

const translations = ref<I18nFieldTranslations>({
  'zh-CN': '你好，国际化',
  'en-US': 'Hello, i18n',
})

const display = ref('')
const textareaDisplay = ref('')
const textareaTranslations = ref<I18nFieldTranslations>({
  'zh-CN': '这里是多行文案。\n你可以点击右上角清除图标。',
  'en-US': 'This is multiline content.\nClick the clear icon in top-right.',
})

watch(
  locale,
  (loc) => {
    const t = translations.value
    display.value = t[loc] != null ? String(t[loc]) : ''
    const tt = textareaTranslations.value
    textareaDisplay.value = tt[loc] != null ? String(tt[loc]) : ''
  },
  { immediate: true },
)

const lastEvent = ref<string>('（点击前缀 / 后缀试试）')

function onPrefixClick() {
  lastEvent.value = `i18nPrefixClick · locale=${locale.value}`
}

function onClearClick() {
  lastEvent.value = `i18nClearClick · locale=${locale.value}`
}

function onTextareaPrefixClick() {
  lastEvent.value = `textarea i18nPrefixClick · locale=${locale.value}`
}

function onTextareaClearClick() {
  lastEvent.value = `textarea i18nClearClick · locale=${locale.value}`
}
</script>

<template>
  <div class="page">
    <h1 class="title">
      @supernova/i18n-vue · Demo
    </h1>
    <p class="lead">
      前缀图标、后缀清除；切换语言会按「当前 <code>translations[locale]</code>」切换输入框展示。清除会清空文案并写入当前语言的空串。
      多行场景设 <code>textarea</code>，由包内壳层处理前后缀与换行对齐，无需自写布局。
    </p>

    <section class="card">
      <h2>语言</h2>
      <div class="row">
        <button
          v-for="loc in locales"
          :key="loc"
          type="button"
          class="chip"
          :class="{ 'chip--active': locale === loc }"
          @click="locale = loc"
        >
          {{ loc }}
        </button>
      </div>
    </section>

    <section class="card">
      <h2>包裹输入</h2>
      <I18nFieldWrapSfc
        v-model="display"
        v-model:translations="translations"
        :locale="locale"
        show-i18n-prefix-icon
        show-i18n-clear-icon
        @i18n-prefix-click="onPrefixClick"
        @i18n-clear-click="onClearClick"
      >
        <InputWithIcons />
      </I18nFieldWrapSfc>
      <p class="hint">
        事件：<strong>{{ lastEvent }}</strong>
      </p>
    </section>

    <section class="card">
      <h2>内置 textarea（<code>textarea</code>）</h2>
      <div class="textarea-chrome">
        <I18nFieldWrapSfc
          v-model="textareaDisplay"
          v-model:translations="textareaTranslations"
          :locale="locale"
          textarea
          :i18n-textarea-rows="4"
          i18n-textarea-placeholder="输入多行文案…"
          show-i18n-prefix-icon
          show-i18n-clear-icon
          @i18n-prefix-click="onTextareaPrefixClick"
          @i18n-clear-click="onTextareaClearClick"
        />
      </div>
    </section>

    <section class="card">
      <h2><code>modelValue</code>（当前语言文案）</h2>
      <pre class="pre">{{ display || '（空）' }}</pre>
    </section>

    <section class="card">
      <h2><code>textarea modelValue</code>（当前语言文案）</h2>
      <pre class="pre">{{ textareaDisplay || '（空）' }}</pre>
    </section>

    <section class="card">
      <h2><code>translations</code></h2>
      <pre class="pre">{{ JSON.stringify(translations, null, 2) }}</pre>
    </section>

    <section class="card">
      <h2><code>textareaTranslations</code></h2>
      <pre class="pre">{{ JSON.stringify(textareaTranslations, null, 2) }}</pre>
    </section>
  </div>
</template>

<style scoped>
.page {
  max-width: 640px;
  margin: 0 auto;
  padding: 2rem 1.25rem 3rem;
  font-family: ui-sans-serif, system-ui, sans-serif;
  color: #1d2129;
}

.title {
  margin: 0 0 0.5rem;
  font-size: 1.5rem;
  font-weight: 650;
}

.lead {
  margin: 0 0 1.5rem;
  font-size: 14px;
  line-height: 1.6;
  color: #4e5969;
}

.lead code {
  font-size: 0.9em;
  padding: 0.1em 0.35em;
  border-radius: 4px;
  background: #f2f3f5;
}

.card {
  margin-bottom: 1.25rem;
  padding: 1rem 1.1rem;
  border: 1px solid #e5e6eb;
  border-radius: 8px;
  background: #fafafa;
}

.card h2 {
  margin: 0 0 0.75rem;
  font-size: 13px;
  font-weight: 600;
  color: #86909c;
  text-transform: uppercase;
  letter-spacing: 0.02em;
}

.row {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.chip {
  padding: 0.35rem 0.75rem;
  border: 1px solid #c9cdd4;
  border-radius: 999px;
  background: #fff;
  font: inherit;
  font-size: 13px;
  cursor: pointer;
  color: #1d2129;
}

.chip:hover {
  border-color: #86909c;
}

.chip--active {
  border-color: #165dff;
  background: #e8f3ff;
  color: #165dff;
}

.hint {
  margin: 0.75rem 0 0;
  font-size: 13px;
  color: #4e5969;
}

.pre {
  margin: 0;
  padding: 0.75rem;
  overflow: auto;
  border-radius: 6px;
  background: #1d2129;
  color: #e8f4ff;
  font-size: 12px;
  line-height: 1.5;
}

.textarea-chrome {
  border: 1px solid #c9cdd4;
  border-radius: 6px;
  background: #fff;
  padding: 0.35rem 0.5rem 0.45rem;
}
</style>
