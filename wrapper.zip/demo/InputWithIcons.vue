<script setup lang="ts">
import type { Component } from 'vue'

/**
 * 最小「类 ElInput」占位：支持通过 props 注入的 `prefixIcon` / `suffixIcon`（与 EP 用法一致），
 * 无需安装 element-plus 即可查看 I18nFieldWrap 的注入效果。
 */
defineOptions({ name: 'DemoInputWithIcons' })

const modelValue = defineModel<string>({ default: '' })

defineProps<{
  prefixIcon?: string | Component
  suffixIcon?: string | Component
}>()

function onInput(e: Event) {
  modelValue.value = (e.target as HTMLInputElement).value
}
</script>

<template>
  <div class="demo-input">
    <span v-if="$props.prefixIcon != null" class="demo-input__adorn demo-input__prefix">
      <i v-if="typeof $props.prefixIcon === 'string'" :class="$props.prefixIcon" aria-hidden="true" />
      <component :is="$props.prefixIcon" v-else />
    </span>
    <input
      class="demo-input__control"
      type="text"
      :value="modelValue"
      placeholder="输入文案…"
      @input="onInput"
    >
    <span v-if="$props.suffixIcon != null" class="demo-input__adorn demo-input__suffix">
      <i v-if="typeof $props.suffixIcon === 'string'" :class="$props.suffixIcon" aria-hidden="true" />
      <component :is="$props.suffixIcon" v-else />
    </span>
  </div>
</template>

<style scoped>
.demo-input {
  display: inline-flex;
  align-items: center;
  gap: 0.35rem;
  min-width: 280px;
  max-width: 100%;
  padding: 0.2rem 0.5rem;
  border: 1px solid #c9cdd4;
  border-radius: 6px;
  background: #fff;
}

.demo-input__control {
  flex: 1;
  min-width: 0;
  padding: 0.35rem 0.25rem;
  border: none;
  outline: none;
  font: inherit;
  font-size: 14px;
  line-height: 1.5;
  color: #1d2129;
}

.demo-input__adorn {
  display: inline-flex;
  align-items: center;
  flex-shrink: 0;
  color: #4e5969;
}

.demo-input__adorn :deep(svg) {
  display: block;
}
</style>
