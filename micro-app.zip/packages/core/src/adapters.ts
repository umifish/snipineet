import {
  normalizePath,
  normalizeRoute,
  type RouteSnapshot
} from "./lifecycle";

export type AdapterKind = "vue2" | "vue3" | "react18" | "react19";

export interface AdapterOptions {
  appName: string;
  basePath: string;
}

export interface FrameworkAdapter {
  kind: AdapterKind;
  normalizeIncomingRoute: (route: RouteSnapshot) => RouteSnapshot;
  toHostPath: (childPath: string, basePath: string) => string;
  mount: (context: AdapterMountContext) => void | Promise<void>;
  update: (context: AdapterUpdateContext) => void | Promise<void>;
  unmount: () => void;
  isMounted: () => boolean;
}

export interface AdapterMountContext {
  container: Element;
  routeBase: string;
  props?: Record<string, unknown>;
}

export interface AdapterUpdateContext {
  routeBase?: string;
  props?: Record<string, unknown>;
}

export interface AdapterRenderPayload {
  routeBase: string;
  props: Record<string, unknown>;
}

export interface AdapterRuntimeHandle {
  update?: (payload: AdapterRenderPayload) => void;
  unmount: () => void;
}

export type AdapterRenderer = (
  container: Element,
  payload: AdapterRenderPayload
) => AdapterRuntimeHandle;

export interface Vue3AppLike {
  mount: (container: Element | string) => unknown;
  unmount: () => void;
}

export type Vue3CreateApp = (
  rootComponent: unknown,
  rootProps?: Record<string, unknown>
) => Vue3AppLike;

export interface Vue2InstanceLike {
  $mount: (container: Element | string) => void;
  $destroy: () => void;
  $forceUpdate?: () => void;
}

export type Vue2InstanceFactory = (
  payload: AdapterRenderPayload
) => Vue2InstanceLike;

function createAdapter(kind: AdapterKind): FrameworkAdapter {
  let mounted = false;

  return {
    kind,
    normalizeIncomingRoute: (route) => normalizeRoute(route),
    toHostPath: (childPath, basePath) =>
      normalizePath(`${normalizePath(basePath)}/${normalizePath(childPath).slice(1)}`),
    mount: () => {
      mounted = true;
    },
    update: () => {
      return;
    },
    unmount: () => {
      mounted = false;
    },
    isMounted: () => mounted
  };
}

function createRuntimeAdapter(kind: AdapterKind, renderer: AdapterRenderer): FrameworkAdapter {
  let mounted = false;
  let handle: AdapterRuntimeHandle | null = null;
  let lastPayload: AdapterRenderPayload | null = null;

  const toPayload = (
    routeBase: string,
    props?: Record<string, unknown>
  ): AdapterRenderPayload => ({
    routeBase: normalizePath(routeBase),
    props: props ?? {}
  });

  return {
    kind,
    normalizeIncomingRoute: (route) => normalizeRoute(route),
    toHostPath: (childPath, basePath) =>
      normalizePath(`${normalizePath(basePath)}/${normalizePath(childPath).slice(1)}`),
    mount: (context) => {
      const payload = toPayload(context.routeBase, context.props);
      handle = renderer(context.container, payload);
      lastPayload = payload;
      mounted = true;
    },
    update: (context) => {
      if (!mounted || !handle) {
        return;
      }
      const payload = toPayload(context.routeBase ?? lastPayload?.routeBase ?? "/", {
        ...(lastPayload?.props ?? {}),
        ...(context.props ?? {})
      });
      lastPayload = payload;
      handle.update?.(payload);
    },
    unmount: () => {
      if (!mounted || !handle) {
        return;
      }
      handle.unmount();
      handle = null;
      mounted = false;
      lastPayload = null;
    },
    isMounted: () => mounted
  };
}

export function createReact18Adapter(renderer: AdapterRenderer): FrameworkAdapter {
  return createRuntimeAdapter("react18", renderer);
}

export function createReact19Adapter(renderer: AdapterRenderer): FrameworkAdapter {
  return createRuntimeAdapter("react19", renderer);
}

export function createVue3Adapter(options: {
  createApp: Vue3CreateApp;
  rootComponent: unknown;
}): FrameworkAdapter {
  return createRuntimeAdapter("vue3", (container, payload) => {
    const app = options.createApp(options.rootComponent, {
      routeBase: payload.routeBase,
      ...payload.props
    });
    app.mount(container);

    return {
      unmount: () => {
        app.unmount();
      }
    };
  });
}

export function createVue2Adapter(options: {
  createInstance: Vue2InstanceFactory;
}): FrameworkAdapter {
  return createRuntimeAdapter("vue2", (container, payload) => {
    const vm = options.createInstance(payload);
    vm.$mount(container);

    return {
      update: () => {
        vm.$forceUpdate?.();
      },
      unmount: () => {
        vm.$destroy();
      }
    };
  });
}

export const vue2Adapter = createAdapter("vue2");
export const vue3Adapter = createAdapter("vue3");
export const react18Adapter = createAdapter("react18");
export const react19Adapter = createAdapter("react19");

export const frameworkAdapters: Record<AdapterKind, FrameworkAdapter> = {
  vue2: vue2Adapter,
  vue3: vue3Adapter,
  react18: react18Adapter,
  react19: react19Adapter
};
