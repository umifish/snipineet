export type LifecyclePhase = "bootstrap" | "mount" | "update" | "unmount" | "error";

export interface LifecycleContext {
  appName: string;
  container?: Element;
  props?: Record<string, unknown>;
  routeBase?: string;
}

export interface LifecycleHooks {
  bootstrap?: (context: LifecycleContext) => Promise<void> | void;
  mount: (context: LifecycleContext) => Promise<void> | void;
  update?: (context: LifecycleContext) => Promise<void> | void;
  unmount: (context: LifecycleContext) => Promise<void> | void;
}

export type NavigateAction = "push" | "replace" | "back";

export interface RouteSnapshot {
  path: string;
  params: Record<string, string>;
  query: Record<string, string>;
}

export interface RouteNavigationCommand {
  action: NavigateAction;
  route?: RouteSnapshot;
}

export function normalizePath(path: string): string {
  const normalized = path.trim().replace(/\/+/g, "/");
  if (!normalized.startsWith("/")) {
    return `/${normalized}`.replace(/\/+/g, "/");
  }
  return normalized.replace(/\/+/g, "/");
}

export function serializeQuery(query: Record<string, string>): string {
  const entries = Object.entries(query).filter(([, value]) => value.length > 0);
  if (entries.length === 0) {
    return "";
  }
  return `?${entries
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
    .join("&")}`;
}

export function parseQuery(queryString: string): Record<string, string> {
  const input = queryString.startsWith("?") ? queryString.slice(1) : queryString;
  if (!input) {
    return {};
  }
  const result: Record<string, string> = {};
  for (const pair of input.split("&")) {
    const [rawKey, rawValue = ""] = pair.split("=");
    if (!rawKey) {
      continue;
    }
    result[decodeURIComponent(rawKey)] = decodeURIComponent(rawValue);
  }
  return result;
}

export function normalizeRoute(route: RouteSnapshot): RouteSnapshot {
  const normalizedQueryEntries: Array<[string, string]> = Object.entries(route.query)
    .map(([key, value]): [string, string] => [key, String(value)])
    .sort(([a], [b]) => a.localeCompare(b));

  return {
    path: normalizePath(route.path),
    params: route.params,
    query: Object.fromEntries(normalizedQueryEntries)
  };
}

export function createLifecycleContract(hooks: LifecycleHooks): LifecycleHooks {
  return {
    bootstrap: hooks.bootstrap,
    mount: hooks.mount,
    update: hooks.update,
    unmount: hooks.unmount
  };
}
