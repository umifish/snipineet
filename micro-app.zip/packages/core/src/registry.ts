export type FrameworkKind = "vue2" | "vue3" | "react18" | "react19" | "unknown";

export type PreloadMode = "critical" | "idle" | "intent" | "manual";

export interface PreloadPolicy {
  mode: PreloadMode;
  priority?: number;
  timeoutMs?: number;
  retries?: number;
  intentSelectors?: string[];
}

export type PrimitiveSchema = "string" | "number" | "boolean";

export interface RouteManifest {
  name: string;
  path: string;
  paramsSchema?: Record<string, PrimitiveSchema>;
  querySchema?: Record<string, PrimitiveSchema>;
  meta?: Record<string, unknown>;
  redirectTo?: string;
}

export interface AppManifest {
  name: string;
  framework: FrameworkKind;
  entry: string;
  version?: string;
  wujie?: {
    alive?: boolean;
    degrade?: boolean;
    sync?: boolean;
    routePrefix?: Record<string, string>;
    /** 挂载前对入口做可达性预检（用于区分 404 / 网络错误 / 超时）。 */
    preflight?: boolean;
    /** 挂载（含预检）整体超时时间，超过判定为 timeout 降级。 */
    mountTimeoutMs?: number;
  };
  preload?: PreloadPolicy[];
  routes?: RouteManifest[];
  loader?: () => Promise<unknown>;
}

export interface AppRegistry {
  register(app: AppManifest): void;
  registerMany(apps: AppManifest[]): void;
  getByName(name: string): AppManifest | undefined;
  list(): AppManifest[];
}

export const PRELOAD_MODES: ReadonlyArray<PreloadMode> = [
  "critical",
  "idle",
  "intent",
  "manual"
];

export function isPreloadMode(input: string): input is PreloadMode {
  return PRELOAD_MODES.includes(input as PreloadMode);
}

export class InMemoryAppRegistry implements AppRegistry {
  private readonly map = new Map<string, AppManifest>();

  register(app: AppManifest): void {
    this.map.set(app.name, app);
  }

  registerMany(apps: AppManifest[]): void {
    for (const app of apps) {
      this.register(app);
    }
  }

  getByName(name: string): AppManifest | undefined {
    return this.map.get(name);
  }

  list(): AppManifest[] {
    return Array.from(this.map.values()).sort((a, b) => a.name.localeCompare(b.name));
  }
}

export function createAppRegistry(seed: AppManifest[] = []): AppRegistry {
  const registry = new InMemoryAppRegistry();
  registry.registerMany(seed);
  return registry;
}
