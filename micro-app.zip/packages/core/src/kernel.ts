import type { Bridge, BridgeEventMap } from "./bridge";
import type {
  AppManifest,
  AppRegistry,
  PreloadMode,
  PreloadPolicy
} from "./registry";
import { destroyApp, preloadApp, setupApp, startApp } from "wujie";

export interface PreloadState {
  appName: string;
  mode: PreloadMode;
  status: "idle" | "running" | "success" | "error";
  startedAt?: number;
  finishedAt?: number;
  attempts: number;
  error?: string;
}

export interface PreloadManager {
  preloadApp(appName: string, mode: PreloadMode): Promise<void>;
  preloadApps(mode: PreloadMode): Promise<void>;
  cancelPreload(appName: string): void;
  getPreloadState(appName: string): PreloadState | undefined;
}

export interface CreatePreloadManagerOptions {
  registry: AppRegistry;
  bridge?: Bridge<BridgeEventMap>;
  maxConcurrency?: number;
}

export interface MountAppOptions {
  appName: string;
  el: HTMLElement | string;
  props?: Record<string, unknown>;
  loading?: HTMLElement;
}

export interface WujieHostRuntime {
  mountApp(options: MountAppOptions): Promise<void>;
  unmountApp(appName: string): void;
  preloadByWujie(appName: string, exec?: boolean): void;
}

export interface CreateWujieHostRuntimeOptions {
  registry: AppRegistry;
  bridge?: Bridge<BridgeEventMap>;
}

interface InternalTask {
  app: AppManifest;
  mode: PreloadMode;
  policy: PreloadPolicy;
}

class InMemoryPreloadManager implements PreloadManager {
  private readonly registry: AppRegistry;
  private readonly bridge?: Bridge<BridgeEventMap>;
  private readonly maxConcurrency: number;
  private readonly queue: InternalTask[] = [];
  private readonly running = new Set<string>();
  private readonly state = new Map<string, PreloadState>();
  private readonly cache = new Map<string, Promise<unknown>>();

  constructor(options: CreatePreloadManagerOptions) {
    this.registry = options.registry;
    this.bridge = options.bridge;
    this.maxConcurrency = Math.max(1, options.maxConcurrency ?? 3);
  }

  async preloadApps(mode: PreloadMode): Promise<void> {
    const apps = this.registry.list();
    const tasks = apps
      .flatMap((app) =>
        (app.preload ?? [])
          .filter((policy) => policy.mode === mode)
          .map((policy) => ({ app, mode, policy }))
      )
      .sort((a, b) => (b.policy.priority ?? 0) - (a.policy.priority ?? 0));

    if (mode === "idle") {
      await this.enqueueIdleTasks(tasks);
      return;
    }

    await this.enqueueTasks(tasks);
  }

  async preloadApp(appName: string, mode: PreloadMode): Promise<void> {
    const app = this.registry.getByName(appName);
    if (!app) {
      return;
    }
    const policy = this.pickPolicy(app, mode);
    if (!policy) {
      return;
    }
    await this.enqueueTasks([{ app, mode, policy }]);
  }

  cancelPreload(appName: string): void {
    const index = this.queue.findIndex((task) => task.app.name === appName);
    if (index >= 0) {
      this.queue.splice(index, 1);
      this.state.set(appName, {
        appName,
        mode: "manual",
        status: "idle",
        attempts: 0
      });
    }
  }

  getPreloadState(appName: string): PreloadState | undefined {
    return this.state.get(appName);
  }

  private async enqueueIdleTasks(tasks: InternalTask[]): Promise<void> {
    const hasRequestIdleCallback =
      typeof globalThis === "object" && "requestIdleCallback" in globalThis;

    if (hasRequestIdleCallback) {
      await new Promise<void>((resolve) => {
        (globalThis as unknown as { requestIdleCallback: (fn: () => void) => number }).requestIdleCallback(
          async () => {
            await this.enqueueTasks(tasks);
            resolve();
          }
        );
      });
      return;
    }

    await new Promise<void>((resolve) => {
      setTimeout(async () => {
        await this.enqueueTasks(tasks);
        resolve();
      }, 32);
    });
  }

  private async enqueueTasks(tasks: InternalTask[]): Promise<void> {
    this.queue.push(...tasks);
    const workers = Array.from({ length: this.maxConcurrency }, () => this.worker());
    await Promise.all(workers);
  }

  private async worker(): Promise<void> {
    while (this.queue.length > 0) {
      const task = this.queue.shift();
      if (!task) {
        return;
      }
      if (this.running.has(task.app.name)) {
        continue;
      }
      this.running.add(task.app.name);
      try {
        await this.runTask(task);
      } finally {
        this.running.delete(task.app.name);
      }
    }
  }

  private async runTask(task: InternalTask): Promise<void> {
    const { app, mode, policy } = task;
    const startAt = Date.now();
    const current = this.state.get(app.name);
    const attempts = (current?.attempts ?? 0) + 1;

    this.state.set(app.name, {
      appName: app.name,
      mode,
      status: "running",
      startedAt: startAt,
      attempts
    });

    this.bridge?.emit("preload:start", { appName: app.name, mode });

    try {
      const taskPromise = this.ensureLoaded(app);
      await this.withTimeout(taskPromise, policy.timeoutMs ?? 5000);
      const finishedAt = Date.now();
      this.state.set(app.name, {
        appName: app.name,
        mode,
        status: "success",
        startedAt: startAt,
        finishedAt,
        attempts
      });
      this.bridge?.emit("preload:success", {
        appName: app.name,
        mode,
        durationMs: finishedAt - startAt
      });
    } catch (error) {
      const maxRetries = policy.retries ?? 0;
      const message = error instanceof Error ? error.message : "unknown preload failure";

      this.state.set(app.name, {
        appName: app.name,
        mode,
        status: "error",
        startedAt: startAt,
        finishedAt: Date.now(),
        attempts,
        error: message
      });

      this.bridge?.emit("preload:error", {
        appName: app.name,
        mode,
        message
      });

      if (attempts <= maxRetries) {
        this.queue.push({ app, mode, policy });
      }
    }
  }

  private ensureLoaded(app: AppManifest): Promise<unknown> {
    const cached = this.cache.get(app.name);
    if (cached) {
      return cached;
    }

    const promise = app.loader
      ? app.loader()
      : Promise.resolve(
          preloadApp({
            name: app.name,
            url: app.entry,
            exec: false,
            alive: app.wujie?.alive,
            degrade: app.wujie?.degrade
          })
        );
    this.cache.set(app.name, promise);
    return promise;
  }

  private async withTimeout<T>(task: Promise<T>, timeoutMs: number): Promise<T> {
    let timeoutHandle: ReturnType<typeof setTimeout> | undefined;

    const timeout = new Promise<T>((_, reject) => {
      timeoutHandle = setTimeout(() => {
        reject(new Error(`preload timeout after ${timeoutMs}ms`));
      }, timeoutMs);
    });

    try {
      return await Promise.race([task, timeout]);
    } finally {
      if (timeoutHandle) {
        clearTimeout(timeoutHandle);
      }
    }
  }

  private pickPolicy(app: AppManifest, mode: PreloadMode): PreloadPolicy | undefined {
    return app.preload?.find((policy) => policy.mode === mode);
  }
}

export function createPreloadManager(
  options: CreatePreloadManagerOptions
): PreloadManager {
  return new InMemoryPreloadManager(options);
}

export type MountFaultReason = "timeout" | "resource-404" | "network" | "unknown";

export class MountError extends Error {
  readonly reason: MountFaultReason;

  constructor(message: string, reason: MountFaultReason) {
    super(message);
    this.name = "MountError";
    this.reason = reason;
  }
}

class InMemoryWujieHostRuntime implements WujieHostRuntime {
  private readonly registry: AppRegistry;
  private readonly bridge?: Bridge<BridgeEventMap>;
  private readonly mountedApps = new Set<string>();

  constructor(options: CreateWujieHostRuntimeOptions) {
    this.registry = options.registry;
    this.bridge = options.bridge;
  }

  async mountApp(options: MountAppOptions): Promise<void> {
    const app = this.registry.getByName(options.appName);
    if (!app) {
      throw new Error(`unknown app: ${options.appName}`);
    }

    this.bridge?.emit("wujie:mount:start", { appName: app.name, url: app.entry });
    const startAt = Date.now();
    const timeoutMs = app.wujie?.mountTimeoutMs;

    try {
      const mountTask = (async () => {
        if (app.wujie?.preflight) {
          await this.preflightEntry(app.entry, timeoutMs);
        }

        setupApp({
          name: app.name,
          url: app.entry,
          props: options.props,
          alive: app.wujie?.alive,
          degrade: app.wujie?.degrade,
          sync: app.wujie?.sync,
          prefix: app.wujie?.routePrefix
        });

        await startApp({
          name: app.name,
          url: app.entry,
          el: options.el,
          props: options.props,
          loading: options.loading,
          alive: app.wujie?.alive,
          degrade: app.wujie?.degrade,
          sync: app.wujie?.sync,
          prefix: app.wujie?.routePrefix
        });
      })();

      await this.withMountTimeout(mountTask, timeoutMs);
      this.mountedApps.add(app.name);

      this.bridge?.emit("wujie:mount:success", {
        appName: app.name,
        durationMs: Date.now() - startAt
      });
    } catch (error) {
      const mountError =
        error instanceof MountError
          ? error
          : new MountError(
              error instanceof Error ? error.message : "wujie mount failed",
              "unknown"
            );
      this.bridge?.emit("wujie:mount:error", {
        appName: app.name,
        message: mountError.message,
        reason: mountError.reason
      });
      throw mountError;
    }
  }

  private async preflightEntry(entry: string, timeoutMs?: number): Promise<void> {
    const timeoutSignal = timeoutMs && timeoutMs > 0 ? AbortSignal.timeout(timeoutMs) : undefined;

    let response: Response;
    try {
      response = await fetch(entry, { method: "GET", signal: timeoutSignal });
    } catch (error) {
      if (error instanceof DOMException && (error.name === "TimeoutError" || error.name === "AbortError")) {
        throw new MountError(`mount preflight timeout: ${entry}`, "timeout");
      }
      const detail = error instanceof Error ? error.message : "unknown";
      throw new MountError(`network error: ${detail} (${entry})`, "network");
    }

    if (response.status === 404) {
      throw new MountError(`resource 404: ${entry}`, "resource-404");
    }
    if (response.status >= 400) {
      throw new MountError(`resource ${response.status}: ${entry}`, "resource-404");
    }
  }

  private async withMountTimeout(task: Promise<void>, timeoutMs?: number): Promise<void> {
    if (!timeoutMs || timeoutMs <= 0) {
      await task;
      return;
    }

    let timer: ReturnType<typeof setTimeout> | undefined;
    const timeout = new Promise<never>((_, reject) => {
      timer = setTimeout(() => {
        reject(new MountError(`mount timeout after ${timeoutMs}ms`, "timeout"));
      }, timeoutMs);
    });

    try {
      await Promise.race([task, timeout]);
    } finally {
      if (timer) {
        clearTimeout(timer);
      }
    }
  }

  unmountApp(appName: string): void {
    if (!this.mountedApps.has(appName)) {
      return;
    }
    this.mountedApps.delete(appName);
    destroyApp(appName);
    this.bridge?.emit("wujie:unmount", { appName });
  }

  preloadByWujie(appName: string, exec = false): void {
    const app = this.registry.getByName(appName);
    if (!app) {
      return;
    }

    preloadApp({
      name: app.name,
      url: app.entry,
      exec,
      alive: app.wujie?.alive,
      degrade: app.wujie?.degrade
    });
  }
}

export function createWujieHostRuntime(
  options: CreateWujieHostRuntimeOptions
): WujieHostRuntime {
  return new InMemoryWujieHostRuntime(options);
}
