import type { Bridge } from "./bridge";

export interface DebugTimelineRecord {
  id: number;
  type: string;
  level: DebugLevel;
  appName?: string;
  timestamp: number;
  payload: unknown;
}

export type DebugLevel = "info" | "warn" | "error";

export interface DebugQueryOptions {
  keyword?: string;
  level?: DebugLevel | "all";
  appName?: string;
}

export interface DebugTimeline {
  records(): DebugTimelineRecord[];
  query(options?: DebugQueryOptions): DebugTimelineRecord[];
  clear(): void;
  exportJson(space?: number): string;
  stop(): void;
}

export interface CreateDebugTimelineOptions<TEvents extends object> {
  bridge: Bridge<TEvents>;
  eventTypes: Array<keyof TEvents>;
  maxRecords?: number;
  onRecord?: (records: DebugTimelineRecord[]) => void;
}

export function createDebugTimeline<TEvents extends object>(
  options: CreateDebugTimelineOptions<TEvents>
): DebugTimeline {
  const maxRecords = Math.max(20, options.maxRecords ?? 200);
  const rows: DebugTimelineRecord[] = [];
  const disposers: Array<() => void> = [];

  let nextId = 1;

  for (const type of options.eventTypes) {
    const dispose = options.bridge.on(type, (payload) => {
      const eventType = String(type);
      rows.unshift({
        id: nextId,
        type: eventType,
        level: inferDebugLevel(eventType),
        appName: inferAppName(payload),
        timestamp: Date.now(),
        payload
      });
      nextId += 1;
      if (rows.length > maxRecords) {
        rows.length = maxRecords;
      }
      options.onRecord?.(rows.slice());
    });

    disposers.push(dispose);
  }

  return {
    records() {
      return rows.slice();
    },
    query(query = {}) {
      const keyword = query.keyword?.trim().toLowerCase();
      const level = query.level ?? "all";
      const appName = query.appName?.trim();

      return rows.filter((row) => {
        if (level !== "all" && row.level !== level) {
          return false;
        }

        if (appName && row.appName !== appName) {
          return false;
        }

        if (!keyword) {
          return true;
        }

        const payloadText = JSON.stringify(row.payload ?? "").toLowerCase();
        return row.type.toLowerCase().includes(keyword) || payloadText.includes(keyword);
      });
    },
    clear() {
      rows.length = 0;
      options.onRecord?.(rows.slice());
    },
    exportJson(space = 2) {
      return JSON.stringify(rows, null, space);
    },
    stop() {
      for (const dispose of disposers) {
        dispose();
      }
      disposers.length = 0;
    }
  };
}

function inferDebugLevel(type: string): DebugLevel {
  if (type.includes("error") || type.includes(":fail")) {
    return "error";
  }
  if (type.includes("warn")) {
    return "warn";
  }
  return "info";
}

function inferAppName(payload: unknown): string | undefined {
  if (!payload || typeof payload !== "object") {
    return undefined;
  }

  const appName = (payload as { appName?: unknown }).appName;
  return typeof appName === "string" ? appName : undefined;
}
