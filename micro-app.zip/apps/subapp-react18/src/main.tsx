import React from "react";
import { createRoot, type Root } from "react-dom/client";
import { CheckoutApp } from "./CheckoutApp";

let root: Root | null = null;

function mount(props: Record<string, unknown> = {}): void {
  const container = document.getElementById("root");
  if (!container) {
    return;
  }
  root = createRoot(container);
  root.render(
    <React.StrictMode>
      <CheckoutApp
        source={(props.source as "host") ?? "standalone"}
        routeBase={(props.routeBase as string) ?? "/checkout"}
        hostProps={props}
      />
    </React.StrictMode>
  );
}

function unmount(): void {
  root?.unmount();
  root = null;
}

declare global {
  interface Window {
    __POWERED_BY_WUJIE__?: boolean;
    __WUJIE_MOUNT?: () => void;
    __WUJIE_UNMOUNT?: () => void;
    __WUJIE_UPDATE?: (props?: Record<string, unknown>) => void;
    __WUJIE?: { props?: Record<string, unknown> };
  }
}

if (window.__POWERED_BY_WUJIE__) {
  window.__WUJIE_MOUNT = () => {
    mount(window.__WUJIE?.props ?? {});
  };
  window.__WUJIE_UNMOUNT = () => {
    unmount();
  };
  window.__WUJIE_UPDATE = (props) => {
    unmount();
    mount(props ?? {});
  };
} else {
  mount({ source: "standalone" });
}
