import { createApp } from "vue";
import { MarketingApp } from "./MarketingApp";

type HostProps = Record<string, unknown>;

let vm: ReturnType<typeof createApp> | null = null;

function mount(props: HostProps = {}): void {
  const container = document.getElementById("root");
  if (!container) {
    return;
  }
  vm = createApp(MarketingApp, {
    source: (props.source as "host") ?? "standalone",
    routeBase: (props.routeBase as string) ?? "/campaign",
    hostProps: props
  });
  vm.mount(container);
}

function unmount(): void {
  vm?.unmount();
  vm = null;
}

declare global {
  interface Window {
    __POWERED_BY_WUJIE__?: boolean;
    __WUJIE_MOUNT?: () => void;
    __WUJIE_UNMOUNT?: () => void;
    __WUJIE_UPDATE?: (props?: Record<string, unknown>) => void;
    __WUJIE?: { props?: Record<string, unknown> };
  }
}

if (window.__POWERED_BY_WUJIE__) {
  window.__WUJIE_MOUNT = () => {
    mount(window.__WUJIE?.props ?? {});
  };
  window.__WUJIE_UNMOUNT = () => {
    unmount();
  };
  window.__WUJIE_UPDATE = (props) => {
    unmount();
    mount(props ?? {});
  };
} else {
  mount({ source: "standalone" });
}
