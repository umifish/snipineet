import { useEffect, useMemo, useRef, useState, type ReactElement } from "react";
import {
  createAppRegistry,
  createBridge,
  createDebugTimeline,
  createPreloadManager,
  createWujieHostRuntime,
  normalizePath,
  parseQuery,
  react18Adapter,
  react19Adapter,
  serializeQuery,
  vue2Adapter,
  vue3Adapter,
  type AppManifest,
  type AppRegistry,
  type BridgeEventMap,
  type DebugLevel,
  type DebugTimeline,
  type DebugTimelineRecord,
  type PreloadMode
} from "@micro-app/core";

const seedApps: AppManifest[] = [
  {
    name: "self-embed-react19",
    framework: "react19",
    entry: "http://localhost:5174/",
    wujie: {
      sync: true,
      alive: false,
      routePrefix: {
        "/self-embed": "/self-embed"
      }
    },
    preload: [
      { mode: "critical", priority: 100, timeoutMs: 3000, retries: 1 },
      { mode: "idle", priority: 70, timeoutMs: 5000 },
      { mode: "intent", priority: 90, timeoutMs: 3000 }
    ],
    routes: [{ name: "self-embed", path: "/self-embed" }]
  },
  {
    name: "checkout-react18",
    framework: "react18",
    entry: "http://localhost:5175/",
    wujie: {
      sync: true,
      alive: false
    },
    preload: [
      { mode: "critical", priority: 96, timeoutMs: 3000, retries: 1 },
      { mode: "intent", priority: 90, timeoutMs: 3000 },
      { mode: "manual", priority: 40, timeoutMs: 5000 }
    ],
    routes: [{ name: "checkout", path: "/checkout" }]
  },
  {
    name: "legacy-vue2-dashboard",
    framework: "vue2",
    entry: "http://localhost:5177/",
    wujie: {
      sync: true,
      alive: false
    },
    preload: [
      { mode: "critical", priority: 95, timeoutMs: 3000, retries: 1 },
      { mode: "intent", priority: 80, timeoutMs: 3000 }
    ],
    routes: [{ name: "dashboard", path: "/dashboard" }]
  },
  {
    name: "marketing-vue3",
    framework: "vue3",
    entry: "http://localhost:5176/",
    wujie: {
      sync: true,
      alive: false
    },
    preload: [
      { mode: "idle", priority: 60, timeoutMs: 5000 },
      { mode: "intent", priority: 80, timeoutMs: 3000 }
    ],
    routes: [{ name: "campaign", path: "/campaign" }]
  },
  {
    name: "broken-debug-app",
    framework: "unknown",
    entry: "http://localhost:5199/",
    wujie: {
      sync: true,
      alive: false
    },
    routes: [{ name: "broken", path: "/broken" }]
  },
  {
    // 故障注入：预加载超时（loader 永不结束，触发 preload timeout）
    name: "fault-timeout-app",
    framework: "unknown",
    entry: "http://localhost:5173/",
    wujie: { sync: true, alive: false },
    preload: [{ mode: "manual", priority: 10, timeoutMs: 200 }],
    loader: () => new Promise<never>(() => {})
  },
  {
    // 故障注入：资源 404（loader 直接拒绝，模拟入口资源缺失）
    name: "fault-404-app",
    framework: "unknown",
    entry: "http://localhost:5173/",
    wujie: { sync: true, alive: false },
    preload: [{ mode: "manual", priority: 10, timeoutMs: 3000 }],
    loader: () => Promise.reject(new Error("resource 404: subapp entry not found"))
  },
  {
    // 故障注入：网络错误（loader 拒绝，模拟连接被拒）
    name: "fault-network-app",
    framework: "unknown",
    entry: "http://localhost:5173/",
    wujie: { sync: true, alive: false },
    preload: [{ mode: "manual", priority: 10, timeoutMs: 3000 }],
    loader: () => Promise.reject(new Error("network error: ECONNREFUSED"))
  },
  {
    // 故障注入（挂载层）：挂载阶段超时（预检指向不可路由地址，AbortSignal.timeout 触发）
    name: "fault-mount-timeout-app",
    framework: "unknown",
    entry: "http://192.0.2.1:5999/",
    wujie: { sync: true, alive: false, preflight: true, mountTimeoutMs: 1200 }
  },
  {
    // 故障注入（挂载层）：资源 404（预检命中真实 404，区别于网络错误）
    name: "fault-mount-404-app",
    framework: "unknown",
    entry: "http://localhost:5175/node_modules/.vite/deps/__missing__.js",
    wujie: { sync: true, alive: false, preflight: true, mountTimeoutMs: 4000 }
  },
  {
    // 故障注入（挂载层）：网络错误（端口无监听，fetch 抛出 TypeError）
    name: "fault-mount-network-app",
    framework: "unknown",
    entry: "http://localhost:5199/",
    wujie: { sync: true, alive: false, preflight: true, mountTimeoutMs: 4000 }
  }
];

function createDependencies(): {
  registry: AppRegistry;
  bridge: ReturnType<typeof createBridge<BridgeEventMap>>;
} {
  const registry = createAppRegistry(seedApps);
  const bridge = createBridge<BridgeEventMap>();
  return { registry, bridge };
}

export function App(): ReactElement {
  const { registry, bridge } = useMemo(() => createDependencies(), []);
  const preloadManager = useMemo(
    () => createPreloadManager({ registry, bridge, maxConcurrency: 2 }),
    [registry, bridge]
  );
  const hostRuntime = useMemo(
    () => createWujieHostRuntime({ registry, bridge }),
    [registry, bridge]
  );

  const [debugRows, setDebugRows] = useState<DebugTimelineRecord[]>([]);
  const [debugKeyword, setDebugKeyword] = useState("");
  const [debugLevel, setDebugLevel] = useState<DebugLevel | "all">("all");
  const [debugAppFilter, setDebugAppFilter] = useState<string>("all");
  const [route, setRoute] = useState("/workspace/home");
  const [selectedApp, setSelectedApp] = useState(seedApps[0]?.name ?? "");
  const [mountedApp, setMountedApp] = useState<string | null>(null);
  const [mountError, setMountError] = useState<string | null>(null);
  const timelineRef = useRef<DebugTimeline | null>(null);

  useEffect(() => {
    const timeline = createDebugTimeline<BridgeEventMap>({
      bridge,
      eventTypes: [
        "preload:start",
        "preload:success",
        "preload:error",
        "wujie:mount:start",
        "wujie:mount:success",
        "wujie:mount:error",
        "wujie:unmount",
        "route:sync",
        "route:navigate"
      ],
      onRecord: (records) => {
        setDebugRows(records);
      }
    });

    timelineRef.current = timeline;

    void preloadManager.preloadApps("critical");
    void preloadManager.preloadApps("idle");

    return () => {
      timelineRef.current = null;
      timeline.stop();
    };
  }, [bridge, preloadManager]);

  useEffect(() => {
    const handlePopState = (event: PopStateEvent): void => {
      const state = event.state as { hostApp?: string | null } | null;
      const target = state && "hostApp" in state ? state.hostApp ?? null : appNameFromHash();
      void applyMountRef.current(target);
    };

    const initial = appNameFromHash();
    window.history.replaceState(
      { hostApp: initial },
      "",
      initial
        ? `#/app/${encodeURIComponent(initial)}`
        : `${window.location.pathname}${window.location.search}`
    );
    if (initial) {
      void applyMountRef.current(initial);
    }

    window.addEventListener("popstate", handlePopState);
    return () => {
      window.removeEventListener("popstate", handlePopState);
    };
  }, []);

  const filteredDebugRows = useMemo(() => {
    const timeline = timelineRef.current;
    if (!timeline) {
      return debugRows;
    }

    return timeline.query({
      keyword: debugKeyword,
      level: debugLevel,
      appName: debugAppFilter === "all" ? undefined : debugAppFilter
    });
  }, [debugRows, debugKeyword, debugLevel, debugAppFilter]);

  const normalizeRoutePreview = () => {
    const path = normalizePath(route);
    const query = parseQuery("?locale=zh-CN&tab=overview");
    return `${path}${serializeQuery(query)}`;
  };

  const preloadByIntent = async (appName: string, mode: PreloadMode) => {
    await preloadManager.preloadApp(appName, mode);
    hostRuntime.preloadByWujie(appName, false);
  };

  const mountedAppRef = useRef<string | null>(null);

  const applyMount = async (appName: string | null): Promise<void> => {
    const current = mountedAppRef.current;
    if (current === appName) {
      return;
    }

    setMountError(null);

    if (current) {
      hostRuntime.unmountApp(current);
      mountedAppRef.current = null;
      setMountedApp(null);
    }

    if (!appName) {
      return;
    }

    // 乐观占位：先标记目标，避免并发（如 StrictMode 双调用、深链初始化）重复挂载
    mountedAppRef.current = appName;

    try {
      await hostRuntime.mountApp({
        appName,
        el: "#wujie-mount-slot",
        props: {
          routeBase: normalizePath(route),
          debug: true,
          source: "host-shell"
        }
      });
      setMountedApp(appName);
      setSelectedApp(appName);
    } catch (error) {
      if (mountedAppRef.current === appName) {
        mountedAppRef.current = null;
      }
      setMountedApp(null);
      setMountError(error instanceof Error ? error.message : "mount failed");
    }
  };

  const applyMountRef = useRef(applyMount);
  applyMountRef.current = applyMount;

  const appNameFromHash = (): string | null => {
    const match = window.location.hash.match(/^#\/app\/(.+)$/);
    const raw = match?.[1];
    if (!raw) {
      return null;
    }
    const name = decodeURIComponent(raw);
    return registry.getByName(name) ? name : null;
  };

  const navigateToApp = (appName: string): void => {
    if (mountedAppRef.current === appName) {
      return;
    }
    window.history.pushState({ hostApp: appName }, "", `#/app/${encodeURIComponent(appName)}`);
    void applyMount(appName);
  };

  const navigateHome = (): void => {
    if (!mountedAppRef.current) {
      return;
    }
    window.history.pushState({ hostApp: null }, "", `${window.location.pathname}${window.location.search}`);
    void applyMount(null);
  };

  const goBack = (): void => {
    window.history.back();
  };

  const emitRouteSync = () => {
    const path = normalizePath(route);
    const query = parseQuery("?locale=zh-CN&tab=overview");
    bridge.emit("route:sync", { source: "host", path });
    bridge.emit("route:navigate", { appName: selectedApp, path, query });
  };

  const exportDebugJson = () => {
    const text = JSON.stringify(filteredDebugRows, null, 2);
    const blob = new Blob([text], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `micro-debug-${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const clearDebugTimeline = () => {
    timelineRef.current?.clear();
  };

  return (
    <main className="layout">
      <aside className="sidebar" data-testid="mount-nav">
        <h2>wujie 挂载调试</h2>
        <nav className="app-nav">
          {registry.list().map((app) => {
            const active = mountedApp === app.name;
            const focused = selectedApp === app.name;
            return (
              <button
                key={app.name}
                type="button"
                className={`app-nav-item${active ? " active" : ""}${focused ? " focused" : ""}`}
                onClick={() => {
                  setSelectedApp(app.name);
                  navigateToApp(app.name);
                }}
              >
                <span className="app-nav-dot" data-active={active} />
                <span className="app-nav-name">{app.name}</span>
              </button>
            );
          })}
        </nav>

        <div className="sidebar-controls">
          <select
            data-testid="mount-app-select"
            value={selectedApp}
            onChange={(event) => setSelectedApp(event.target.value)}
          >
            {registry.list().map((app) => (
              <option key={app.name} value={app.name}>
                {app.name}
              </option>
            ))}
          </select>
          <div className="row">
            <button data-testid="back-btn" type="button" onClick={goBack}>
              返回
            </button>
            <button data-testid="mount-btn" type="button" onClick={() => navigateToApp(selectedApp)}>
              挂载子应用
            </button>
            <button data-testid="unmount-btn" type="button" onClick={navigateHome}>
              卸载子应用
            </button>
          </div>
          <p>当前挂载: {mountedApp ?? "无"}</p>
          {mountError ? (
            <p data-testid="mount-error" className="error">
              挂载失败: {mountError}
            </p>
          ) : null}
        </div>
      </aside>

      <div className="content">
        <header>
          <h1>Host Shell · React 19</h1>
          <p>已接入预加载、路由一致性与类型导出最小实现。</p>
        </header>

        <section className="card">
          <h2>子应用预加载</h2>
          <div className="row">
            {registry.list().map((app) => (
              <button
                key={app.name}
                type="button"
                onMouseEnter={() => void preloadByIntent(app.name, "intent")}
                onClick={() => void preloadByIntent(app.name, "manual")}
              >
                预热 {app.name}
              </button>
            ))}
          </div>
          <ul>
            {registry.list().map((app) => {
              const state = preloadManager.getPreloadState(app.name);
              return (
                <li key={app.name}>
                  {app.name}: {state?.status ?? "idle"}
                </li>
              );
            })}
          </ul>
        </section>

        <section className="card">
          <h2>路由一致性</h2>
          <input
            data-testid="route-input"
            value={route}
            onChange={(event) => setRoute(event.target.value)}
          />
          <p>归一化结果: {normalizeRoutePreview()}</p>
          <button data-testid="route-sync-btn" type="button" onClick={emitRouteSync}>
            发送路由同步事件
          </button>
          <p>
            适配器基准: {vue2Adapter.kind}, {vue3Adapter.kind}, {react18Adapter.kind}, {react19Adapter.kind}
          </p>
        </section>

        <section className="card">
          <h2>挂载视图</h2>
          <p>当前挂载: {mountedApp ?? "无"}（从左侧导航菜单选择子应用进行挂载）</p>
          <div id="wujie-mount-slot" data-testid="mount-slot" className="mount-slot" />
        </section>

        <section className="card">
          <h2>调试时间线</h2>
          <div className="row">
            <input
              data-testid="debug-search-input"
              value={debugKeyword}
              placeholder="搜索事件或 payload"
              onChange={(event) => setDebugKeyword(event.target.value)}
            />
          </div>
          <div className="row">
            <select
              data-testid="debug-level-select"
              value={debugLevel}
              onChange={(event) => setDebugLevel(event.target.value as DebugLevel | "all")}
            >
              <option value="all">全部级别</option>
              <option value="info">info</option>
              <option value="warn">warn</option>
              <option value="error">error</option>
            </select>
            <select
              data-testid="debug-app-select"
              value={debugAppFilter}
              onChange={(event) => setDebugAppFilter(event.target.value)}
            >
              <option value="all">全部应用</option>
              {registry.list().map((app) => (
                <option key={app.name} value={app.name}>
                  {app.name}
                </option>
              ))}
            </select>
          </div>
          <div className="row">
            <button data-testid="export-debug-btn" type="button" onClick={exportDebugJson}>
              导出调试 JSON
            </button>
            <button data-testid="clear-debug-btn" type="button" onClick={clearDebugTimeline}>
              清空时间线
            </button>
            <span>
              记录数: {filteredDebugRows.length}/{debugRows.length}
            </span>
          </div>
          <ul data-testid="debug-list">
            {filteredDebugRows.slice(0, 30).map((row) => (
              <li key={row.id} data-testid="debug-row">
                [{new Date(row.timestamp).toLocaleTimeString()}] [{row.level}] {row.appName ?? "-"} · {row.type}
              </li>
            ))}
          </ul>
        </section>
      </div>
    </main>
  );
}
