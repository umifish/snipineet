import { lifecycle } from "./lifecycle";

declare global {
  interface Window {
    __POWERED_BY_WUJIE__?: boolean;
    __WUJIE_MOUNT?: () => void;
    __WUJIE_UNMOUNT?: () => void;
    __WUJIE_UPDATE?: (props?: Record<string, unknown>) => void;
    __WUJIE?: {
      props?: Record<string, unknown>;
    };
  }
}

function mountFromHost(props?: Record<string, unknown>): void {
  void lifecycle.mount({
    appName: "self-embed-app",
    routeBase: "/self-embed",
    props
  });
}

if (window.__POWERED_BY_WUJIE__) {
  window.__WUJIE_MOUNT = () => {
    mountFromHost(window.__WUJIE?.props);
  };

  window.__WUJIE_UNMOUNT = () => {
    void lifecycle.unmount({
      appName: "self-embed-app"
    });
  };

  window.__WUJIE_UPDATE = (props) => {
    void lifecycle.update?.({
      appName: "self-embed-app",
      routeBase: "/self-embed",
      props
    });
  };
} else {
  mountFromHost({
    source: "standalone"
  });
}
