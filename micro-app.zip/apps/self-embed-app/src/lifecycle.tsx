import { createRoot, type Root } from "react-dom/client";
import { App } from "./App";
import {
  createLifecycleContract,
  normalizePath,
  type LifecycleContext,
  type LifecycleHooks
} from "@micro-app/core";

let root: Root | null = null;
let currentContainer: Element | null = null;

function resolveContainer(context: LifecycleContext): Element {
  return context.container ?? document.getElementById("root") ?? document.body;
}

function renderFromContext(context: LifecycleContext): void {
  if (!root) {
    return;
  }
  root.render(
    <App
      routeBase={normalizePath(context.routeBase ?? "/")}
      source={context.container ? "host" : "standalone"}
      hostProps={context.props}
    />
  );
}

const hooks: LifecycleHooks = {
  mount(context) {
    const container = resolveContainer(context);
    currentContainer = container;
    root = createRoot(container);
    renderFromContext(context);
  },
  update(context) {
    if (!root || !currentContainer) {
      return;
    }
    renderFromContext(context);
  },
  unmount() {
    if (!root) {
      return;
    }
    root.unmount();
    root = null;
    currentContainer = null;
  }
};

export const lifecycle = createLifecycleContract(hooks);
