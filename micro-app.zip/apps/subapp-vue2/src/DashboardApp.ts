import Vue, { type CreateElement, type VNode } from "vue";

type Range = "7d" | "30d" | "90d";

interface Metric {
  label: string;
  value: number;
  unit: string;
  delta: number;
}

interface TableRow {
  channel: string;
  visits: number;
  orders: number;
  revenue: number;
}

const RANGE_BARS: Record<Range, number[]> = {
  "7d": [120, 200, 150, 80, 220, 260, 190],
  "30d": [90, 130, 170, 210, 160, 140, 230, 250],
  "90d": [60, 110, 140, 90, 180, 210, 240, 200, 270]
};

const RANGE_LABEL: Record<Range, string> = {
  "7d": "近 7 天",
  "30d": "近 30 天",
  "90d": "近 90 天"
};

const TABLE: TableRow[] = [
  { channel: "自然流量", visits: 18230, orders: 1240, revenue: 386000 },
  { channel: "付费广告", visits: 9450, orders: 890, revenue: 298000 },
  { channel: "私域社群", visits: 6120, orders: 720, revenue: 211000 },
  { channel: "联盟分销", visits: 3380, orders: 410, revenue: 132000 }
];

function metricsFor(range: Range): Metric[] {
  const factor = range === "7d" ? 1 : range === "30d" ? 3.6 : 9.2;
  return [
    { label: "访问量", value: Math.round(37180 * factor), unit: "", delta: 8.4 },
    { label: "订单数", value: Math.round(3260 * factor), unit: "", delta: 5.1 },
    { label: "成交额", value: Math.round(1027000 * factor), unit: "¥", delta: 12.7 },
    { label: "转化率", value: 8.7, unit: "%", delta: -1.2 }
  ];
}

const card = "border:1px solid #e2e8f0;border-radius:12px;padding:16px;margin-top:16px";

export function createDashboardInstance(props: Record<string, unknown>): Vue {
  const source = (props.source as "host") ?? "standalone";
  const routeBase = (props.routeBase as string) ?? "/dashboard";

  return new Vue({
    data() {
      return { range: "7d" as Range };
    },
    methods: {
      renderBanner(h: CreateElement): VNode {
        return h(
          "div",
          {
            style:
              "display:flex;justify-content:space-between;align-items:center;background:#ecfeff;border:1px solid #a5f3fc;border-radius:10px;padding:8px 12px;font-size:13px;color:#0e7490"
          },
          [
            h("strong", "运营看板 · Vue 2"),
            h("span", `${source === "host" ? "宿主挂载" : "独立运行"} · routeBase ${routeBase}`)
          ]
        );
      },
      renderRanges(h: CreateElement): VNode {
        const ranges: Range[] = ["7d", "30d", "90d"];
        return h(
          "div",
          { style: "display:flex;gap:8px;margin-top:12px" },
          ranges.map((r) =>
            h(
              "button",
              {
                key: r,
                style:
                  "border:1px solid #e2e8f0;border-radius:999px;padding:4px 12px;cursor:pointer;font-size:13px;background:#fff" +
                  (this.range === r ? ";border-color:#0891b2;color:#0891b2;font-weight:600" : ""),
                on: {
                  click: () => {
                    this.range = r;
                  }
                }
              },
              RANGE_LABEL[r]
            )
          )
        );
      },
      renderMetrics(h: CreateElement): VNode {
        return h(
          "div",
          { style: "display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:16px" },
          metricsFor(this.range).map((m) =>
            h("div", { key: m.label, style: card.replace("margin-top:16px", "margin-top:0") }, [
              h("div", { style: "color:#64748b;font-size:13px" }, m.label),
              h(
                "div",
                { style: "font-size:22px;font-weight:700;margin:4px 0" },
                `${m.unit}${m.value.toLocaleString()}`
              ),
              h(
                "div",
                {
                  style: `font-size:12px;color:${m.delta >= 0 ? "#16a34a" : "#dc2626"}`
                },
                `${m.delta >= 0 ? "▲" : "▼"} ${Math.abs(m.delta)}%`
              )
            ])
          )
        );
      },
      renderChart(h: CreateElement): VNode {
        const bars = RANGE_BARS[this.range];
        const max = Math.max(...bars);
        const width = 480;
        const height = 160;
        const gap = 8;
        const barWidth = (width - gap * (bars.length - 1)) / bars.length;
        const rects = bars.map((value, index) => {
          const barHeight = Math.round((value / max) * (height - 24));
          return h("rect", {
            key: index,
            attrs: {
              x: index * (barWidth + gap),
              y: height - barHeight,
              width: barWidth,
              height: barHeight,
              rx: 4,
              fill: "#0891b2"
            }
          });
        });
        return h("section", { style: card }, [
          h("h3", { style: "margin:0 0 8px" }, `趋势（${RANGE_LABEL[this.range]}）`),
          h(
            "svg",
            { attrs: { width: "100%", viewBox: `0 0 ${width} ${height}`, role: "img" } },
            rects
          )
        ]);
      },
      renderTable(h: CreateElement): VNode {
        const th = "text-align:left;padding:8px;border-bottom:2px solid #e2e8f0;color:#64748b;font-size:13px";
        const td = "padding:8px;border-bottom:1px solid #f1f5f9;font-size:14px";
        return h("section", { style: card }, [
          h("h3", { style: "margin:0 0 8px" }, "渠道明细"),
          h("table", { style: "width:100%;border-collapse:collapse" }, [
            h("thead", [
              h("tr", [
                h("th", { style: th }, "渠道"),
                h("th", { style: th }, "访问"),
                h("th", { style: th }, "订单"),
                h("th", { style: th }, "成交额")
              ])
            ]),
            h(
              "tbody",
              TABLE.map((row) =>
                h("tr", { key: row.channel }, [
                  h("td", { style: td }, row.channel),
                  h("td", { style: td }, row.visits.toLocaleString()),
                  h("td", { style: td }, row.orders.toLocaleString()),
                  h("td", { style: td }, `¥${row.revenue.toLocaleString()}`)
                ])
              )
            )
          ])
        ]);
      }
    },
    render(h: CreateElement): VNode {
      return h(
        "main",
        {
          style:
            "font-family:system-ui,sans-serif;color:#0f172a;padding:16px;max-width:760px;margin:0 auto"
        },
        [
          this.renderBanner(h),
          this.renderRanges(h),
          this.renderMetrics(h),
          this.renderChart(h),
          this.renderTable(h)
        ]
      );
    }
  });
}
