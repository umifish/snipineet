import type Vue from "vue";
import { createDashboardInstance } from "./DashboardApp";

type HostProps = Record<string, unknown>;

let vm: Vue | null = null;

function mount(props: HostProps = {}): void {
  vm = createDashboardInstance(props);
  vm.$mount("#root");
}

function unmount(): void {
  if (!vm) {
    return;
  }
  vm.$destroy();
  const root = document.getElementById("root");
  if (root) {
    root.innerHTML = "";
  }
  vm = null;
}

declare global {
  interface Window {
    __POWERED_BY_WUJIE__?: boolean;
    __WUJIE_MOUNT?: () => void;
    __WUJIE_UNMOUNT?: () => void;
    __WUJIE_UPDATE?: (props?: Record<string, unknown>) => void;
    __WUJIE?: { props?: Record<string, unknown> };
  }
}

if (window.__POWERED_BY_WUJIE__) {
  window.__WUJIE_MOUNT = () => {
    mount(window.__WUJIE?.props ?? {});
  };
  window.__WUJIE_UNMOUNT = () => {
    unmount();
  };
  window.__WUJIE_UPDATE = (props) => {
    unmount();
    mount(props ?? {});
  };
} else {
  mount({ source: "standalone" });
}
