# micro-app

React 19 微前端工程（wujie 主内核）起步实现。

## 当前实现范围

- Monorepo 基线（apps + packages）
- 子应用预加载最小能力（critical / idle / intent / manual）
- 路由一致性最小契约（path / params / query）
- 公共类型统一导出（包根入口导出 runtime + type）

## 快速开始

```bash
pnpm install
pnpm dev
```

### wujie 本地联调

```bash
# 一键启动联调矩阵（5173-5177）
pnpm dev:matrix

# 若 5173/5174 已被你本地其他会话占用，仅启动新增矩阵子应用（5175-5177）
pnpm dev:matrix:subapps

# 启动后检查各入口是否可访问
pnpm matrix:check

# 浏览器端到端回归（Chrome）
pnpm matrix:e2e

# 可选执行（无 Chrome 时自动跳过，适合 CI）
pnpm matrix:e2e:optional

# 性能基线回归（首屏/FCP、挂载耗时、预加载命中率）
pnpm matrix:perf

# 更新性能基线快照
pnpm matrix:perf:baseline

# nightly 性能趋势采集（追加历史，无 Chrome 时自动跳过）
pnpm matrix:perf:nightly

# 由历史数据生成趋势可视化报告（docs/matrix-perf-trend.html）
pnpm matrix:perf:report
```

主应用页面内可直接执行：

- 子应用预加载（intent/manual）
- wujie 挂载/卸载
- 路由同步事件发送
- 调试时间线导出 JSON

联调矩阵包含：

- React19 子应用：self-embed（5174）
- React18 子应用：subapp-react18（5175）
- Vue3 子应用：subapp-vue3（5176）
- Vue2 子应用：subapp-vue2（5177）

说明：

- `matrix:e2e` 依赖本机可用 Chrome（默认路径：`/Applications/Google Chrome.app`）。
- `matrix:e2e` 覆盖挂载成功、路由同步、卸载回收、跨框架路由一致性（host→Vue3 / host→Vue2）与挂载降级失败路径。
- `matrix:perf` 会输出 `docs/matrix-perf-report.json`，并基于 `docs/matrix-perf-baseline.json` 做回归判定；`matrix:perf:nightly` 会追加到 `docs/matrix-perf-history.json` 维护趋势。
- 若主应用与 self-embed 已在其他终端运行，可仅启动 `dev:matrix:subapps` 后执行 `matrix:check` 与 `matrix:e2e`。

## 质量命令

```bash
pnpm lint
pnpm typecheck
pnpm build
pnpm test
pnpm test:type
```
