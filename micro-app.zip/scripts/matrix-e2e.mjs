import { access } from "node:fs/promises";
import process from "node:process";
import { chromium } from "playwright-core";

const isOptional = process.argv.includes("--optional");

const targets = [
  { name: "host-shell", url: "http://localhost:5173/" },
  { name: "self-embed-react19", url: "http://localhost:5174/" },
  { name: "subapp-react18", url: "http://localhost:5175/" },
  { name: "subapp-vue3", url: "http://localhost:5176/" },
  { name: "subapp-vue2", url: "http://localhost:5177/" }
];

const chromePathCandidates = [
  process.env.CHROME_PATH,
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
  "/usr/bin/google-chrome",
  "/usr/bin/google-chrome-stable",
  "/usr/bin/chromium",
  "/usr/bin/chromium-browser"
].filter(Boolean);

class MissingChromeError extends Error {
  constructor(message) {
    super(message);
    this.name = "MissingChromeError";
  }
}

async function resolveChromePath() {
  for (const candidate of chromePathCandidates) {
    try {
      await access(candidate);
      return candidate;
    } catch {
      // Continue searching.
    }
  }

  throw new MissingChromeError(
    "Chrome executable not found. Set CHROME_PATH or install Google Chrome in /Applications."
  );
}

async function ensureMatrixHealth() {
  const failed = [];

  for (const target of targets) {
    try {
      const response = await fetch(target.url);
      if (!response.ok) {
        failed.push(`${target.name}(${response.status})`);
      }
    } catch {
      failed.push(target.name);
    }
  }

  if (failed.length > 0) {
    throw new Error(
      `Matrix endpoints not ready: ${failed.join(", ")}. Start services with pnpm dev:matrix or pnpm dev:matrix:subapps.`
    );
  }
}

async function waitForText(page, selector, expected, timeout = 15000) {
  try {
    await page.waitForFunction(
      ({ selectorInner, expectedInner }) => {
        const node = document.querySelector(selectorInner);
        if (!node) {
          return false;
        }
        return (node.textContent ?? "").includes(expectedInner);
      },
      { selectorInner: selector, expectedInner: expected },
      { timeout }
    );
  } catch (error) {
    const content = (await page.locator(selector).first().textContent().catch(() => null)) ?? "";
    throw new Error(
      `Timeout waiting for text "${expected}" in "${selector}". Current text: "${content.slice(0, 240)}". ${
        error instanceof Error ? error.message : String(error)
      }`
    );
  }
}

async function runStep(name, action) {
  process.stdout.write(`[E2E] ${name}...\n`);
  await action();
  process.stdout.write(`[E2E] ${name} OK\n`);
}

async function waitMountSlot(page, mounted, timeout = 20000) {
  await page.waitForFunction(
    (expectedMounted) => {
      const slot = document.querySelector("[data-testid='mount-slot']");
      if (!slot) {
        return false;
      }
      const hasMountNode = Boolean(slot.querySelector("iframe, wujie-app, [data-wujie-id]"));
      return expectedMounted ? hasMountNode : !hasMountNode;
    },
    mounted,
    { timeout }
  );
}

async function mountApp(page, appName) {
  await page.locator("[data-testid='mount-app-select']").selectOption(appName);
  await page.locator("[data-testid='mount-btn']").click();
  await page.waitForSelector(`text=当前挂载: ${appName}`, { timeout: 20000 });
  await waitMountSlot(page, true, 25000);
}

async function unmountApp(page) {
  await page.locator("[data-testid='unmount-btn']").click();
  await page.waitForSelector("text=当前挂载: 无", { timeout: 15000 });
  await waitMountSlot(page, false, 15000);
}

async function syncRoute(page, route) {
  await page.locator("[data-testid='route-input']").fill(route);
  await page.locator("[data-testid='route-sync-btn']").click();
}

async function run() {
  await ensureMatrixHealth();
  const executablePath = await resolveChromePath();

  const browser = await chromium.launch({
    executablePath,
    headless: true
  });

  const context = await browser.newContext({
    viewport: { width: 1440, height: 900 }
  });
  const page = await context.newPage();

  try {
    await page.goto(targets[0].url, { waitUntil: "domcontentloaded", timeout: 20000 });
    await page.waitForSelector("text=Host Shell", { timeout: 15000 });

    // 1) Mount success check on React18 subapp.
    await runStep("Mount React18", async () => {
      await page.locator("[data-testid='mount-app-select']").selectOption("checkout-react18");
      await page.locator("[data-testid='mount-btn']").click();
      await page.waitForSelector("text=当前挂载: checkout-react18", { timeout: 15000 });
      await page.waitForFunction(
        () => {
          const slot = document.querySelector("[data-testid='mount-slot']");
          if (!slot) {
            return false;
          }
          return Boolean(slot.querySelector("iframe, wujie-app, [data-wujie-id]"));
        },
        undefined,
        { timeout: 20000 }
      );
    });

    // 2) Route sync event check.
    await runStep("Route Sync Event", async () => {
      await page.locator("[data-testid='route-input']").fill("/checkout/order");
      await page.locator("[data-testid='route-sync-btn']").click();
      await waitForText(page, "[data-testid='debug-list']", "route:sync", 20000);
    });

    // 3) Unmount recovery check.
    await runStep("Unmount Recovery", async () => {
      await page.locator("[data-testid='unmount-btn']").click();
      await page.waitForSelector("text=当前挂载: 无", { timeout: 15000 });
    });

    // 3.1) Cross-framework route consistency: host -> Vue3.
    await runStep("Cross Framework Route Vue3", async () => {
      await mountApp(page, "marketing-vue3");
      await syncRoute(page, "/campaign/spring");
      await waitForText(page, "[data-testid='debug-list']", "route:navigate", 20000);
      await waitForText(page, "[data-testid='debug-list']", "marketing-vue3", 20000);
      await unmountApp(page);
    });

    // 3.2) Cross-framework route consistency: host -> Vue2.
    await runStep("Cross Framework Route Vue2", async () => {
      await mountApp(page, "legacy-vue2-dashboard");
      await syncRoute(page, "/dashboard/overview");
      await waitForText(page, "[data-testid='debug-list']", "route:navigate", 20000);
      await waitForText(page, "[data-testid='debug-list']", "legacy-vue2-dashboard", 20000);
      await unmountApp(page);
    });

    // 4) Mount error check on intentionally broken app (degradation path).
    await runStep("Broken App Error Path", async () => {
      await page.locator("[data-testid='mount-app-select']").selectOption("broken-debug-app");
      await page.locator("[data-testid='mount-btn']").click();
      await page.waitForSelector("[data-testid='mount-error']", { timeout: 25000 });
      await waitForText(page, "[data-testid='debug-list']", "wujie:mount:error", 25000);
    });

    // 4.1) Fault injection on preload layer: timeout / 404 / network error.
    await runStep("Fault Injection Preload", async () => {
      for (const faultApp of ["fault-timeout-app", "fault-404-app", "fault-network-app"]) {
        await page.locator(`button:has-text("预热 ${faultApp}")`).click();
        await waitForText(page, "[data-testid='debug-list']", "preload:error", 20000);
        await waitForText(page, "[data-testid='debug-list']", faultApp, 20000);
      }
    });

    // 4.2) Fault injection on mount layer: timeout / resource-404 / network classification.
    await runStep("Fault Mount Layer", async () => {
      const mountFaults = [
        { app: "fault-mount-timeout-app", expect: "timeout" },
        { app: "fault-mount-404-app", expect: "404" },
        { app: "fault-mount-network-app", expect: "network" }
      ];
      for (const { app, expect } of mountFaults) {
        await page.locator("[data-testid='mount-app-select']").selectOption(app);
        await page.locator("[data-testid='mount-btn']").click();
        await page.waitForSelector("[data-testid='mount-error']", { timeout: 25000 });
        await waitForText(page, "[data-testid='mount-error']", expect, 25000);
        await waitForText(page, "[data-testid='debug-list']", "wujie:mount:error", 25000);
      }
    });

    // 5) Debug filter and clear check.
    await runStep("Debug Filter And Clear", async () => {
      await page.locator("[data-testid='debug-level-select']").selectOption("error");
      await waitForText(page, "[data-testid='debug-list']", "[error]", 15000);
      await page.locator("[data-testid='clear-debug-btn']").click();
      await page.waitForFunction(
        () => document.querySelectorAll("[data-testid='debug-row']").length === 0,
        undefined,
        { timeout: 8000 }
      );
    });

    console.log("Matrix E2E check passed.");
  } finally {
    await context.close();
    await browser.close();
  }
}

run().catch((error) => {
  if (isOptional && error instanceof MissingChromeError) {
    console.warn(`[E2E SKIP] ${error.message}`);
    process.exit(0);
  }

  const message = error instanceof Error ? error.message : String(error);
  console.error(`[E2E FAIL] ${message}`);
  process.exit(1);
});
