const matrix = [
  { name: "host-shell", url: "http://localhost:5173/" },
  { name: "self-embed-react19", url: "http://localhost:5174/" },
  { name: "subapp-react18", url: "http://localhost:5175/" },
  { name: "subapp-vue3", url: "http://localhost:5176/" },
  { name: "subapp-vue2", url: "http://localhost:5177/" }
];

let failed = false;

for (const target of matrix) {
  try {
    const response = await fetch(target.url);
    if (!response.ok) {
      console.error(`[FAIL] ${target.name} -> ${target.url} (status ${response.status})`);
      failed = true;
      continue;
    }
    const html = await response.text();
    const hasHtmlTag = html.includes("<html") || html.includes("<!doctype html>");
    if (!hasHtmlTag) {
      console.error(`[FAIL] ${target.name} -> ${target.url} (unexpected response body)`);
      failed = true;
      continue;
    }
    console.log(`[OK] ${target.name} -> ${target.url}`);
  } catch (error) {
    const message = error instanceof Error ? error.message : "unknown error";
    console.error(`[FAIL] ${target.name} -> ${target.url} (${message})`);
    failed = true;
  }
}

if (failed) {
  process.exit(1);
}

console.log("Matrix health check passed.");
