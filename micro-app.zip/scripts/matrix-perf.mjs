import { access, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright-core";

const args = new Set(process.argv.slice(2));
const shouldUpdateBaseline = args.has("--update-baseline");
const isOptional = args.has("--optional");
const shouldRecordHistory = args.has("--history");
const historyLimit = 100;

const targets = [
  { name: "host-shell", url: "http://localhost:5173/" },
  { name: "self-embed-react19", url: "http://localhost:5174/" },
  { name: "subapp-react18", url: "http://localhost:5175/" },
  { name: "subapp-vue3", url: "http://localhost:5176/" },
  { name: "subapp-vue2", url: "http://localhost:5177/" }
];

const mountApps = ["checkout-react18", "marketing-vue3", "legacy-vue2-dashboard"];

const chromePathCandidates = [
  process.env.CHROME_PATH,
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
  "/usr/bin/google-chrome",
  "/usr/bin/google-chrome-stable",
  "/usr/bin/chromium",
  "/usr/bin/chromium-browser"
].filter(Boolean);

const defaultTolerance = {
  firstScreenMs: 0.35,
  avgMountDurationMs: 0.35,
  preloadHitRate: 0.15
};

const scriptPath = fileURLToPath(import.meta.url);
const projectRoot = path.resolve(path.dirname(scriptPath), "..");
const baselinePath = path.join(projectRoot, "docs", "matrix-perf-baseline.json");
const reportPath = path.join(projectRoot, "docs", "matrix-perf-report.json");
const historyPath = path.join(projectRoot, "docs", "matrix-perf-history.json");

class MissingChromeError extends Error {
  constructor(message) {
    super(message);
    this.name = "MissingChromeError";
  }
}

async function resolveChromePath() {
  for (const candidate of chromePathCandidates) {
    try {
      await access(candidate);
      return candidate;
    } catch {
      // Continue searching.
    }
  }

  throw new MissingChromeError(
    "Chrome executable not found. Set CHROME_PATH or provide a Chrome/Chromium runtime in PATH."
  );
}

async function ensureMatrixHealth() {
  const failed = [];

  for (const target of targets) {
    try {
      const response = await fetch(target.url);
      if (!response.ok) {
        failed.push(`${target.name}(${response.status})`);
      }
    } catch {
      failed.push(target.name);
    }
  }

  if (failed.length > 0) {
    throw new Error(
      `Matrix endpoints not ready: ${failed.join(", ")}. Start services with pnpm dev:matrix or pnpm dev:matrix:subapps.`
    );
  }
}

function toNumberOrNull(value) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function round(value, digits = 2) {
  const factor = 10 ** digits;
  return Math.round(value * factor) / factor;
}

function percentile(values, ratio) {
  if (values.length === 0) {
    return 0;
  }

  const sorted = values.slice().sort((a, b) => a - b);
  const index = Math.min(sorted.length - 1, Math.max(0, Math.ceil(sorted.length * ratio) - 1));
  return sorted[index] ?? sorted[sorted.length - 1];
}

async function collectHostMetrics(page) {
  return page.evaluate(() => {
    const navEntry = performance.getEntriesByType("navigation")[0];
    const paintEntries = performance.getEntriesByType("paint");

    const firstPaint = paintEntries.find((entry) => entry.name === "first-paint");
    const firstContentfulPaint = paintEntries.find(
      (entry) => entry.name === "first-contentful-paint"
    );

    return {
      domContentLoadedMs:
        navEntry && typeof navEntry.domContentLoadedEventEnd === "number"
          ? navEntry.domContentLoadedEventEnd
          : null,
      loadEventMs:
        navEntry && typeof navEntry.loadEventEnd === "number" ? navEntry.loadEventEnd : null,
      firstPaintMs:
        firstPaint && typeof firstPaint.startTime === "number" ? firstPaint.startTime : null,
      firstContentfulPaintMs:
        firstContentfulPaint && typeof firstContentfulPaint.startTime === "number"
          ? firstContentfulPaint.startTime
          : null
    };
  });
}

async function getPreloadStatus(page, appName) {
  return page.evaluate((targetAppName) => {
    const cards = Array.from(document.querySelectorAll("section.card"));
    const preloadCard = cards.find((card) => {
      const title = card.querySelector("h2")?.textContent ?? "";
      return title.includes("子应用预加载");
    });

    if (!preloadCard) {
      return null;
    }

    const line = Array.from(preloadCard.querySelectorAll("li"))
      .map((li) => (li.textContent ?? "").trim())
      .find((text) => text.startsWith(`${targetAppName}:`));

    if (!line) {
      return null;
    }

    const [, status = ""] = line.split(":");
    return status.trim() || null;
  }, appName);
}

async function waitForMountSlotState(page, mounted, timeout = 20000) {
  await page.waitForFunction(
    (expectedMounted) => {
      const slot = document.querySelector("[data-testid='mount-slot']");
      if (!slot) {
        return false;
      }
      const hasMountNode = Boolean(slot.querySelector("iframe, wujie-app, [data-wujie-id]"));
      return expectedMounted ? hasMountNode : !hasMountNode;
    },
    mounted,
    { timeout }
  );
}

async function measureMountDuration(page, appName) {
  await waitForMountSlotState(page, false, 12000);
  const preloadStatus = await getPreloadStatus(page, appName);

  await page.locator("[data-testid='mount-app-select']").selectOption(appName);

  const startedAt = Date.now();
  await page.locator("[data-testid='mount-btn']").click();
  await page.waitForSelector(`text=当前挂载: ${appName}`, { timeout: 20000 });
  await waitForMountSlotState(page, true, 25000);
  const durationMs = Date.now() - startedAt;

  await page.locator("[data-testid='unmount-btn']").click();
  await page.waitForSelector("text=当前挂载: 无", { timeout: 15000 });
  await waitForMountSlotState(page, false, 15000);

  return {
    appName,
    durationMs,
    preloadStatus,
    preloadHit: preloadStatus === "success"
  };
}

function summarizeMetrics(hostMetrics, mountSamples) {
  const durations = mountSamples.map((sample) => sample.durationMs);
  const preloadHits = mountSamples.filter((sample) => sample.preloadHit).length;
  const firstScreenMs =
    toNumberOrNull(hostMetrics.firstContentfulPaintMs) ??
    toNumberOrNull(hostMetrics.firstPaintMs) ??
    toNumberOrNull(hostMetrics.domContentLoadedMs);

  return {
    firstScreenMs,
    domContentLoadedMs: toNumberOrNull(hostMetrics.domContentLoadedMs),
    firstPaintMs: toNumberOrNull(hostMetrics.firstPaintMs),
    firstContentfulPaintMs: toNumberOrNull(hostMetrics.firstContentfulPaintMs),
    avgMountDurationMs: durations.length > 0 ? round(durations.reduce((a, b) => a + b, 0) / durations.length) : 0,
    p95MountDurationMs: round(percentile(durations, 0.95)),
    preloadHitRate: mountSamples.length > 0 ? round(preloadHits / mountSamples.length, 4) : 0,
    sampleCount: mountSamples.length
  };
}

async function loadBaseline() {
  try {
    const text = await readFile(baselinePath, "utf8");
    const parsed = JSON.parse(text);
    return parsed && typeof parsed === "object" ? parsed : null;
  } catch {
    return null;
  }
}

async function writeJson(filePath, value) {
  await writeFile(filePath, `${JSON.stringify(value, null, 2)}\n`, "utf8");
}

async function appendHistory(summary) {
  let history = [];
  try {
    const text = await readFile(historyPath, "utf8");
    const parsed = JSON.parse(text);
    if (Array.isArray(parsed)) {
      history = parsed;
    }
  } catch {
    history = [];
  }

  history.push({
    recordedAt: new Date().toISOString(),
    firstScreenMs: summary.firstScreenMs,
    avgMountDurationMs: summary.avgMountDurationMs,
    p95MountDurationMs: summary.p95MountDurationMs,
    preloadHitRate: summary.preloadHitRate,
    sampleCount: summary.sampleCount
  });

  if (history.length > historyLimit) {
    history = history.slice(history.length - historyLimit);
  }

  await writeJson(historyPath, history);
  console.log(
    `[PERF] history appended (${history.length}/${historyLimit}): ${path.relative(projectRoot, historyPath)}`
  );
}

function checkRegression(summary, baseline) {
  const failures = [];

  const baselineMetrics = baseline?.metrics ?? {};
  const tolerance = {
    ...defaultTolerance,
    ...(baseline?.tolerance ?? {})
  };

  const firstScreenBaseline = toNumberOrNull(baselineMetrics.firstScreenMs);
  const avgMountBaseline = toNumberOrNull(baselineMetrics.avgMountDurationMs);
  const preloadHitBaseline = toNumberOrNull(baselineMetrics.preloadHitRate);

  if (firstScreenBaseline !== null && summary.firstScreenMs !== null) {
    const budget = round(firstScreenBaseline * (1 + tolerance.firstScreenMs));
    if (summary.firstScreenMs > budget) {
      failures.push(
        `首屏耗时回归: current=${summary.firstScreenMs}ms, budget<=${budget}ms (baseline=${firstScreenBaseline}ms)`
      );
    }
  }

  if (avgMountBaseline !== null) {
    const budget = round(avgMountBaseline * (1 + tolerance.avgMountDurationMs));
    if (summary.avgMountDurationMs > budget) {
      failures.push(
        `子应用平均挂载耗时回归: current=${summary.avgMountDurationMs}ms, budget<=${budget}ms (baseline=${avgMountBaseline}ms)`
      );
    }
  }

  if (preloadHitBaseline !== null) {
    const floor = round(Math.max(0, preloadHitBaseline - tolerance.preloadHitRate), 4);
    if (summary.preloadHitRate < floor) {
      failures.push(
        `预加载命中率回归: current=${summary.preloadHitRate}, floor>=${floor} (baseline=${preloadHitBaseline})`
      );
    }
  }

  return failures;
}

async function run() {
  await ensureMatrixHealth();
  const chromePath = await resolveChromePath();

  const browser = await chromium.launch({ executablePath: chromePath, headless: true });
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await context.newPage();

  let hostMetrics;
  const mountSamples = [];

  try {
    await page.goto(targets[0].url, { waitUntil: "domcontentloaded", timeout: 20000 });
    await page.waitForSelector("text=Host Shell", { timeout: 15000 });

    hostMetrics = await collectHostMetrics(page);

    for (const appName of mountApps) {
      const sample = await measureMountDuration(page, appName);
      mountSamples.push(sample);
      console.log(
        `[PERF] ${appName} mount=${sample.durationMs}ms preload=${sample.preloadStatus ?? "unknown"}`
      );
    }
  } finally {
    await context.close();
    await browser.close();
  }

  const summary = summarizeMetrics(hostMetrics, mountSamples);
  const report = {
    generatedAt: new Date().toISOString(),
    chromePath,
    hostMetrics,
    mountSamples,
    summary
  };

  await writeJson(reportPath, report);
  console.log(`[PERF] report written: ${path.relative(projectRoot, reportPath)}`);

  if (shouldRecordHistory) {
    await appendHistory(summary);
  }

  const existingBaseline = await loadBaseline();

  if (shouldUpdateBaseline) {
    const baseline = {
      schemaVersion: 1,
      updatedAt: new Date().toISOString(),
      metrics: {
        firstScreenMs: summary.firstScreenMs ?? summary.domContentLoadedMs ?? 0,
        avgMountDurationMs: summary.avgMountDurationMs,
        preloadHitRate: summary.preloadHitRate
      },
      tolerance: {
        ...defaultTolerance,
        ...(existingBaseline?.tolerance ?? {})
      }
    };

    await writeJson(baselinePath, baseline);
    console.log(`[PERF] baseline updated: ${path.relative(projectRoot, baselinePath)}`);
    return;
  }

  if (!existingBaseline) {
    console.warn(
      "[PERF] baseline not found, skip regression check. Run `pnpm matrix:perf -- --update-baseline` to initialize."
    );
    return;
  }

  const regressions = checkRegression(summary, existingBaseline);
  if (regressions.length > 0) {
    for (const line of regressions) {
      console.error(`[PERF FAIL] ${line}`);
    }
    process.exit(1);
  }

  console.log("[PERF] regression check passed.");
}

run().catch((error) => {
  if (isOptional && error instanceof MissingChromeError) {
    console.warn(`[PERF SKIP] ${error.message}`);
    process.exit(0);
  }

  const message = error instanceof Error ? error.message : String(error);
  console.error(`[PERF FAIL] ${message}`);
  process.exit(1);
});
