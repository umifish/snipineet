import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";

const scriptPath = fileURLToPath(import.meta.url);
const projectRoot = path.resolve(path.dirname(scriptPath), "..");
const historyPath = path.join(projectRoot, "docs", "matrix-perf-history.json");
const baselinePath = path.join(projectRoot, "docs", "matrix-perf-baseline.json");
const outputPath = path.join(projectRoot, "docs", "matrix-perf-trend.html");

async function readJson(filePath, fallback) {
  try {
    const text = await readFile(filePath, "utf8");
    return JSON.parse(text);
  } catch {
    return fallback;
  }
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function buildLineChart(title, points, options = {}) {
  const width = 720;
  const height = 220;
  const padding = { top: 24, right: 24, bottom: 36, left: 56 };
  const innerWidth = width - padding.left - padding.right;
  const innerHeight = height - padding.top - padding.bottom;

  const values = points.map((point) => point.value);
  const hasData = values.length > 0;
  const maxValue = hasData ? Math.max(...values, options.min ?? 0) : 1;
  const minValue = hasData ? Math.min(...values, options.min ?? 0) : 0;
  const span = maxValue - minValue || 1;

  const toX = (index) =>
    padding.left + (points.length <= 1 ? innerWidth / 2 : (index / (points.length - 1)) * innerWidth);
  const toY = (value) => padding.top + innerHeight - ((value - minValue) / span) * innerHeight;

  const polyline = points.map((point, index) => `${toX(index)},${toY(point.value)}`).join(" ");
  const circles = points
    .map(
      (point, index) =>
        `<circle cx="${toX(index)}" cy="${toY(point.value)}" r="3" fill="#2563eb"><title>${escapeHtml(
          point.label
        )}: ${escapeHtml(point.value)}</title></circle>`
    )
    .join("");

  const baselineLine =
    typeof options.baseline === "number"
      ? `<line x1="${padding.left}" y1="${toY(options.baseline)}" x2="${width - padding.right}" y2="${toY(
          options.baseline
        )}" stroke="#f59e0b" stroke-dasharray="6 4" stroke-width="1.5"></line>`
      : "";

  const yTicks = Array.from({ length: 4 }, (_, i) => {
    const value = minValue + (span * i) / 3;
    const y = toY(value);
    return `<text x="${padding.left - 8}" y="${y + 4}" text-anchor="end" font-size="11" fill="#64748b">${
      Math.round(value * 100) / 100
    }</text><line x1="${padding.left}" y1="${y}" x2="${width - padding.right}" y2="${y}" stroke="#e2e8f0" stroke-width="1"></line>`;
  }).join("");

  const emptyHint = hasData
    ? ""
    : `<text x="${width / 2}" y="${height / 2}" text-anchor="middle" font-size="13" fill="#94a3b8">暂无历史数据</text>`;

  return `
  <figure class="chart">
    <figcaption>${escapeHtml(title)}</figcaption>
    <svg viewBox="0 0 ${width} ${height}" role="img" aria-label="${escapeHtml(title)}">
      ${yTicks}
      ${baselineLine}
      <polyline fill="none" stroke="#2563eb" stroke-width="2" points="${polyline}"></polyline>
      ${circles}
      ${emptyHint}
    </svg>
  </figure>`;
}

function formatTimeLabel(iso) {
  if (typeof iso !== "string") {
    return "-";
  }
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) {
    return iso;
  }
  return date.toISOString().slice(5, 16).replace("T", " ");
}

async function run() {
  const history = await readJson(historyPath, []);
  const baseline = await readJson(baselinePath, null);
  const records = Array.isArray(history) ? history : [];

  const firstScreenPoints = records.map((row) => ({
    label: formatTimeLabel(row.recordedAt),
    value: Number(row.firstScreenMs ?? 0)
  }));
  const mountPoints = records.map((row) => ({
    label: formatTimeLabel(row.recordedAt),
    value: Number(row.avgMountDurationMs ?? 0)
  }));
  const preloadPoints = records.map((row) => ({
    label: formatTimeLabel(row.recordedAt),
    value: Number(row.preloadHitRate ?? 0)
  }));

  const baselineMetrics = baseline?.metrics ?? {};

  const latest = records.at(-1);
  const summaryCards = latest
    ? `
    <div class="cards">
      <div class="metric"><span>最近首屏</span><strong>${escapeHtml(latest.firstScreenMs ?? "-")} ms</strong></div>
      <div class="metric"><span>平均挂载</span><strong>${escapeHtml(latest.avgMountDurationMs ?? "-")} ms</strong></div>
      <div class="metric"><span>P95 挂载</span><strong>${escapeHtml(latest.p95MountDurationMs ?? "-")} ms</strong></div>
      <div class="metric"><span>预加载命中率</span><strong>${escapeHtml(latest.preloadHitRate ?? "-")}</strong></div>
    </div>`
    : '<p class="empty">尚无历史记录，先运行 <code>pnpm matrix:perf:nightly</code> 采集数据。</p>';

  const html = `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>micro-app 性能趋势</title>
<style>
  :root { color-scheme: light; }
  body { font-family: -apple-system, "Segoe UI", system-ui, sans-serif; margin: 0; padding: 24px; background: #f8fafc; color: #0f172a; }
  h1 { font-size: 20px; margin: 0 0 4px; }
  .meta { color: #64748b; font-size: 13px; margin-bottom: 20px; }
  .cards { display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 20px; }
  .metric { background: #fff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 12px 16px; min-width: 140px; }
  .metric span { display: block; font-size: 12px; color: #64748b; }
  .metric strong { font-size: 18px; }
  .chart { background: #fff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 12px 16px; margin: 0 0 16px; }
  .chart figcaption { font-weight: 600; font-size: 14px; margin-bottom: 8px; }
  .chart svg { width: 100%; height: auto; }
  .legend { font-size: 12px; color: #92400e; }
  .empty { color: #64748b; }
  code { background: #e2e8f0; border-radius: 4px; padding: 1px 6px; }
</style>
</head>
<body>
  <h1>micro-app 联调性能趋势</h1>
  <p class="meta">生成时间：${escapeHtml(new Date().toISOString())} · 数据点：${records.length} 条 · 来源：docs/matrix-perf-history.json</p>
  ${summaryCards}
  ${buildLineChart("首屏耗时 (ms)", firstScreenPoints, { min: 0, baseline: Number(baselineMetrics.firstScreenMs) || undefined })}
  ${buildLineChart("子应用平均挂载耗时 (ms)", mountPoints, { min: 0, baseline: Number(baselineMetrics.avgMountDurationMs) || undefined })}
  ${buildLineChart("预加载命中率", preloadPoints, { min: 0 })}
  <p class="legend">虚线为 docs/matrix-perf-baseline.json 中的基线值。</p>
</body>
</html>
`;

  await writeFile(outputPath, html, "utf8");
  console.log(`[PERF REPORT] written: ${path.relative(projectRoot, outputPath)} (${records.length} points)`);
}

run().catch((error) => {
  const message = error instanceof Error ? error.message : String(error);
  console.error(`[PERF REPORT FAIL] ${message}`);
  process.exit(1);
});
