# Implementation Status

## 已完成（起步版本）

- F0: monorepo 根配置、工作区、基础脚本
- F1: 预加载管理器（critical / idle / intent / manual）+ wujie preload 对接
- F2: 路由归一化与查询参数序列化基础实现 + route 事件同步
- F3: 各能力包包根入口统一导出类型与运行时
- wujie Host Runtime: 已在 micro-kernel 中接通 setupApp/startApp/destroyApp
- Framework Adapters: 已补齐 React18/React19/Vue2/Vue3 的运行时挂载适配工厂接口
- Host/SelfEmbed: React 19 主应用与子应用骨架，self-embed 已支持 wujie 生命周期挂载
- Debug: 新增 micro-debug 调试时间线，支持事件分级、应用筛选、关键字检索、清空与 JSON 导出
- Matrix Subapps: 已新增 React18/Vue3/Vue2 三个本地子应用（wujie 生命周期接入）
- Matrix Health Check: 已新增 `pnpm matrix:check` 脚本用于联调入口验活
- Matrix Browser E2E: 已新增 `pnpm matrix:e2e` 覆盖挂载成功、路由同步、卸载回收、挂载失败与调试筛选
- Matrix CI Optional E2E: 已新增 `.github/workflows/micro-app-ci.yml`，通过 `workflow_dispatch` 按需触发，且仅在 Runner 检测到 Chrome 时执行
- Matrix Perf Regression: 已新增 `pnpm matrix:perf` 与 `docs/matrix-perf-baseline.json`，覆盖首屏耗时、子应用挂载耗时、预加载命中率
- Matrix Cross-Framework E2E: `matrix:e2e` 已增补 host→Vue3 / host→Vue2 跨框架路由一致性与挂载降级失败路径
- Matrix Perf Nightly Trend: `pnpm matrix:perf:nightly` + CI `schedule` 定时任务，追加 `docs/matrix-perf-history.json` 维护历史趋势
- Matrix Perf Trend Report: `pnpm matrix:perf:report` 由历史数据生成零依赖内联 SVG 趋势报告 `docs/matrix-perf-trend.html`
- Matrix Fault Injection: 新增 timeout / 404 / network 三类确定性故障子应用，`matrix:e2e` 覆盖预加载层降级 `preload:error` 路径
- Matrix Mount-Layer Fault Injection: micro-kernel 新增挂载预检（`preflight`）与挂载超时（`mountTimeoutMs`），`MountError.reason` 区分 timeout / resource-404 / network；host 新增三类挂载层故障子应用，`matrix:e2e` 覆盖挂载层 `wujie:mount:error` 分类路径
- Packages Consolidation: 将 micro-bridge / micro-registry / micro-lifecycle / micro-debug / micro-kernel / framework-adapters 六个子包合并为单一 `@micro-app/core`（内部按 `bridge`/`registry`/`lifecycle`/`debug`/`kernel`/`adapters` 模块拆分，`src/index.ts` 统一导出）
- Host Shell 左侧导航：将「wujie 挂载调试」区块改造为左侧侧边栏导航菜单（点击即选中并挂载，含激活高亮与状态指示），右侧为挂载视图与调试面板两栏布局
- wujie 升级：内核依赖由 `wujie@^1.0.22` 升级至 `wujie@^2.0.2`，`setupApp`/`startApp`/`preloadApp`/`destroyApp` API 兼容无需改造，`lint`/`typecheck`/`build`/`test:type` 与 `matrix:check`/`matrix:e2e:optional` 全量回归通过
- 路由回退：Host Shell 接入浏览器历史，切换子应用时以 `#/app/<name>` 写入 `pushState`，通过 `popstate` 监听重建挂载状态，新增「返回」按钮并支持深链直达；`applyMount` 采用乐观占位避免 StrictMode 双调用/深链初始化的并发重复挂载，运行时 `unmountApp` 以挂载集合做幂等保护，避免重复 `destroyApp` 触发的二次卸载

## 下一步

- 将挂载层故障的降级 UI 与可观测埋点接入主应用调试面板（按 reason 分类聚合）
