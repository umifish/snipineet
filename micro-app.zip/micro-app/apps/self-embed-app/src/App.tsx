import {
  isChannelEnvelope,
  postToParent,
  type GlobalPreferences
} from "@micro-app/core";
import { useEffect, useMemo, useRef, useState, type CSSProperties, type ReactElement } from "react";

type Tab = "overview" | "tasks" | "activity";

interface Task {
  id: number;
  title: string;
  done: boolean;
  owner: string;
}

const INITIAL_TASKS: Task[] = [
  { id: 1, title: "对齐子应用路由前缀约定", done: true, owner: "前端" },
  { id: 2, title: "补充挂载层故障注入用例", done: true, owner: "平台" },
  { id: 3, title: "接入趋势报告可观测面板", done: false, owner: "平台" },
  { id: 4, title: "梳理 core 包导出类型", done: false, owner: "前端" }
];

const ACTIVITY = [
  { time: "09:12", text: "checkout-react18 挂载成功" },
  { time: "09:40", text: "marketing-vue3 路由同步 /campaign/spring" },
  { time: "10:05", text: "legacy-vue2-dashboard 预加载命中" },
  { time: "10:22", text: "fault-mount-404-app 触发 resource-404 降级" }
];

const palette = {
  primary: "#0ea5e9",
  border: "#e2e8f0",
  muted: "#64748b",
  bg: "#f0f9ff",
  ok: "#16a34a"
};

const styles: Record<string, CSSProperties> = {
  root: {
    fontFamily: "system-ui, sans-serif",
    color: "#0f172a",
    padding: 16,
    maxWidth: 760,
    margin: "0 auto"
  },
  banner: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    background: palette.bg,
    border: `1px solid #bae6fd`,
    borderRadius: 10,
    padding: "8px 12px",
    fontSize: 13,
    color: "#0369a1"
  },
  tabs: { display: "flex", gap: 8, marginTop: 12 },
  card: { border: `1px solid ${palette.border}`, borderRadius: 12, padding: 16, marginTop: 16 },
  metricGrid: { display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12, marginTop: 16 },
  row: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "8px 0",
    borderBottom: `1px solid #f1f5f9`
  }
};

function tabStyle(active: boolean): CSSProperties {
  return {
    border: `1px solid ${active ? palette.primary : palette.border}`,
    color: active ? palette.primary : palette.muted,
    fontWeight: active ? 600 : 400,
    background: "#fff",
    borderRadius: 999,
    padding: "4px 14px",
    cursor: "pointer",
    fontSize: 13
  };
}

export function App(props: {
  routeBase: string;
  source: "standalone" | "host";
  hostProps?: Record<string, unknown>;
}): ReactElement {
  const [tab, setTab] = useState<Tab>("overview");
  const [tasks, setTasks] = useState<Task[]>(INITIAL_TASKS);
  const [preferences, setPreferences] = useState<GlobalPreferences>({
    theme: "light",
    timezone: "Asia/Shanghai",
    language: "zh-CN"
  });
  const [inbox, setInbox] = useState<string[]>([]);
  const [relayTarget, setRelayTarget] = useState("checkout-react18");
  const [outgoingData, setOutgoingData] = useState('{"workspace":"home","intent":"sync"}');
  const relaySeenRef = useRef<Set<string>>(new Set());

  const doneCount = tasks.filter((t) => t.done).length;
  const progress = Math.round((doneCount / tasks.length) * 100);

  const metrics = useMemo(
    () => [
      { label: "在线子应用", value: "4" },
      { label: "今日挂载", value: "27" },
      { label: "降级事件", value: "3" }
    ],
    []
  );

  const toggleTask = (id: number) => {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));
  };

  useEffect(() => {
    postToParent("self-embed-react19", "subapp:ready", { from: "subapp" });

    const onMessage = (event: MessageEvent) => {
      if (!isChannelEnvelope(event.data) || event.data.direction !== "host-to-subapp") {
        return;
      }
      const envelope = event.data;
      if (envelope.appName !== "self-embed-react19") {
        return;
      }

      if (envelope.type === "host:settings-change") {
        setPreferences((envelope.payload as { preferences: GlobalPreferences }).preferences);
      }

      if (envelope.type === "host:data-sync" || envelope.type === "host:notify") {
        setInbox((prev) => {
          const next = [`${envelope.type} @ ${new Date(envelope.timestamp).toLocaleTimeString()}`, ...prev];
          return next.slice(0, 6);
        });
      }

      if (envelope.type === "host:subapp-relay") {
        const relayPayload = envelope.payload as {
          fromApp: string;
          topic: string;
          data: Record<string, unknown>;
          messageId: string;
        };
        const alreadySeen = relaySeenRef.current.has(relayPayload.messageId);
        if (!alreadySeen) {
          relaySeenRef.current.add(relayPayload.messageId);
        }
        setInbox((prev) => {
          const next = [
            `relay(${relayPayload.fromApp}) ${relayPayload.topic} #${relayPayload.messageId} @ ${new Date(envelope.timestamp).toLocaleTimeString()}`,
            ...prev
          ];
          return next.slice(0, 6);
        });
        postToParent("self-embed-react19", "subapp:relay-ack", {
          from: "subapp",
          messageId: relayPayload.messageId,
          status: alreadySeen ? "ignored" : "received"
        });
      }
    };

    window.addEventListener("message", onMessage);
    return () => {
      window.removeEventListener("message", onMessage);
    };
  }, []);

  return (
    <main style={styles.root}>
      <div style={styles.banner}>
        <strong style={{ color: "#0f172a" }}>工作台 · React 19（自嵌入）</strong>
        <span>
          {props.source === "host" ? "宿主挂载" : "独立运行"} · routeBase {props.routeBase}
        </span>
      </div>
      <section style={{ ...styles.card, marginTop: 12 }}>
        <h3 style={{ margin: "0 0 8px" }}>主子通信</h3>
        <p style={{ margin: "4px 0", color: palette.muted, fontSize: 13 }}>
          主题 {preferences.theme} · 时区 {preferences.timezone} · 语言 {preferences.language}
        </p>
        <div style={{ display: "flex", gap: 8 }}>
          <select value={relayTarget} onChange={(event) => setRelayTarget(event.target.value)}>
            <option value="checkout-react18">checkout-react18</option>
            <option value="marketing-vue3">marketing-vue3</option>
            <option value="legacy-vue2-dashboard">legacy-vue2-dashboard</option>
          </select>
          <input value={outgoingData} onChange={(event) => setOutgoingData(event.target.value)} />
          <button
            type="button"
            style={tabStyle(false)}
            onClick={() =>
              postToParent("self-embed-react19", "subapp:notify", {
                from: "subapp",
                level: "info",
                message: "workspace 已接收宿主通信能力"
              })
            }
          >
            向宿主发送消息通知
          </button>
          <button
            type="button"
            style={tabStyle(false)}
            onClick={() => {
              try {
                const data = JSON.parse(outgoingData) as Record<string, unknown>;
                postToParent("self-embed-react19", "subapp:relay", {
                  from: "subapp",
                  toApp: relayTarget,
                  topic: "workspace:state-sync",
                  data,
                  messageId: `workspace-${Date.now().toString(36)}`,
                  ttlMs: 30_000
                });
              } catch {
                postToParent("self-embed-react19", "subapp:notify", {
                  from: "subapp",
                  level: "error",
                  message: "workspace 中继发送失败：JSON 解析错误"
                });
              }
            }}
          >
            发送给子应用
          </button>
        </div>
        <ul style={{ marginTop: 8 }}>
          {inbox.map((line) => (
            <li key={line}>{line}</li>
          ))}
        </ul>
      </section>

      <nav style={styles.tabs}>
        {(["overview", "tasks", "activity"] as Tab[]).map((key) => (
          <button key={key} type="button" style={tabStyle(tab === key)} onClick={() => setTab(key)}>
            {key === "overview" ? "概览" : key === "tasks" ? "任务" : "动态"}
          </button>
        ))}
      </nav>

      {tab === "overview" ? (
        <>
          <div style={styles.metricGrid}>
            {metrics.map((m) => (
              <div key={m.label} style={{ ...styles.card, marginTop: 0 }}>
                <div style={{ color: palette.muted, fontSize: 13 }}>{m.label}</div>
                <div style={{ fontSize: 24, fontWeight: 700, marginTop: 4 }}>{m.value}</div>
              </div>
            ))}
          </div>
          <section style={styles.card}>
            <h3 style={{ margin: "0 0 8px" }}>迭代进度</h3>
            <div style={{ background: "#e2e8f0", borderRadius: 999, height: 10, overflow: "hidden" }}>
              <div
                style={{
                  width: `${progress}%`,
                  height: "100%",
                  background: palette.primary,
                  transition: "width .3s"
                }}
              />
            </div>
            <p style={{ color: palette.muted, fontSize: 13, marginTop: 8 }}>
              已完成 {doneCount}/{tasks.length} 项（{progress}%）
            </p>
          </section>
        </>
      ) : null}

      {tab === "tasks" ? (
        <section style={styles.card}>
          <h3 style={{ margin: "0 0 8px" }}>任务清单</h3>
          {tasks.map((t) => (
            <label key={t.id} style={{ ...styles.row, cursor: "pointer" }}>
              <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <input type="checkbox" checked={t.done} onChange={() => toggleTask(t.id)} />
                <span
                  style={{
                    textDecoration: t.done ? "line-through" : "none",
                    color: t.done ? palette.muted : "#0f172a"
                  }}
                >
                  {t.title}
                </span>
              </span>
              <span style={{ color: palette.muted, fontSize: 13 }}>{t.owner}</span>
            </label>
          ))}
        </section>
      ) : null}

      {tab === "activity" ? (
        <section style={styles.card}>
          <h3 style={{ margin: "0 0 8px" }}>最近动态</h3>
          {ACTIVITY.map((a, index) => (
            <div key={index} style={styles.row}>
              <span style={{ color: palette.muted, fontSize: 13, minWidth: 56 }}>{a.time}</span>
              <span style={{ flex: 1, marginLeft: 12 }}>{a.text}</span>
            </div>
          ))}
        </section>
      ) : null}
    </main>
  );
}

