import {
  isChannelEnvelope,
  postToParent,
  type GlobalPreferences
} from "@micro-app/core";
import { useEffect, useMemo, useRef, useState, type CSSProperties, type ReactElement } from "react";

export interface CheckoutAppProps {
  source: "standalone" | "host";
  routeBase: string;
  hostProps: Record<string, unknown>;
}

interface CartLine {
  id: string;
  name: string;
  unitPrice: number;
  qty: number;
}

type View = "cart" | "confirm" | "done";

const CATALOG: CartLine[] = [
  { id: "sku-keyboard", name: "机械键盘 87 键", unitPrice: 399, qty: 1 },
  { id: "sku-mouse", name: "无线人体工学鼠标", unitPrice: 199, qty: 2 },
  { id: "sku-monitor", name: "27 寸 2K 显示器", unitPrice: 1299, qty: 1 }
];

const COUPONS: Record<string, number> = {
  WELCOME10: 0.1,
  VIP20: 0.2
};

const palette = {
  primary: "#2563eb",
  border: "#e2e8f0",
  muted: "#64748b",
  bg: "#f8fafc",
  ok: "#16a34a"
};

const styles: Record<string, CSSProperties> = {
  root: {
    fontFamily: "system-ui, sans-serif",
    color: "#0f172a",
    padding: 16,
    maxWidth: 720,
    margin: "0 auto"
  },
  banner: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    background: palette.bg,
    border: `1px solid ${palette.border}`,
    borderRadius: 10,
    padding: "8px 12px",
    fontSize: 13,
    color: palette.muted
  },
  card: {
    border: `1px solid ${palette.border}`,
    borderRadius: 12,
    padding: 16,
    marginTop: 16
  },
  row: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
    padding: "10px 0",
    borderBottom: `1px solid ${palette.border}`
  },
  qtyBtn: {
    width: 28,
    height: 28,
    borderRadius: 6,
    border: `1px solid ${palette.border}`,
    background: "#fff",
    cursor: "pointer",
    fontSize: 16,
    lineHeight: 1
  },
  primaryBtn: {
    background: palette.primary,
    color: "#fff",
    border: "none",
    borderRadius: 8,
    padding: "10px 18px",
    cursor: "pointer",
    fontSize: 14
  },
  ghostBtn: {
    background: "#fff",
    color: palette.primary,
    border: `1px solid ${palette.primary}`,
    borderRadius: 8,
    padding: "10px 18px",
    cursor: "pointer",
    fontSize: 14
  },
  input: {
    border: `1px solid ${palette.border}`,
    borderRadius: 8,
    padding: "8px 10px",
    fontSize: 14
  }
};

function formatPrice(value: number): string {
  return `¥${value.toFixed(2)}`;
}

export function CheckoutApp(props: CheckoutAppProps): ReactElement {
  const [lines, setLines] = useState<CartLine[]>(CATALOG);
  const [couponInput, setCouponInput] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
  const [view, setView] = useState<View>("cart");
  const [orderId, setOrderId] = useState<string | null>(null);
  const [preferences, setPreferences] = useState<GlobalPreferences>({
    theme: "light",
    timezone: "Asia/Shanghai",
    language: "zh-CN"
  });
  const [inbox, setInbox] = useState<string[]>([]);
  const [outgoingData, setOutgoingData] = useState('{"cartItems":4,"intent":"settlement"}');
  const [relayTarget, setRelayTarget] = useState("marketing-vue3");
  const relaySeenRef = useRef<Set<string>>(new Set());

  const subtotal = useMemo(
    () => lines.reduce((sum, line) => sum + line.unitPrice * line.qty, 0),
    [lines]
  );
  const discountRate = appliedCoupon ? COUPONS[appliedCoupon] ?? 0 : 0;
  const discount = Math.round(subtotal * discountRate * 100) / 100;
  const total = subtotal - discount;
  const itemCount = lines.reduce((sum, line) => sum + line.qty, 0);

  const changeQty = (id: string, delta: number) => {
    setLines((prev) =>
      prev.map((line) =>
        line.id === id ? { ...line, qty: Math.max(0, line.qty + delta) } : line
      )
    );
  };

  const applyCoupon = () => {
    const code = couponInput.trim().toUpperCase();
    setAppliedCoupon(code in COUPONS ? code : null);
  };

  const placeOrder = () => {
    setOrderId(`ORD-${Date.now().toString(36).toUpperCase()}`);
    setView("done");
  };

  const reset = () => {
    setLines(CATALOG);
    setAppliedCoupon(null);
    setCouponInput("");
    setOrderId(null);
    setView("cart");
  };

  useEffect(() => {
    postToParent("checkout-react18", "subapp:ready", { from: "subapp" });

    const onMessage = (event: MessageEvent) => {
      if (!isChannelEnvelope(event.data) || event.data.direction !== "host-to-subapp") {
        return;
      }
      const envelope = event.data;
      if (envelope.appName !== "checkout-react18") {
        return;
      }

      if (envelope.type === "host:settings-change") {
        setPreferences((envelope.payload as { preferences: GlobalPreferences }).preferences);
      }

      if (envelope.type === "host:data-sync" || envelope.type === "host:notify") {
        setInbox((prev) => {
          const next = [`${envelope.type} @ ${new Date(envelope.timestamp).toLocaleTimeString()}`, ...prev];
          return next.slice(0, 6);
        });
      }

      if (envelope.type === "host:subapp-relay") {
        const relayPayload = envelope.payload as {
          fromApp: string;
          topic: string;
          data: Record<string, unknown>;
          messageId: string;
        };
        const alreadySeen = relaySeenRef.current.has(relayPayload.messageId);
        if (!alreadySeen) {
          relaySeenRef.current.add(relayPayload.messageId);
        }
        setInbox((prev) => {
          const next = [
            `relay(${relayPayload.fromApp}) ${relayPayload.topic} #${relayPayload.messageId} @ ${new Date(envelope.timestamp).toLocaleTimeString()}`,
            ...prev
          ];
          return next.slice(0, 6);
        });
        postToParent("checkout-react18", "subapp:relay-ack", {
          from: "subapp",
          messageId: relayPayload.messageId,
          status: alreadySeen ? "ignored" : "received"
        });
      }
    };

    window.addEventListener("message", onMessage);
    return () => {
      window.removeEventListener("message", onMessage);
    };
  }, []);

  const sendDataToHost = () => {
    try {
      const data = JSON.parse(outgoingData) as Record<string, unknown>;
      postToParent("checkout-react18", "subapp:data-sync", { from: "subapp", data });
      postToParent("checkout-react18", "subapp:notify", {
        from: "subapp",
        level: "info",
        message: "checkout 已发送业务数据"
      });
    } catch {
      postToParent("checkout-react18", "subapp:notify", {
        from: "subapp",
        level: "error",
        message: "checkout 发送失败：JSON 解析错误"
      });
    }
  };

  const suggestTokyoSetting = () => {
    postToParent("checkout-react18", "subapp:settings-change", {
      from: "subapp",
      preferences: {
        ...preferences,
        timezone: "Asia/Tokyo"
      }
    });
  };

  const relayToSubapp = () => {
    try {
      const data = JSON.parse(outgoingData) as Record<string, unknown>;
      postToParent("checkout-react18", "subapp:relay", {
        from: "subapp",
        toApp: relayTarget,
        topic: "checkout:cart-sync",
        data,
        messageId: `checkout-${Date.now().toString(36)}`,
        ttlMs: 30_000
      });
      postToParent("checkout-react18", "subapp:notify", {
        from: "subapp",
        level: "info",
        message: `checkout 已向 ${relayTarget} 发送中继消息`
      });
    } catch {
      postToParent("checkout-react18", "subapp:notify", {
        from: "subapp",
        level: "error",
        message: "checkout 中继发送失败：JSON 解析错误"
      });
    }
  };

  return (
    <main style={styles.root}>
      <div style={styles.banner}>
        <strong style={{ color: "#0f172a" }}>结算中心 · React 18</strong>
        <span>
          {props.source === "host" ? "宿主挂载" : "独立运行"} · routeBase {props.routeBase}
        </span>
      </div>
      <section style={{ ...styles.card, marginTop: 12 }}>
        <h3 style={{ margin: "0 0 8px" }}>主子通信</h3>
        <p style={{ margin: "4px 0", color: palette.muted, fontSize: 13 }}>
          主题 {preferences.theme} · 时区 {preferences.timezone} · 语言 {preferences.language}
        </p>
        <div style={{ display: "flex", gap: 8 }}>
          <select value={relayTarget} onChange={(event) => setRelayTarget(event.target.value)}>
            <option value="marketing-vue3">marketing-vue3</option>
            <option value="legacy-vue2-dashboard">legacy-vue2-dashboard</option>
            <option value="self-embed-react19">self-embed-react19</option>
          </select>
          <input
            style={styles.input}
            value={outgoingData}
            onChange={(event) => setOutgoingData(event.target.value)}
          />
          <button type="button" style={styles.ghostBtn} onClick={sendDataToHost}>
            回传数据
          </button>
          <button type="button" style={styles.ghostBtn} onClick={suggestTokyoSetting}>
            建议切换东京时区
          </button>
          <button type="button" style={styles.ghostBtn} onClick={relayToSubapp}>
            发送给子应用
          </button>
        </div>
        <ul style={{ marginTop: 8 }}>
          {inbox.map((line) => (
            <li key={line}>{line}</li>
          ))}
        </ul>
      </section>

      <nav style={{ display: "flex", gap: 8, marginTop: 12 }}>
        {(["cart", "confirm", "done"] as View[]).map((step, index) => (
          <span
            key={step}
            style={{
              fontSize: 13,
              color: view === step ? palette.primary : palette.muted,
              fontWeight: view === step ? 600 : 400
            }}
          >
            {index + 1}. {step === "cart" ? "购物车" : step === "confirm" ? "确认订单" : "完成"}
          </span>
        ))}
      </nav>

      {view === "cart" ? (
        <section style={styles.card}>
          <h3 style={{ margin: "0 0 8px" }}>购物车（{itemCount} 件）</h3>
          {lines.map((line) => (
            <div key={line.id} style={styles.row}>
              <div>
                <div>{line.name}</div>
                <div style={{ color: palette.muted, fontSize: 13 }}>
                  {formatPrice(line.unitPrice)} / 件
                </div>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <button
                  type="button"
                  style={styles.qtyBtn}
                  onClick={() => changeQty(line.id, -1)}
                  aria-label={`减少 ${line.name}`}
                >
                  −
                </button>
                <span style={{ minWidth: 24, textAlign: "center" }}>{line.qty}</span>
                <button
                  type="button"
                  style={styles.qtyBtn}
                  onClick={() => changeQty(line.id, 1)}
                  aria-label={`增加 ${line.name}`}
                >
                  +
                </button>
                <strong style={{ minWidth: 90, textAlign: "right" }}>
                  {formatPrice(line.unitPrice * line.qty)}
                </strong>
              </div>
            </div>
          ))}

          <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
            <input
              style={styles.input}
              value={couponInput}
              placeholder="优惠码 WELCOME10 / VIP20"
              onChange={(event) => setCouponInput(event.target.value)}
            />
            <button type="button" style={styles.ghostBtn} onClick={applyCoupon}>
              应用优惠码
            </button>
          </div>
          {couponInput && appliedCoupon === null ? (
            <p style={{ color: "#dc2626", fontSize: 13 }}>优惠码无效</p>
          ) : null}

          <div style={{ ...styles.row, borderBottom: "none", marginTop: 8 }}>
            <span style={{ color: palette.muted }}>合计</span>
            <strong style={{ fontSize: 18 }}>{formatPrice(total)}</strong>
          </div>
          <div style={{ textAlign: "right" }}>
            <button
              type="button"
              style={styles.primaryBtn}
              disabled={itemCount === 0}
              onClick={() => setView("confirm")}
            >
              去结算
            </button>
          </div>
        </section>
      ) : null}

      {view === "confirm" ? (
        <section style={styles.card}>
          <h3 style={{ margin: "0 0 8px" }}>确认订单</h3>
          <div style={styles.row}>
            <span style={{ color: palette.muted }}>商品件数</span>
            <span>{itemCount}</span>
          </div>
          <div style={styles.row}>
            <span style={{ color: palette.muted }}>商品金额</span>
            <span>{formatPrice(subtotal)}</span>
          </div>
          <div style={styles.row}>
            <span style={{ color: palette.muted }}>
              优惠{appliedCoupon ? `（${appliedCoupon}）` : ""}
            </span>
            <span style={{ color: discount > 0 ? palette.ok : undefined }}>
              -{formatPrice(discount)}
            </span>
          </div>
          <div style={{ ...styles.row, borderBottom: "none" }}>
            <strong>应付金额</strong>
            <strong style={{ fontSize: 18, color: palette.primary }}>
              {formatPrice(total)}
            </strong>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 12 }}>
            <button type="button" style={styles.ghostBtn} onClick={() => setView("cart")}>
              返回购物车
            </button>
            <button type="button" style={styles.primaryBtn} onClick={placeOrder}>
              提交订单
            </button>
          </div>
        </section>
      ) : null}

      {view === "done" ? (
        <section style={{ ...styles.card, textAlign: "center" }}>
          <div style={{ fontSize: 40 }}>✅</div>
          <h3 style={{ margin: "8px 0" }}>下单成功</h3>
          <p style={{ color: palette.muted }}>订单号 {orderId}</p>
          <p style={{ color: palette.muted }}>实付 {formatPrice(total)}</p>
          <button type="button" style={styles.ghostBtn} onClick={reset}>
            再下一单
          </button>
        </section>
      ) : null}
    </main>
  );
}
