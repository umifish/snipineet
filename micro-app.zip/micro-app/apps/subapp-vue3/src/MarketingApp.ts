import {
  isChannelEnvelope,
  postToParent,
  type GlobalPreferences
} from "@micro-app/core";
import { defineComponent, h, ref, computed, onMounted, onBeforeUnmount, type PropType } from "vue";

interface Campaign {
  id: string;
  title: string;
  channel: string;
  status: "draft" | "running" | "ended";
  budget: number;
  enrolled: number;
}

const CAMPAIGNS: Campaign[] = [
  { id: "c-spring", title: "春季焕新大促", channel: "App Push", status: "running", budget: 80000, enrolled: 1280 },
  { id: "c-newuser", title: "新人专享礼包", channel: "短信", status: "running", budget: 30000, enrolled: 642 },
  { id: "c-brand", title: "品牌联名活动", channel: "社媒", status: "draft", budget: 120000, enrolled: 0 },
  { id: "c-winback", title: "沉睡用户召回", channel: "邮件", status: "ended", budget: 20000, enrolled: 357 }
];

const STATUS_TEXT: Record<Campaign["status"], string> = {
  draft: "草稿",
  running: "进行中",
  ended: "已结束"
};

const STATUS_COLOR: Record<Campaign["status"], string> = {
  draft: "#94a3b8",
  running: "#16a34a",
  ended: "#64748b"
};

const card = "border:1px solid #e2e8f0;border-radius:12px;padding:16px;margin-top:16px";
const chipBase = "border:1px solid #e2e8f0;border-radius:999px;padding:4px 12px;cursor:pointer;font-size:13px;background:#fff";
const primaryBtn = "background:#7c3aed;color:#fff;border:none;border-radius:8px;padding:10px 18px;cursor:pointer;font-size:14px";
const input = "border:1px solid #e2e8f0;border-radius:8px;padding:8px 10px;font-size:14px;width:100%;box-sizing:border-box";

export const MarketingApp = defineComponent({
  name: "MarketingApp",
  props: {
    source: { type: String as PropType<"standalone" | "host">, default: "standalone" },
    routeBase: { type: String, default: "/campaign" },
    hostProps: { type: Object as PropType<Record<string, unknown>>, default: () => ({}) }
  },
  setup(props) {
    const filter = ref<"all" | Campaign["status"]>("all");
    const selectedId = ref<string | null>(null);
    const enrollName = ref("");
    const enrollMessage = ref<string | null>(null);
    const localEnrolled = ref<Record<string, number>>({});
    const preferences = ref<GlobalPreferences>({
      theme: "light",
      timezone: "Asia/Shanghai",
      language: "zh-CN"
    });
    const outboundData = ref('{"campaign":"spring","action":"enroll"}');
    const inbox = ref<string[]>([]);
    const relayTarget = ref("checkout-react18");
    const relaySeen = ref<Set<string>>(new Set());

    const visible = computed(() =>
      CAMPAIGNS.filter((c) => filter.value === "all" || c.status === filter.value)
    );
    const selected = computed(() =>
      CAMPAIGNS.find((c) => c.id === selectedId.value) ?? null
    );
    const totalBudget = computed(() =>
      CAMPAIGNS.reduce((sum, c) => sum + c.budget, 0)
    );

    const enrolledOf = (c: Campaign) => c.enrolled + (localEnrolled.value[c.id] ?? 0);

    const submitEnroll = () => {
      const target = selected.value;
      if (!target || !enrollName.value.trim()) {
        enrollMessage.value = "请输入报名人姓名";
        return;
      }
      localEnrolled.value = {
        ...localEnrolled.value,
        [target.id]: (localEnrolled.value[target.id] ?? 0) + 1
      };
      enrollMessage.value = `${enrollName.value.trim()} 已报名「${target.title}」`;
      enrollName.value = "";
      postToParent("marketing-vue3", "subapp:notify", {
        from: "subapp",
        level: "info",
        message: `${target.title} 报名成功`
      });
    };

    const onMessage = (event: MessageEvent) => {
      if (!isChannelEnvelope(event.data) || event.data.direction !== "host-to-subapp") {
        return;
      }
      const envelope = event.data;
      if (envelope.appName !== "marketing-vue3") {
        return;
      }

      if (envelope.type === "host:settings-change") {
        preferences.value = (envelope.payload as { preferences: GlobalPreferences }).preferences;
      }

      if (envelope.type === "host:data-sync" || envelope.type === "host:notify") {
        inbox.value = [
          `${envelope.type} @ ${new Date(envelope.timestamp).toLocaleTimeString()}`,
          ...inbox.value
        ].slice(0, 6);
      }

      if (envelope.type === "host:subapp-relay") {
        const relayPayload = envelope.payload as {
          fromApp: string;
          topic: string;
          data: Record<string, unknown>;
          messageId: string;
        };
        const alreadySeen = relaySeen.value.has(relayPayload.messageId);
        if (!alreadySeen) {
          relaySeen.value.add(relayPayload.messageId);
        }
        inbox.value = [
          `relay(${relayPayload.fromApp}) ${relayPayload.topic} #${relayPayload.messageId} @ ${new Date(envelope.timestamp).toLocaleTimeString()}`,
          ...inbox.value
        ].slice(0, 6);
        postToParent("marketing-vue3", "subapp:relay-ack", {
          from: "subapp",
          messageId: relayPayload.messageId,
          status: alreadySeen ? "ignored" : "received"
        });
      }
    };

    onMounted(() => {
      postToParent("marketing-vue3", "subapp:ready", { from: "subapp" });
      window.addEventListener("message", onMessage);
    });

    onBeforeUnmount(() => {
      window.removeEventListener("message", onMessage);
    });

    const sendDataToHost = () => {
      try {
        const data = JSON.parse(outboundData.value) as Record<string, unknown>;
        postToParent("marketing-vue3", "subapp:data-sync", { from: "subapp", data });
      } catch {
        postToParent("marketing-vue3", "subapp:notify", {
          from: "subapp",
          level: "error",
          message: "marketing 发送失败：JSON 解析错误"
        });
      }
    };

    const suggestEnglish = () => {
      postToParent("marketing-vue3", "subapp:settings-change", {
        from: "subapp",
        preferences: {
          ...preferences.value,
          language: "en-US"
        }
      });
    };

    const relayToSubapp = () => {
      try {
        const data = JSON.parse(outboundData.value) as Record<string, unknown>;
        postToParent("marketing-vue3", "subapp:relay", {
          from: "subapp",
          toApp: relayTarget.value,
          topic: "marketing:campaign-sync",
          data,
          messageId: `marketing-${Date.now().toString(36)}`,
          ttlMs: 30_000
        });
      } catch {
        postToParent("marketing-vue3", "subapp:notify", {
          from: "subapp",
          level: "error",
          message: "marketing 中继发送失败：JSON 解析错误"
        });
      }
    };

    const renderBanner = () =>
      h(
        "div",
        {
          style:
            "display:flex;justify-content:space-between;align-items:center;background:#faf5ff;border:1px solid #e9d5ff;border-radius:10px;padding:8px 12px;font-size:13px;color:#7c3aed"
        },
        [
          h("strong", "营销中心 · Vue 3"),
          h(
            "span",
            `${props.source === "host" ? "宿主挂载" : "独立运行"} · 总预算 ¥${totalBudget.value.toLocaleString()}`
          )
        ]
      );

    const renderChannel = () =>
      h("section", { style: card }, [
        h("h3", { style: "margin:0 0 8px" }, "主子通信"),
        h(
          "p",
          { style: "margin:0 0 8px;color:#64748b;font-size:13px" },
          `主题 ${preferences.value.theme} · 时区 ${preferences.value.timezone} · 语言 ${preferences.value.language}`
        ),
        h("div", { style: "display:flex;gap:8px;align-items:center" }, [
          h(
            "select",
            {
              value: relayTarget.value,
              onInput: (e: Event) => {
                relayTarget.value = (e.target as HTMLSelectElement).value;
              }
            },
            [
              h("option", { attrs: { value: "checkout-react18" } }, "checkout-react18"),
              h("option", { attrs: { value: "legacy-vue2-dashboard" } }, "legacy-vue2-dashboard"),
              h("option", { attrs: { value: "self-embed-react19" } }, "self-embed-react19")
            ]
          ),
          h("input", {
            style: input,
            value: outboundData.value,
            onInput: (e: Event) => {
              outboundData.value = (e.target as HTMLInputElement).value;
            }
          }),
          h(
            "button",
            {
              style: primaryBtn,
              onClick: sendDataToHost
            },
            "回传数据"
          ),
          h(
            "button",
            {
              style: primaryBtn,
              onClick: suggestEnglish
            },
            "建议切换英文"
          ),
          h(
            "button",
            {
              style: primaryBtn,
              onClick: relayToSubapp
            },
            "发送给子应用"
          )
        ]),
        h(
          "ul",
          { style: "margin:8px 0 0;padding-left:18px" },
          inbox.value.map((line) => h("li", { key: line }, line))
        )
      ]);

    const renderFilters = () =>
      h("div", { style: "display:flex;gap:8px;margin-top:12px;flex-wrap:wrap" },
        (["all", "running", "draft", "ended"] as const).map((key) =>
          h(
            "button",
            {
              key,
              style:
                chipBase +
                (filter.value === key ? ";border-color:#7c3aed;color:#7c3aed;font-weight:600" : ""),
              onClick: () => {
                filter.value = key;
              }
            },
            key === "all" ? "全部" : STATUS_TEXT[key]
          )
        )
      );

    const renderList = () =>
      h("section", { style: card }, [
        h("h3", { style: "margin:0 0 8px" }, `活动列表（${visible.value.length}）`),
        ...visible.value.map((c) =>
          h(
            "div",
            {
              key: c.id,
              style:
                "display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid #e2e8f0;cursor:pointer",
              onClick: () => {
                selectedId.value = c.id;
                enrollMessage.value = null;
              }
            },
            [
              h("div", [
                h("div", c.title),
                h(
                  "div",
                  { style: "color:#64748b;font-size:13px" },
                  `${c.channel} · 已报名 ${enrolledOf(c)}`
                )
              ]),
              h(
                "span",
                {
                  style: `color:${STATUS_COLOR[c.status]};font-size:13px;font-weight:600`
                },
                STATUS_TEXT[c.status]
              )
            ]
          )
        )
      ]);

    const renderDetail = () => {
      const c = selected.value;
      if (!c) {
        return h(
          "section",
          { style: card + ";color:#64748b" },
          "点击左侧活动查看详情并报名"
        );
      }
      return h("section", { style: card }, [
        h("h3", { style: "margin:0 0 4px" }, c.title),
        h(
          "p",
          { style: "color:#64748b;font-size:13px;margin:0 0 12px" },
          `渠道 ${c.channel} · 预算 ¥${c.budget.toLocaleString()} · 状态 ${STATUS_TEXT[c.status]}`
        ),
        h("div", { style: "display:flex;gap:8px;align-items:center" }, [
          h("input", {
            style: input,
            placeholder: "报名人姓名",
            value: enrollName.value,
            onInput: (e: Event) => {
              enrollName.value = (e.target as HTMLInputElement).value;
            }
          })
        ]),
        h(
          "div",
          { style: "margin-top:12px;display:flex;gap:8px;align-items:center" },
          [
            h(
              "button",
              {
                style: primaryBtn,
                disabled: c.status !== "running",
                onClick: submitEnroll
              },
              c.status === "running" ? "立即报名" : "活动未开放"
            ),
            enrollMessage.value
              ? h("span", { style: "color:#16a34a;font-size:13px" }, enrollMessage.value)
              : null
          ]
        )
      ]);
    };

    return () =>
      h(
        "main",
        {
          style:
            "font-family:system-ui,sans-serif;color:#0f172a;padding:16px;max-width:760px;margin:0 auto"
        },
        [
          renderBanner(),
          renderChannel(),
          renderFilters(),
          h(
            "div",
            { style: "display:grid;grid-template-columns:1fr 1fr;gap:16px;align-items:start" },
            [renderList(), renderDetail()]
          )
        ]
      );
  }
});
