import { useEffect, useMemo, useRef, useState, type ReactElement } from "react";
import {
  createAppRegistry,
  createBridge,
  createDebugTimeline,
  createPreloadManager,
  createWujieHostRuntime,
  isChannelEnvelope,
  normalizePath,
  originFromUrl,
  parseQuery,
  postToParent,
  postToIframe,
  react18Adapter,
  react19Adapter,
  serializeQuery,
  vue2Adapter,
  vue3Adapter,
  type AppManifest,
  type AppRegistry,
  type BridgeEventMap,
  type DebugLevel,
  type DebugTimeline,
  type DebugTimelineRecord,
  type GlobalPreferences,
  type PreloadMode
} from "@micro-app/core";

const seedApps: AppManifest[] = [
  {
    name: "self-embed-react19",
    framework: "react19",
    entry: "http://localhost:5174/",
    wujie: {
      sync: true,
      alive: false,
      routePrefix: {
        "/self-embed": "/self-embed"
      }
    },
    preload: [
      { mode: "critical", priority: 100, timeoutMs: 3000, retries: 1 },
      { mode: "idle", priority: 70, timeoutMs: 5000 },
      { mode: "intent", priority: 90, timeoutMs: 3000 }
    ],
    routes: [{ name: "self-embed", path: "/self-embed" }]
  },
  {
    name: "checkout-react18",
    framework: "react18",
    entry: "http://localhost:5175/",
    wujie: {
      sync: true,
      alive: false
    },
    preload: [
      { mode: "critical", priority: 96, timeoutMs: 3000, retries: 1 },
      { mode: "intent", priority: 90, timeoutMs: 3000 },
      { mode: "manual", priority: 40, timeoutMs: 5000 }
    ],
    routes: [{ name: "checkout", path: "/checkout" }]
  },
  {
    name: "legacy-vue2-dashboard",
    framework: "vue2",
    entry: "http://localhost:5177/",
    wujie: {
      sync: true,
      alive: false
    },
    preload: [
      { mode: "critical", priority: 95, timeoutMs: 3000, retries: 1 },
      { mode: "intent", priority: 80, timeoutMs: 3000 }
    ],
    routes: [{ name: "dashboard", path: "/dashboard" }]
  },
  {
    name: "marketing-vue3",
    framework: "vue3",
    entry: "http://localhost:5176/",
    wujie: {
      sync: true,
      alive: false
    },
    preload: [
      { mode: "idle", priority: 60, timeoutMs: 5000 },
      { mode: "intent", priority: 80, timeoutMs: 3000 }
    ],
    routes: [{ name: "campaign", path: "/campaign" }]
  },
  {
    name: "broken-debug-app",
    framework: "unknown",
    entry: "http://localhost:5199/",
    wujie: {
      sync: true,
      alive: false
    },
    routes: [{ name: "broken", path: "/broken" }]
  },
  {
    // 故障注入：预加载超时（loader 永不结束，触发 preload timeout）
    name: "fault-timeout-app",
    framework: "unknown",
    entry: "http://localhost:5173/",
    wujie: { sync: true, alive: false },
    preload: [{ mode: "manual", priority: 10, timeoutMs: 200 }],
    loader: () => new Promise<never>(() => {})
  },
  {
    // 故障注入：资源 404（loader 直接拒绝，模拟入口资源缺失）
    name: "fault-404-app",
    framework: "unknown",
    entry: "http://localhost:5173/",
    wujie: { sync: true, alive: false },
    preload: [{ mode: "manual", priority: 10, timeoutMs: 3000 }],
    loader: () => Promise.reject(new Error("resource 404: subapp entry not found"))
  },
  {
    // 故障注入：网络错误（loader 拒绝，模拟连接被拒）
    name: "fault-network-app",
    framework: "unknown",
    entry: "http://localhost:5173/",
    wujie: { sync: true, alive: false },
    preload: [{ mode: "manual", priority: 10, timeoutMs: 3000 }],
    loader: () => Promise.reject(new Error("network error: ECONNREFUSED"))
  },
  {
    // 故障注入（挂载层）：挂载阶段超时（预检指向不可路由地址，AbortSignal.timeout 触发）
    name: "fault-mount-timeout-app",
    framework: "unknown",
    entry: "http://192.0.2.1:5999/",
    wujie: { sync: true, alive: false, preflight: true, mountTimeoutMs: 1200 }
  },
  {
    // 故障注入（挂载层）：资源 404（预检命中真实 404，区别于网络错误）
    name: "fault-mount-404-app",
    framework: "unknown",
    entry: "http://localhost:5175/node_modules/.vite/deps/__missing__.js",
    wujie: { sync: true, alive: false, preflight: true, mountTimeoutMs: 4000 }
  },
  {
    // 故障注入（挂载层）：网络错误（端口无监听，fetch 抛出 TypeError）
    name: "fault-mount-network-app",
    framework: "unknown",
    entry: "http://localhost:5199/",
    wujie: { sync: true, alive: false, preflight: true, mountTimeoutMs: 4000 }
  }
];

function createDependencies(): {
  registry: AppRegistry;
  bridge: ReturnType<typeof createBridge<BridgeEventMap>>;
} {
  const registry = createAppRegistry(seedApps);
  const bridge = createBridge<BridgeEventMap>();
  return { registry, bridge };
}

export interface HostShellAppProps {
  source?: "standalone" | "host";
  routeBase?: string;
  hostProps?: Record<string, unknown>;
}

type PreloadStrategy = "manager-only" | "wujie-only" | "hybrid";

export function App(props: HostShellAppProps = {}): ReactElement {
  const source = props.source ?? "standalone";
  const hostProps = props.hostProps ?? {};
  const hasInjectedAppName = typeof hostProps["appName"] === "string";
  const hasInjectedParentOrigin = typeof hostProps["parentOrigin"] === "string";
  const selfAppName =
    hasInjectedAppName ? (hostProps["appName"] as string) : "host-shell";
  const initialRouteBase = normalizePath(props.routeBase ?? "/workspace/home");
  const { registry, bridge } = useMemo(() => createDependencies(), []);
  const preloadManager = useMemo(
    () => createPreloadManager({ registry, bridge, maxConcurrency: 2 }),
    [registry, bridge]
  );
  const hostRuntime = useMemo(
    () => createWujieHostRuntime({ registry, bridge }),
    [registry, bridge]
  );
  const appOriginByName = useMemo(() => {
    const mapping = new Map<string, string>();
    for (const app of registry.list()) {
      const origin = originFromUrl(app.entry);
      if (origin) {
        mapping.set(app.name, origin);
      }
    }
    return mapping;
  }, [registry]);

  const [debugRows, setDebugRows] = useState<DebugTimelineRecord[]>([]);
  const [debugKeyword, setDebugKeyword] = useState("");
  const [debugLevel, setDebugLevel] = useState<DebugLevel | "all">("all");
  const [debugAppFilter, setDebugAppFilter] = useState<string>("all");
  const [route, setRoute] = useState(initialRouteBase);
  const [preferences, setPreferences] = useState<GlobalPreferences>({
    theme: "light",
    timezone: "Asia/Shanghai",
    language: "zh-CN"
  });
  const [hostDataInput, setHostDataInput] = useState('{"workspace":"alpha","featureFlag":true}');
  const [hostNotice, setHostNotice] = useState("宿主通知：请刷新活动预算");
  const [subappInbox, setSubappInbox] = useState<string[]>([]);
  const [preloadStrategy, setPreloadStrategy] = useState<PreloadStrategy>("manager-only");
  const [routeIsolationMode, setRouteIsolationMode] = useState<"strict" | "inherit">(() => {
    const mode = hostProps["routeIsolation"];
    if (mode === "strict" || mode === "inherit") {
      return mode;
    }
    return source === "host" ? "strict" : "inherit";
  });
  const [selectedApp, setSelectedApp] = useState(seedApps[0]?.name ?? "");
  const [mountedApp, setMountedApp] = useState<string | null>(null);
  const [mountError, setMountError] = useState<string | null>(null);
  const timelineRef = useRef<DebugTimeline | null>(null);
  const bootPreloadedRef = useRef(false);
  const missingContractWarnedRef = useRef<{ appName: boolean; parentOrigin: boolean }>({
    appName: false,
    parentOrigin: false
  });
  const parentTargetOrigin = useMemo(() => {
    const raw = hostProps["parentOrigin"];
    if (typeof raw !== "string" || raw.length === 0) {
      return "*";
    }
    return originFromUrl(raw) ?? raw;
  }, [hostProps]);

  useEffect(() => {
    const pref = hostProps["preferences"] as Partial<GlobalPreferences> | undefined;
    if (pref && typeof pref === "object") {
      setPreferences((prev) => ({
        theme:
          pref.theme === "light" || pref.theme === "dark" || pref.theme === "system"
            ? pref.theme
            : prev.theme,
        timezone: typeof pref.timezone === "string" ? pref.timezone : prev.timezone,
        language: typeof pref.language === "string" ? pref.language : prev.language
      }));
    }

    const hostData = hostProps["data"] as Record<string, unknown> | undefined;
    if (hostData && typeof hostData === "object") {
      setHostDataInput(JSON.stringify(hostData));
    }
  }, [hostProps]);

  useEffect(() => {
    if (source !== "host") {
      return;
    }

    if (!hasInjectedAppName && !missingContractWarnedRef.current.appName) {
      const message = "子应用契约告警: 缺少 appName 注入，已降级为 host-shell";
      bridge.emit("notify:message", {
        source: "subapp",
        appName: selfAppName,
        level: "warn",
        message
      });
      console.warn(`[host-shell] ${message}`);
      missingContractWarnedRef.current.appName = true;
    }

    if (!hasInjectedParentOrigin && !missingContractWarnedRef.current.parentOrigin) {
      const message = "子应用契约告警: 缺少 parentOrigin 注入，postMessage targetOrigin 已降级为 '*'";
      bridge.emit("notify:message", {
        source: "subapp",
        appName: selfAppName,
        level: "warn",
        message
      });
      console.warn(`[host-shell] ${message}`);
      missingContractWarnedRef.current.parentOrigin = true;
    }
  }, [bridge, source, selfAppName, hasInjectedAppName, hasInjectedParentOrigin]);

  useEffect(() => {
    if (source !== "host") {
      return;
    }

    postToParent(selfAppName, "subapp:ready", { from: "subapp" }, parentTargetOrigin);

    const onParentMessage = (event: MessageEvent): void => {
      if (!isChannelEnvelope(event.data) || event.data.direction !== "host-to-subapp") {
        return;
      }
      if (event.source !== window.parent) {
        return;
      }
      if (parentTargetOrigin !== "*" && event.origin !== parentTargetOrigin) {
        return;
      }

      const envelope = event.data;
      if (envelope.appName !== selfAppName) {
        return;
      }

      if (envelope.type === "host:settings-change") {
        const settingsPayload = envelope.payload as { preferences: GlobalPreferences };
        setPreferences(settingsPayload.preferences);
      }

      if (envelope.type === "host:data-sync") {
        const dataPayload = envelope.payload as { data: Record<string, unknown> };
        setHostDataInput(JSON.stringify(dataPayload.data));
      }

      if (envelope.type === "host:notify") {
        const notifyPayload = envelope.payload as { message: string };
        setHostNotice(notifyPayload.message);
      }

      setSubappInbox((prev) => {
        const next = [
          `[${new Date(envelope.timestamp).toLocaleTimeString()}] parent · ${envelope.type}`,
          ...prev
        ];
        return next.slice(0, 8);
      });
    };

    window.addEventListener("message", onParentMessage);
    return () => {
      window.removeEventListener("message", onParentMessage);
    };
  }, [source, selfAppName, parentTargetOrigin]);

  useEffect(() => {
    setRoute(initialRouteBase);
  }, [initialRouteBase]);

  useEffect(() => {
    const strategy = hostProps["preloadStrategy"];
    if (strategy === "manager-only" || strategy === "wujie-only" || strategy === "hybrid") {
      setPreloadStrategy(strategy);
    }
  }, [hostProps]);

  const preloadByStrategy = async (appName: string, mode: PreloadMode): Promise<void> => {
    if (preloadStrategy === "wujie-only") {
      hostRuntime.preloadByWujie(appName, false);
      return;
    }

    await preloadManager.preloadApp(appName, mode);
    if (preloadStrategy === "hybrid") {
      hostRuntime.preloadByWujie(appName, false);
    }
  };

  const preloadBootApps = async (): Promise<void> => {
    const apps = registry.list();
    if (preloadStrategy === "wujie-only") {
      for (const app of apps) {
        hostRuntime.preloadByWujie(app.name, false);
      }
      return;
    }

    await preloadManager.preloadApps("critical");
    await preloadManager.preloadApps("idle");
    if (preloadStrategy === "hybrid") {
      for (const app of apps) {
        hostRuntime.preloadByWujie(app.name, false);
      }
    }
  };

  useEffect(() => {
    const timeline = createDebugTimeline<BridgeEventMap>({
      bridge,
      eventTypes: [
        "preload:start",
        "preload:success",
        "preload:error",
        "wujie:mount:start",
        "wujie:mount:success",
        "wujie:mount:error",
        "wujie:unmount",
        "route:sync",
        "route:navigate",
        "channel:host->subapp",
        "channel:subapp->host",
        "channel:subapp->subapp",
        "settings:change",
        "notify:message"
      ],
      onRecord: (records) => {
        setDebugRows(records);
      }
    });

    timelineRef.current = timeline;

    if (!bootPreloadedRef.current) {
      bootPreloadedRef.current = true;
      void preloadBootApps();
    }

    return () => {
      timelineRef.current = null;
      timeline.stop();
    };
  }, [bridge, preloadManager, preloadStrategy, hostRuntime, registry]);

  useEffect(() => {
    const mode = hostProps["routeIsolation"];
    if (mode === "strict" || mode === "inherit") {
      setRouteIsolationMode(mode);
      return;
    }
    if (source === "host") {
      setRouteIsolationMode("strict");
    }
  }, [hostProps, source]);

  useEffect(() => {
    const handlePopState = (event: PopStateEvent): void => {
      const state = event.state as { hostApp?: string | null } | null;
      const target = state && "hostApp" in state ? state.hostApp ?? null : appNameFromHash();
      void applyMountRef.current(target);
    };

    const isolateInSubapp = source === "host" && routeIsolationMode === "strict";
    if (isolateInSubapp) {
      return;
    }

    const initial = appNameFromHash();
    window.history.replaceState(
      { hostApp: initial },
      "",
      initial
        ? `#/app/${encodeURIComponent(initial)}`
        : `${window.location.pathname}${window.location.search}`
    );
    if (initial) {
      void applyMountRef.current(initial);
    }

    window.addEventListener("popstate", handlePopState);
    return () => {
      window.removeEventListener("popstate", handlePopState);
    };
  }, [registry, source, routeIsolationMode]);

  const filteredDebugRows = useMemo(() => {
    const timeline = timelineRef.current;
    if (!timeline) {
      return debugRows;
    }

    return timeline.query({
      keyword: debugKeyword,
      level: debugLevel,
      appName: debugAppFilter === "all" ? undefined : debugAppFilter
    });
  }, [debugRows, debugKeyword, debugLevel, debugAppFilter]);

  const normalizeRoutePreview = () => {
    const path = normalizePath(route);
    const query = parseQuery("?locale=zh-CN&tab=overview");
    return `${path}${serializeQuery(query)}`;
  };

  const preloadByIntent = async (appName: string, mode: PreloadMode) => {
    await preloadByStrategy(appName, mode);
  };

  const resolveMountedIframeWindow = (): Window | null => {
    const mountSlot = document.getElementById("wujie-mount-slot");
    if (!mountSlot) {
      return null;
    }
    const iframe = mountSlot.querySelector("iframe");
    return iframe?.contentWindow ?? null;
  };

  type HostRelayPayload = {
    from: "host";
    fromApp: string;
    topic: string;
    data: Record<string, unknown>;
    messageId: string;
    createdAt: number;
    ttlMs: number;
  };

  const relayQueueRef = useRef<Map<string, HostRelayPayload[]>>(new Map());
  const relayPendingRef = useRef<Map<string, HostRelayPayload>>(new Map());

  const createRelayMessageId = (appName: string): string =>
    `${appName}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

  const normalizeTtlMs = (ttlMs: number | undefined): number => {
    if (typeof ttlMs !== "number" || Number.isNaN(ttlMs)) {
      return 30_000;
    }
    return Math.min(300_000, Math.max(1_000, Math.floor(ttlMs)));
  };

  const relayExpired = (payload: HostRelayPayload): boolean =>
    Date.now() > payload.createdAt + payload.ttlMs;

  const postHostMessageToMountedApp = (
    appName: string,
    type: "host:data-sync" | "host:subapp-relay" | "host:settings-change" | "host:notify",
    payload:
      | { from: "host"; data: Record<string, unknown> }
      | HostRelayPayload
      | { from: "host"; preferences: GlobalPreferences }
      | { from: "host"; level: "info" | "warn" | "error"; message: string }
  ): boolean => {
    if (type === "host:subapp-relay" && "messageId" in payload && relayExpired(payload)) {
      relayPendingRef.current.delete(payload.messageId);
      bridge.emit("notify:message", {
        source: "host",
        appName,
        level: "warn",
        message: `中继消息过期并丢弃: ${payload.messageId}`
      });
      return false;
    }

    if (mountedAppRef.current !== appName) {
      return false;
    }
    const iframeWindow = resolveMountedIframeWindow();
    if (!iframeWindow) {
      return false;
    }
    const targetOrigin = appOriginByName.get(appName) ?? "*";
    postToIframe(iframeWindow, appName, type, payload, targetOrigin);
    bridge.emit("channel:host->subapp", { appName, type });
    return true;
  };

  const sendToSubapp = (
    type: "host:data-sync" | "host:subapp-relay" | "host:settings-change" | "host:notify",
    payload:
      | { from: "host"; data: Record<string, unknown> }
      | HostRelayPayload
      | { from: "host"; preferences: GlobalPreferences }
      | { from: "host"; level: "info" | "warn" | "error"; message: string }
  ): void => {
    if (!mountedAppRef.current) {
      setMountError("请先挂载子应用，再发送消息");
      return;
    }

    const sent = postHostMessageToMountedApp(mountedAppRef.current, type, payload);
    if (!sent) {
      setMountError("未找到子应用 iframe，稍后重试");
      return;
    }
  };

  useEffect(() => {
    const handler = (event: MessageEvent): void => {
      if (!isChannelEnvelope(event.data) || event.data.direction !== "subapp-to-host") {
        return;
      }

       const mounted = mountedAppRef.current;
      if (!mounted) {
        return;
      }

      const expectedOrigin = appOriginByName.get(mounted);
      if (expectedOrigin && event.origin !== expectedOrigin) {
        return;
      }

      const mountedIframeWindow = resolveMountedIframeWindow();
      if (mountedIframeWindow && event.source !== mountedIframeWindow) {
        return;
      }

      const envelope = event.data;
      bridge.emit("channel:subapp->host", {
        appName: envelope.appName,
        type: envelope.type
      });

      if (envelope.type === "subapp:notify") {
        const notifyPayload = envelope.payload as {
          level: "info" | "warn" | "error";
          message: string;
        };
        bridge.emit("notify:message", {
          source: "subapp",
          appName: envelope.appName,
          level: notifyPayload.level,
          message: notifyPayload.message
        });
      }

      if (envelope.type === "subapp:settings-change") {
        const settingsPayload = envelope.payload as { preferences: GlobalPreferences };
        setPreferences(settingsPayload.preferences);
        bridge.emit("settings:change", {
          source: "subapp",
          appName: envelope.appName,
          theme: settingsPayload.preferences.theme,
          timezone: settingsPayload.preferences.timezone,
          language: settingsPayload.preferences.language
        });
      }

      if (envelope.type === "subapp:relay") {
        const relayPayload = envelope.payload as {
          toApp: string;
          topic: string;
          data: Record<string, unknown>;
          messageId?: string;
          ttlMs?: number;
        };
        bridge.emit("channel:subapp->subapp", {
          fromApp: envelope.appName,
          toApp: relayPayload.toApp,
          topic: relayPayload.topic
        });

        const messageId = relayPayload.messageId ?? createRelayMessageId(envelope.appName);
        const hostRelayPayload: HostRelayPayload = {
          from: "host",
          fromApp: envelope.appName,
          topic: relayPayload.topic,
          data: relayPayload.data,
          messageId,
          createdAt: Date.now(),
          ttlMs: normalizeTtlMs(relayPayload.ttlMs)
        };

        relayPendingRef.current.set(messageId, hostRelayPayload);

        const delivered = postHostMessageToMountedApp(
          relayPayload.toApp,
          "host:subapp-relay",
          hostRelayPayload
        );

        if (!delivered) {
          if (relayExpired(hostRelayPayload)) {
            relayPendingRef.current.delete(messageId);
            bridge.emit("notify:message", {
              source: "host",
              appName: relayPayload.toApp,
              level: "warn",
              message: `目标应用 ${relayPayload.toApp} 的中继消息已过期并丢弃: ${messageId}`
            });
            return;
          }

          const queue = relayQueueRef.current.get(relayPayload.toApp) ?? [];
          queue.push(hostRelayPayload);
          relayQueueRef.current.set(relayPayload.toApp, queue.slice(-20));
          bridge.emit("notify:message", {
            source: "host",
            appName: relayPayload.toApp,
            level: "warn",
            message: `目标应用 ${relayPayload.toApp} 未挂载，消息已入队: ${messageId}`
          });
        }
      }

      if (envelope.type === "subapp:relay-ack") {
        const ackPayload = envelope.payload as {
          messageId: string;
          status: "received" | "ignored";
        };
        relayPendingRef.current.delete(ackPayload.messageId);
        bridge.emit("notify:message", {
          source: "subapp",
          appName: envelope.appName,
          level: ackPayload.status === "received" ? "info" : "warn",
          message: `中继回执 ${ackPayload.status}: ${ackPayload.messageId}`
        });
      }

      setSubappInbox((prev) => {
        const next = [
          `[${new Date(envelope.timestamp).toLocaleTimeString()}] ${envelope.appName} · ${envelope.type}`,
          ...prev
        ];
        return next.slice(0, 8);
      });
    };

    window.addEventListener("message", handler);
    return () => {
      window.removeEventListener("message", handler);
    };
  }, [bridge, appOriginByName]);

  const mountedAppRef = useRef<string | null>(null);

  const applyMount = async (appName: string | null): Promise<void> => {
    const current = mountedAppRef.current;
    if (current === appName) {
      return;
    }

    setMountError(null);

    if (current) {
      hostRuntime.unmountApp(current);
      mountedAppRef.current = null;
      setMountedApp(null);
    }

    if (!appName) {
      return;
    }

    // 乐观占位：先标记目标，避免并发（如 StrictMode 双调用、深链初始化）重复挂载
    mountedAppRef.current = appName;

    try {
      await hostRuntime.mountApp({
        appName,
        el: "#wujie-mount-slot",
        props: {
          routeBase: normalizePath(route),
          debug: true,
          source: "host-shell"
        }
      });
      setMountedApp(appName);
      setSelectedApp(appName);

      const queued = relayQueueRef.current.get(appName) ?? [];
      if (queued.length > 0) {
        for (const payload of queued) {
          if (relayExpired(payload)) {
            relayPendingRef.current.delete(payload.messageId);
            continue;
          }
          postHostMessageToMountedApp(appName, "host:subapp-relay", payload);
        }
        relayQueueRef.current.delete(appName);
      }
    } catch (error) {
      if (mountedAppRef.current === appName) {
        mountedAppRef.current = null;
      }
      setMountedApp(null);
      setMountError(error instanceof Error ? error.message : "mount failed");
    }
  };

  const applyMountRef = useRef(applyMount);
  applyMountRef.current = applyMount;

  const appNameFromHash = (): string | null => {
    const match = window.location.hash.match(/^#\/app\/(.+)$/);
    const raw = match?.[1];
    if (!raw) {
      return null;
    }
    const name = decodeURIComponent(raw);
    return registry.getByName(name) ? name : null;
  };

  const navigateToApp = (appName: string): void => {
    if (mountedAppRef.current === appName) {
      return;
    }
    const isolateInSubapp = source === "host" && routeIsolationMode === "strict";
    if (!isolateInSubapp) {
      window.history.pushState({ hostApp: appName }, "", `#/app/${encodeURIComponent(appName)}`);
    }
    void applyMount(appName);
  };

  const navigateHome = (): void => {
    if (!mountedAppRef.current) {
      return;
    }
    const isolateInSubapp = source === "host" && routeIsolationMode === "strict";
    if (!isolateInSubapp) {
      window.history.pushState({ hostApp: null }, "", `${window.location.pathname}${window.location.search}`);
    }
    void applyMount(null);
  };

  const goBack = (): void => {
    const isolateInSubapp = source === "host" && routeIsolationMode === "strict";
    if (isolateInSubapp) {
      void applyMount(null);
      return;
    }
    window.history.back();
  };

  const emitRouteSync = () => {
    const path = normalizePath(route);
    const query = parseQuery("?locale=zh-CN&tab=overview");
    bridge.emit("route:sync", { source: "host", path });
    bridge.emit("route:navigate", { appName: selectedApp, path, query });
  };

  const syncHostData = () => {
    try {
      const parsed = JSON.parse(hostDataInput) as Record<string, unknown>;
      sendToSubapp("host:data-sync", { from: "host", data: parsed });
      setMountError(null);
    } catch {
      setMountError("数据 JSON 格式错误，请修正后再发送");
    }
  };

  const syncPreferences = () => {
    sendToSubapp("host:settings-change", { from: "host", preferences });
    bridge.emit("settings:change", {
      source: "host",
      theme: preferences.theme,
      timezone: preferences.timezone,
      language: preferences.language
    });
    setMountError(null);
  };

  const sendHostNotice = () => {
    sendToSubapp("host:notify", {
      from: "host",
      level: "info",
      message: hostNotice.trim() || "宿主通知"
    });
    bridge.emit("notify:message", {
      source: "host",
      appName: mountedAppRef.current ?? undefined,
      level: "info",
      message: hostNotice.trim() || "宿主通知"
    });
    if (source === "host") {
      postToParent(selfAppName, "subapp:notify", {
        from: "subapp",
        level: "info",
        message: hostNotice.trim() || "host-shell 已接收上层通知"
      }, parentTargetOrigin);
    }
    setMountError(null);
  };

  const exportDebugJson = () => {
    const text = JSON.stringify(filteredDebugRows, null, 2);
    const blob = new Blob([text], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `micro-debug-${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const clearDebugTimeline = () => {
    timelineRef.current?.clear();
  };

  return (
    <main className="layout">
      <aside className="sidebar" data-testid="mount-nav">
        <h2>wujie 挂载调试</h2>
        <nav className="app-nav">
          {registry.list().map((app) => {
            const active = mountedApp === app.name;
            const focused = selectedApp === app.name;
            return (
              <button
                key={app.name}
                type="button"
                className={`app-nav-item${active ? " active" : ""}${focused ? " focused" : ""}`}
                onClick={() => {
                  setSelectedApp(app.name);
                  navigateToApp(app.name);
                }}
              >
                <span className="app-nav-dot" data-active={active} />
                <span className="app-nav-name">{app.name}</span>
              </button>
            );
          })}
        </nav>

        <div className="sidebar-controls">
          <select
            data-testid="mount-app-select"
            value={selectedApp}
            onChange={(event) => setSelectedApp(event.target.value)}
          >
            {registry.list().map((app) => (
              <option key={app.name} value={app.name}>
                {app.name}
              </option>
            ))}
          </select>
          <div className="row">
            <button
              data-testid="back-btn"
              type="button"
              onClick={goBack}
              disabled={source === "host" && routeIsolationMode === "strict" && !mountedApp}
            >
              返回
            </button>
            <button data-testid="mount-btn" type="button" onClick={() => navigateToApp(selectedApp)}>
              挂载子应用
            </button>
            <button data-testid="unmount-btn" type="button" onClick={navigateHome}>
              卸载子应用
            </button>
          </div>
          <p>当前挂载: {mountedApp ?? "无"}</p>
          {mountError ? (
            <p data-testid="mount-error" className="error">
              挂载失败: {mountError}
            </p>
          ) : null}
        </div>
      </aside>

      <div className="content">
        <header>
          <h1>Host Shell · React 19</h1>
          <p>
            已接入预加载、路由一致性、主子/子子通信。当前模式: {source === "host" ? "子应用挂载" : "独立主应用"}
          </p>
        </header>

        <section className="card">
          <h2>子应用预加载</h2>
          <div className="row">
            <label>
              预加载策略
              <select
                value={preloadStrategy}
                onChange={(event) =>
                  setPreloadStrategy(event.target.value as PreloadStrategy)
                }
              >
                <option value="manager-only">manager-only（推荐）</option>
                <option value="wujie-only">wujie-only</option>
                <option value="hybrid">hybrid（兼容）</option>
              </select>
            </label>
            <p>当前策略：{preloadStrategy}</p>
          </div>
          <div className="row">
            {registry.list().map((app) => (
              <button
                key={app.name}
                type="button"
                onMouseEnter={() => void preloadByIntent(app.name, "intent")}
                onClick={() => void preloadByIntent(app.name, "manual")}
              >
                预热 {app.name}
              </button>
            ))}
          </div>
          <ul>
            {registry.list().map((app) => {
              const state = preloadManager.getPreloadState(app.name);
              return (
                <li key={app.name}>
                  {app.name}: {state?.status ?? "idle"}
                </li>
              );
            })}
          </ul>
        </section>

        <section className="card">
          <h2>路由一致性</h2>
          {source === "host" ? (
            <label>
              子应用模式路由策略
              <select
                value={routeIsolationMode}
                onChange={(event) =>
                  setRouteIsolationMode(event.target.value as "strict" | "inherit")
                }
              >
                <option value="strict">strict（默认，不接管外层历史）</option>
                <option value="inherit">inherit（沿用浏览器历史）</option>
              </select>
            </label>
          ) : null}
          <input
            data-testid="route-input"
            value={route}
            onChange={(event) => setRoute(event.target.value)}
          />
          <p>归一化结果: {normalizeRoutePreview()}</p>
          <button data-testid="route-sync-btn" type="button" onClick={emitRouteSync}>
            发送路由同步事件
          </button>
          <p>
            适配器基准: {vue2Adapter.kind}, {vue3Adapter.kind}, {react18Adapter.kind}, {react19Adapter.kind}
          </p>
        </section>

        <section className="card">
          <h2>主子应用通信</h2>
          <p>已挂载目标: {mountedApp ?? "无"}</p>
          <div className="row">
            <label>
              主题
              <select
                value={preferences.theme}
                onChange={(event) =>
                  setPreferences((prev) => ({
                    ...prev,
                    theme: event.target.value as GlobalPreferences["theme"]
                  }))
                }
              >
                <option value="light">light</option>
                <option value="dark">dark</option>
                <option value="system">system</option>
              </select>
            </label>
            <label>
              时区
              <select
                value={preferences.timezone}
                onChange={(event) =>
                  setPreferences((prev) => ({ ...prev, timezone: event.target.value }))
                }
              >
                <option value="Asia/Shanghai">Asia/Shanghai</option>
                <option value="Asia/Tokyo">Asia/Tokyo</option>
                <option value="Europe/London">Europe/London</option>
                <option value="America/New_York">America/New_York</option>
              </select>
            </label>
            <label>
              语言
              <select
                value={preferences.language}
                onChange={(event) =>
                  setPreferences((prev) => ({ ...prev, language: event.target.value }))
                }
              >
                <option value="zh-CN">zh-CN</option>
                <option value="en-US">en-US</option>
                <option value="ja-JP">ja-JP</option>
              </select>
            </label>
            <button type="button" onClick={syncPreferences}>
              发送主题/时区/语言变更
            </button>
          </div>
          <div className="row">
            <input
              value={hostDataInput}
              onChange={(event) => setHostDataInput(event.target.value)}
              placeholder="发送给子应用的数据 JSON"
            />
            <button type="button" onClick={syncHostData}>
              发送业务数据
            </button>
          </div>
          <div className="row">
            <input
              value={hostNotice}
              onChange={(event) => setHostNotice(event.target.value)}
              placeholder="宿主通知消息"
            />
            <button type="button" onClick={sendHostNotice}>
              发送消息通知
            </button>
          </div>
          <ul>
            {subappInbox.map((line) => (
              <li key={line}>{line}</li>
            ))}
          </ul>
        </section>

        <section className="card">
          <h2>挂载视图</h2>
          <p>当前挂载: {mountedApp ?? "无"}（从左侧导航菜单选择子应用进行挂载）</p>
          <div id="wujie-mount-slot" data-testid="mount-slot" className="mount-slot" />
        </section>

        <section className="card">
          <h2>调试时间线</h2>
          <div className="row">
            <input
              data-testid="debug-search-input"
              value={debugKeyword}
              placeholder="搜索事件或 payload"
              onChange={(event) => setDebugKeyword(event.target.value)}
            />
          </div>
          <div className="row">
            <select
              data-testid="debug-level-select"
              value={debugLevel}
              onChange={(event) => setDebugLevel(event.target.value as DebugLevel | "all")}
            >
              <option value="all">全部级别</option>
              <option value="info">info</option>
              <option value="warn">warn</option>
              <option value="error">error</option>
            </select>
            <select
              data-testid="debug-app-select"
              value={debugAppFilter}
              onChange={(event) => setDebugAppFilter(event.target.value)}
            >
              <option value="all">全部应用</option>
              {registry.list().map((app) => (
                <option key={app.name} value={app.name}>
                  {app.name}
                </option>
              ))}
            </select>
          </div>
          <div className="row">
            <button data-testid="export-debug-btn" type="button" onClick={exportDebugJson}>
              导出调试 JSON
            </button>
            <button data-testid="clear-debug-btn" type="button" onClick={clearDebugTimeline}>
              清空时间线
            </button>
            <span>
              记录数: {filteredDebugRows.length}/{debugRows.length}
            </span>
          </div>
          <ul data-testid="debug-list">
            {filteredDebugRows.slice(0, 30).map((row) => (
              <li key={row.id} data-testid="debug-row">
                [{new Date(row.timestamp).toLocaleTimeString()}] [{row.level}] {row.appName ?? "-"} · {row.type}
              </li>
            ))}
          </ul>
        </section>
      </div>
    </main>
  );
}
