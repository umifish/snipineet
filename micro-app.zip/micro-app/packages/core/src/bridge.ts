export interface BridgeEventMap {
  "preload:start": { appName: string; mode: string };
  "preload:success": { appName: string; mode: string; durationMs: number };
  "preload:error": { appName: string; mode: string; message: string };
  "wujie:mount:start": { appName: string; url: string };
  "wujie:mount:success": { appName: string; durationMs: number };
  "wujie:mount:error": { appName: string; message: string; reason?: string };
  "wujie:unmount": { appName: string };
  "route:navigate": { appName: string; path: string; query?: Record<string, string> };
  "route:sync": { source: "host" | "subapp"; path: string };
  "channel:host->subapp": {
    appName: string;
    type: "host:data-sync" | "host:subapp-relay" | "host:settings-change" | "host:notify";
  };
  "channel:subapp->host": {
    appName: string;
    type:
      | "subapp:ready"
      | "subapp:data-sync"
      | "subapp:settings-change"
      | "subapp:relay"
      | "subapp:relay-ack"
      | "subapp:notify";
  };
  "channel:subapp->subapp": {
    fromApp: string;
    toApp: string;
    topic: string;
  };
  "settings:change": {
    source: "host" | "subapp";
    appName?: string;
    theme: string;
    timezone: string;
    language: string;
  };
  "notify:message": {
    source: "host" | "subapp";
    appName?: string;
    level: "info" | "warn" | "error";
    message: string;
  };
  "lifecycle:error": { appName: string; phase: string; message: string };
}

export type BridgeHandler<TEvent> = (event: TEvent) => void;

export interface Bridge<TEvents extends object> {
  on<K extends keyof TEvents>(type: K, handler: BridgeHandler<TEvents[K]>): () => void;
  off<K extends keyof TEvents>(type: K, handler: BridgeHandler<TEvents[K]>): void;
  emit<K extends keyof TEvents>(type: K, payload: TEvents[K]): void;
}

export class TypedBridge<TEvents extends object>
  implements Bridge<TEvents>
{
  private readonly listeners = new Map<keyof TEvents, Set<BridgeHandler<unknown>>>();

  on<K extends keyof TEvents>(type: K, handler: BridgeHandler<TEvents[K]>): () => void {
    const set = this.listeners.get(type) ?? new Set<BridgeHandler<unknown>>();
    set.add(handler as BridgeHandler<unknown>);
    this.listeners.set(type, set);
    return () => this.off(type, handler);
  }

  off<K extends keyof TEvents>(type: K, handler: BridgeHandler<TEvents[K]>): void {
    const set = this.listeners.get(type);
    if (!set) {
      return;
    }
    set.delete(handler as BridgeHandler<unknown>);
    if (set.size === 0) {
      this.listeners.delete(type);
    }
  }

  emit<K extends keyof TEvents>(type: K, payload: TEvents[K]): void {
    const set = this.listeners.get(type);
    if (!set) {
      return;
    }
    for (const listener of set) {
      (listener as BridgeHandler<TEvents[K]>)(payload);
    }
  }
}

export function createBridge<TEvents extends object>(): Bridge<TEvents> {
  return new TypedBridge<TEvents>();
}
