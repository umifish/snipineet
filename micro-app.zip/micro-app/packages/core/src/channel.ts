export interface GlobalPreferences {
  theme: "light" | "dark" | "system";
  timezone: string;
  language: string;
}

export interface HostToSubappPayloadMap {
  "host:data-sync": {
    from: "host";
    data: Record<string, unknown>;
  };
  "host:subapp-relay": {
    from: "host";
    fromApp: string;
    topic: string;
    data: Record<string, unknown>;
    messageId: string;
    createdAt: number;
    ttlMs: number;
  };
  "host:settings-change": {
    from: "host";
    preferences: GlobalPreferences;
  };
  "host:notify": {
    from: "host";
    level: "info" | "warn" | "error";
    message: string;
  };
}

export interface SubappToHostPayloadMap {
  "subapp:ready": {
    from: "subapp";
  };
  "subapp:data-sync": {
    from: "subapp";
    data: Record<string, unknown>;
  };
  "subapp:settings-change": {
    from: "subapp";
    preferences: GlobalPreferences;
  };
  "subapp:relay": {
    from: "subapp";
    toApp: string;
    topic: string;
    data: Record<string, unknown>;
    messageId?: string;
    ttlMs?: number;
  };
  "subapp:relay-ack": {
    from: "subapp";
    messageId: string;
    status: "received" | "ignored";
  };
  "subapp:notify": {
    from: "subapp";
    level: "info" | "warn" | "error";
    message: string;
  };
}

export type HostToSubappType = keyof HostToSubappPayloadMap;
export type SubappToHostType = keyof SubappToHostPayloadMap;

interface ChannelEnvelopeBase {
  protocol: "micro-app-channel";
  appName: string;
  timestamp: number;
}

type HostToSubappEnvelope<K extends HostToSubappType = HostToSubappType> = ChannelEnvelopeBase & {
  direction: "host-to-subapp";
  type: K;
  payload: HostToSubappPayloadMap[K];
};

type SubappToHostEnvelope<K extends SubappToHostType = SubappToHostType> = ChannelEnvelopeBase & {
  direction: "subapp-to-host";
  type: K;
  payload: SubappToHostPayloadMap[K];
};

export type ChannelEnvelope = HostToSubappEnvelope | SubappToHostEnvelope;

export function isChannelEnvelope(value: unknown): value is ChannelEnvelope {
  if (!value || typeof value !== "object") {
    return false;
  }
  const candidate = value as Partial<ChannelEnvelope>;
  return (
    candidate.protocol === "micro-app-channel" &&
    (candidate.direction === "host-to-subapp" || candidate.direction === "subapp-to-host") &&
    typeof candidate.appName === "string" &&
    typeof candidate.type === "string" &&
    typeof candidate.timestamp === "number"
  );
}

export function createHostEnvelope<K extends HostToSubappType>(
  appName: string,
  type: K,
  payload: HostToSubappPayloadMap[K]
): HostToSubappEnvelope<K> {
  return {
    protocol: "micro-app-channel",
    direction: "host-to-subapp",
    appName,
    type,
    payload,
    timestamp: Date.now()
  };
}

export function createSubappEnvelope<K extends SubappToHostType>(
  appName: string,
  type: K,
  payload: SubappToHostPayloadMap[K]
): SubappToHostEnvelope<K> {
  return {
    protocol: "micro-app-channel",
    direction: "subapp-to-host",
    appName,
    type,
    payload,
    timestamp: Date.now()
  };
}

export function postToParent<K extends SubappToHostType>(
  appName: string,
  type: K,
  payload: SubappToHostPayloadMap[K],
  targetOrigin = "*"
): void {
  if (typeof window === "undefined" || window.parent === window) {
    return;
  }
  window.parent.postMessage(createSubappEnvelope(appName, type, payload), targetOrigin);
}

export function postToIframe<K extends HostToSubappType>(
  iframeWindow: Window,
  appName: string,
  type: K,
  payload: HostToSubappPayloadMap[K],
  targetOrigin = "*"
): void {
  iframeWindow.postMessage(createHostEnvelope(appName, type, payload), targetOrigin);
}

export function originFromUrl(input: string): string | null {
  try {
    return new URL(input).origin;
  } catch {
    return null;
  }
}
