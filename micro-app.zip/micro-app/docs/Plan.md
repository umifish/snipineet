# Plan: React19 双向集成微前端工程设计（可执行版）

## 1. 目标与范围

目标：在 micro-app 中形成双角色微前端壳能力。

1. 可作为主应用，挂载并治理 Vue2、Vue3、React18、React19 子应用。
2. 可作为子应用，被外部主应用挂载并接受上下文注入。
3. 可提供主子双向通信与子子通信（经宿主中继）。

范围边界：

1. 本期仅前端微前端（不含 BFF/API/鉴权网关后端实现）。
2. 保留现有 CI 流程与质量门，不新增基础设施依赖。

## 2. 约束与兼容矩阵

1. 主应用基准：React19。
2. 子应用兼容：Vue2、Vue3、React18、React19。
3. 微前端内核：wujie 2.x。
4. 必须能力：注册中心、生命周期协议、通信桥、路由边界、样式隔离、失败降级。

## 3. 双角色接入契约（新增）

### 3.1 作为主应用

1. 由 registry 描述 appName、entry、framework、路由前缀和故障注入配置。
2. 所有挂载必须通过统一 host runtime 执行。
3. 子子通信必须经过 host 中继，不允许子应用间直接耦合地址。

### 3.2 作为子应用

1. 必须暴露标准生命周期：__WUJIE_MOUNT / __WUJIE_UNMOUNT / __WUJIE_UPDATE。
2. 外部主应用至少可注入字段：
	1. appName
	2. routeBase
	3. parentOrigin
	4. preferences
	5. data
3. 当 appName 或 parentOrigin 缺失时，采用降级策略并输出可观测告警。

## 4. 通信协议与可靠性语义（新增）

### 4.1 主子通信

1. host:data-sync
2. host:settings-change
3. host:notify
4. subapp:ready
5. subapp:data-sync
6. subapp:settings-change
7. subapp:notify

### 4.2 子子通信（经宿主中继）

1. 子应用上行：subapp:relay(toApp, topic, data)
2. 宿主下发：host:subapp-relay(fromApp, topic, data)
3. 目标未挂载时：进入宿主短队列，目标挂载后自动投递。

### 4.3 可靠性语义（本期要求）

1. 队列容量上限（防止内存膨胀）。
2. 入队/投递事件写入调试时间线。
3. 至少一次投递语义（at-least-once）。

### 4.4 可靠性语义（下期预留）

1. messageId + ack。
2. ttl + dead-letter。
3. 幂等消费约束。

## 5. 安全模型（新增）

1. postMessage 必须支持 targetOrigin，禁止默认长期使用星号。
2. 收包必须校验：
	1. 协议签名字段
	2. event.origin
	3. event.source
3. 作为子应用时，必须校验上层 parentOrigin。
4. 作为主应用时，必须校验子应用消息来源 origin 与 entry origin 匹配。

### 5.1 强制策略

1. 发送侧：
	1. host -> subapp 使用 entry 推导 origin（originFromUrl），仅在未知 origin 时退化为星号。
	2. subapp -> parent 使用 parentOrigin；parentOrigin 缺失时允许发送但必须打告警。
2. 接收侧：
	1. 先校验协议壳（protocol/direction/appName/type/timestamp）。
	2. 再校验 event.source（主应用只接受当前挂载 iframe；子应用只接受 window.parent）。
	3. 再校验 event.origin（主应用要求与 entry origin 匹配；子应用要求与 parentOrigin 匹配）。
3. 拒收策略：
	1. 任一校验失败直接丢弃消息，不进入业务处理。
	2. 拒收行为记录到调试时间线（notify/warn）用于审计。

### 5.2 最小防护面

1. 白名单来源：appName -> origin 映射由 registry 单点维护。
2. 协议版本：统一 channel envelope，禁止业务代码直接消费裸 postMessage。
3. 可靠性联动：中继消息使用 messageId/ttl，过期即丢弃，避免重放与堆积。

### 5.3 验收口径

1. 非法 origin/source 消息不能更新 UI 状态。
2. parentOrigin 错配时，子应用不处理上层消息。
3. 中继过期消息不可投递，时间线可见“过期丢弃”。

## 6. 路由边界策略（新增）

1. 主应用模式：host 管理浏览器历史与 hash。
2. 子应用模式：
	1. 默认不劫持外层路由历史。
	2. 仅管理自身 routeBase 范围内状态。
3. 必须定义冲突规避：上层主应用路由优先。

### 6.1 运行策略

1. 主应用模式（standalone）：
	1. 启用 pushState/replaceState/popstate 与 hash 深链（#/app/:name）。
	2. back/forward 驱动挂载回放。
2. 子应用模式（host）：
	1. 默认 strict：不写入外层 history，不注册外层 popstate 驱动。
	2. 可切换 inherit：允许沿用浏览器 history 行为，用于兼容外层集成。
	3. strict 下返回按钮执行“应用内卸载”而非外层历史回退。

### 6.2 冲突规避

1. 路由优先级：外层主应用 > host-shell 子应用 > 子应用内部路由。
2. host-shell 仅操作 routeBase 作用域状态，不改写非作用域路径。
3. 发生冲突时，host-shell 进入保守模式（仅挂载状态切换，不推动 history）。

### 6.3 验收口径

1. 子应用模式 strict 下，连续挂载/卸载不污染外层历史栈。
2. inherit 模式下，回退行为与浏览器 history 一致。
3. 深链进入时不会触发重复挂载或双重卸载。

## 7. 分阶段执行

### Phase A 工程骨架

1. monorepo 分层与统一脚本。
2. host-shell、self-embed-app、matrix 子应用基线。

### Phase B 双向集成核心

1. 主应用挂载链路。
2. 子应用生命周期暴露。
3. 主子通信可闭环。

### Phase C 兼容适配层

1. vue2/vue3/react18/react19 适配器。
2. 统一挂载/卸载/清理行为。

### Phase D 运行治理

1. 预加载、超时、熔断、降级。
2. 调试时间线与可观测指标。

### Phase E 示例与验收

1. React19 host -> Vue2。
2. React19 host -> Vue3。
3. React19 host -> React18。
4. host-shell 作为子应用被外部 host 集成。

## 8. 验收矩阵（可执行）

1. 挂载：成功/失败/卸载回收。
2. 路由：前缀隔离、回退、深链直达。
3. 主子通信：数据/通知/设置变更双向可达。
4. 子子中继：
	1. 已挂载目标直达。
	2. 未挂载目标入队。
	3. 目标挂载后投递。
5. 安全：origin/source 校验生效，非法消息被丢弃。
6. 样式：无跨应用污染。
7. 质量门：lint、typecheck、build、matrix:e2e 通过。

## 9. 交付物

1. 架构说明。
2. 接入手册（主应用接入、子应用接入、双角色接入）。
3. 协议文档（生命周期、通信、安全策略）。
4. 故障排查手册。

## 10. 里程碑

1. M1：骨架可运行。
2. M2：主子双向集成可用。
3. M3：四类框架与双角色验证通过。
4. M4：子子中继与安全校验验收通过。

## 11. 决策记录

1. 位置：micro-app。
2. 形态：monorepo。
3. 主方案：wujie 内核 + 统一适配层。
4. 兼容目标：Vue2/Vue3/React18/React19。
5. 排除项：后端微服务与鉴权网关实现。

## 12. 计划-实现-测试对照（执行追踪）

| 计划项 | 当前实现 | 验证方式 | 状态 |
| --- | --- | --- | --- |
| 双角色生命周期（可主可子） | host-shell 支持 __WUJIE_MOUNT / __WUJIE_UNMOUNT / __WUJIE_UPDATE，独立与嵌入双模式 | `pnpm --filter @micro-app/host-shell typecheck` + `pnpm --filter @micro-app/host-shell build` | 已完成 |
| 双角色接入契约（缺失字段可观测告警） | 子应用模式下 appName/parentOrigin 缺失会降级并发出 notify/warn 与 console 告警 | `pnpm --filter @micro-app/host-shell lint && pnpm --filter @micro-app/host-shell typecheck && pnpm --filter @micro-app/host-shell build` | 已完成 |
| 主子双向通信 | 统一 channel 协议：host:data-sync / host:settings-change / host:notify / subapp:ready / subapp:data-sync / subapp:settings-change / subapp:notify | `pnpm matrix:e2e:optional`，并在 host 调试时间线观察 `channel:host->subapp` / `channel:subapp->host` | 已完成 |
| 子子通信中继 | 协议支持 subapp:relay + host:subapp-relay；宿主中继并维护短队列，目标挂载后投递 | `pnpm matrix:e2e:optional` 中 `Subapp Relay Queue` 步骤 | 已完成 |
| 通信安全模型 | 增加 targetOrigin、originFromUrl；校验 parentOrigin、子应用 origin/source；非法来源丢弃 | `pnpm lint && pnpm typecheck` + relay 相关 E2E 回归 | 已完成 |
| 路由回退与深链 | host-shell 接入 pushState/popstate，支持 back 与深链直达，避免并发重复挂载 | `pnpm matrix:e2e:optional` 中挂载/卸载/路由步骤 | 已完成 |
| 跨框架兼容（Vue2/Vue3/React18/React19） | adapter 与 matrix 子应用接入完成，host-shell 可挂载三类子应用；self-embed 支持被挂载 | `pnpm matrix:check` + `pnpm matrix:e2e:optional` | 已完成 |
| 故障注入与降级路径 | 预加载层与挂载层 timeout/404/network 分类故障覆盖 | `pnpm matrix:e2e:optional` 中 Fault Injection/Fault Mount Layer | 已完成 |
| 质量门与工程基线 | monorepo、lint/typecheck/build/test:type、CI 可选浏览器矩阵回归 | `pnpm lint && pnpm typecheck && pnpm build && pnpm test:type` | 已完成 |
| 可靠性语义（messageId/ack/ttl/幂等） | 协议新增 relay messageId/ttl；host 维护 pending/queue 并处理过期；子应用回执 relay-ack 且按 messageId 去重消费 | `pnpm lint && pnpm typecheck && pnpm build` + `pnpm matrix:e2e:optional` | 已完成 |
| 子应用模式路由隔离开关 | host-shell 增加 strict/inherit 策略开关；子应用模式默认 strict，避免接管外层历史 | `pnpm --filter @micro-app/host-shell lint && pnpm --filter @micro-app/host-shell typecheck && pnpm --filter @micro-app/host-shell build` + `pnpm matrix:e2e:optional` | 已完成 |

### 12.1 对照文件

1. 核心协议与安全：packages/core/src/channel.ts
2. 事件与类型：packages/core/src/bridge.ts
3. 主应用与双角色壳：apps/host-shell/src/main.tsx, apps/host-shell/src/App.tsx
4. 子应用通信接入：
	1. apps/subapp-react18/src/CheckoutApp.tsx
	2. apps/subapp-vue3/src/MarketingApp.ts
	3. apps/subapp-vue2/src/DashboardApp.ts
	4. apps/self-embed-app/src/App.tsx
5. 回归脚本：scripts/matrix-e2e.mjs

### 12.2 本轮执行记录（2026-06-11）

1. 质量门执行：`pnpm lint && pnpm typecheck && pnpm build`，全部通过。
2. 矩阵健康检查：`pnpm matrix:check`，host-shell 与四个子应用均为 OK。
3. 矩阵启动验证：`pnpm --dir /Users/umifish/Desktop/Umifish/repository/micro-app dev:matrix`。
	1. 命令报端口占用（5173-5177），原因为已有 dev 实例在运行。
	2. 通过 `lsof -nP -iTCP:5173 -iTCP:5174 -iTCP:5175 -iTCP:5176 -iTCP:5177 -sTCP:LISTEN` 验证五端口均在监听。
	3. 结论：矩阵已运行，启动脚本可用。
4. P1 路由隔离开关落地：
	1. host-shell 新增子应用模式路由策略开关：strict/inherit。
	2. strict 模式默认启用，避免子应用模式接管浏览器历史。
	3. 回归验证：`pnpm --filter @micro-app/host-shell lint && pnpm --filter @micro-app/host-shell typecheck && pnpm --filter @micro-app/host-shell build` 通过。
	4. 端到端复验：`pnpm matrix:e2e:optional` 通过。
5. P1 可靠性语义落地：
	1. `channel` 协议新增：relay messageId、ttlMs、createdAt 与 `subapp:relay-ack`。
	2. host-shell 新增中继 pending 追踪、过期丢弃、回执消费。
	3. 四个子应用新增 relay 去重与 ack 上报。
	4. 全量验证：`pnpm lint && pnpm typecheck && pnpm build`、`pnpm matrix:e2e:optional` 全部通过。
6. 双角色契约缺失字段告警补齐：
	1. 子应用模式缺少 `appName` 时，降级为 `host-shell` 并输出可观测 warn。
	2. 子应用模式缺少 `parentOrigin` 时，降级为 `*` 并输出可观测 warn。
	3. 验证：`pnpm --filter @micro-app/host-shell lint && pnpm --filter @micro-app/host-shell typecheck && pnpm --filter @micro-app/host-shell build` 通过。
