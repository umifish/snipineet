# Supernova

一个基于 `pnpm workspace` 的国际化 SDK 工程，核心包为 `@supernova/i18n-sdk`，支持：

- 多语言管理（默认中/英/韩）
- URL / 系统语言 / 默认语言自动解析
- 远端文案动态获取（支持请求方法配置与 API 响应适配）
- 多级缓存（memory / localStorage / indexedDB / 自定义适配器）
- 可配置缓存策略（`network-first` 等）
- 全局请求拦截器（`fetch` + `XMLHttpRequest` 注入 `x-lang` / `x-zone`）
- 框架桥接（`vue-i18n` 与 `react-i18next`）

## 项目结构

```txt
supernova/
├─ packages/
│  └─ i18n-sdk/                 # 核心 SDK 包
├─ examples/
│  ├─ vue-demo/                 # Vue 可运行示例
│  └─ react-demo/               # React 可运行示例
├─ package.json                 # workspace 根脚本
└─ pnpm-workspace.yaml
```

## 环境要求

- Node.js 18+
- pnpm 10+

## 快速开始

安装依赖：

```bash
pnpm install
```

构建全部包：

```bash
pnpm build
```

代码检查：

```bash
pnpm lint
```

## 运行示例

启动 Vue 示例：

```bash
pnpm dev:vue-demo
```

启动 React 示例：

```bash
pnpm dev:react-demo
```

单独构建示例：

```bash
pnpm --filter @supernova/vue-demo build
pnpm --filter @supernova/react-demo build
```

## SDK 导出说明

包名：`@supernova/i18n-sdk`

主入口：

- `@supernova/i18n-sdk`

框架子路径入口：

- `@supernova/i18n-sdk/vue-i18n`
- `@supernova/i18n-sdk/react-i18next`

## 核心使用

### 1. 创建 I18n 实例

```ts
import { I18n } from '@supernova/i18n-sdk'

const i18n = await I18n.create({
  defaultLanguage: 'zh',
  supportedLanguages: ['zh', 'en', 'ko'],
  fetchDictionary: async (lang) => {
    const res = await fetch(`/api/i18n/${lang}`)
    return res.json()
  },
})
```

语言初始化优先级：

1. URL `?lang=xx`
2. 系统语言（`navigator.language`）
3. `defaultLanguage`
4. `zh`

### 2. 切换语言

```ts
await i18n.setLanguage('en')
const text = i18n.t('hello')
```

### 3. 预加载与刷新

```ts
await i18n.preloadLanguage('ko')
await i18n.refreshLanguage() // 刷新当前语种
```

## 动态请求配置（替代 fetchDictionary）

当不想自己写 `fetchDictionary` 时，可通过 `request` 配置请求行为：

```ts
const i18n = await I18n.create({
  request: {
    endpoint: '/api/i18n',
    method: 'GET',
    queryParamName: 'lang',
    responseAdapter: (payload) => {
      // 适配任意 API 返回结构
      return (payload as any).data
    },
  },
})
```

也支持语义化别名：`dictionaryRequest`（优先级高于 `request`）。

支持配置：

- `endpoint`
- `method`
- `headers`
- `queryParamName`
- `body`
- `requester`
- `responseAdapter`

## 查询语种接口 API 配置

初始化阶段可通过 `bootstrap.languageListRequest` 配置“可用语种列表”接口：

```ts
const i18n = await I18n.create({
  bootstrap: {
    languageListRequest: {
      endpoint: '/api/i18n/languages',
      method: 'GET',
      responseAdapter: payload => (payload as { data: string[] }).data,
    },
  },
})
```

若同时提供 `bootstrap.fetchLanguageList`，会优先使用函数配置。

## 缓存系统

### 1. 默认行为

- 默认启用 `memory` 缓存适配器
- 可通过 `cache.enabled = false` 关闭缓存

### 2. 缓存配置示例

```ts
const i18n = await I18n.create({
  cache: {
    adapter: 'localStorage',
    strategy: 'stale-while-revalidate',
    ttlMs: 1000 * 60 * 30,
    keyPrefix: 'supernova:i18n:',
  },
})
```

支持适配器：

- `memory`
- `localStorage`
- `indexedDB`
- 自定义 `DictionaryCacheAdapter`

支持策略：

- `network-first`（默认）
- `cache-first`
- `cache-only`
- `network-only`
- `stale-while-revalidate`

### 3. 统一缓存操作接口

```ts
const cache = i18n.getCache()
await cache?.get('en')
await cache?.remove('en')
await cache?.clear()
```

## 请求拦截器

可以全局拦截 `fetch` 与 `XMLHttpRequest`，自动注入 `x-lang` 与 `x-zone`。

可在实例化时配置 `bootstrap.interceptorUrlPatterns`，仅拦截匹配正则的接口；未配置时默认拦截全部请求。

```ts
const i18n = await I18n.create({
  bootstrap: {
    interceptorUrlPatterns: ['^/api/', '^https://api\\.example\\.com/'],
  },
})
```

### 1. 通过实例安装

```ts
const interceptor = i18n.installRequestInterceptors()

// 需要时卸载
interceptor.uninstall()
```

### 2. 独立安装

```ts
import { installRequestInterceptors } from '@supernova/i18n-sdk'

const interceptor = installRequestInterceptors({
  getLang: () => 'zh',
  getZone: () => 'Asia/Shanghai',
  langHeaderName: 'x-lang',
  zoneHeaderName: 'x-zone',
})
```

## Vue 集成（vue-i18n）

```ts
import { I18n } from '@supernova/i18n-sdk'
import { createVueI18n, syncVueI18nLanguage } from '@supernova/i18n-sdk/vue-i18n'

const sdk = await I18n.create({ /* ... */ })
const vueI18n = await createVueI18n(sdk, {
  fallbackLocale: 'zh',
  preloadLanguages: ['en', 'ko'],
})

// 运行时切换语言（会自动注入新语言 messages）
await syncVueI18nLanguage(sdk, vueI18n, 'zh')
```

## React 集成（react-i18next）

```ts
import { I18n } from '@supernova/i18n-sdk'
import { createReactI18next, syncReactI18nextLanguage } from '@supernova/i18n-sdk/react-i18next'

const sdk = await I18n.create({ /* ... */ })
const i18next = await createReactI18next(sdk, {
  fallbackLng: 'zh',
  preloadLanguages: ['en', 'ko'],
})

// 运行时切换语言（会自动注入新语言 resources 并 changeLanguage）
await syncReactI18nextLanguage(sdk, i18next, 'zh')
```

## 开发脚本

根目录常用脚本：

- `pnpm build`: 构建所有 workspace 包
- `pnpm dev`: 启动所有包的 dev 脚本
- `pnpm dev:vue-demo`: 启动 Vue 示例
- `pnpm dev:react-demo`: 启动 React 示例
- `pnpm lint`: ESLint 检查
- `pnpm lint:fix`: 自动修复格式和风格

---

如需补充发布指南（npm publish）或 CI（GitHub Actions 自动 lint/build），可以在此 README 上继续扩展。
