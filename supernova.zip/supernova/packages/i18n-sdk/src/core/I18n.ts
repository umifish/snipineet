import type {
  DictionaryCache,
  DictionaryData,
  DictionaryRequestConfig,
  I18nBootstrapConfig,
  I18nConfig,
  InstalledRequestInterceptors,
  RequestInterceptorConfig,
  SupportedLanguage,
  UserProfileLocalePayload,
} from '../types'
import { getDefaultI18nConfig, mergeI18nConfig } from '../config'
import { installRequestInterceptors } from '../interceptors/request'
import { createLanguageListFetcher } from '../services/language-list-service'
import { normalizeLanguage } from '../utils/language'
import { interpolateTemplate } from '../utils/template'
import { DictionaryLoader } from './dictionary-loader'
import { createSupportedLanguageSet, resolveInitialLanguage, validateDefaultLanguage } from './language-resolver'

export class I18n {
  private static singletonInstance?: I18n
  private static singletonPromise?: Promise<I18n>
  private static baseConfig: I18nConfig = getDefaultI18nConfig()

  private currentLang: SupportedLanguage
  private currentZone: string
  private supportedLangs: Set<string>
  private dictionaryLoader: DictionaryLoader
  private autoPreloadCurrentLanguage: boolean
  private bootstrapConfig: I18nBootstrapConfig
  private fetchLanguageListFromApi?: () => Promise<SupportedLanguage[]>
  private localStorageLangKey: string
  private localStorageZoneKey: string

  constructor(config: I18nConfig = {}) {
    const dictionaryRequestConfig = resolveDictionaryRequestConfig(config)
    const languageListRequestConfig = resolveLanguageListRequestConfig(config)

    // 1. 初始化支持的语种（基础支持中、英、韩）
    this.supportedLangs = createSupportedLanguageSet(config.supportedLanguages)

    // 2. 用户配置默认语种校验（如果传入）
    validateDefaultLanguage(config.defaultLanguage, this.supportedLangs)

    // 3. 初始化语种优先级：URL lang 参数 > 系统环境语言 > 配置默认语言 > 中文
    this.currentLang = resolveInitialLanguage(this.supportedLangs, config.defaultLanguage)

    // 4. 初始字典数据加载
    this.dictionaryLoader = new DictionaryLoader({
      supportedLanguages: this.supportedLangs,
      cache: config.cache,
      dictionaries: config.dictionaries,
      fetchDictionary: config.fetchDictionary,
      request: dictionaryRequestConfig,
    })

    // 5. 注册异步请求接口
    this.autoPreloadCurrentLanguage = config.autoPreloadCurrentLanguage !== false
    this.bootstrapConfig = config.bootstrap || {}
    this.fetchLanguageListFromApi = createLanguageListFetcher(
      this.bootstrapConfig.fetchLanguageList,
      languageListRequestConfig,
    )
    this.localStorageLangKey = this.bootstrapConfig.localStorageLangKey || 'i18n_lang'
    this.localStorageZoneKey = this.bootstrapConfig.localStorageZoneKey || 'i18n_zone'
    this.currentZone = getDefaultZone() || this.bootstrapConfig.fallbackZone || 'Asia/Shanghai'
  }

  /**
   * 异步工厂：创建实例后自动预加载当前语种文案
   */
  public static async create(config: I18nConfig = {}): Promise<I18n> {
    const resolvedConfig = this.resolveConfig(config)
    const i18n = new I18n(resolvedConfig)
    await i18n.bootstrap()

    return i18n
  }

  /**
   * 获取单例实例（懒加载）
   */
  public static async getInstance(config: I18nConfig = {}): Promise<I18n> {
    if (this.singletonInstance) {
      return this.singletonInstance
    }

    if (!this.singletonPromise) {
      this.singletonPromise = this.create(config)
        .then((instance) => {
          this.singletonInstance = instance
          return instance
        })
        .finally(() => {
          this.singletonPromise = undefined
        })
    }

    return this.singletonPromise
  }

  /**
   * 重置单例实例
   */
  public static resetInstance(): void {
    this.singletonInstance = undefined
    this.singletonPromise = undefined
  }

  /**
   * 设置默认初始化配置（作用于后续 create/getInstance）
   */
  public static configureDefaultConfig(config: I18nConfig): void {
    this.baseConfig = mergeI18nConfig(getDefaultI18nConfig(), config)
  }

  /**
   * 获取当前默认初始化配置
   */
  public static getDefaultConfig(): I18nConfig {
    return mergeI18nConfig(getDefaultI18nConfig(), this.baseConfig)
  }

  private static resolveConfig(config: I18nConfig): I18nConfig {
    return mergeI18nConfig(this.baseConfig, config)
  }

  private async bootstrap(): Promise<void> {
    const [userProfileResult, languageListResult] = await Promise.allSettled([
      this.fetchUserProfile(),
      this.fetchLanguageList(),
    ])

    if (languageListResult.status === 'fulfilled') {
      this.addSupportedLanguages(languageListResult.value)
    }

    const userProfile = userProfileResult.status === 'fulfilled' ? userProfileResult.value : undefined
    const resolved = this.resolveBootstrapLocale(userProfile)
    this.currentLang = resolved.lang
    this.currentZone = resolved.zone
    this.persistLocaleState()

    if (this.autoPreloadCurrentLanguage) {
      await this.preloadCurrentLanguageWithFallback()
    }

    if (this.bootstrapConfig.autoInstallInterceptors !== false) {
      this.installRequestInterceptors()
    }
  }

  /**
   * 校验语种是否在支持列表中
   */
  public isValidLanguage(lang: string): boolean {
    return this.supportedLangs.has(lang)
  }

  /**
   * 切换当前语言。如果字典不存在且存在 fetchDictionary 接口，它会自动拉取
   */
  public async setLanguage(lang: SupportedLanguage): Promise<void> {
    const normalizedLang = normalizeLanguage(lang)
    if (!normalizedLang || !this.isValidLanguage(normalizedLang)) {
      throw new Error(`[I18n Error]: Unsupported language "${lang}". Supported languages check failed.`)
    }

    // 切换语言时按需动态拉取对应语种包
    await this.dictionaryLoader.ensureLoaded(normalizedLang)

    this.currentLang = normalizedLang
    this.persistLocaleState()
  }

  /**
   * 设置当前时区
   */
  public setZone(zone: string): void {
    const trimmed = zone.trim()
    if (!trimmed) {
      throw new Error('[I18n Error]: Zone cannot be empty.')
    }

    this.currentZone = trimmed
    this.persistLocaleState()
  }

  /**
   * 预加载某个语种的文案资源
   */
  public async preloadLanguage(lang: SupportedLanguage): Promise<void> {
    const normalizedLang = normalizeLanguage(lang)
    if (!normalizedLang || !this.isValidLanguage(normalizedLang)) {
      throw new Error(`[I18n Error]: Cannot preload unsupported language "${lang}".`)
    }

    await this.dictionaryLoader.ensureLoaded(normalizedLang)
  }

  /**
   * 强制刷新语种文案（从接口重新拉取）
   */
  public async refreshLanguage(lang?: SupportedLanguage): Promise<void> {
    const targetLang = lang ?? this.currentLang
    const normalizedLang = normalizeLanguage(targetLang)
    if (!normalizedLang || !this.isValidLanguage(normalizedLang)) {
      throw new Error(`[I18n Error]: Cannot refresh unsupported language "${targetLang}".`)
    }

    await this.dictionaryLoader.ensureLoaded(normalizedLang, true)
  }

  /**
   * 往系统内手动添加翻译字典
   */
  public addDictionary(lang: SupportedLanguage, dict: Record<string, string>): void {
    const normalizedLang = normalizeLanguage(lang)
    if (!normalizedLang || !this.isValidLanguage(normalizedLang)) {
      throw new Error(`[I18n Error]: Cannot add dictionary for unsupported language "${lang}".`)
    }
    this.dictionaryLoader.add(normalizedLang, dict)
  }

  /**
   * 获取当前的翻译内容
   */
  public t(key: string, variables?: Record<string, string>): string {
    const dict = this.dictionaryLoader.get(this.currentLang)
    const text = dict?.[key] || key // 如果找不到翻译，兜底返回 key 本身

    // 简单的变量替换支持，比如 "hello {name}"
    return interpolateTemplate(text, variables)
  }

  /**
   * 获取当前缓存实例（统一缓存操作接口）
   */
  public getCache(): DictionaryCache | undefined {
    return this.dictionaryLoader.getCache()
  }

  /**
   * 获取指定语种的字典（默认当前语种）
   */
  public getDictionary(lang: SupportedLanguage = this.currentLang): DictionaryData | undefined {
    const normalizedLang = normalizeLanguage(lang)
    if (!normalizedLang || !this.isValidLanguage(normalizedLang)) {
      return undefined
    }

    return this.dictionaryLoader.get(normalizedLang)
  }

  /**
   * 安装全局请求拦截器，自动向 fetch/XMLHttpRequest 注入 x-lang 和 x-zone。
   */
  public installRequestInterceptors(config: Omit<RequestInterceptorConfig, 'getLang'> = {}): InstalledRequestInterceptors {
    return installRequestInterceptors({
      requestUrlPatterns: this.bootstrapConfig.interceptorUrlPatterns,
      ...config,
      getLang: () => String(this.getCurrentLanguage()),
      getZone: config.getZone || (() => this.getCurrentZone()),
    })
  }

  /**
   * 获取当前生效的语种
   */
  public getCurrentLanguage(): SupportedLanguage {
    return this.currentLang
  }

  /**
   * 获取当前时区
   */
  public getCurrentZone(): string {
    return this.currentZone
  }

  /**
   * 获取系统目前支持的完整语种列表
   */
  public getSupportedLanguages(): string[] {
    return [...this.supportedLangs]
  }

  private async preloadCurrentLanguageWithFallback(): Promise<void> {
    try {
      await this.preloadLanguage(this.currentLang)
    }
    catch {
      const fallbackLanguage = this.resolveFallbackLanguage()
      if (fallbackLanguage === this.currentLang) {
        throw new Error(`[I18n Error]: Failed to load dictionary for language "${this.currentLang}".`)
      }

      try {
        await this.preloadLanguage(fallbackLanguage)
        this.currentLang = fallbackLanguage
        this.persistLocaleState()
      }
      catch {
        throw new Error(`[I18n Error]: Failed to load both primary and fallback dictionaries. Primary: "${this.currentLang}", fallback: "${fallbackLanguage}".`)
      }
    }
  }

  private resolveFallbackLanguage(): SupportedLanguage {
    const configured = normalizeLanguage(this.bootstrapConfig.fallbackLanguage)
    if (configured && this.supportedLangs.has(configured)) {
      return configured
    }

    if (this.supportedLangs.has('zh')) {
      return 'zh'
    }

    return [...this.supportedLangs][0] || 'zh'
  }

  private resolveBootstrapLocale(userProfile?: UserProfileLocalePayload): {
    lang: SupportedLanguage
    zone: string
  } {
    const langQueryParamName = this.bootstrapConfig.langQueryParamName || 'lang'
    const zoneQueryParamName = this.bootstrapConfig.zoneQueryParamName || 'zone'

    const langCandidates = [
      this.getQueryParam(langQueryParamName),
      this.readFromLocalStorage(this.localStorageLangKey),
      userProfile?.language,
      this.getSystemLanguage(),
      this.currentLang,
      'zh',
    ]

    const lang = this.pickFirstSupportedLanguage(langCandidates)
      || this.resolveFallbackLanguage()

    const zoneCandidates = [
      this.getQueryParam(zoneQueryParamName),
      this.readFromLocalStorage(this.localStorageZoneKey),
      userProfile?.zone,
      userProfile?.timezone,
      getDefaultZone(),
      this.bootstrapConfig.fallbackZone,
      'Asia/Shanghai',
    ]

    const zone = zoneCandidates
      .map(value => value?.trim())
      .find(value => Boolean(value))
      || 'Asia/Shanghai'

    return {
      lang,
      zone,
    }
  }

  private pickFirstSupportedLanguage(candidates: Array<SupportedLanguage | undefined>): SupportedLanguage | undefined {
    for (const candidate of candidates) {
      const normalized = normalizeLanguage(candidate)
      if (normalized && this.supportedLangs.has(normalized)) {
        return normalized
      }
    }

    return undefined
  }

  private addSupportedLanguages(languages: SupportedLanguage[]): void {
    for (const language of languages) {
      const normalized = normalizeLanguage(language)
      if (normalized) {
        this.supportedLangs.add(normalized)
      }
    }
  }

  private async fetchUserProfile(): Promise<UserProfileLocalePayload | undefined> {
    if (!this.bootstrapConfig.fetchUserProfile) {
      return undefined
    }

    try {
      return await this.bootstrapConfig.fetchUserProfile()
    }
    catch {
      return undefined
    }
  }

  private async fetchLanguageList(): Promise<SupportedLanguage[]> {
    if (!this.fetchLanguageListFromApi) {
      return []
    }

    try {
      const languages = await this.fetchLanguageListFromApi()
      return Array.isArray(languages) ? languages : []
    }
    catch {
      return []
    }
  }

  private getSystemLanguage(): SupportedLanguage | undefined {
    const globalScope = globalThis as {
      navigator?: { language?: string }
    }

    return normalizeLanguage(globalScope.navigator?.language)
  }

  private getQueryParam(name: string): string | undefined {
    const globalScope = globalThis as {
      location?: { search?: string }
    }

    const search = globalScope.location?.search
    if (!search) {
      return undefined
    }

    const value = new URLSearchParams(search).get(name)
    return value || undefined
  }

  private readFromLocalStorage(key: string): string | undefined {
    const globalScope = globalThis as {
      localStorage?: Storage
    }

    try {
      return globalScope.localStorage?.getItem(key) || undefined
    }
    catch {
      return undefined
    }
  }

  private writeToLocalStorage(key: string, value: string): void {
    const globalScope = globalThis as {
      localStorage?: Storage
    }

    try {
      globalScope.localStorage?.setItem(key, value)
    }
    catch {
      // ignore storage errors
    }
  }

  private persistLocaleState(): void {
    this.writeToLocalStorage(this.localStorageLangKey, String(this.currentLang))
    this.writeToLocalStorage(this.localStorageZoneKey, this.currentZone)
  }
}

function getDefaultZone(): string | undefined {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone
  }
  catch {
    return undefined
  }
}

function resolveDictionaryRequestConfig(config: I18nConfig): DictionaryRequestConfig | undefined {
  if (config.dictionaryRequest || config.request) {
    return config.dictionaryRequest || config.request
  }

  if (!config.api?.dictionaryEndpoint) {
    return undefined
  }

  return {
    baseUrl: config.api.baseUrl,
    endpoint: config.api.dictionaryEndpoint,
    method: 'GET',
    queryParamName: 'lang',
  }
}

function resolveLanguageListRequestConfig(config: I18nConfig): I18nBootstrapConfig['languageListRequest'] {
  if (config.bootstrap?.languageListRequest) {
    return config.bootstrap.languageListRequest
  }

  if (!config.api?.languageListEndpoint) {
    return undefined
  }

  return {
    baseUrl: config.api.baseUrl,
    endpoint: config.api.languageListEndpoint,
    method: 'GET',
  }
}
