import type {
  CacheConfig,
  CacheStrategy,
  DictionaryCache,
  DictionaryData,
  DictionaryRequestConfig,
  SupportedLanguage,
} from '../types'
import { createDictionaryCache } from '../cache/factory'
import { createDictionaryFetcher } from '../services/dictionary-service'
import { normalizeLanguage } from '../utils/language'

interface DictionaryLoaderOptions {
  supportedLanguages: Set<string>
  dictionaries?: Record<string, Record<string, string>>
  fetchDictionary?: (lang: SupportedLanguage) => Promise<DictionaryData>
  request?: DictionaryRequestConfig
  cache?: CacheConfig
}

export class DictionaryLoader {
  private cacheAdapter?: DictionaryCache
  private cacheStrategy: CacheStrategy
  private cacheTtlMs?: number
  private dictionaries: Map<string, DictionaryData>
  private fetchDictionary?: (lang: SupportedLanguage) => Promise<DictionaryData>
  private loadingDictionaries: Map<string, Promise<void>>

  constructor(options: DictionaryLoaderOptions) {
    this.cacheAdapter = createDictionaryCache(options.cache)
    this.cacheStrategy = options.cache?.strategy || 'network-first'
    this.cacheTtlMs = options.cache?.ttlMs
    this.dictionaries = createInitialDictionaries(options.supportedLanguages, options.dictionaries)
    this.fetchDictionary = createDictionaryFetcher(options.fetchDictionary, options.request)
    this.loadingDictionaries = new Map()
  }

  public get(lang: SupportedLanguage): DictionaryData | undefined {
    return this.dictionaries.get(lang)
  }

  public getCache(): DictionaryCache | undefined {
    return this.cacheAdapter
  }

  public add(lang: SupportedLanguage, dict: DictionaryData): void {
    const existingDict = this.dictionaries.get(lang) || {}
    const mergedDict = { ...existingDict, ...dict }
    this.dictionaries.set(lang, mergedDict)
    void this.saveToCache(lang, mergedDict)
  }

  public async ensureLoaded(lang: SupportedLanguage, forceReload = false): Promise<void> {
    if (!forceReload && this.dictionaries.has(lang)) {
      return
    }

    const inFlight = this.loadingDictionaries.get(lang)
    if (inFlight) {
      await inFlight
      return
    }

    const request = this.loadDictionaryWithStrategy(lang, forceReload)
      .finally(() => {
        this.loadingDictionaries.delete(lang)
      })

    this.loadingDictionaries.set(lang, request)
    await request
  }

  private async loadDictionaryWithStrategy(lang: SupportedLanguage, forceReload: boolean): Promise<void> {
    if (forceReload) {
      await this.fetchFromRemote(lang)
      return
    }

    switch (this.cacheStrategy) {
      case 'cache-only': {
        const hasCache = await this.loadFromCache(lang)
        if (!hasCache) {
          throw new Error(`[I18n Error]: No cached dictionary found for language "${lang}".`)
        }
        return
      }
      case 'cache-first': {
        const hasCache = await this.loadFromCache(lang)
        if (hasCache) {
          return
        }
        await this.fetchFromRemote(lang)
        return
      }
      case 'network-only': {
        await this.fetchFromRemote(lang)
        return
      }
      case 'stale-while-revalidate': {
        const hasCache = await this.loadFromCache(lang)
        if (hasCache) {
          void this.fetchFromRemote(lang).catch(() => {
            // keep stale cache on background refresh failure
          })
          return
        }
        await this.fetchFromRemote(lang)
        return
      }
      case 'network-first':
      default: {
        try {
          await this.fetchFromRemote(lang)
        }
        catch {
          const hasCache = await this.loadFromCache(lang)
          if (hasCache) {
            return
          }

          throw new Error(`[I18n Error]: Failed to fetch dictionary for language "${lang}".`)
        }
      }
    }
  }

  private async fetchFromRemote(lang: SupportedLanguage): Promise<void> {
    if (!this.fetchDictionary) {
      throw new Error(`[I18n Error]: Missing fetchDictionary implementation for language "${lang}".`)
    }

    let dict: DictionaryData
    try {
      dict = await this.fetchDictionary(lang)
    }
    catch {
      throw new Error(`[I18n Error]: Failed to fetch dictionary for language "${lang}".`)
    }

    if (!dict || typeof dict !== 'object' || Array.isArray(dict)) {
      throw new Error(`[I18n Error]: Invalid dictionary payload for language "${lang}".`)
    }

    this.dictionaries.set(lang, { ...dict })
    await this.saveToCache(lang, dict)
  }

  private async loadFromCache(lang: SupportedLanguage): Promise<boolean> {
    if (!this.cacheAdapter) {
      return false
    }

    const cached = await this.cacheAdapter.get(lang)
    if (!cached) {
      return false
    }

    if (typeof this.cacheTtlMs === 'number' && this.cacheTtlMs >= 0) {
      const age = Date.now() - cached.updatedAt
      if (age > this.cacheTtlMs) {
        await this.cacheAdapter.remove(lang)
        return false
      }
    }

    this.dictionaries.set(lang, { ...cached.dictionary })
    return true
  }

  private async saveToCache(lang: SupportedLanguage, dictionary: DictionaryData): Promise<void> {
    if (!this.cacheAdapter) {
      return
    }

    await this.cacheAdapter.set(lang, {
      dictionary: { ...dictionary },
      updatedAt: Date.now(),
    })
  }
}

function createInitialDictionaries(supportedLanguages: Set<string>, dictionaries?: Record<string, Record<string, string>>): Map<string, Record<string, string>> {
  const initialDictionaries = new Map<string, Record<string, string>>()
  if (!dictionaries) {
    return initialDictionaries
  }

  for (const [lang, dict] of Object.entries(dictionaries)) {
    const normalizedLang = normalizeLanguage(lang)
    if (normalizedLang && supportedLanguages.has(normalizedLang)) {
      initialDictionaries.set(normalizedLang, dict)
    }
  }

  return initialDictionaries
}
