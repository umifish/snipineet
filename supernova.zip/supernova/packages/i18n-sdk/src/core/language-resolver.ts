import type { SupportedLanguage } from '../types'
import { normalizeLanguage } from '../utils/language'

export function createSupportedLanguageSet(languages?: SupportedLanguage[]): Set<string> {
  const initialLanguages = languages || ['zh', 'en', 'ko']

  return new Set(
    initialLanguages
      .map(lang => normalizeLanguage(lang))
      .filter((lang): lang is string => Boolean(lang)),
  )
}

export function validateDefaultLanguage(defaultLanguage: SupportedLanguage | undefined, supportedLanguages: Set<string>): void {
  if (!defaultLanguage) {
    return
  }

  const normalizedDefault = normalizeLanguage(defaultLanguage)
  if (!normalizedDefault || !supportedLanguages.has(normalizedDefault)) {
    throw new Error(`[I18n Error]: Invalid default language "${defaultLanguage}". Supported languages are: ${[...supportedLanguages].join(', ')}`)
  }
}

export function resolveInitialLanguage(supportedLanguages: Set<string>, configDefaultLanguage?: SupportedLanguage): SupportedLanguage {
  const fromUrl = getLanguageFromUrl(supportedLanguages)
  if (fromUrl) {
    return fromUrl
  }

  const fromSystem = getLanguageFromSystem(supportedLanguages)
  if (fromSystem) {
    return fromSystem
  }

  const normalizedDefault = configDefaultLanguage ? normalizeLanguage(configDefaultLanguage) : undefined
  if (normalizedDefault && supportedLanguages.has(normalizedDefault)) {
    return normalizedDefault
  }

  return 'zh'
}

function getLanguageFromUrl(supportedLanguages: Set<string>): SupportedLanguage | undefined {
  const globalScope = globalThis as {
    location?: { search?: string }
  }

  const search = globalScope.location?.search
  if (!search) {
    return undefined
  }

  const langParam = new URLSearchParams(search).get('lang')
  const normalized = normalizeLanguage(langParam || undefined)
  if (normalized && supportedLanguages.has(normalized)) {
    return normalized
  }

  return undefined
}

function getLanguageFromSystem(supportedLanguages: Set<string>): SupportedLanguage | undefined {
  const globalScope = globalThis as {
    navigator?: { language?: string }
  }

  const normalized = normalizeLanguage(globalScope.navigator?.language)
  if (normalized && supportedLanguages.has(normalized)) {
    return normalized
  }

  return undefined
}
