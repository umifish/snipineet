import type { I18nBootstrapConfig, I18nConfig } from '../types'

export const DEFAULT_BOOTSTRAP_CONFIG: Readonly<I18nBootstrapConfig> = {
  autoInstallInterceptors: true,
  fallbackLanguage: 'zh',
  fallbackZone: 'Asia/Shanghai',
  languageListRequest: {
    endpoint: '/api/i18n/languages',
    method: 'GET',
  },
  langQueryParamName: 'lang',
  localStorageLangKey: 'i18n_lang',
  localStorageZoneKey: 'i18n_zone',
  zoneQueryParamName: 'zone',
}

export const DEFAULT_I18N_CONFIG: Readonly<I18nConfig> = {
  autoPreloadCurrentLanguage: true,
  bootstrap: DEFAULT_BOOTSTRAP_CONFIG,
  cache: {
    adapter: 'memory',
    enabled: true,
    strategy: 'network-first',
  },
  dictionaryRequest: {
    endpoint: '/api/i18n/dictionary',
    method: 'GET',
    queryParamName: 'lang',
  },
  defaultLanguage: 'zh',
  api: {
    dictionaryEndpoint: '/api/i18n/dictionary',
    languageListEndpoint: '/api/i18n/languages',
  },
  supportedLanguages: ['zh', 'en', 'ko'],
}

export function getDefaultI18nConfig(): I18nConfig {
  return {
    ...DEFAULT_I18N_CONFIG,
    bootstrap: {
      ...(DEFAULT_I18N_CONFIG.bootstrap || {}),
    },
    cache: {
      ...(DEFAULT_I18N_CONFIG.cache || {}),
    },
    dictionaryRequest: DEFAULT_I18N_CONFIG.dictionaryRequest
      ? {
          ...DEFAULT_I18N_CONFIG.dictionaryRequest,
        }
      : undefined,
    api: {
      ...(DEFAULT_I18N_CONFIG.api || {}),
    },
    supportedLanguages: [...(DEFAULT_I18N_CONFIG.supportedLanguages || ['zh', 'en', 'ko'])],
  }
}
