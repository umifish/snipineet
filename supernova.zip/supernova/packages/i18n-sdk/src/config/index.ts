export { DEFAULT_BOOTSTRAP_CONFIG, DEFAULT_I18N_CONFIG, getDefaultI18nConfig } from './default-config'
export { mergeI18nConfig } from './merge-config'
