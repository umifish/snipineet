import type { I18nConfig } from '../types'

export function mergeI18nConfig(baseConfig: I18nConfig, overrideConfig: I18nConfig = {}): I18nConfig {
  const mergedBootstrap = mergeObject(baseConfig.bootstrap, overrideConfig.bootstrap)

  const mergedLanguageListRequest = mergeObject(
    baseConfig.bootstrap?.languageListRequest,
    overrideConfig.bootstrap?.languageListRequest,
  )

  return {
    ...baseConfig,
    ...overrideConfig,
    bootstrap: mergedBootstrap
      ? {
          ...mergedBootstrap,
          languageListRequest: mergedLanguageListRequest,
        }
      : undefined,
    cache: {
      ...(baseConfig.cache || {}),
      ...(overrideConfig.cache || {}),
    },
    api: mergeObject(baseConfig.api, overrideConfig.api),
    dictionaryRequest: mergeObject(baseConfig.dictionaryRequest, overrideConfig.dictionaryRequest),
    request: mergeObject(baseConfig.request, overrideConfig.request),
    supportedLanguages: overrideConfig.supportedLanguages || baseConfig.supportedLanguages,
  }
}

function mergeObject<T extends object>(base?: T, override?: T): T | undefined {
  if (!base && !override) {
    return undefined
  }

  return {
    ...(base || {}),
    ...(override || {}),
  } as T
}
