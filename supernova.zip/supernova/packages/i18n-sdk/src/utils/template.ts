const placeholderRegexCache = new Map<string, RegExp>()

function getPlaceholderRegex(key: string): RegExp {
  const cached = placeholderRegexCache.get(key)
  if (cached) {
    return cached
  }

  const regex = new RegExp(`{${key}}`, 'g')
  placeholderRegexCache.set(key, regex)
  return regex
}

export function interpolateTemplate(text: string, variables?: Record<string, string>): string {
  if (!variables) {
    return text
  }

  let result = text
  for (const [key, value] of Object.entries(variables)) {
    result = result.replace(getPlaceholderRegex(key), value)
  }

  return result
}
