import type { SupportedLanguage } from '../types'

const languageSeparatorRegex = /[-_]/

export function normalizeLanguage(lang?: string): SupportedLanguage | undefined {
  if (!lang) {
    return undefined
  }

  const normalized = lang.toLowerCase().split(languageSeparatorRegex)[0]
  return normalized || undefined
}
