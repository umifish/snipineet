import type { i18n as I18nextInstance, InitOptions } from 'i18next'
import type { I18n } from '../core/I18n'
import type { ReactI18nextBridgeOptions, ReactI18nextOptions, SupportedLanguage } from '../types'
import i18next from 'i18next'
import { initReactI18next } from 'react-i18next'

export async function createReactI18nextOptions(i18n: I18n, options: ReactI18nextBridgeOptions = {}): Promise<ReactI18nextOptions> {
  const lng = String(i18n.getCurrentLanguage())
  const fallbackLng = String(options.fallbackLng || lng)
  const preloadLanguages = normalizeLanguages(lng, options.preloadLanguages || [])
  const resources = await createReactI18nextResources(i18n, preloadLanguages)

  return {
    lng,
    fallbackLng,
    resources,
  }
}

export async function createReactI18nextResources(i18n: I18n, preloadLanguages: SupportedLanguage[] = []): Promise<Record<string, { translation: Record<string, string> }>> {
  const lng = String(i18n.getCurrentLanguage())
  const targetLanguages = normalizeLanguages(lng, preloadLanguages)
  const resources: Record<string, { translation: Record<string, string> }> = {}

  for (const lang of targetLanguages) {
    await i18n.preloadLanguage(lang)
    const dictionary = i18n.getDictionary(lang)
    if (dictionary) {
      resources[lang] = {
        translation: { ...dictionary },
      }
    }
  }

  return resources
}

export interface CreateReactI18nextConfig {
  i18nextInstance?: I18nextInstance
  initOptions?: Omit<InitOptions, 'fallbackLng' | 'lng' | 'resources'>
}

export async function createReactI18next(i18n: I18n, options: ReactI18nextBridgeOptions = {}, config: CreateReactI18nextConfig = {}): Promise<I18nextInstance> {
  const i18nextOptions = await createReactI18nextOptions(i18n, options)
  const instance = config.i18nextInstance || i18next.createInstance()

  await instance
    .use(initReactI18next)
    .init({
      interpolation: {
        escapeValue: false,
      },
      ...config.initOptions,
      ...i18nextOptions,
    })

  return instance
}

export async function syncReactI18nextLanguage(i18n: I18n, i18nextInstance: I18nextInstance, lang: SupportedLanguage): Promise<void> {
  await i18n.setLanguage(lang)
  const targetLanguage = String(i18n.getCurrentLanguage())
  const dictionary = i18n.getDictionary(targetLanguage) || {}

  i18nextInstance.addResourceBundle(targetLanguage, 'translation', { ...dictionary }, true, true)
  await i18nextInstance.changeLanguage(targetLanguage)
}

function normalizeLanguages(current: string, preloadLanguages: SupportedLanguage[]): string[] {
  const unique = new Set<string>([current])
  for (const lang of preloadLanguages) {
    unique.add(String(lang))
  }

  return [...unique]
}
