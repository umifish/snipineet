import type { I18n as VueI18nInstance, I18nOptions as VueI18nNativeOptions } from 'vue-i18n'
import type { I18n } from '../core/I18n'
import type { SupportedLanguage, VueI18nBridgeOptions, VueI18nOptions } from '../types'
import { createI18n } from 'vue-i18n'

export async function createVueI18nOptions(i18n: I18n, options: VueI18nBridgeOptions = {}): Promise<VueI18nOptions> {
  const locale = String(i18n.getCurrentLanguage())
  const fallbackLocale = String(options.fallbackLocale || locale)
  const preloadLanguages = normalizeLanguages(locale, options.preloadLanguages || [])
  const messages = await buildMessages(i18n, preloadLanguages)

  return {
    locale,
    fallbackLocale,
    messages,
  }
}

export async function createVueI18nMessages(i18n: I18n, preloadLanguages: SupportedLanguage[] = []): Promise<Record<string, Record<string, string>>> {
  const locale = String(i18n.getCurrentLanguage())
  const targetLanguages = normalizeLanguages(locale, preloadLanguages)
  return buildMessages(i18n, targetLanguages)
}

export interface CreateVueI18nConfig {
  vueI18nOptions?: Omit<VueI18nNativeOptions, 'locale' | 'fallbackLocale' | 'messages'>
}

export async function createVueI18n(i18n: I18n, options: VueI18nBridgeOptions = {}, config: CreateVueI18nConfig = {}): Promise<VueI18nInstance> {
  const vueI18nOptions = await createVueI18nOptions(i18n, options)

  return createI18n({
    legacy: false,
    ...config.vueI18nOptions,
    ...vueI18nOptions,
  })
}

export async function syncVueI18nLanguage(i18n: I18n, vueI18n: VueI18nInstance, lang: SupportedLanguage): Promise<void> {
  await i18n.setLanguage(lang)
  const targetLanguage = String(i18n.getCurrentLanguage())
  const dictionary = i18n.getDictionary(targetLanguage) || {}

  vueI18n.global.setLocaleMessage(targetLanguage, { ...dictionary })

  const localeRef = (vueI18n.global as { locale: unknown }).locale
  if (typeof localeRef === 'string') {
    ;(vueI18n.global as { locale: string }).locale = targetLanguage
    return
  }

  if (localeRef && typeof localeRef === 'object' && 'value' in localeRef) {
    ;(localeRef as { value: string }).value = targetLanguage
  }
}

async function buildMessages(i18n: I18n, languages: string[]): Promise<Record<string, Record<string, string>>> {
  const messages: Record<string, Record<string, string>> = {}

  for (const lang of languages) {
    await i18n.preloadLanguage(lang)
    const dictionary = i18n.getDictionary(lang)
    if (dictionary) {
      messages[lang] = { ...dictionary }
    }
  }

  return messages
}

function normalizeLanguages(current: string, preloadLanguages: SupportedLanguage[]): string[] {
  const unique = new Set<string>([current])
  for (const lang of preloadLanguages) {
    unique.add(String(lang))
  }

  return [...unique]
}
