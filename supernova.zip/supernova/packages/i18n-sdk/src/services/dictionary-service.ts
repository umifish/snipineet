import type {
  DictionaryData,
  DictionaryRequestConfig,
  DictionaryRequestMethod,
  SupportedLanguage,
} from '../types'

const methodWithBody = new Set<DictionaryRequestMethod>(['POST', 'PUT', 'PATCH', 'DELETE'])

export function createDictionaryFetcher(
  fetchDictionary: ((lang: SupportedLanguage) => Promise<DictionaryData>) | undefined,
  requestConfig: DictionaryRequestConfig | undefined,
): ((lang: SupportedLanguage) => Promise<DictionaryData>) | undefined {
  if (fetchDictionary) {
    return fetchDictionary
  }

  if (!requestConfig) {
    return undefined
  }

  return async (lang: SupportedLanguage) => {
    const requester = requestConfig.requester || getDefaultRequester()
    const method = requestConfig.method || 'GET'
    const endpoint = resolveEndpoint(requestConfig.endpoint, lang)
    const url = buildRequestUrl(endpoint, method, requestConfig.queryParamName || 'lang', lang, requestConfig.baseUrl)
    const body = resolveBody(requestConfig.body, lang)

    const headers = {
      ...requestConfig.headers,
    }

    const init: RequestInit = {
      method,
      headers,
    }

    if (body !== undefined && methodWithBody.has(method)) {
      if (!headers['Content-Type']) {
        headers['Content-Type'] = 'application/json'
      }

      init.body = typeof body === 'string' ? body : JSON.stringify(body)
    }

    const response = await requester(url, init)
    if (!response.ok) {
      throw new Error(`[I18n Error]: Dictionary request failed with status ${response.status}.`)
    }

    const payload = await parseResponsePayload(response)
    const adapter = requestConfig.responseAdapter || defaultResponseAdapter
    const dictionary = adapter(payload, lang)

    if (!isDictionaryData(dictionary)) {
      throw new TypeError(`[I18n Error]: API response adapter must return a dictionary object for language "${lang}".`)
    }

    return dictionary
  }
}

function getDefaultRequester(): (input: string, init?: RequestInit) => Promise<Response> {
  const globalScope = globalThis as {
    fetch?: (input: string, init?: RequestInit) => Promise<Response>
  }

  if (!globalScope.fetch) {
    throw new Error('[I18n Error]: No fetch implementation found. Please provide request.requester or fetchDictionary.')
  }

  return globalScope.fetch
}

function resolveEndpoint(endpoint: string | ((lang: SupportedLanguage) => string), lang: SupportedLanguage): string {
  return typeof endpoint === 'function' ? endpoint(lang) : endpoint
}

function buildRequestUrl(
  endpoint: string,
  method: DictionaryRequestMethod,
  queryParamName: string,
  lang: SupportedLanguage,
  baseUrl?: string,
): string {
  if (method !== 'GET') {
    return resolveAbsoluteUrl(endpoint, baseUrl)
  }

  try {
    const url = new URL(endpoint, getBaseUrl(baseUrl))
    url.searchParams.set(queryParamName, String(lang))
    return url.toString()
  }
  catch {
    const absoluteEndpoint = resolveAbsoluteUrl(endpoint, baseUrl)
    const separator = absoluteEndpoint.includes('?') ? '&' : '?'
    return `${absoluteEndpoint}${separator}${encodeURIComponent(queryParamName)}=${encodeURIComponent(String(lang))}`
  }
}

function resolveBody(body: unknown | ((lang: SupportedLanguage) => unknown) | undefined, lang: SupportedLanguage): unknown {
  if (typeof body === 'function') {
    return body(lang)
  }

  return body
}

async function parseResponsePayload(response: Response): Promise<unknown> {
  const contentType = response.headers.get('content-type') || ''
  if (contentType.includes('application/json')) {
    return response.json()
  }

  const text = await response.text()
  try {
    return JSON.parse(text)
  }
  catch {
    return text
  }
}

function defaultResponseAdapter(payload: unknown): DictionaryData {
  if (isDictionaryData(payload)) {
    return payload
  }

  if (payload && typeof payload === 'object') {
    const record = payload as Record<string, unknown>
    const candidates = [record.data, record.dictionary, record.messages, record.translations]
    for (const candidate of candidates) {
      if (isDictionaryData(candidate)) {
        return candidate
      }
    }
  }

  throw new Error('[I18n Error]: Unable to resolve dictionary from API payload. Please provide request.responseAdapter.')
}

function isDictionaryData(value: unknown): value is DictionaryData {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    return false
  }

  return Object.values(value).every(item => typeof item === 'string')
}

function resolveAbsoluteUrl(endpoint: string, baseUrl?: string): string {
  try {
    return new URL(endpoint).toString()
  }
  catch {
    return new URL(endpoint, getBaseUrl(baseUrl)).toString()
  }
}

function getBaseUrl(baseUrl?: string): string {
  if (baseUrl) {
    return baseUrl
  }

  const globalScope = globalThis as {
    location?: { origin?: string }
  }

  return globalScope.location?.origin || 'http://localhost'
}
