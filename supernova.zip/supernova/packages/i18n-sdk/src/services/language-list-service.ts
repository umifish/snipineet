import type { DictionaryRequestMethod, LanguageListRequestConfig, SupportedLanguage } from '../types'

const methodWithBody = new Set<DictionaryRequestMethod>(['POST', 'PUT', 'PATCH', 'DELETE'])

export function createLanguageListFetcher(
  fetchLanguageList: (() => Promise<SupportedLanguage[]>) | undefined,
  requestConfig: LanguageListRequestConfig | undefined,
): (() => Promise<SupportedLanguage[]>) | undefined {
  if (fetchLanguageList) {
    return fetchLanguageList
  }

  if (!requestConfig) {
    return undefined
  }

  return async () => {
    const requester = requestConfig.requester || getDefaultRequester()
    const method = requestConfig.method || 'GET'
    const endpoint = resolveEndpoint(requestConfig.endpoint)
    const url = resolveAbsoluteUrl(endpoint, requestConfig.baseUrl)

    const headers = {
      ...requestConfig.headers,
    }

    const init: RequestInit = {
      method,
      headers,
    }

    if (requestConfig.body !== undefined && methodWithBody.has(method)) {
      if (!headers['Content-Type']) {
        headers['Content-Type'] = 'application/json'
      }

      init.body = typeof requestConfig.body === 'string'
        ? requestConfig.body
        : JSON.stringify(requestConfig.body)
    }

    const response = await requester(url, init)
    if (!response.ok) {
      throw new Error(`[I18n Error]: Language list request failed with status ${response.status}.`)
    }

    const payload = await parseResponsePayload(response)
    const adapter = requestConfig.responseAdapter || defaultResponseAdapter
    const languages = adapter(payload)

    if (!Array.isArray(languages)) {
      throw new TypeError('[I18n Error]: languageListRequest.responseAdapter must return an array.')
    }

    return languages
      .map(lang => String(lang).trim())
      .filter(Boolean)
  }
}

function getDefaultRequester(): (input: string, init?: RequestInit) => Promise<Response> {
  const globalScope = globalThis as {
    fetch?: (input: string, init?: RequestInit) => Promise<Response>
  }

  if (!globalScope.fetch) {
    throw new Error('[I18n Error]: No fetch implementation found. Please provide languageListRequest.requester or fetchLanguageList.')
  }

  return globalScope.fetch
}

function resolveEndpoint(endpoint: string | (() => string)): string {
  return typeof endpoint === 'function' ? endpoint() : endpoint
}

async function parseResponsePayload(response: Response): Promise<unknown> {
  const contentType = response.headers.get('content-type') || ''
  if (contentType.includes('application/json')) {
    return response.json()
  }

  const text = await response.text()
  try {
    return JSON.parse(text)
  }
  catch {
    return text
  }
}

function defaultResponseAdapter(payload: unknown): SupportedLanguage[] {
  if (Array.isArray(payload)) {
    return payload as SupportedLanguage[]
  }

  if (payload && typeof payload === 'object') {
    const record = payload as Record<string, unknown>
    const candidates = [record.data, record.languages, record.list]

    for (const candidate of candidates) {
      if (Array.isArray(candidate)) {
        return candidate as SupportedLanguage[]
      }
    }
  }

  throw new Error('[I18n Error]: Unable to resolve language list from API payload. Please provide languageListRequest.responseAdapter.')
}

function resolveAbsoluteUrl(endpoint: string, baseUrl?: string): string {
  try {
    return new URL(endpoint).toString()
  }
  catch {
    return new URL(endpoint, getBaseUrl(baseUrl)).toString()
  }
}

function getBaseUrl(baseUrl?: string): string {
  if (baseUrl) {
    return baseUrl
  }

  const globalScope = globalThis as {
    location?: { origin?: string }
  }

  return globalScope.location?.origin || 'http://localhost'
}
