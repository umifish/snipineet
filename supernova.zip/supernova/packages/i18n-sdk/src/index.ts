/**
 * 使用示例：
 * const i18n = await I18n.create({
 *   fetchDictionary: async (lang) => fetch(`/api/i18n/${lang}`).then((res) => res.json())
 * })
 */

export {
  createDictionaryCache,
  createDictionaryCacheAdapter,
  IndexedDBDictionaryCacheAdapter,
  LocalStorageDictionaryCacheAdapter,
  MemoryDictionaryCacheAdapter,
} from './cache'
export { DEFAULT_BOOTSTRAP_CONFIG, DEFAULT_I18N_CONFIG, getDefaultI18nConfig, mergeI18nConfig } from './config'
export { I18n } from './core/I18n'
export {
  createReactI18next,
  createReactI18nextOptions,
  createReactI18nextResources,
  syncReactI18nextLanguage,
} from './integrations/react-i18next'
export type { CreateReactI18nextConfig } from './integrations/react-i18next'
export {
  createVueI18n,
  createVueI18nMessages,
  createVueI18nOptions,
  syncVueI18nLanguage,
} from './integrations/vue-i18n'
export type { CreateVueI18nConfig } from './integrations/vue-i18n'
export { installRequestInterceptors } from './interceptors'
export type {
  CacheAdapterPreset,
  CacheConfig,
  CachedDictionaryEntry,
  CacheStrategy,
  DictionaryCache,
  DictionaryCacheAdapter,
  DictionaryRequestConfig,
  DictionaryRequestMethod,
  I18nApiConfig,
  I18nBootstrapConfig,
  I18nConfig,
  InstalledRequestInterceptors,
  LanguageListRequestConfig,
  ReactI18nextBridgeOptions,
  ReactI18nextOptions,
  RequestInterceptorConfig,
  SupportedLanguage,
  UserProfileLocalePayload,
  VueI18nBridgeOptions,
  VueI18nOptions,
} from './types'
