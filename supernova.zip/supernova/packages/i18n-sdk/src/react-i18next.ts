export { createReactI18next, createReactI18nextOptions, createReactI18nextResources, syncReactI18nextLanguage } from './integrations/react-i18next'
export type { CreateReactI18nextConfig } from './integrations/react-i18next'
export type { ReactI18nextBridgeOptions, ReactI18nextOptions } from './types'
