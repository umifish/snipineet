export { createVueI18n, createVueI18nMessages, createVueI18nOptions, syncVueI18nLanguage } from './integrations/vue-i18n'
export type { CreateVueI18nConfig } from './integrations/vue-i18n'
export type { VueI18nBridgeOptions, VueI18nOptions } from './types'
