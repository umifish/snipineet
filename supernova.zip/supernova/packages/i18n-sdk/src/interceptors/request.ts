import type { InstalledRequestInterceptors, RequestInterceptorConfig } from '../types'

const xhrMetaSymbol = Symbol('i18n-sdk-xhr-meta')

interface XhrMeta {
  headers: Record<string, string>
  requestUrl?: string
}

export function installRequestInterceptors(config: RequestInterceptorConfig): InstalledRequestInterceptors {
  const globalScope = globalThis as {
    XMLHttpRequest?: typeof XMLHttpRequest
    fetch?: (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>
  }

  const interceptFetch = config.interceptFetch !== false
  const interceptXMLHttpRequest = config.interceptXMLHttpRequest !== false
  const langHeaderName = config.langHeaderName || 'x-lang'
  const zoneHeaderName = config.zoneHeaderName || 'x-zone'
  const overrideExisting = config.overrideExisting === true
  const requestUrlMatchers = normalizeUrlMatchers(config.requestUrlPatterns)

  const originalFetch = globalScope.fetch
  const xhrCtor = globalScope.XMLHttpRequest
  const originalXhrOpen = xhrCtor?.prototype.open
  const originalXhrSend = xhrCtor?.prototype.send
  const originalXhrSetRequestHeader = xhrCtor?.prototype.setRequestHeader

  if (interceptFetch && originalFetch) {
    globalScope.fetch = async (input, init) => {
      const requestUrl = resolveFetchRequestUrl(input)
      if (!shouldInterceptRequest(requestUrl, requestUrlMatchers)) {
        return originalFetch(input, init)
      }

      const headers = new Headers(
        init?.headers
        || (typeof Request !== 'undefined' && input instanceof Request ? input.headers : undefined),
      )
      injectHeaders(
        headers,
        {
          getLang: config.getLang,
          getZone: config.getZone,
          langHeaderName,
          zoneHeaderName,
          overrideExisting,
        },
      )

      return originalFetch(input, {
        ...init,
        headers,
      })
    }
  }

  if (interceptXMLHttpRequest && xhrCtor && originalXhrOpen && originalXhrSend && originalXhrSetRequestHeader) {
    xhrCtor.prototype.open = function open(
      this: XMLHttpRequest,
      method: string,
      url: string | URL,
      async?: boolean,
      username?: string | null,
      password?: string | null,
    ): void {
      const meta = getOrCreateXhrMeta(this)
      meta.requestUrl = resolveXhrRequestUrl(url)
      return originalXhrOpen.call(this, method, url, async ?? true, username, password)
    }

    xhrCtor.prototype.setRequestHeader = function setRequestHeader(this: XMLHttpRequest, headerName: string, headerValue: string): void {
      const meta = getOrCreateXhrMeta(this)
      meta.headers[headerName.toLowerCase()] = headerValue
      return originalXhrSetRequestHeader.call(this, headerName, headerValue)
    }

    xhrCtor.prototype.send = function send(this: XMLHttpRequest, body?: Document | XMLHttpRequestBodyInit | null): void {
      const meta = getOrCreateXhrMeta(this)
      if (!shouldInterceptRequest(meta.requestUrl, requestUrlMatchers)) {
        return originalXhrSend.call(this, body)
      }

      injectXhrHeaders(
        this,
        meta,
        {
          getLang: config.getLang,
          getZone: config.getZone,
          langHeaderName,
          zoneHeaderName,
          overrideExisting,
        },
      )

      return originalXhrSend.call(this, body)
    }
  }

  return {
    uninstall: () => {
      if (interceptFetch && originalFetch) {
        globalScope.fetch = originalFetch
      }

      if (interceptXMLHttpRequest && xhrCtor && originalXhrOpen && originalXhrSend && originalXhrSetRequestHeader) {
        xhrCtor.prototype.open = originalXhrOpen
        xhrCtor.prototype.send = originalXhrSend
        xhrCtor.prototype.setRequestHeader = originalXhrSetRequestHeader
      }
    },
  }
}

function injectHeaders(
  headers: Headers,
  options: {
    getLang: () => string | undefined
    getZone?: () => string | undefined
    langHeaderName: string
    zoneHeaderName: string
    overrideExisting: boolean
  },
): void {
  const lang = options.getLang()
  const zone = options.getZone?.()

  if (lang) {
    const hasLang = headers.has(options.langHeaderName)
    if (options.overrideExisting || !hasLang) {
      headers.set(options.langHeaderName, lang)
    }
  }

  if (zone) {
    const hasZone = headers.has(options.zoneHeaderName)
    if (options.overrideExisting || !hasZone) {
      headers.set(options.zoneHeaderName, zone)
    }
  }
}

function injectXhrHeaders(
  xhr: XMLHttpRequest,
  meta: XhrMeta,
  options: {
    getLang: () => string | undefined
    getZone?: () => string | undefined
    langHeaderName: string
    zoneHeaderName: string
    overrideExisting: boolean
  },
): void {
  const lang = options.getLang()
  const zone = options.getZone?.()

  const langHeaderKey = options.langHeaderName.toLowerCase()
  const zoneHeaderKey = options.zoneHeaderName.toLowerCase()

  if (lang && (options.overrideExisting || !meta.headers[langHeaderKey])) {
    xhr.setRequestHeader(options.langHeaderName, lang)
    meta.headers[langHeaderKey] = lang
  }

  if (zone && (options.overrideExisting || !meta.headers[zoneHeaderKey])) {
    xhr.setRequestHeader(options.zoneHeaderName, zone)
    meta.headers[zoneHeaderKey] = zone
  }
}

function getOrCreateXhrMeta(xhr: XMLHttpRequest): XhrMeta {
  type XhrWithMeta = XMLHttpRequest & {
    [xhrMetaSymbol]?: XhrMeta
  }

  const xhrWithMeta = xhr as XhrWithMeta
  if (!xhrWithMeta[xhrMetaSymbol]) {
    xhrWithMeta[xhrMetaSymbol] = {
      headers: {},
    }
  }

  return xhrWithMeta[xhrMetaSymbol]
}

function normalizeUrlMatchers(patterns?: Array<string | RegExp>): RegExp[] {
  if (!patterns || patterns.length === 0) {
    return []
  }

  return patterns.map((pattern) => {
    if (pattern instanceof RegExp) {
      return pattern
    }

    return new RegExp(pattern)
  })
}

function shouldInterceptRequest(url: string | undefined, matchers: RegExp[]): boolean {
  if (matchers.length === 0) {
    return true
  }

  if (!url) {
    return false
  }

  return matchers.some(matcher => matcher.test(url))
}

function resolveFetchRequestUrl(input: RequestInfo | URL): string | undefined {
  if (typeof input === 'string') {
    return input
  }

  if (typeof URL !== 'undefined' && input instanceof URL) {
    return input.toString()
  }

  if (typeof Request !== 'undefined' && input instanceof Request) {
    return input.url
  }

  return undefined
}

function resolveXhrRequestUrl(url: string | URL): string {
  if (typeof url === 'string') {
    return url
  }

  return url.toString()
}
