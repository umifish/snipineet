export type SupportedLanguage = 'zh' | 'en' | 'ko' | string
export type DictionaryData = Record<string, string>
export type CacheAdapterPreset = 'memory' | 'localStorage' | 'indexedDB'
export type CacheStrategy = 'network-first' | 'cache-first' | 'cache-only' | 'network-only' | 'stale-while-revalidate'
export type DictionaryRequestMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE'

export interface I18nApiConfig {
  /** API 根地址，例如 https://api.example.com */
  baseUrl?: string
  /** 多语言文案接口地址 */
  dictionaryEndpoint?: string | ((lang: SupportedLanguage) => string)
  /** 查询语种列表接口地址 */
  languageListEndpoint?: string | (() => string)
}

export interface RequestInterceptorConfig {
  /** 是否拦截 fetch，默认 true */
  interceptFetch?: boolean
  /** 是否拦截 XMLHttpRequest，默认 true */
  interceptXMLHttpRequest?: boolean
  /** 语言 header 名，默认 x-lang */
  langHeaderName?: string
  /** 时区 header 名，默认 x-zone */
  zoneHeaderName?: string
  /** 是否覆盖已有 header，默认 false */
  overrideExisting?: boolean
  /** 请求 URL 匹配规则（字符串会转为 RegExp）；未配置时默认拦截全部 */
  requestUrlPatterns?: Array<string | RegExp>
  /** 获取当前语言 */
  getLang: () => string | undefined
  /** 获取当前时区 */
  getZone?: () => string | undefined
}

export interface InstalledRequestInterceptors {
  uninstall: () => void
}

export interface VueI18nBridgeOptions {
  fallbackLocale?: SupportedLanguage
  preloadLanguages?: SupportedLanguage[]
}

export interface VueI18nOptions {
  locale: string
  fallbackLocale: string
  messages: Record<string, DictionaryData>
}

export interface ReactI18nextBridgeOptions {
  fallbackLng?: SupportedLanguage
  preloadLanguages?: SupportedLanguage[]
}

export interface ReactI18nextOptions {
  fallbackLng: string
  lng: string
  resources: Record<string, { translation: DictionaryData }>
}

export interface UserProfileLocalePayload {
  language?: SupportedLanguage
  zone?: string
  timezone?: string
}

export interface I18nBootstrapConfig {
  /** 自动安装请求拦截器，默认 true */
  autoInstallInterceptors?: boolean
  /** URL 中语言参数名，默认 lang */
  langQueryParamName?: string
  /** URL 中时区参数名，默认 zone */
  zoneQueryParamName?: string
  /** localStorage 语言键名，默认 i18n_lang */
  localStorageLangKey?: string
  /** localStorage 时区键名，默认 i18n_zone */
  localStorageZoneKey?: string
  /** 获取个人信息（含 language/zone） */
  fetchUserProfile?: () => Promise<UserProfileLocalePayload>
  /** 获取可用语言列表 */
  fetchLanguageList?: () => Promise<SupportedLanguage[]>
  /** 可用语言列表 API 配置（可替代 fetchLanguageList） */
  languageListRequest?: LanguageListRequestConfig
  /** 请求拦截 URL 匹配规则（字符串会转为 RegExp）；未配置时默认拦截全部 */
  interceptorUrlPatterns?: Array<string | RegExp>
  /** 文案加载失败时的兜底语言，默认 zh */
  fallbackLanguage?: SupportedLanguage
  /** 兜底时区，默认 Asia/Shanghai */
  fallbackZone?: string
}

export interface LanguageListRequestConfig {
  /** API 根地址，可选 */
  baseUrl?: string
  /** 请求地址 */
  endpoint: string | (() => string)
  /** 请求方法，默认 GET */
  method?: DictionaryRequestMethod
  /** 请求头 */
  headers?: Record<string, string>
  /** 请求体 */
  body?: unknown
  /** 自定义请求器，默认使用全局 fetch */
  requester?: (input: string, init?: RequestInit) => Promise<Response>
  /** API 响应适配器，将任意结构映射为语言列表 */
  responseAdapter?: (payload: unknown) => SupportedLanguage[]
}

export interface CachedDictionaryEntry {
  dictionary: DictionaryData
  updatedAt: number
}

export interface DictionaryCacheAdapter {
  get: (lang: SupportedLanguage) => Promise<CachedDictionaryEntry | undefined>
  set: (lang: SupportedLanguage, entry: CachedDictionaryEntry) => Promise<void>
  remove?: (lang: SupportedLanguage) => Promise<void>
  clear?: () => Promise<void>
}

export interface DictionaryCache {
  get: (lang: SupportedLanguage) => Promise<CachedDictionaryEntry | undefined>
  set: (lang: SupportedLanguage, entry: CachedDictionaryEntry) => Promise<void>
  remove: (lang: SupportedLanguage) => Promise<void>
  clear: () => Promise<void>
}

export interface CacheConfig {
  /** 是否启用缓存功能，默认启用 */
  enabled?: boolean
  /** 缓存适配器类型或自定义适配器实例 */
  adapter?: CacheAdapterPreset | DictionaryCacheAdapter
  /** 缓存策略，默认 network-first */
  strategy?: CacheStrategy
  /** 缓存有效期（毫秒），超时后视为失效 */
  ttlMs?: number
  /** localStorage key 前缀 */
  keyPrefix?: string
  /** indexedDB 数据库名 */
  dbName?: string
  /** indexedDB 对象仓库名 */
  storeName?: string
}

export interface DictionaryRequestConfig {
  /** API 根地址，可选 */
  baseUrl?: string
  /** 请求地址，支持函数动态拼接 */
  endpoint: string | ((lang: SupportedLanguage) => string)
  /** 请求方法，默认 GET */
  method?: DictionaryRequestMethod
  /** 请求头 */
  headers?: Record<string, string>
  /** 查询参数名，默认 lang */
  queryParamName?: string
  /** 请求体，可为对象或函数 */
  body?: unknown | ((lang: SupportedLanguage) => unknown)
  /** 自定义请求器，默认使用全局 fetch */
  requester?: (input: string, init?: RequestInit) => Promise<Response>
  /** API 响应适配器，将任意结构映射为字典 */
  responseAdapter?: (payload: unknown, lang: SupportedLanguage) => DictionaryData
}

export interface I18nConfig {
  /** API 地址配置 */
  api?: I18nApiConfig
  /** 默认语言，必填或提供回退值 */
  defaultLanguage?: SupportedLanguage
  /** 系统支持的语言列表，默认包含中英韩 */
  supportedLanguages?: SupportedLanguage[]
  /** 异步获取远端语言字典的接口函数 */
  fetchDictionary?: (lang: SupportedLanguage) => Promise<DictionaryData>
  /** 远程字典请求配置（可替代 fetchDictionary） */
  request?: DictionaryRequestConfig
  /** 远程字典请求配置（语义化别名，优先级高于 request） */
  dictionaryRequest?: DictionaryRequestConfig
  /** 初始字典配置 */
  dictionaries?: Record<string, Record<string, string>>
  /** 是否在初始化时自动预加载当前语种文案，默认开启 */
  autoPreloadCurrentLanguage?: boolean
  /** 缓存配置 */
  cache?: CacheConfig
  /** 初始化流程配置 */
  bootstrap?: I18nBootstrapConfig
}
