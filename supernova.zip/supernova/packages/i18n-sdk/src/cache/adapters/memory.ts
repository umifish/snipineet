import type { CachedDictionaryEntry, DictionaryCacheAdapter, SupportedLanguage } from '../../types'

export class MemoryDictionaryCacheAdapter implements DictionaryCacheAdapter {
  private cache = new Map<string, CachedDictionaryEntry>()

  public async get(lang: SupportedLanguage): Promise<CachedDictionaryEntry | undefined> {
    return this.cache.get(lang)
  }

  public async set(lang: SupportedLanguage, entry: CachedDictionaryEntry): Promise<void> {
    this.cache.set(lang, entry)
  }

  public async remove(lang: SupportedLanguage): Promise<void> {
    this.cache.delete(lang)
  }

  public async clear(): Promise<void> {
    this.cache.clear()
  }
}
