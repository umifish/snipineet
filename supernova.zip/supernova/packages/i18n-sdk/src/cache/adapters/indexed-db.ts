import type { CachedDictionaryEntry, DictionaryCacheAdapter, SupportedLanguage } from '../../types'

interface IndexedDBAdapterOptions {
  dbName?: string
  storeName?: string
}

export class IndexedDBDictionaryCacheAdapter implements DictionaryCacheAdapter {
  private dbName: string
  private storeName: string

  constructor(options: IndexedDBAdapterOptions = {}) {
    this.dbName = options.dbName || 'i18n-sdk-cache'
    this.storeName = options.storeName || 'dictionaries'
  }

  public async get(lang: SupportedLanguage): Promise<CachedDictionaryEntry | undefined> {
    const db = await this.openDatabase()
    if (!db) {
      return undefined
    }

    return new Promise((resolve) => {
      const transaction = db.transaction(this.storeName, 'readonly')
      const store = transaction.objectStore(this.storeName)
      const request = store.get(lang)

      request.onsuccess = () => {
        const result = request.result as CachedDictionaryEntry | undefined
        if (!result || typeof result !== 'object' || !result.dictionary || typeof result.updatedAt !== 'number') {
          resolve(undefined)
          return
        }

        resolve(result)
      }

      request.onerror = () => resolve(undefined)
    })
  }

  public async set(lang: SupportedLanguage, entry: CachedDictionaryEntry): Promise<void> {
    const db = await this.openDatabase()
    if (!db) {
      return
    }

    await new Promise<void>((resolve) => {
      const transaction = db.transaction(this.storeName, 'readwrite')
      const store = transaction.objectStore(this.storeName)
      store.put(entry, lang)
      transaction.oncomplete = () => resolve()
      transaction.onerror = () => resolve()
    })
  }

  public async remove(lang: SupportedLanguage): Promise<void> {
    const db = await this.openDatabase()
    if (!db) {
      return
    }

    await new Promise<void>((resolve) => {
      const transaction = db.transaction(this.storeName, 'readwrite')
      const store = transaction.objectStore(this.storeName)
      store.delete(lang)
      transaction.oncomplete = () => resolve()
      transaction.onerror = () => resolve()
    })
  }

  public async clear(): Promise<void> {
    const db = await this.openDatabase()
    if (!db) {
      return
    }

    await new Promise<void>((resolve) => {
      const transaction = db.transaction(this.storeName, 'readwrite')
      const store = transaction.objectStore(this.storeName)
      store.clear()
      transaction.oncomplete = () => resolve()
      transaction.onerror = () => resolve()
    })
  }

  private async openDatabase(): Promise<IDBDatabase | undefined> {
    const indexedDBRef = getIndexedDB()
    if (!indexedDBRef) {
      return undefined
    }

    return new Promise((resolve) => {
      const request = indexedDBRef.open(this.dbName, 1)

      request.onupgradeneeded = () => {
        const db = request.result
        if (!db.objectStoreNames.contains(this.storeName)) {
          db.createObjectStore(this.storeName)
        }
      }

      request.onsuccess = () => resolve(request.result)
      request.onerror = () => resolve(undefined)
    })
  }
}

function getIndexedDB(): IDBFactory | undefined {
  const globalScope = globalThis as {
    indexedDB?: IDBFactory
  }

  return globalScope.indexedDB
}
