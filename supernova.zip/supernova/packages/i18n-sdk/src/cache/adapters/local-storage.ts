import type { CachedDictionaryEntry, DictionaryCacheAdapter, SupportedLanguage } from '../../types'

interface LocalStorageAdapterOptions {
  keyPrefix?: string
}

export class LocalStorageDictionaryCacheAdapter implements DictionaryCacheAdapter {
  private keyPrefix: string

  constructor(options: LocalStorageAdapterOptions = {}) {
    this.keyPrefix = options.keyPrefix || 'i18n-sdk:dictionary:'
  }

  public async get(lang: SupportedLanguage): Promise<CachedDictionaryEntry | undefined> {
    const storage = getLocalStorage()
    if (!storage) {
      return undefined
    }

    try {
      const raw = storage.getItem(this.buildKey(lang))
      if (!raw) {
        return undefined
      }

      const parsed = JSON.parse(raw) as CachedDictionaryEntry
      if (!parsed || typeof parsed !== 'object' || !parsed.dictionary || typeof parsed.updatedAt !== 'number') {
        return undefined
      }

      return parsed
    }
    catch {
      return undefined
    }
  }

  public async set(lang: SupportedLanguage, entry: CachedDictionaryEntry): Promise<void> {
    const storage = getLocalStorage()
    if (!storage) {
      return
    }

    try {
      storage.setItem(this.buildKey(lang), JSON.stringify(entry))
    }
    catch {
      // ignore quota/storage errors
    }
  }

  public async remove(lang: SupportedLanguage): Promise<void> {
    const storage = getLocalStorage()
    if (!storage) {
      return
    }

    try {
      storage.removeItem(this.buildKey(lang))
    }
    catch {
      // ignore storage errors
    }
  }

  public async clear(): Promise<void> {
    const storage = getLocalStorage()
    if (!storage) {
      return
    }

    try {
      const keysToRemove: string[] = []
      for (let index = 0; index < storage.length; index += 1) {
        const key = storage.key(index)
        if (key?.startsWith(this.keyPrefix)) {
          keysToRemove.push(key)
        }
      }

      for (const key of keysToRemove) {
        storage.removeItem(key)
      }
    }
    catch {
      // ignore storage errors
    }
  }

  private buildKey(lang: SupportedLanguage): string {
    return `${this.keyPrefix}${lang}`
  }
}

function getLocalStorage(): Storage | undefined {
  const globalScope = globalThis as {
    localStorage?: Storage
  }

  return globalScope.localStorage
}
