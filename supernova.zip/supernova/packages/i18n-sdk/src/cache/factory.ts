import type { CacheConfig, DictionaryCache, DictionaryCacheAdapter, SupportedLanguage } from '../types'
import { IndexedDBDictionaryCacheAdapter } from './adapters/indexed-db'
import { LocalStorageDictionaryCacheAdapter } from './adapters/local-storage'
import { MemoryDictionaryCacheAdapter } from './adapters/memory'

export function createDictionaryCache(config?: CacheConfig): DictionaryCache | undefined {
  if (config?.enabled === false) {
    return undefined
  }

  let adapter: DictionaryCacheAdapter

  if (!config?.adapter || config.adapter === 'memory') {
    adapter = new MemoryDictionaryCacheAdapter()
    return withUnifiedOperations(adapter)
  }

  if (config.adapter === 'localStorage') {
    adapter = new LocalStorageDictionaryCacheAdapter({
      keyPrefix: config.keyPrefix,
    })
    return withUnifiedOperations(adapter)
  }

  if (config.adapter === 'indexedDB') {
    adapter = new IndexedDBDictionaryCacheAdapter({
      dbName: config.dbName,
      storeName: config.storeName,
    })
    return withUnifiedOperations(adapter)
  }

  adapter = config.adapter
  return withUnifiedOperations(adapter)
}

export function createDictionaryCacheAdapter(config?: CacheConfig): DictionaryCache | undefined {
  return createDictionaryCache(config)
}

function withUnifiedOperations(adapter: DictionaryCacheAdapter): DictionaryCache {
  return {
    get: adapter.get,
    set: adapter.set,
    remove: adapter.remove || noOpRemove,
    clear: adapter.clear || noOpClear,
  }
}

async function noOpRemove(_lang: SupportedLanguage): Promise<void> {
  return Promise.resolve()
}

async function noOpClear(): Promise<void> {
  return Promise.resolve()
}
