import { fileURLToPath } from 'node:url'
import { defineConfig } from 'vite'

const entries = {
  'index': fileURLToPath(new URL('./src/index.ts', import.meta.url)),
  'react-i18next': fileURLToPath(new URL('./src/react-i18next.ts', import.meta.url)),
  'vue-i18n': fileURLToPath(new URL('./src/vue-i18n.ts', import.meta.url)),
}

export default defineConfig({
  build: {
    lib: {
      entry: entries,
      name: 'SupernovaI18n',
      formats: ['es', 'cjs'],
      fileName: (format, entryName) => `${entryName}.${format === 'es' ? 'js' : 'cjs'}`,
    },
    sourcemap: true,
    emptyOutDir: true,
    rollupOptions: {
      external: [
        'i18next',
        'react-i18next',
        'vue',
        'vue-i18n',
      ],
    },
  },
})
