import { I18n } from '@supernova/i18n-sdk'
import { createReactI18next } from '@supernova/i18n-sdk/react-i18next'
import React from 'react'

import ReactDOM from 'react-dom/client'
import App from './App'
import './style.css'

const dictionaries: Record<string, Record<string, string>> = {
  zh: {
    title: 'React 示例',
    desc: '这是通过 @supernova/i18n-sdk 与 react-i18next 联动的可运行示例。',
    lang: '当前语言: {{lang}}',
  },
  en: {
    title: 'React Demo',
    desc: 'This is a runnable example integrated with @supernova/i18n-sdk and react-i18next.',
    lang: 'Current language: {{lang}}',
  },
  ko: {
    title: 'React 예제',
    desc: '@supernova/i18n-sdk 와 react-i18next 연동 실행 예제입니다.',
    lang: '현재 언어: {{lang}}',
  },
}

const fallbackLanguage = 'zh'
const fallbackZone = 'Asia/Shanghai'

void bootstrap()

async function bootstrap() {
  try {
    I18n.resetInstance()
    I18n.configureDefaultConfig({
      defaultLanguage: fallbackLanguage,
      supportedLanguages: ['zh', 'en', 'ko'],
      cache: {
        adapter: 'memory',
        ttlMs: 1000 * 60 * 10,
      },
      bootstrap: {
        autoInstallInterceptors: true,
        localStorageLangKey: 'supernova:lang',
        localStorageZoneKey: 'supernova:zone',
        fallbackLanguage,
        fallbackZone,
        fetchUserProfile,
        fetchLanguageList,
      },
      fetchDictionary: async (lang) => {
        const dict = dictionaries[String(lang)]
        if (!dict) {
          throw new Error(`Dictionary not found for language: ${lang}`)
        }

        return dict
      },
    })

    const sdk = await I18n.getInstance()

    await createReactI18next(sdk, {
      fallbackLng: fallbackLanguage,
      preloadLanguages: ['en', 'ko'],
    })

    ReactDOM.createRoot(document.getElementById('root')!).render(
      <React.StrictMode>
        <App i18nSdk={sdk} />
      </React.StrictMode>,
    )
  }
  catch (error) {
    renderInitError(error)
  }
}

async function fetchUserProfile(): Promise<{ language?: string, zone?: string }> {
  await delay(80)
  return {
    language: 'en',
    zone: 'Asia/Shanghai',
  }
}

async function fetchLanguageList(): Promise<string[]> {
  await delay(60)
  return ['zh', 'en', 'ko']
}

function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms))
}

function renderInitError(error: unknown): void {
  const message = error instanceof Error ? error.message : 'Unknown initialization error'
  const root = document.getElementById('root')
  if (!root) {
    return
  }

  root.innerHTML = `<pre style="padding:16px;color:#b91c1c;white-space:pre-wrap;">[React i18n init failed]\n${message}</pre>`
}
