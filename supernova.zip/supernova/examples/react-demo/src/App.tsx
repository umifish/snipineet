import type { I18n } from '@supernova/i18n-sdk'
import { syncReactI18nextLanguage } from '@supernova/i18n-sdk/react-i18next'

import { useState } from 'react'
import { useTranslation } from 'react-i18next'

interface Props {
  i18nSdk: I18n
}

export default function App({ i18nSdk }: Props) {
  const { t, i18n } = useTranslation()
  const [pending, setPending] = useState(false)

  async function changeLanguage(lang: 'zh' | 'en' | 'ko') {
    setPending(true)
    try {
      await syncReactI18nextLanguage(i18nSdk, i18n, lang)
    }
    finally {
      setPending(false)
    }
  }

  return (
    <main className="page">
      <h1>{t('title')}</h1>
      <p>{t('desc')}</p>
      <p>{t('lang', { lang: i18n.language })}</p>

      <div className="actions">
        <button disabled={pending} onClick={() => changeLanguage('zh')}>中文</button>
        <button disabled={pending} onClick={() => changeLanguage('en')}>English</button>
        <button disabled={pending} onClick={() => changeLanguage('ko')}>한국어</button>
      </div>
    </main>
  )
}
