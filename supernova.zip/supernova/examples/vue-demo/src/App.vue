<script setup lang="ts">
import { computed, inject } from 'vue'
import { useI18n } from 'vue-i18n'

import { I18n } from '@supernova/i18n-sdk'
import { syncVueI18nLanguage } from '@supernova/i18n-sdk/vue-i18n'
import type { I18n as VueI18nInstance } from 'vue-i18n'

const sdk = inject<I18n>('sdk')
if (!sdk) {
  throw new Error('I18n SDK not provided')
}

const vueI18n = inject<VueI18nInstance>('vueI18n')
if (!vueI18n) {
  throw new Error('vue-i18n instance not provided')
}

const { t, locale } = useI18n()

const currentLang = computed(() => locale.value)

async function changeLanguage(lang: 'zh' | 'en' | 'ko') {
  await syncVueI18nLanguage(sdk, vueI18n, lang)
}
</script>

<template>
  <main class="page">
    <h1>{{ t('title') }}</h1>
    <p>{{ t('desc') }}</p>
    <p>{{ t('lang', { lang: currentLang }) }}</p>

    <div class="actions">
      <button @click="changeLanguage('zh')">中文</button>
      <button @click="changeLanguage('en')">English</button>
      <button @click="changeLanguage('ko')">한국어</button>
    </div>
  </main>
</template>
