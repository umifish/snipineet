import { I18n } from '@supernova/i18n-sdk'
import { createVueI18n } from '@supernova/i18n-sdk/vue-i18n'
import { createApp } from 'vue'

import App from './App.vue'
import './style.css'

const dictionaries: Record<string, Record<string, string>> = {
  zh: {
    title: 'Vue 示例',
    desc: '这是通过 @supernova/i18n-sdk 与 vue-i18n 联动的可运行示例。',
    lang: '当前语言: {lang}',
    switch: '切换语言',
  },
  en: {
    title: 'Vue Demo',
    desc: 'This is a runnable example integrated with @supernova/i18n-sdk and vue-i18n.',
    lang: 'Current language: {lang}',
    switch: 'Switch language',
  },
  ko: {
    title: 'Vue 예제',
    desc: '@supernova/i18n-sdk 와 vue-i18n 연동 실행 예제입니다.',
    lang: '현재 언어: {lang}',
    switch: '언어 전환',
  },
}

const fallbackLanguage = 'zh'
const fallbackZone = 'Asia/Shanghai'

void bootstrap()

async function bootstrap() {
  try {
    I18n.resetInstance()
    I18n.configureDefaultConfig({
      defaultLanguage: fallbackLanguage,
      supportedLanguages: ['zh', 'en', 'ko'],
      cache: {
        adapter: 'memory',
        ttlMs: 1000 * 60 * 10,
      },
      bootstrap: {
        autoInstallInterceptors: true,
        localStorageLangKey: 'supernova:lang',
        localStorageZoneKey: 'supernova:zone',
        fallbackLanguage,
        fallbackZone,
        fetchUserProfile,
        fetchLanguageList,
      },
      fetchDictionary: async (lang) => {
        const dict = dictionaries[String(lang)]
        if (!dict) {
          throw new Error(`Dictionary not found for language: ${lang}`)
        }

        return dict
      },
    })

    const sdk = await I18n.getInstance()

    const vueI18n = await createVueI18n(sdk, {
      fallbackLocale: fallbackLanguage,
      preloadLanguages: ['en', 'ko'],
    })

    createApp(App)
      .provide('sdk', sdk)
      .provide('vueI18n', vueI18n)
      .use(vueI18n)
      .mount('#app')
  }
  catch (error) {
    renderInitError(error)
  }
}

async function fetchUserProfile(): Promise<{ language?: string, zone?: string }> {
  await delay(80)
  return {
    language: 'en',
    zone: 'Asia/Shanghai',
  }
}

async function fetchLanguageList(): Promise<string[]> {
  await delay(60)
  return ['zh', 'en', 'ko']
}

function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms))
}

function renderInitError(error: unknown): void {
  const message = error instanceof Error ? error.message : 'Unknown initialization error'
  const app = document.getElementById('app')
  if (!app) {
    return
  }

  app.innerHTML = `<pre style="padding:16px;color:#b91c1c;white-space:pre-wrap;">[Vue i18n init failed]\n${message}</pre>`
}
