/**
 * Prettier（`prettier.config.mjs`）
 *
 * ## 角色
 * - **工具**：Prettier 负责换行、引号、分号、缩进等**纯格式**（与 ESLint 分工见下）。
 * - **本文件**：只写仓库根级默认项与**必要** `overrides`；逐项说明见下方块注释，全量选项表见「全量选项参考」。
 *
 * ## 与本仓库其它工具的关系（最佳实践）
 * - **ESLint**（`eslint.config.mjs`）：语义与部分风格规则；与 Prettier 冲突时优先用配置对齐，少用 `eslint-disable`（见 `docs/ENGINEERING_CAPABILITIES.md`「Linter」）。花括号位置与 `style/brace-style: 1tbs` 一致（如 `} catch {` 同一行，无 Stroustrup 式换行）。
 * - **EditorConfig**（`.editorconfig`）：编辑器级缩进/换行；与 Prettier 保持一致。
 * - **忽略范围**：`.prettierignore`（与 ESLint `ignores` 意图对齐：跳过构建产物等）。
 *
 * ## 修改约定
 * - 调整与 ESLint 交叉的格式（如箭头函数括号、行宽）时，**同时检查** `eslint.config.mjs` 是否需要同步。
 * - 升级 Prettier 大版本/小版本后，视情况运行 `pnpm docs:gen:prettier-full`，并核对 `docs/ENGINEERING_CAPABILITIES.md` 中格式相关描述。
 * - 生成型参考文件若语法上需要例外，用 `overrides` 收窄，避免改全局默认。
 *
 * ## 全量选项参考（本仓库生成）
 * - 表格：`docs/reference/prettier/prettier.full.reference.md`
 * - 注解 JSONC：`docs/reference/prettier/prettier.full.reference.jsonc`
 *
 * ## 参考链接
 * - Prettier Configuration：https://prettier.io/docs/configuration
 * - Prettier Options：https://prettier.io/docs/options
 */

/** @typedef {import('prettier').Config} PrettierConfig */

/**
 * @type {PrettierConfig}
 * @see https://prettier.io/docs/options
 */
export default {
  /**
   * 单参箭头函数也保留括号：`(x) => x`，与 ESLint `style/arrow-parens: ['error', 'always']` 一致，避免与格式工具拉扯。
   * @see https://prettier.io/docs/options#arrow-function-parentheses
   */
  arrowParens: 'always',

  /**
   * 对象字面量花括号内侧保留空格（`{ foo: bar }`）；与 `true` 对应的常见可读性风格一致。
   */
  bracketSpacing: true,

  /**
   * 超过该列宽时尝试换行；若项目内另有行宽约束（如 ESLint `max-len`），应与此协调。
   */
  printWidth: 160,

  /**
   * 对象键引号策略为 `consistent`——需要引号时全部加，避免同一对象内混用。
   */
  quoteProps: 'consistent',

  /**
   * 句末不输出分号；与仓库 TS/JS 默认风格一致。
   */
  semi: false,

  /**
   * 字符串使用单引号，减少与 JSX 属性双引号的视觉冲突。
   */
  singleQuote: true,

  /**
   * 缩进宽度（空格数），与 `.editorconfig` 的 `indent_size` 对齐。
   */
  tabWidth: 2,

  /**
   * 多行合法处保留尾随逗号（`all`），利于 diff 与 git blame。
   */
  trailingComma: 'all',

  /**
   * 使用空格缩进（`false`），不使用 Tab 字符。
   */
  useTabs: false,

  /**
   * 按 `files` glob 覆盖默认项；数组中靠后的条目优先。
   */
  overrides: [
    {
      /**
       * 命中该生成型 JSONC 的路径；其余文件仍使用全局尾逗号策略。
       */
      files: 'docs/reference/typescript/tsconfig.full.reference.jsonc',
      options: {
        /**
         * 此文件根对象在 `compilerOptions` 闭合后不能再有逗号，否则 JSONC 非法；故在此覆盖为 `none`。
         */
        trailingComma: 'none',
      },
    },
  ],
}
