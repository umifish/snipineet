# supernova

`pnpm` monorepo：应用、共享包、门户与工具脚本分目录管理；工程约定与协作流程见仓库内文档。

## 前置条件

- [Node.js](https://nodejs.org/)（与团队约定版本一致）
- [pnpm](https://pnpm.io/) **10.31.0**（与根目录 `package.json` 的 `packageManager` 一致；可用 `corepack enable` 对齐）
- [Python](https://www.python.org/) + [Ruff](https://docs.astral.sh/ruff/)：运行 `pnpm ruff` 时需要；规则见根目录 [`.ruff.toml`](./.ruff.toml)

## 快速开始

```bash
pnpm install
pnpm lint
pnpm format:check
pnpm typecheck
```

各 **应用 / 包** 的开发、构建命令请在其目录下的 `package.json` 与对应 `README.md` 中查看。

## 常用脚本（根目录）

| 命令                                | 说明                                         |
| ----------------------------------- | -------------------------------------------- |
| `pnpm lint` / `pnpm lint:fix`       | ESLint                                       |
| `pnpm format` / `pnpm format:check` | Prettier                                     |
| `pnpm typecheck`                    | 根 `tsconfig` 类型检查                       |
| `pnpm build`                        | 递归执行子包 `build`（有则执行）             |
| `pnpm test:gate` / `pnpm test:run`  | 测试门禁与递归测试                           |
| `pnpm ruff`                         | Python（Ruff），见 `.ruff.toml`              |
| `pnpm docs:gen:tsconfig-full`       | 生成 TS `compilerOptions` 全量参考（维护用） |
| `pnpm docs:gen:eslint-full`         | 生成 ESLint 规则参考（维护用）               |
| `pnpm docs:gen:prettier-full`       | 生成 Prettier 选项参考（维护用）             |

## 目录一览

| 路径         | 说明            |
| ------------ | --------------- |
| `apps/*`     | 应用            |
| `packages/*` | 共享包          |
| `portals/*`  | 门户 / 聚合入口 |
| `scripts/*`  | 仓库脚本        |
| `docs/*`     | 文档与参考      |

## 文档

| 文档                                                                     | 内容                                                |
| ------------------------------------------------------------------------ | --------------------------------------------------- |
| [`AGENTS.md`](./AGENTS.md)                                               | AI 协作总纲与文档地图                               |
| [`docs/ENGINEERING_CAPABILITIES.md`](./docs/ENGINEERING_CAPABILITIES.md) | 工程约束与工具链                                    |
| [`docs/CAPABILITY_MAP.md`](./docs/CAPABILITY_MAP.md)                     | 仓库工程能力地图（国际化、`packages/*` 与规则入口） |
| [`docs/AI_OPERATION_PLAYBOOK.md`](./docs/AI_OPERATION_PLAYBOOK.md)       | AI 落地操作与门禁顺序                               |
| [`docs/AI_ARCHIVING_SPEC.md`](./docs/AI_ARCHIVING_SPEC.md)               | AI 变更归档规范（条目写在 `docs/AI_CHANGELOG.md`）  |
| [`docs/AI_BUGFIX_GUIDE.md`](./docs/AI_BUGFIX_GUIDE.md)                   | AI 缺陷排查补充（按需）                             |
| [`docs/PR_TEMPLATE.md`](./docs/PR_TEMPLATE.md)                           | PR 描述模板                                         |
| [`docs/reference/`](./docs/reference/README.md)                          | 技术参考材料索引                                    |

其余 AI 相关入口见 [`AGENTS.md`](./AGENTS.md) 中的「文档地图」与「延伸阅读」。

## 许可证

见 [`LICENSE`](./LICENSE)。
