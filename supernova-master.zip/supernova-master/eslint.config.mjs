/**
 * ESLint Flat Config（`eslint.config.mjs`）
 *
 * ## 角色
 * - **基础规则集**：`@antfu/eslint-config`（集成 TypeScript、import、unicorn、stylistic 等，适配 Flat Config）。
 * - **本文件**：只写本 monorepo 的 `ignores` 与**显式覆盖**；不要在此重复实现一套与 Antfu 重复的规则。
 * - **不使用** legacy `.eslintrc.*`：避免与 Flat Config 双轨并存、规则来源不清。
 *
 * ## 与本仓库其它工具的关系（最佳实践）
 * - **Prettier**（`prettier.config.mjs`）：负责换行、引号、分号等**纯格式**；若与 ESLint 冲突，优先用配置对齐或改代码，少用 `eslint-disable`。
 * - **EditorConfig**（`.editorconfig`）：编辑器级缩进/换行；与 Prettier 保持一致。
 * - **TypeScript**：类型检查以 `pnpm typecheck` / `tsconfig.json` 为准；ESLint 侧重可自动修复的风格与常见错误。
 *
 * ## 修改约定
 * - 新增/收紧规则时，同步更新 `docs/ENGINEERING_CAPABILITIES.md` 中「Linter」相关说明。
 * - 子包（`apps/*`、`packages/*`、`portals/*`）若需特殊规则，优先在该目录单独 `eslint.config` 扩展，避免根配置无限膨胀。
 *
 * ## 参考链接
 * - ESLint Flat Config：https://eslint.org/docs/latest/use/configure/configuration-files
 * - `@antfu/eslint-config`：https://github.com/antfu/eslint-config
 * - ESLint Stylistic（风格规则）：https://eslint.style/
 */
import antfu from '@antfu/eslint-config'

export default antfu({
  /**
   * 显式忽略（Flat Config 下 `.eslintignore` 不生效，以这里为准）。
   * 与 `.prettierignore` 中「不扫描构建产物」的意图对齐，减少无意义扫描与误报。
   */
  ignores: ['**/node_modules/**', '**/.pnpm/**', '**/dist/**', '**/build/**', '**/.next/**', '**/coverage/**', '**/*.min.js'],

  /**
   * 覆盖 Antfu 默认：键名与插件前缀以实际报错为准（如 `style/*`、`unicorn/*`）。
   * 原则：可读性、与 Prettier 共存、与本仓库 `AGENTS.md` / 工程文档一致。
   */
  rules: {
    /**
     * `console`：开发期保留（脚本、调试）；上线代码应在业务层用统一 logger，再考虑改为 `warn` 或按目录覆盖。
     */
    'no-console': 'off',

    /**
     * 单参数箭头函数也保留括号：`(x) => x`，与 Prettier `arrowParens: "always"` 一致，避免与格式工具拉扯。
     * @see https://eslint.style/rules/js/arrow-parens（Antfu 使用 stylistic 体系时规则名可能为 `style/arrow-parens`）
     */
    'style/arrow-parens': ['error', 'always'],

    /**
     * 花括号风格（1tbs）：`} else {` / `} catch {` / `} finally {` 与 Prettier 默认输出同一行，避免 `try/catch` 与 ESLint、Prettier 拉扯。
     */
    'style/brace-style': ['error', '1tbs'],

    /**
     * 所有控制语句必须带花括号，禁止 `if (x) return y` 单行形式，降低误改与 diff 噪音。
     */
    'curly': ['error', 'all'],

    /**
     * 可读性：变量声明块与后续 `if` 之间、以及 `return` 前保留空行（与仓库脚本/协作习惯一致）。
     */
    'padding-line-between-statements': [
      'error',
      { blankLine: 'always', prev: ['const', 'let', 'var'], next: 'if' },
      { blankLine: 'always', prev: '*', next: 'return' },
    ],
  },
})
