import { useHelloI18n } from '@supernova/i18n-react'

export function App() {
  const title = useHelloI18n('zh-CN')

  return (
    <main>
      <h1>{title}</h1>
      <p>
        Vite + React + workspace
        <code>@supernova/i18n-react</code>
      </p>
    </main>
  )
}
