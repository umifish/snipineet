# frontend-react

- **开发**（在子包定义 `vite`）：仓库根 `pnpm --filter @supernova/frontend-react dev`，或 `cd apps/frontend-react && pnpm dev`
- **构建**：`pnpm --filter @supernova/frontend-react build`
- 依赖 **`@supernova/i18n-react`**（再依赖 `@supernova/i18n`）；开发与类型检查通过根 `tsconfig` / Vite `alias` 指向源码（无需先 `build` 库）。
