import path from 'node:path'
import { fileURLToPath } from 'node:url'

import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@supernova/common': path.resolve(__dirname, '../../packages/common/src/index.ts'),
      '@supernova/request': path.resolve(__dirname, '../../packages/request/src/index.ts'),
      '@supernova/validation': path.resolve(__dirname, '../../packages/validation/src/index.ts'),
      '@supernova/i18n': path.resolve(__dirname, '../../packages/intl/i18n/src/index.ts'),
      '@supernova/i18n-react': path.resolve(__dirname, '../../packages/intl/i18n-react/src/index.ts'),
    },
  },
})
