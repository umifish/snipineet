# portals

`pnpm` workspace 中的**门户 / 聚合入口**目录（与 `apps/*` 并列）。仓库总览、前置条件与常用脚本见根目录 [README.md](../README.md)。

## 现状

当前 **`portals/` 下尚无子目录/子包**，仅保留本说明。后续新增门户应用时，请按下方 [约定](#约定) 创建独立 workspace 包。

## 约定

无子包时本段仍保留：**约定的是「新增门户子包时」应遵守的规则**，避免与仓库其余部分（`apps/*`、`packages/*`）分工混淆。

- 每个子目录（例如 `portals/<name>/`）应为 **pnpm workspace 包**（含独立 `package.json`），由根目录 [`pnpm-workspace.yaml`](../pnpm-workspace.yaml) 的 `portals/*` 纳入工作区。
- 复用逻辑优先来自 `packages/*`；与主站共享的 UI/协议约定见 [`docs/ENGINEERING_CAPABILITIES.md`](../docs/ENGINEERING_CAPABILITIES.md)。
- TypeScript、lint、测试门禁与仓库根脚本一致；业务源码变更受 `pnpm test:gate` 约束，协作流程见 [`AGENTS.md`](../AGENTS.md)。
