/**
 * 生成 docs/reference/prettier/prettier.full.reference.md 与 prettier.full.reference.jsonc
 * 选项列表与说明来自本机 `prettier` 的 `getSupportInfo().options`（与当前 Prettier 版本一致）。
 * 运行：node scripts/generate-prettier-full-reference.mjs
 */
import fs from 'node:fs'
import { createRequire } from 'node:module'
import path from 'node:path'
import process from 'node:process'
import { fileURLToPath } from 'node:url'

const require = createRequire(import.meta.url)
const __dirname = path.dirname(fileURLToPath(import.meta.url))
const root = path.resolve(__dirname, '..')

const prettier = await import('prettier')
const prettierPkg = path.join(path.dirname(require.resolve('prettier/package.json', { paths: [root] })), 'package.json')
const prettierVersion = JSON.parse(fs.readFileSync(prettierPkg, 'utf8')).version

const { options } = await prettier.getSupportInfo()
const sorted = [...options].sort((a, b) => a.name.localeCompare(b.name))

const outDir = path.join(root, 'docs/reference/prettier')
fs.mkdirSync(outDir, { recursive: true })

/** 与官网文档锚点习惯一致：camelCase → kebab-case */
const RE_OPTION_ANCHOR_1 = /([a-z0-9])([A-Z])/g
const RE_OPTION_ANCHOR_2 = /([A-Z])([A-Z][a-z])/g
const RE_ESC_MD_PIPE = /\|/g
const RE_ESC_MD_NEWLINE = /\r?\n/g
const RE_JSONC_DESC_NEWLINE = /\n/g

function optionAnchor(name) {
  return name.replace(RE_OPTION_ANCHOR_1, '$1-$2').replace(RE_OPTION_ANCHOR_2, '$1-$2').toLowerCase()
}

const docBase = 'https://prettier.io/docs/options'

function escMd(s) {
  if (s == null) {
    return ''
  }

  return String(s).replace(RE_ESC_MD_PIPE, '\\|').replace(RE_ESC_MD_NEWLINE, ' ')
}

const mdRows = sorted.map((o) => {
  const hash = optionAnchor(o.name)
  const link = `${docBase}#${hash}`
  const def = o.default === undefined ? '—' : typeof o.default === 'object' ? JSON.stringify(o.default) : String(o.default)
  let choices = ''

  if (o.choices?.length) {
    choices = o.choices.map((c) => `\`${c.value}\`: ${escMd(c.description)}`).join('<br>')
  }

  return `| \`${o.name}\` | ${o.category} | ${o.type} | \`${escMd(def)}\` | ${escMd(o.description)} | ${choices ? escMd(choices) : '—'} | [选项文档](${link}) |`
})

const mdHeader = `<!-- 本文件由 scripts/generate-prettier-full-reference.mjs 生成，请勿手改；升级 prettier 后请运行 pnpm docs:gen:prettier-full -->

# Prettier 配置项全表（参考）

本文件与 \`docs/reference/typescript/tsconfig.full.reference.jsonc\` 用途相同：**速查 + 链到官网**；具体启用与否以根目录 \`prettier.config.mjs\` 为准。

- **说明文案**：表格中「英文说明」来自当前依赖包内 \`getSupportInfo().options[].description\`（与 Prettier 内置文档同源）。
- **默认值**：来自 \`default\` 字段；实际项目以 \`prettier.config.mjs\` 为准。

## 官方入口

- 配置：<https://prettier.io/docs/configuration>
- 选项详解：<https://prettier.io/docs/options>

## 统计

- Prettier 版本（本机依赖）：\`${prettierVersion}\`
- \`getSupportInfo().options\` 条数：**${sorted.length}**

## 选项一览

| 选项名 \`option\` | 分类 | 类型 | 默认值 | 英文说明 | 可选值 | 官网 |
| --- | --- | --- | --- | --- | --- | --- |
`

const mdPath = path.join(outDir, 'prettier.full.reference.md')
fs.writeFileSync(mdPath, `${mdHeader + mdRows.join('\n')}\n`, 'utf8')

let jsonc = `/**
 * Prettier — 全量选项参考（注解版，不参与构建）
 *
 * - 选项名、默认值与说明来自本机 prettier 的 getSupportInfo()（与 prettier.full.reference.md 同源）。
 * - 复制到项目时请按需删减；仓库实际配置见根目录 prettier.config.mjs。
 *
 * 官方文档：https://prettier.io/docs/options
 */

{
`

for (const o of sorted) {
  const hash = optionAnchor(o.name)
  const link = `${docBase}#${hash}`
  const def = o.default === undefined ? undefined : o.default
  const defStr = def === undefined ? '（无默认或依解析器）' : JSON.stringify(def)
  const descOneLine = String(o.description).replace(RE_ESC_MD_NEWLINE, ' ')

  jsonc += `
  // ---------------------------------------------------------------------------
  // ${o.name}  [${o.category}]  type: ${o.type}
  // ${descOneLine}
  // 默认（官方）: ${defStr}
`

  if (o.choices?.length) {
    for (const c of o.choices) {
      jsonc += `  //   - ${JSON.stringify(c.value)}: ${c.description.replace(RE_JSONC_DESC_NEWLINE, '\n  //     ')}\n`
    }
  }

  jsonc += `  // ${link}
  // ---------------------------------------------------------------------------
  // "${o.name}": ${def === undefined ? 'null' : JSON.stringify(def)},

`
}

jsonc += `  "overrides": []
}
`

const jsoncPath = path.join(outDir, 'prettier.full.reference.jsonc')

fs.writeFileSync(jsoncPath, jsonc, 'utf8')

process.stdout.write(`Wrote ${mdPath}\nWrote ${jsoncPath} (${sorted.length} options)\n`)
