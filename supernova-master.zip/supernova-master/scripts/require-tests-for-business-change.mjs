import { execSync } from 'node:child_process'
import process from 'node:process'

const TEST_FILE_PATTERNS = [/(^|\/)tests\/.*\.(ts|tsx)$/, /(^|\/)__tests__\/.*\.(ts|tsx)$/, /\.(test|spec)\.(ts|tsx)$/]

const BUSINESS_SOURCE_PATTERNS = [/^apps\/.*\.(ts|tsx)$/, /^packages\/.*\.(ts|tsx)$/, /^portals\/.*\.(ts|tsx)$/]

function repoHasAnyTestFiles() {
  // If the repository has no test files at all, the business test gate should be a no-op.
  const allFilesOutput = execSync('git ls-files', { encoding: 'utf8' })
  const allFiles = allFilesOutput.split('\n').filter(Boolean)

  return allFiles.some((filePath) => TEST_FILE_PATTERNS.some((pattern) => pattern.test(filePath)))
}

function readChangedFiles(baseSha, headSha) {
  const diffOutput = execSync(`git diff --name-only ${baseSha} ${headSha}`, {
    encoding: 'utf8',
  })
  const text = diffOutput.trim()

  if (text.length === 0) {
    return []
  }

  return text.split('\n').filter(Boolean)
}

function isBusinessSourceFile(filePath) {
  if (filePath.endsWith('.d.ts')) {
    return false
  }

  return BUSINESS_SOURCE_PATTERNS.some((pattern) => pattern.test(filePath))
}

function hasTestFileChange(changedFiles) {
  return changedFiles.some((filePath) => TEST_FILE_PATTERNS.some((pattern) => pattern.test(filePath)))
}

function tryGetSha(ref) {
  try {
    return execSync(`git rev-parse --verify ${ref}`, { encoding: 'utf8' }).trim()
  } catch {
    return ''
  }
}

const baseShaFromInput = process.env.GIT_BASE_SHA ?? process.argv[2] ?? ''
const headShaFromInput = process.env.GIT_HEAD_SHA ?? process.argv[3] ?? ''

let baseSha = baseShaFromInput
let headSha = headShaFromInput

if (baseSha === '') {
  // Local fallback: best-effort for "last commit" diffs.
  baseSha = tryGetSha('HEAD~1')
}

if (headSha === '') {
  headSha = tryGetSha('HEAD')
}

if (!baseSha || !headSha) {
  console.warn('Business test gate: cannot determine base/head SHAs (missing GIT_BASE_SHA/GIT_HEAD_SHA and HEAD~1/HEAD). Skip gate.')
  process.exit(0)
}

if (!repoHasAnyTestFiles()) {
  console.warn('Business test gate: no matching test files in repo. Skip gate.')
  process.exit(0)
}

const changedFiles = readChangedFiles(baseSha, headSha)
const businessChanged = changedFiles.filter(isBusinessSourceFile)

if (businessChanged.length === 0) {
  process.exit(0)
}

const hasAnyTestChange = hasTestFileChange(changedFiles)

if (!hasAnyTestChange) {
  console.error('Business test gate failed: business-source TS/TSX changed but no test files were added/updated.')
  console.error('Changed business source files:')

  for (const filePath of businessChanged) {
    console.error(`- ${filePath}`)
  }

  console.error('')
  console.error('Add/update at least one test file, e.g.:')
  console.error('  - `**/*.test.ts` / `**/*.spec.ts`')
  console.error('  - `**/__tests__/**`')
  console.error('  - `**/tests/**`')

  process.exit(1)
}

process.exit(0)
