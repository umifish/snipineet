/**
 * 生成 docs/reference/eslint/eslint.full.reference.md
 * 规则列表来自本机 `eslint` 包内的 `builtinRules`（与当前 ESLint 版本一致）。
 * 运行：node scripts/generate-eslint-full-reference.mjs
 */
import fs from 'node:fs'
import { createRequire } from 'node:module'
import path from 'node:path'
import process from 'node:process'
import { fileURLToPath } from 'node:url'
import { builtinRules } from 'eslint/use-at-your-own-risk'

const PIPE_IN_CELL = /\|/g
const NEWLINE_IN_CELL = /\r?\n/g

const require = createRequire(import.meta.url)
const __dirname = path.dirname(fileURLToPath(import.meta.url))
const root = path.resolve(__dirname, '..')
const eslintPkgJson = path.join(path.dirname(require.resolve('eslint/package.json', { paths: [root] })), 'package.json')
const eslintVersion = JSON.parse(fs.readFileSync(eslintPkgJson, 'utf8')).version
const outDir = path.join(root, 'docs/reference/eslint')
const outPath = path.join(outDir, 'eslint.full.reference.md')

fs.mkdirSync(outDir, { recursive: true })

function escCell(s) {
  if (!s) {
    return ''
  }

  return String(s).replace(PIPE_IN_CELL, '\\|').replace(NEWLINE_IN_CELL, ' ')
}

const names = [...builtinRules.keys()].sort((a, b) => a.localeCompare(b))

const rows = names.map((name) => {
  const rule = builtinRules.get(name)
  const meta = rule?.meta
  const docs = meta?.docs
  const url = docs?.url ?? `https://eslint.org/docs/latest/rules/${name}`
  const deprecated = meta?.deprecated === true ? '是' : ''
  const desc = docs?.description ?? '（无 description 字段，详见文档页）'

  return `| \`${name}\` | ${deprecated} | ${escCell(desc)} | [文档](${url}) |`
})

const header = `<!-- 本文件由 scripts/generate-eslint-full-reference.mjs 生成，请勿手改；升级 eslint 后请运行 pnpm docs:gen:eslint-full -->

# ESLint 内置规则全表（参考）

本文件与 \`docs/reference/typescript/tsconfig.full.reference.jsonc\` 用途相同：**速查 + 链到官网**；具体启用与否以根目录 \`eslint.config.mjs\`（及 \`@antfu/eslint-config\`）为准。

> **范围**：仅列出 ESLint 核心 **\`builtinRules\`**。\`@typescript-eslint/*\`、\`eslint-plugin-*\` 等插件规则不在此表。

## 文档语言约定

- 本表「英文说明」列直接引用 ESLint 自带的 \`rule.meta.docs.description\`（与官网一致），便于对照报错原文、复制英文检索。
- 规则名、URL 保持**英文**；需要中文释义时以官网文档页面为准。

## 官方入口（Flat Config / 规则索引）

- 配置（Flat Config）：<https://eslint.org/docs/latest/use/configure/configuration-files>
- 规则列表索引：<https://eslint.org/docs/latest/rules/>
- \`@antfu/eslint-config\`：<https://github.com/antfu/eslint-config>

## 统计

- ESLint 版本（本机 \`package.json\` 依赖）：\`${eslintVersion}\`
- 内置规则条数：**${names.length}**（含已弃用规则；\`已弃用\` 列标「是」）

## 内置规则一览

| 规则名 \`rule\` | 已弃用 | 英文说明（meta.description） | 官方文档 |
| --- | --- | --- | --- |
`

const body = rows.join('\n')
const footer = `
`

fs.writeFileSync(outPath, `${header}${body}${footer}`, 'utf8')
process.stdout.write(`Wrote ${outPath} (${names.length} rules)\n`)
