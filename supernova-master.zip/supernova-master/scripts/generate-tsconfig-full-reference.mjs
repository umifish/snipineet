/**
 * 生成 docs/reference/typescript/tsconfig.full.reference.jsonc
 * 运行：node scripts/generate-tsconfig-full-reference.mjs
 */
import fs from 'node:fs'
import { createRequire } from 'node:module'
import path from 'node:path'
import process from 'node:process'
import { fileURLToPath } from 'node:url'

const require = createRequire(import.meta.url)
const __dirname = path.dirname(fileURLToPath(import.meta.url))
const root = path.resolve(__dirname, '..')
const libDir = path.dirname(require.resolve('typescript', { paths: [root] }))
const dtsPath = path.join(libDir, 'typescript.d.ts')
const outPath = path.join(root, 'docs/reference/typescript/tsconfig.full.reference.jsonc')

const d = fs.readFileSync(dtsPath, 'utf8')
const start = d.indexOf('    interface CompilerOptions {')
const end = d.indexOf('        [option: string]: CompilerOptionsValue', start)
const block = d.slice(start, end)

const lines = block.split('\n')
const entries = []
let pendingDeprecated = false
let pendingJsDoc = []

for (let i = 0; i < lines.length; i++) {
  const raw = lines[i]
  const t = raw.trim()

  if (t.startsWith('/**')) {
    if (t.includes('*/')) {
      pendingDeprecated = t.includes('@deprecated')
    } else {
      pendingJsDoc = [t]
    }

    continue
  }

  if (pendingJsDoc.length) {
    pendingJsDoc.push(t)
    if (t.includes('*/')) {
      pendingDeprecated = pendingJsDoc.some((x) => x.includes('@deprecated'))
      pendingJsDoc = []
    }

    continue
  }

  const m = t.match(/^([a-z][a-z0-9]*)\?:/i)

  if (m) {
    entries.push({ name: m[1], deprecated: pendingDeprecated })
    pendingDeprecated = false
    pendingJsDoc = []
  }
}

/** 常用项：一行中文用途/实践提示；未列出的选项输出「详见官网该选项说明。」（链接为准）。 */
const zhHint = {
  allowImportingTsExtensions: '允许在 import 中使用 `.ts`/`.tsx`/`.mts`/`.cts` 扩展名；通常与 `noEmit` 同用（打包器场景）。',
  allowJs: '将 JavaScript 文件纳入编译/检查。',
  allowSyntheticDefaultImports: '允许对无 default 导出的模块写默认导入（类型层面）。',
  baseUrl: '解析非相对模块名的根目录；常与 `paths` 联用（注意与 `rootDirs`/monorepo 边界）。',
  checkJs: '对 `.js` 文件做类型检查（需同时 `allowJs`）。',
  composite: '用于 project references；启用后对输出与引用关系有约束，常配合 `declaration`。',
  declaration: '生成 `.d.ts`（发 npm 包或 composite 子项目时常开）。',
  declarationMap: '为声明文件生成 source map，便于从类型跳到源码。',
  exactOptionalPropertyTypes: '可选属性与 `undefined` 区分更严；易与现有代码不兼容，按需开启。',
  forceConsistentCasingInFileNames: '强制 import 路径大小写与磁盘一致；跨平台协作建议开启。',
  incremental: '写入 `.tsbuildinfo` 缓存以加速重复 `tsc`（与 `composite` 常一起用）。',
  isolatedModules: '每个文件可独立转译；与 Babel/swc 等配合时建议开启。',
  jsx: 'JSX 转译方式；React 常用 `react-jsx`（经典模式为 `react`）。',
  lib: '指定默认类型库（如 `DOM`、`ES2022`）；不填则随 `target` 推断。',
  module: '输出模块格式；应用+打包器常用 `ESNext`；Node 库常见 `CommonJS`/`NodeNext`。',
  moduleResolution: '模块解析策略：`bundler` / `node10` / `node16` / `nodenext` 等。',
  noEmit: '只类型检查、不生成输出文件。',
  noFallthroughCasesInSwitch: '禁止 `switch` 中无意贯穿到下一 `case`（与 ESLint `no-fallthrough` 互补）。',
  noImplicitAny: '禁止隐式 `any`（`strict` 已包含；单独列出便于按需关闭时对照）。',
  noUncheckedIndexedAccess: '索引/属性访问结果含 `undefined`；更安但可能大量报错，渐进启用。',
  noUnusedLocals: '禁止未使用的局部变量（需 clean unused imports 时常开）。',
  noUnusedParameters: '禁止未使用的函数参数（可用 `_` 前缀等惯例配合）。',
  paths: '路径别名映射（通常与 `baseUrl` 配合）。',
  resolveJsonModule: '允许 `import` JSON 作为模块。',
  skipLibCheck: '跳过对 `.d.ts` 声明文件的类型检查以加速。',
  strict: '启用 strict 族检查的主开关。',
  strictFunctionTypes: '`strict` 子项：函数类型检查更严（方法参数与回调易踩坑时对照官网）。',
  strictNullChecks: '`strict` 子项：`null`/`undefined` 与类型窄化；多数项目与 `strict` 同开。',
  strictPropertyInitialization: '`strict` 子项：类属性须在构造函数中赋值或明确断言。',
  target: '编译目标（如 `ES2022`）；影响语法降级与可用的原生 API 类型。',
  types: '仅加载列出的 `@types` 包名；可限制全局类型污染。',
  useDefineForClassFields: '类字段按 ES 标准语义（与 `target`、装饰器实验相关；迁移旧代码时注意）。',
  verbatimModuleSyntax: '保留 `import type`/`export type` 等语法不被擦除。',
  esModuleInterop: '改进 CommonJS/ESM 互操作。',
}

const header = `/**
 * TypeScript — tsconfig「全量 compilerOptions」参考（注解版）
 *
 * - 选项列表与顺序来自本机安装的 TypeScript 包内 \`lib/typescript.d.ts\` 的 \`CompilerOptions\` 接口（与当前 \`typescript\` 版本一致）。
 * - 每项均附官网锚点链接；**默认值、边界与完整示例以官网为准**。
 * - **注释策略**：仓库在 \`scripts/generate-tsconfig-full-reference.mjs\` 的 \`zhHint\` 中为**常用项**写一行中文用途/实践提示；其余选项为「详见官网该选项说明。」（避免本文件与官方文档重复维护）。
 * - 本文件不参与构建；复制到项目时请按需删减。
 *
 * 官方文档入口：
 * - TSConfig：https://www.typescriptlang.org/tsconfig
 * - Compiler Options 手册：https://www.typescriptlang.org/docs/handbook/compiler-options.html
 * - tsconfig.json 结构：https://www.typescriptlang.org/docs/handbook/tsconfig-json.html
 * - JSON Schema：https://json.schemastore.org/tsconfig
 */

`

const docBase = 'https://www.typescriptlang.org/tsconfig#'

let body = `{
  "$schema": "https://json.schemastore.org/tsconfig",
  "compilerOptions": {
`

for (const { name, deprecated } of entries) {
  const tag = deprecated ? ' 【已弃用】' : ''
  const hint = zhHint[name] || '详见官网该选项说明。'
  body += `    // ---------------------------------------------------------------------------\n`
  body += `    // ${name}${tag}\n`
  body += `    // ${hint}\n`
  body += `    // ${docBase}${name}\n`
  body += `    // （按需取消注释并填写合法值，勿保留占位符）\n\n`
}

// 根对象仅含 `$schema` 与 `compilerOptions`；此处用 `}` 而非 `},`，避免逗号后只有注释被判定为非法尾随逗号（jsonc / 部分校验器）。
body += `  }\n`

body += `
  // ===========================================================================
  // 顶层字段（与 compilerOptions 平级，摘自 tsconfig.json 结构说明）
  // 文档：https://www.typescriptlang.org/docs/handbook/tsconfig-json.html
  // ===========================================================================

  // "extends": "./tsconfig.base.json",
  // "files": [],
  // "include": ["src/**/*"],
  // "exclude": ["node_modules", "dist"],
  // "references": [{ "path": "./packages/foo" }],
  // "compileOnSave": true,

  // "watchOptions": {
  //   "watchFile": "useFsEvents",
  //   "watchDirectory": "useFsEvents",
  //   "fallbackPolling": "dynamicPriority",
  //   "synchronousWatchDirectory": true,
  //   "excludeDirectories": ["**/node_modules", "_build"],
  //   "excludeFiles": ["**/node_modules/**"]
  // },

  // "typeAcquisition": {
  //   "enable": false,
  //   "include": ["jquery"],
  //   "exclude": ["@types/unnecessary"]
  // }
}
`

fs.writeFileSync(outPath, header + body, 'utf8')
process.stdout.write(`Wrote ${outPath} (${entries.length} compiler options)\n`)
