#!/usr/bin/env node

import { execSync } from 'node:child_process'
import fs from 'node:fs'
import process from 'node:process'

const SSH_ORIGIN_RE = /git@([^:]+):(.+?)(\.git)?$/
const HTTPS_ORIGIN_RE = /https?:\/\/([^/]+)\/(.+?)(\.git)?$/
const TRAILING_GIT_RE = /\.git$/

function getArg(name) {
  const idx = process.argv.indexOf(name)

  if (idx === -1) {
    return undefined
  }

  return process.argv[idx + 1]
}

function requireArg(name) {
  const value = getArg(name)

  if (!value) {
    throw new Error(`Missing required argument: ${name}`)
  }

  return value
}

function getGitOriginUrl() {
  const originUrl = execSync('git config --get remote.origin.url', { encoding: 'utf8' }).trim()

  if (!originUrl) {
    throw new Error('Could not resolve git remote "origin" URL')
  }

  return originUrl
}

function getCurrentBranch() {
  return execSync('git rev-parse --abbrev-ref HEAD', { encoding: 'utf8' }).trim()
}

function parseOriginRepo(originUrl) {
  // Supports:
  // - git@HOST:group/subgroup/project.git
  // - https://HOST/group/subgroup/project(.git)
  const m1 = originUrl.match(SSH_ORIGIN_RE)

  if (m1) {
    return { host: m1[1], projectPath: m1[2].replace(TRAILING_GIT_RE, '') }
  }

  const m2 = originUrl.match(HTTPS_ORIGIN_RE)

  if (m2) {
    return { host: m2[1], projectPath: m2[2].replace(TRAILING_GIT_RE, '') }
  }

  throw new Error(`Unsupported origin URL format: ${originUrl}`)
}

async function main() {
  const token = process.env.GITLAB_TOKEN

  if (!token) {
    throw new Error('Missing env GITLAB_TOKEN (GitLab API token).')
  }

  const head = requireArg('--head')

  if (!(head.startsWith('ai/') || head.startsWith('ai-'))) {
    throw new Error('Invalid --head branch name. It must start with "ai/" or "ai-".')
  }

  const title = requireArg('--title')

  const base = getArg('--base') // default: current branch
  const bodyFile = getArg('--body-file')
  let body = bodyFile ? fs.readFileSync(bodyFile, 'utf8') : getArg('--body')

  if (!body) {
    // Allow piping content via stdin
    //   cat mr-body.md | node ... --head ... --title ...
    const stdinBody = fs.readFileSync(0, 'utf8').trim()

    if (stdinBody) {
      body = stdinBody
    }
  }

  if (!body) {
    throw new Error('Missing MR body. Provide either --body-file <path>, --body <string>, or pipe via stdin.')
  }

  const originUrl = getGitOriginUrl()
  const { host, projectPath } = parseOriginRepo(originUrl)

  const targetBranch = base ?? getCurrentBranch()

  const apiBase = `https://${host}/api/v4`
  const url = `${apiBase}/projects/${encodeURIComponent(projectPath)}/merge_requests`

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'PRIVATE-TOKEN': token,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      title,
      source_branch: head,
      target_branch: targetBranch,
      description: body,
    }),
  })

  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(`GitLab API failed: ${res.status} ${res.statusText}\n${text}`)
  }

  const json = await res.json()
  console.log(json.web_url)
}

main().catch((err) => {
  console.error(err instanceof Error ? err.message : String(err))
  process.exit(1)
})
