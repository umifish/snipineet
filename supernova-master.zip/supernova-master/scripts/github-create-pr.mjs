#!/usr/bin/env node

import { execSync } from 'node:child_process'
import fs from 'node:fs'
import process from 'node:process'

const GITHUB_SSH_ORIGIN_RE = /git@github\.com:([^/]+)\/(.+?)(\.git)?$/
const GITHUB_HTTPS_ORIGIN_RE = /https?:\/\/github\.com\/([^/]+)\/(.+?)(\.git)?$/
const TRAILING_GIT_RE = /\.git$/

function getArg(name) {
  const idx = process.argv.indexOf(name)

  if (idx === -1) {
    return undefined
  }

  return process.argv[idx + 1]
}

function requireArg(name) {
  const value = getArg(name)

  if (!value) {
    throw new Error(`Missing required argument: ${name}`)
  }

  return value
}

function parseOriginRepo(originUrl) {
  // Supports:
  // - git@github.com:owner/repo.git
  // - https://github.com/owner/repo.git
  // - https://github.com/owner/repo
  const m1 = originUrl.match(GITHUB_SSH_ORIGIN_RE)

  if (m1) {
    return { owner: m1[1], repo: m1[2].replace(TRAILING_GIT_RE, '') }
  }

  const m2 = originUrl.match(GITHUB_HTTPS_ORIGIN_RE)

  if (m2) {
    return { owner: m2[1], repo: m2[2].replace(TRAILING_GIT_RE, '') }
  }

  throw new Error(`Unsupported origin URL format: ${originUrl}`)
}

function getGitOriginUrl() {
  const originUrl = execSync('git config --get remote.origin.url', { encoding: 'utf8' }).trim()

  if (!originUrl) {
    throw new Error('Could not resolve git remote "origin" URL')
  }

  return originUrl
}

function getCurrentBranch() {
  return execSync('git rev-parse --abbrev-ref HEAD', { encoding: 'utf8' }).trim()
}

async function main() {
  const token = process.env.GITHUB_TOKEN

  if (!token) {
    throw new Error('Missing env GITHUB_TOKEN (GitHub API token).')
  }

  const head = requireArg('--head')

  if (!(head.startsWith('ai/') || head.startsWith('ai-'))) {
    throw new Error('Invalid --head branch name. It must start with "ai/" or "ai-".')
  }
  const title = requireArg('--title')

  const base = getArg('--base') // default: current branch
  const bodyFile = getArg('--body-file')
  let body = bodyFile ? fs.readFileSync(bodyFile, 'utf8') : getArg('--body')

  if (!body) {
    // Allow piping content via stdin:
    //   cat pr-body.md | node ... --head ... --title ...
    const stdinBody = fs.readFileSync(0, 'utf8').trim()

    if (stdinBody) {
      body = stdinBody
    }
  }

  if (!body) {
    throw new Error('Missing PR body. Provide either --body-file <path>, --body <string>, or pipe via stdin.')
  }

  const originUrl = await getGitOriginUrl()
  const { owner, repo } = parseOriginRepo(originUrl)

  const finalBase = base ?? getCurrentBranch()

  const url = `https://api.github.com/repos/${owner}/${repo}/pulls`

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Accept': 'application/vnd.github+json',
      'Authorization': `Bearer ${token}`,
      'X-GitHub-Api-Version': '2022-11-28',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      title,
      head,
      base: finalBase,
      body,
      draft: false,
    }),
  })

  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(`GitHub API failed: ${res.status} ${res.statusText}\n${text}`)
  }

  const json = await res.json()
  console.log(json.html_url)
}

main().catch((err) => {
  console.error(err instanceof Error ? err.message : String(err))
  process.exit(1)
})
