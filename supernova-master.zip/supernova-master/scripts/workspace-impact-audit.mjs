/**
 * Lists workspace packages that declare a dependency on one or more @supernova/* packages
 * (reverse dependency / Impact Audit). Run from repository root.
 *
 * Usage: node scripts/workspace-impact-audit.mjs <@scope/name> [@scope/name ...]
 * Example: pnpm impact:audit @supernova/request @supernova/i18n-react
 */
import { execSync } from 'node:child_process'
import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import process from 'node:process'
import { fileURLToPath } from 'node:url'

const __dirname = dirname(fileURLToPath(import.meta.url))
const repoRoot = join(__dirname, '..')

/** @type {RegExp} */
const WORKSPACE_PKG_JSON_PREFIX = /^(?:apps|packages|portals)\//

const targets = process.argv.slice(2).filter((a) => !a.startsWith('-'))

if (targets.length === 0) {
  console.error('Usage: pnpm impact:audit <@scope/pkg> [@scope/pkg ...]')
  console.error('Example: pnpm impact:audit @supernova/request')
  process.exit(1)
}

function listWorkspacePackageJsonPaths() {
  try {
    return execSync('git ls-files', { encoding: 'utf8', cwd: repoRoot })
      .split('\n')
      .filter(Boolean)
      .filter((f) => f.endsWith('package.json'))
      .filter((f) => f !== 'package.json')
      .filter((f) => WORKSPACE_PKG_JSON_PREFIX.test(f))
  } catch {
    console.error('impact:audit: git ls-files failed (run from repository root).')
    process.exit(1)
  }
}

function mergedDeps(pkg) {
  return {
    ...pkg.dependencies,
    ...pkg.devDependencies,
    ...pkg.peerDependencies,
  }
}

const paths = listWorkspacePackageJsonPaths()
const consumersByTarget = new Map()

for (const t of targets) {
  consumersByTarget.set(t, [])
}

for (const rel of paths) {
  const abs = join(repoRoot, rel)
  let pkg

  try {
    pkg = JSON.parse(readFileSync(abs, 'utf8'))
  } catch {
    continue
  }

  const name = pkg.name

  if (!name || typeof name !== 'string') {
    continue
  }

  const deps = mergedDeps(pkg)

  for (const target of targets) {
    if (Object.hasOwn(deps, target)) {
      consumersByTarget.get(target).push({ consumer: name, path: rel })
    }
  }
}

for (const target of targets) {
  const list = consumersByTarget.get(target).sort((a, b) => a.path.localeCompare(b.path))
  console.log(`Dependents of ${target} (${list.length}):`)

  if (list.length === 0) {
    console.log('  (none — no other workspace package.json lists this dependency.)')
  } else {
    for (const { consumer, path } of list) {
      console.log(`  - ${consumer}  ${path}`)
    }
  }

  console.log('')
}

process.exit(0)
