# intl

本目录仅用于**归类**国际化相关 workspace 子包（**不是**一个 npm 包，无根级 `package.json`）。

| 子目录                                 | 包名                    |
| -------------------------------------- | ----------------------- |
| [`i18n`](./i18n/README.md)             | `@supernova/i18n`       |
| [`i18n-react`](./i18n-react/README.md) | `@supernova/i18n-react` |
| [`i18n-vue`](./i18n-vue/README.md)     | `@supernova/i18n-vue`   |

Workspace 见根目录 `pnpm-workspace.yaml` 中的 `packages/intl/*`。
