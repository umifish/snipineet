# @supernova/i18n

Workspace 内可复用包，使用 **tsup** 产出 `dist`：`index.cjs`（CJS）、`index.mjs`（ESM）、类型声明（`pnpm build`）。

根目录 `tsconfig.json` 的 `paths` 将 `@supernova/i18n` 指向 `src`，便于应用侧类型检查与 Vite 开发时无需先构建本包。

React 适配请使用独立包 **`@supernova/i18n-react`**；Vue 3 适配请使用 **`@supernova/i18n-vue`**。
