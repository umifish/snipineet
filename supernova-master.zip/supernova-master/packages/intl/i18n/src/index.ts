/**
 * 示例：workspace 内可复用包（由 tsup 产出 dist）。
 */
export function helloI18n(locale: string): string {
  return `hello (${locale})`
}
