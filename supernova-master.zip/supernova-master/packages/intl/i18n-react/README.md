# @supernova/i18n-react

React 适配层：**构建时将 `@supernova/i18n` 核心打进本包**（`tsup` 不将 `@supernova/i18n` 标为 `external`），因此使用方**只需**安装 **`@supernova/i18n-react`** 与 **`react`**，不必再单独安装 `@supernova/i18n`。

开发本包时仍通过 `devDependencies` 引用 `@supernova/i18n` 源码以参与构建。

```ts
import { helloI18n, useHelloI18n } from '@supernova/i18n-react'
```

若业务只要框架无关 API、不要 React，可继续单独使用 **`@supernova/i18n`**。
