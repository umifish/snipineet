import { helloI18n } from '@supernova/i18n'

import { useMemo } from 'react'

/** 由构建打入本包，使用方无需再安装 `@supernova/i18n`。 */
export { helloI18n }

/**
 * React 侧示例：基于核心 `@supernova/i18n` 的 hook（可按项目替换为真实 i18n）。
 */
export function useHelloI18n(locale: string): string {
  return useMemo(() => {
    return helloI18n(locale)
  }, [locale])
}
