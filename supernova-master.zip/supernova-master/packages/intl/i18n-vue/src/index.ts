import type { ComputedRef, MaybeRefOrGetter } from 'vue'

import { helloI18n } from '@supernova/i18n'
import { computed, toValue } from 'vue'

/** 由构建打入本包，使用方无需再安装 `@supernova/i18n`。 */
export { helloI18n }

/**
 * Vue 3 示例：基于核心 `@supernova/i18n` 的 composable（可按项目替换为真实 i18n）。
 * `locale` 支持 ref、getter 或普通字符串（与 `toValue` 语义一致）。
 */
export function useHelloI18n(locale: MaybeRefOrGetter<string>): ComputedRef<string> {
  return computed(() => {
    return helloI18n(toValue(locale))
  })
}
