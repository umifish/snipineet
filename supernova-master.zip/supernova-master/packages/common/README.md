# @supernova/common

**不发布**的 workspace 公共包（`"private": true`），供 `apps/*`、`portals/*`、`packages/*` 通过 workspace 协议引用。

使用 **tsup** 产出 `dist`：`index.cjs`（CJS）、`index.mjs`（ESM）、类型声明（`pnpm build`）。

根目录 `tsconfig.json` 的 `paths` 将 `@supernova/common` 指向 `src`，便于类型检查与 Vite 开发时**无需先构建**本包。

## 在其他包中引用

在仓库根目录执行（或在目标包目录执行并写好 filter）：

```bash
pnpm add @supernova/common@workspace:* --filter <目标包名>
```

或在目标包 `package.json` 的 `dependencies` 中手动加入对 `@supernova/common` 的 workspace 引用后执行 `pnpm install`。

示例：

```ts
import { PACKAGE_NAME } from '@supernova/common'
```

## 脚本

| 命令             | 说明        |
| ---------------- | ----------- |
| `pnpm build`     | 构建 `dist` |
| `pnpm typecheck` | 类型检查    |
