/**
 * 仓库内公共能力（不发布；仅 workspace 引用）。
 * 在此导出跨应用 / 跨包复用的工具函数、类型与常量。
 */

/** 包名常量（可用于日志、断言等）。 */
export const PACKAGE_NAME = '@supernova/common' as const
