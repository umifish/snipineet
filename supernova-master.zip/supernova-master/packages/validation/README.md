# @supernova/validation

**不发布**的 workspace 包（`"private": true`），基于 **zod** 做数据校验；统一 re-export `zod`，并提供 `parseOrThrow` 等少量工具。

使用 **tsup** 产出 `dist`；根目录 `tsconfig.json` 的 `paths` 指向 `src`，便于类型检查与 Vite 开发时无需先构建。

## 在其他包中引用

```bash
pnpm add @supernova/validation@workspace:* --filter <目标包名>
```

## 示例

```ts
import { parseOrThrow, z } from '@supernova/validation'

const User = z.object({ id: z.string(), age: z.number().int().nonnegative() })

const data = parseOrThrow(User, JSON.parse('{"id":"a","age":1}'))
```

## 脚本

| 命令             | 说明        |
| ---------------- | ----------- |
| `pnpm build`     | 构建 `dist` |
| `pnpm typecheck` | 类型检查    |
