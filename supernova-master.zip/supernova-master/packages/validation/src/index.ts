/**
 * 数据校验（`@supernova/validation`）：基于 **zod** 的 workspace 包（不发布；仅 workspace 引用）。
 *
 * 业务 schema 建议放在各 app / 包内；此处统一 re-export `zod` 并补充少量通用工具。
 */
import type { ZodType } from 'zod'

export * from 'zod'

/**
 * 对未知输入做 `schema.safeParse`，失败时抛出带 `issues` 的 `ZodError`（便于与 `try/catch` 统一处理）。
 */
export function parseOrThrow<T>(schema: ZodType<T>, data: unknown): T {
  const result = schema.safeParse(data)

  if (!result.success) {
    throw result.error
  }

  return result.data
}
