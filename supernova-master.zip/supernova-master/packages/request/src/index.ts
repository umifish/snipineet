/**
 * 基于 axios 的 HTTP 客户端封装（`@supernova/request`；不发布；仅 workspace 引用）。
 */
import type { AxiosInstance, CreateAxiosDefaults } from 'axios'
import axios from 'axios'

const DEFAULT_TIMEOUT_MS = 30_000

/**
 * 创建带仓库默认项的 Axios 实例（超时、JSON Content-Type 等），传入的 `config` 会覆盖默认项。
 */
export function createHttpClient(config?: CreateAxiosDefaults): AxiosInstance {
  return axios.create({
    timeout: DEFAULT_TIMEOUT_MS,
    headers: {
      'Content-Type': 'application/json',
    },
    ...config,
  })
}

export { axios }
export type {
  AxiosError,
  AxiosInstance,
  AxiosInterceptorManager,
  AxiosRequestConfig,
  AxiosResponse,
  CreateAxiosDefaults,
  InternalAxiosRequestConfig,
} from 'axios'
