# @supernova/request

**不发布**的 workspace 包（`"private": true`），基于 **axios** 提供统一 HTTP 客户端工厂 `createHttpClient`。

使用 **tsup** 产出 `dist`；根目录 `tsconfig.json` 的 `paths` 指向 `src`，便于类型检查与 Vite 开发时无需先构建。

## 在其他包中引用

```bash
pnpm add @supernova/request@workspace:* --filter <目标包名>
```

## 示例

```ts
import { createHttpClient } from '@supernova/request'

const http = createHttpClient({ baseURL: '/api' })
await http.get('/health')
```

## 脚本

| 命令             | 说明        |
| ---------------- | ----------- |
| `pnpm build`     | 构建 `dist` |
| `pnpm typecheck` | 类型检查    |
