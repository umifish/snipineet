# 仓库工程能力地图（Capability map）

条文以 [`ENGINEERING_CAPABILITIES.md`](./ENGINEERING_CAPABILITIES.md) 为准；本页仅索引。

| 域           | `ENGINEERING_CAPABILITIES.md` | 入口                                                                                                                                                                    |
| ------------ | ----------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **packages** | 目录与模块边界                | [intl](../packages/intl/README.md) · [request](../packages/request/README.md) · [validation](../packages/validation/README.md) · [common](../packages/common/README.md) |
| **UI**       | 框架与 UI、设计决策边界       | `apps/*` · `portals/*` · [portals/README](../portals/README.md)                                                                                                         |
| **工具链**   | 构建与打包；Linter / 格式化   | [build](./reference/build/README.md) · [eslint](./reference/eslint/README.md) · [prettier](./reference/prettier/README.md)                                              |
| **门禁**     | 业务变更测试                  | `package.json`：`typecheck`、`test:gate`、`test:run`                                                                                                                    |
| **安全**     | 安全与合规；确定性兜底        | [`AGENTS.md`](../AGENTS.md) §5                                                                                                                                          |

其它（如 `pnpm ruff`、[`.ruff.toml`](../.ruff.toml)）见工程文档全文。新规则先写入 `ENGINEERING_CAPABILITIES.md`，再更新本表。
