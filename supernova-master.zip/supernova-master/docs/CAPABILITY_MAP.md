# 仓库工程能力地图（Capability map）

## 目的

供 **AI 与人类**快速回答「本仓库有哪些可复用能力、**工程规则**写在 `docs/ENGINEERING_CAPABILITIES.md` 哪一节、**代码与包**在哪个路径」。

- **规则与政策的单一事实来源**仍是 [`docs/ENGINEERING_CAPABILITIES.md`](./ENGINEERING_CAPABILITIES.md)；本文件**不**重复条文，只作**导航与对照**。
- **具体 API 与用法**以各包 `README.md` 为准。若本地图与包内文档或工程能力文档冲突，以 **`ENGINEERING_CAPABILITIES.md` 条文 + 包内最新说明** 为准。

## 能力对照表

| 能力                           | 约定在 `ENGINEERING_CAPABILITIES.md` 中的位置            | 代码或延伸阅读                                                                                                                           |
| ------------------------------ | -------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------- |
| **国际化（i18n）**             | 「目录与模块边界」中的国际化分包命名与物理目录           | [`packages/intl/README.md`](../packages/intl/README.md)（`@supernova/i18n` / `i18n-react` / `i18n-vue`）                                 |
| **HTTP 客户端**                | 复用优先见「目录与模块边界」；新建调用优先用共享包       | [`packages/request/README.md`](../packages/request/README.md)（`@supernova/request`，axios）                                             |
| **数据校验**                   | 与协议/边界相关时与「TypeScript 优先」「确定性实现」配合 | [`packages/validation/README.md`](../packages/validation/README.md)（`@supernova/validation`，zod）                                      |
| **公共工具/共享常量**          | 「目录与模块边界」                                       | [`packages/common/README.md`](../packages/common/README.md)（`@supernova/common`）                                                       |
| **UI（React / Vue 与组件库）** | 「框架与 UI 组件优先复用」「AI 与设计决策边界」          | 应用见 `apps/*`；门户见 `portals/*`（[`portals/README.md`](../portals/README.md)）                                                       |
| **构建（Vite / tsup）**        | 「构建与打包」                                           | [`docs/reference/build/README.md`](./reference/build/README.md)                                                                          |
| **类型检查与测试门禁**         | 「TypeScript 优先」「业务变更测试」                      | 根目录 `package.json` 中 `typecheck`、`test:gate`、`test:run`                                                                            |
| **Lint / Format**              | 「Linter / 格式化约束」                                  | [`docs/reference/eslint/README.md`](./reference/eslint/README.md)、[`docs/reference/prettier/README.md`](./reference/prettier/README.md) |
| **Python（Ruff）**             | 「Python」小节                                           | 根目录 [`.ruff.toml`](../.ruff.toml)                                                                                                     |
| **安全与合规**                 | 「安全与合规」「确定性实现与禁止概率兜底」               | 与 [`AGENTS.md`](../AGENTS.md) 授权边界、密钥禁止项配合                                                                                  |

## 维护约定

新增共享能力时：除维护包内 `README.md` 外，应在本表**增行或更新第三列**；若引入新的工程级规则，**必须先**写入 `docs/ENGINEERING_CAPABILITIES.md`，再在本地图中挂链。
