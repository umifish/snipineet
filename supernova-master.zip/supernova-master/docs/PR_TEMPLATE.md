# PR 说明

## 变更摘要

<!-- 做了什么、为什么做 -->

## 影响面

<!-- 涉及的接口/协议/行为变化；涉及哪些 `apps/*` / `portals/*` / `packages/*` 模块 -->

<!-- 若有设计稿、需求/issue、设计系统说明等依据，可写可访问链接或仓库内文档路径（须脱敏）；无则省略。视觉与信息架构边界见 `docs/ENGINEERING_CAPABILITIES.md`「AI 与设计决策边界」。 -->

## 验证结果（PR 前必须先通过）

<!-- 与 `AGENTS.md` 固定规则第 5 项、`docs/AI_OPERATION_PLAYBOOK.md` 第 2.3 节对齐；未跑某条须写明原因或「待验证」。仅文档变更见 Playbook 第 2.7 节。 -->

- [ ] `pnpm lint`
- [ ] `pnpm format:check`
- [ ] `pnpm typecheck`（涉及 TS/业务逻辑/协议/数据结构或关键流程时必跑）
- [ ] `pnpm test:gate`（业务变更须跑；无业务源码变更时多为通过/跳过）
- [ ] `pnpm test:run`（存在需执行的测试时）
- [ ] `pnpm ruff`（涉及 Python 且本地可用时；CI 可能单独跑）
- [ ] `pnpm build`（可选：改动影响构建产物、对外入口或子包 `exports` 时建议跑并在此说明结论）

## 风险与后续

<!-- 按风险维度给出：风险清单（含严重度）+ 触发条件/受影响范围 + 缓解/验证方式 + 下一步跟踪建议 -->

## 关联

<!-- 关联 issue/需求/PR/commit hash（如有） -->
