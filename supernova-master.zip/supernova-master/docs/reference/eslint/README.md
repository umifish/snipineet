# ESLint（Reference）

对应 ESLint 官网 **[Rules](https://eslint.org/docs/latest/rules/)** 与 **Flat Config**：本目录存放与内置规则、配置相关的**参考表**；实际启用规则以根目录 `eslint.config.mjs` 及 `@antfu/eslint-config` 为准。

> 说明：`eslint.full.reference.md` 仅覆盖 **ESLint 核心 `builtinRules`**（与 `eslint` 包版本一致）。`@typescript-eslint/*`、`eslint-plugin-*` 等插件规则不在此表，需查对应插件文档。

## 文件

| 文件                                                                                                   | 说明                                                                                 |
| ------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------ |
| [`eslint.full.reference.md`](./eslint.full.reference.md)                                               | **全量**内置规则表（条数与当前依赖的 `eslint` 版本一致）+ 每规则官网链接；由脚本生成 |
| [`../../scripts/generate-eslint-full-reference.mjs`](../../scripts/generate-eslint-full-reference.mjs) | 生成上一文件的脚本；升级 ESLint 后可运行 `pnpm docs:gen:eslint-full` 再提交          |

## 官方入口

- [Configuration Files (Flat Config)](https://eslint.org/docs/latest/use/configure/configuration-files)
- [Rules](https://eslint.org/docs/latest/rules/)
