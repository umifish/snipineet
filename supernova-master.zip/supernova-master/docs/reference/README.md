# Reference

本目录存放与**官方文档结构类似**的参考材料（按技术主题分子目录），便于与 `docs/` 下其它说明性文档区分。

- 官方 TypeScript 文档结构示例：<https://www.typescriptlang.org/docs/>

## 子目录

| 目录                                    | 说明                                                |
| --------------------------------------- | --------------------------------------------------- |
| [`typescript/`](./typescript/README.md) | TypeScript / tsconfig 相关注解与模板                |
| [`eslint/`](./eslint/README.md)         | ESLint 内置规则全表与配置参考                       |
| [`build/`](./build/README.md)           | Vite / tsup 分工与约定                              |
| [`prettier/`](./prettier/README.md)     | Prettier 配置、`prettier.full.reference.*` 全量选项 |
