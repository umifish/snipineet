# Prettier

## 配置入口

- 仓库根目录 **`prettier.config.mjs`**（含中文注释与 `overrides` 说明）。
- 历史说明与工程约束见 **`docs/ENGINEERING_CAPABILITIES.md`**（Prettier / ESLint 对齐、花括号 1tbs 与 `} catch {` 约定、`prettier-ignore` 使用条件）。
- 忽略路径见 **`.prettierignore`**。

## 全量选项参考（与当前依赖版本对齐）

| 文件                                                               | 说明                                       |
| ------------------------------------------------------------------ | ------------------------------------------ |
| [`prettier.full.reference.md`](./prettier.full.reference.md)       | `getSupportInfo().options` 表格 + 官网锚点 |
| [`prettier.full.reference.jsonc`](./prettier.full.reference.jsonc) | 每项注释 + 占位键（注解模板，不参与构建）  |

升级 Prettier 依赖后请运行：`pnpm docs:gen:prettier-full`

## 官方链接

- 配置：<https://prettier.io/docs/configuration>
- 选项：<https://prettier.io/docs/options>
