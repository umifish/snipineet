# TypeScript（Reference）

对应 TypeScript 官网 **[Reference](https://www.typescriptlang.org/tsconfig)** 类文档：本目录放与 `tsconfig`、编译选项相关的**注解版模板**，便于团队查阅；实际构建仍以仓库根目录 `tsconfig.base.json` / `tsconfig.json` 为准。

## 文件

| 文件                                                                                                       | 说明                                                                                                              |
| ---------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------- |
| [`tsconfig.base.reference.jsonc`](./tsconfig.base.reference.jsonc)                                         | 与本仓库 `tsconfig.base.json` 对齐的注解版模板（常用项 + 官方链接）                                               |
| [`tsconfig.full.reference.jsonc`](./tsconfig.full.reference.jsonc)                                         | **全量** `compilerOptions`（与当前依赖的 `typescript` 版本 `CompilerOptions` 接口一致）+ 顶层字段说明；由脚本生成 |
| [`../../scripts/generate-tsconfig-full-reference.mjs`](../../scripts/generate-tsconfig-full-reference.mjs) | 生成上一文件的脚本；升级 TS 后可运行 `pnpm docs:gen:tsconfig-full` 再提交                                         |

## 官方入口

- [TSConfig Reference](https://www.typescriptlang.org/tsconfig)
- [Compiler Options](https://www.typescriptlang.org/docs/handbook/compiler-options.html)
