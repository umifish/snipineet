# ENGINEERING_CAPABILITIES.md

## 目的

集中维护 `supernova` 仓库的工程能力边界：编码约束（coding constraints）、lint/format 规范、以及工具链约定。

- `AGENTS.md`：agent 协作总纲与固定规则。
- `docs/AI_OPERATION_PLAYBOOK.md`：**AI 执行顺序**、自检命令顺序、提交/PR 前的**操作步骤**与正确性对照清单（§2.3～§2.4）；**仅文档变更**时的精简自检见 **§2.7**；**Bug 修复**执行补充见 **§2.8**。
- `docs/AI_BUGFIX_GUIDE.md`：缺陷排查与**常见问题**补充清单（按需；**原则**见本文件「Bug 修复与回归策略」）。
- `docs/CAPABILITY_MAP.md`：可复用能力（国际化、`packages/*` 等）与**本文件章节**、代码路径的**对照表**（导航用；**规则条文**仍以本文件为准）。
- **本文件**：工程规则与能力边界的**单一事实来源**（目录、TS/UI、安全、确定性、Linter 细节等）；**不**重复罗列「先跑哪条命令」（以 Playbook 与根目录 `package.json` 为准）。

### 文档与注释语言（Documentation & comments）

- **叙述与解释**：默认使用**中文**，便于团队内一致阅读。
- **保留英文（不强行翻译）**：工具/包/文件名、CLI 子命令、`package.json` scripts、配置键名、ESLint rule id、API 符号、与报错原文一致的术语、以及官方文档 URL。
- **不必全文双语**：避免同一段落内中英文各写一遍；若有对外（英文）读者，优先单独维护英文版 `README` 或独立文档，而不是在每条注释里重复双语。
- **示例**：说明写「与 Prettier 的 `arrowParens: "always"` 对齐」，而不是把整句规则名再翻译一遍。

## 约束（Coding Constraints）

### 目录与模块边界

- 业务语义优先放在 `apps/*`。
- **门户/聚合入口类**独立应用放在 `portals/*`（与 `apps/*` 并列的 workspace 子包；说明见 `portals/README.md`）。
- 复用能力优先放在 `packages/*`，并明确公开接口（输入/输出/错误语义）。
- **国际化分包命名**：核心为 **`@supernova/i18n`**；框架适配使用**独立包名**（如 **`@supernova/i18n-react`**、**`@supernova/i18n-vue`**），**不使用** `@supernova/i18n/react` 这类子路径导出，以免与团队习惯不一致。`@supernova/i18n-react` / `@supernova/i18n-vue` 构建时将核心**打入包内**，业务可只装对应适配包（不必再装 `@supernova/i18n`）；仅要框架无关 API 时仍可只装 `@supernova/i18n`。相关包在仓库中物理位于 **`packages/intl/*`**（归类目录，见 `packages/intl/README.md`）。
- 根目录只放配置与规范，避免堆叠业务代码。

### 工作区与包管理

- 使用 **pnpm** 工作区，配置见根目录 `pnpm-workspace.yaml` 与 `package.json` 中的 **`packageManager`** 字段（与本地/CI 对齐，避免锁文件与包管理器混用）。
- 子包依赖与 `workspace:` 协议以各包 `package.json` 为准；新增共享依赖时优先在**根**或**具体子包**显式声明，避免幽灵依赖。

### 构建与打包（Vite / tsup）

- 仓库根提供 **Vite**、**tsup** 作为共享打包工具（见根目录 `package.json` 的 `devDependencies`）。
- **约定**：**应用/门户**（`apps/*`、`portals/*`）优先用 **Vite**（开发服务器与浏览器端构建）；**可复用库**（`packages/*`）优先用 **tsup** 产出 `dist`（ESM/CJS、类型声明等）。细则与链接见 `docs/reference/build/README.md`。
- `tsconfig.base.json` 中 `moduleResolution: "bundler"` 与 Vite 场景一致；纯 Node 库若在子包需要 `NodeNext` 等，在该包单独扩展 `tsconfig`。

### TypeScript 优先（TypeScript-first Policy）

- `tsconfig` 注解版参考（与官方 Reference 文档分区对应）：`docs/reference/typescript/tsconfig.base.reference.jsonc`；**全量 compilerOptions 列表**（与当前 `typescript` 版本对齐）：`docs/reference/typescript/tsconfig.full.reference.jsonc`（索引：`docs/reference/typescript/README.md`；升级 TS 后可运行 `pnpm docs:gen:tsconfig-full` 重新生成）。
- 默认新代码优先使用 TypeScript（`*.ts/ *.tsx`）。只有当现有工程/依赖/接口约束明确要求使用 JavaScript（例如脚手架/兼容层/第三方仅提供 JS API）时，才允许引入或新增 JavaScript。
- JavaScript 作为辅：用于
  - 工具脚本/构建脚本/配置文件（例如 `*.mjs`、`vite.config.*` 等）
  - 与遗留代码的过渡层（并在 PR 的 `风险与后续` 说明后续迁移计划）
  - 明确需要保持 JS 兼容的边界（例如只存在 JS 类型定义的第三方薄封装）
- 类型检查门禁：对影响业务逻辑/协议/数据结构的改动，必须完成类型校验（`tsc --noEmit` 或仓库提供的 `typecheck` 脚本），并在 PR 的 `验证结果` 里给出结论。
- 业务变更测试门禁：对影响业务逻辑/协议/数据结构/关键流程的改动，必须新增或更新至少一个测试文件（例如 `*.test.ts` / `*.spec.ts` 或 `__tests__` / `tests` 目录）。若仓库中完全不存在匹配的测试文件/测试内容，则门禁会自动跳过；否则先跑 `pnpm test:gate`（门禁检查），再跑 `pnpm test:run`（执行递归测试；子包若未提供测试脚本将跳过）。

#### 业务变更测试的内容要求（边界与异常）

门禁只保证「有测试、能跑通」；**测试断言**仍须对准业务语义。新增或更新的测试应在合理范围内覆盖：

- **主路径 / 成功路径**：与本次改动直接相关的预期行为。
- **业务边界**：与协议或类型一致的边界条件（如空值/空集合、极值、长度上限、枚举或状态机边界等），以仓库内既有约定与类型为准。
- **异常与错误路径**：可预见的无效输入、非法状态、资源不存在、权限或前置条件不满足等；断言须与现有错误类型、HTTP 状态码、错误码或用户可见文案的约定一致（若仓库已有统一模式则必须对齐）。
- **无法覆盖时**：若某类场景因环境、外部依赖或范围限制无法在单测/集成测试中稳定覆盖，须在 PR 的 `风险与后续` 中写明**未覆盖点、为何接受、以及建议的手动或后续补测方式**。

### 框架与 UI 组件优先复用（Framework/UI Policy）

- React（`apps/frontend-react`）：所有 UI 默认优先使用 Ant Design（`antd`）提供的标准组件与其推荐用法。
- Vue（`apps/frontend-vue`）：所有 UI 默认优先使用 Element Plus（`element-plus`）提供的标准组件与其推荐用法。若仓库中**尚未**创建该目录，本条视为**未来 Vue 应用**的约定；当前仅有 React 应用时，以 React 条款为准。

**可访问性（最低）**：复用或封装 UI 时，不得主动破坏键盘操作、焦点与语义化标签；若使用 `antd` / `element-plus` 默认无障碍行为，避免用非语义节点重写交互而未补齐等价能力。

#### 复用流程（生成代码时必须遵守）

1. 先在仓库内搜索复用点：优先查 `packages/*`（若工程已有统一 UI/布局/表单/表格封装），其次查对应应用的 `apps/*` 或 `portals/*` 内现有用法示例。
2. 若存在可复用封装：必须复用并保持一致的 props/事件/样式/可访问性约定。
3. 若不存在合适封装：可以直接使用 `antd` / `element-plus` 对应的标准组件，但不得“重新发明”与标准组件重叠的替代 UI（完整样式与交互）。
4. 只有当 `antd`/`element-plus` 无法满足且需求有明确业务价值时，才允许新增工程封装层（公共 UI 能力优先放到 `packages/*`，并在 PR 里说明新增原因与影响面）。

#### 禁止项（默认不能做）

- 禁止在 React 页面中引入 Element Plus（以及相反方向），用来实现同类 UI 能力。
- 禁止为标准 UI 能力（按钮、表单、弹窗、表格、分页、表单校验、loading 等）绕过 UI 库自行实现完整样式与交互。
- 禁止为“外观不一样/随手更换”额外引入新的 UI 组件库或样式依赖；如确需引入，必须在 PR 的 `风险与后续` 中给出理由、受影响范围、以及回滚/迁移预案。

#### 偏离与回退

- 若必须偏离 UI Policy：在 PR 的 `风险与后续` 写明偏离点、受影响范围、为什么不能复用既有组件、以及如何回退/迁移到标准 UI 体系。

#### AI 与设计决策边界（Design decision boundaries）

本节约束 **视觉与信息架构层面的决策**，与上文「组件库复用」互补：前者管 **用什么组件**，本节管 **在未有设计交付物时，AI 允许改到什么粒度**。

- **证据优先**（与 `AGENTS.md` 一致）：无设计稿、无设计系统/主题说明、无产品书面范围时，以仓库内**同类页面的既有布局与样式约定**以及 **`antd` / `element-plus` 默认主题与推荐用法**为准；不凭空定义品牌色板、字号阶梯或全局间距体系。
- **视觉一致性**：优先沿用应用内已有样式入口（例如 Less/CSS 变量、`ConfigProvider` / `theme`、项目已约定的 token）；避免在业务页面大量写死颜色、字号、圆角等「一次性魔法值」；确需新增时集中定义并说明用途。
- **信息架构与导航**：不擅自大改应用级导航、路由结构或核心页面层级；若需求表述开放，应在 PR 的 `影响面` 或 `风险与后续` 写明**依据**或**待产品/设计确认**之点。
- **与禁止项一致**：禁止为「更好看」或「换一种风格」而引入新 UI 库或大范围自定义皮肤；确需视觉升级须有明确需求或设计输入，并按上文「偏离与回退」处理。

### 命名与风格（跨语言统一最低要求）

- JavaScript/TypeScript：函数/变量 `camelCase`；类/组件 `PascalCase`；文件命名倾向 `kebab-case`。
- Python：函数/变量 `snake_case`；类 `PascalCase`；常量 `UPPER_SNAKE_CASE`。
- 新增公共接口要“可读”：在代码注释或文档片段中说明关键输入、输出与错误行为。

### 可维护性

- 避免魔法值：需要说明的常量集中定义。
- 错误可追踪：错误信息包含关键上下文，但不泄露敏感信息。
- 函数职责单一：优先拆分为更小、更可测的逻辑单元。

### Bug 修复与回归策略（Bugfix）

- **范围**：以修复缺陷为首要目标，**避免**顺带大范围重构或与缺陷无关的格式化；确需顺手清理时须在 PR 中**单独说明**范围，避免与修复混为一谈。
- **依据**：根因须有仓库内证据（调用链、类型、测试、日志或稳定复现步骤）；适用 **`AGENTS.md` 证据优先**与上文「确定性实现与禁止概率兜底」；禁止用猜测修改协议或对外可见行为。
- **回归测试**：在可稳定断言的前提下，应**新增或更新测试**覆盖该缺陷的触发条件与修复后的预期，并覆盖相关**边界与异常**（见「业务变更测试的内容要求（边界与异常）」）。无法在自动化测试中稳定复现时（如环境/硬件/第三方偶发），须在 PR「风险与后续」写明**复现方式**与**手动验证步骤**。
- **交付说明**：建议在 PR 中写清 **现象**、**根因**（或已验证的假设）、**修复要点**、**验证方式**（命令或步骤），便于评审与回溯。
- **常见问题与排查清单**：见 `docs/AI_BUGFIX_GUIDE.md`（团队可扩展；与本节冲突时以本节为准）。

### 安全与合规（最低要求）

- 不提交机密：token/密码/私钥/真实外部回调地址等不应进入仓库。
- 环境变量：本地密钥与真实地址放在 **`.env`**（已由 `.gitignore` 忽略）；可提交 **`.env.example`** 仅含占位键与说明，**不含**真实值。
- 日志避免输出敏感字段；涉及个人数据要先脱敏再记录。
- 修改 CI/CD、部署或密钥相关配置时，须遵循 `AGENTS.md` **第 5 节**授权边界。

### 确定性实现与禁止概率兜底（No-probabilistic Fallback）

- 默认要求确定性：除非需求明确要求（例如统计抽样、A/B 实验、加密学等），否则不要使用随机、投票、阈值概率、或“基于推测的分支”来决定关键业务逻辑。
- 无证据就停止：当关键接口/协议/数据结构/边界条件无法从仓库中定位到确定依据时，必须停止并提出澄清/列出需要的补充信息；不要用“可能/大概/大概率/猜测”继续写代码。
- 不确定要走确定性错误/降级：遇到无法确定的输入/状态时，优先使用确定的校验（类型、范围、空值、状态机）并返回明确错误，或采用可控的、可验证的降级策略；降级必须在 PR 的 `风险与后续` 里写明触发条件与回滚/验证方式。

## Linter / 格式化约束（Linter Rules）

### JavaScript / Node

#### 格式化与 Lint 冲突处理策略（Prettier vs ESLint）

1. 优先保持一致：当 `prettier` 输出与 `eslint` 规则冲突时，首先尝试通过调整 `prettier.config.mjs`、`.editorconfig` 或相关工具配置，让两者在同一套风格下对齐。
2. 优先用代码改动替代 ignore：如果仅通过重排/换行/拆行就能同时满足 lint 与 format，则用代码改动解决。
3. 最后手段才允许 `prettier-ignore`：仅当“无法通过配置或合理代码改动对齐”时才允许使用 `// prettier-ignore`，并满足：
   - 注释中写清原因（例如：eslint 规则要求的结构无法被 prettier 表达，或存在已知工具兼容问题）。
   - 尽量缩小作用范围（只忽略最小语句/最小对象）。
   - 在 PR 的 `风险与后续` 中补充“后续移除 ignore 的条件/计划”。

- ESLint：使用 Antfu 生态 `@antfu/eslint-config`，入口为根目录 `eslint.config.mjs`。**当前根目录 `lint` 脚本的 glob 不包含 `docs/**`下 Markdown**（以`package.json` 为准）；Markdown 的格式与排版由 Prettier（`pnpm format:check`）覆盖，语义与链接依赖 PR 审查。内置规则速查表（与当前 `eslint` 版本对齐，脚本生成）：`docs/reference/eslint/eslint.full.reference.md`（索引：`docs/reference/eslint/README.md`；升级 ESLint 后可运行 `pnpm docs:gen:eslint-full` 重新生成）。
- Prettier：使用根目录 `prettier.config.mjs`（说明见 `docs/reference/prettier/README.md`）；**全量选项表**（与当前 `prettier` 版本 `getSupportInfo()` 一致）：`docs/reference/prettier/prettier.full.reference.md` / `prettier.full.reference.jsonc`（升级 Prettier 后可运行 `pnpm docs:gen:prettier-full` 重新生成）。
- 花括号风格（`style/brace-style`）：采用 **1tbs**（与根目录 `eslint.config.mjs` 一致）。`} else {`、`} catch {`、`} finally {` 等与 Prettier 默认输出**同一行**；**不要**采用 Stroustrup 风格（闭合 `}` 后换行再写 `else` / `catch` / `finally`）。若手写换行，`pnpm format` 会改回与 Prettier 一致的写法。
- 空白与换行：使用 `.editorconfig` 作为最终规则。

需要的前置依赖：

- `eslint`
- `prettier`
- `@antfu/eslint-config`

### Python

- Ruff：使用根目录 `.ruff.toml`。
- 关注项：基础错误（`E/F`）、导入排序（`I`）、升级建议（`UP`）。
- 默认行宽：`line-length = 100`。

需要的前置依赖：

- `ruff`

## 本地校验与命令（本仓库）

**执行顺序与必跑命令**已写在 `docs/AI_OPERATION_PLAYBOOK.md` **§2.3**（编辑与本地自检），并与 `AGENTS.md` **固定规则第 5 项**、根目录 `package.json` 的 `scripts` 对齐。

**仅文档变更**（例如仅 Markdown、未改业务源码）时的精简自检见 Playbook **§2.7**，并与 `AGENTS.md` **固定规则第 5 项**中「仅文档变更」子项一致。

**Bug 修复**的原则与回归要求见上文「Bug 修复与回归策略」；执行顺序的补充见 Playbook **§2.8**；常见问题见 `docs/AI_BUGFIX_GUIDE.md`。

**正确性与代码质量**在执行时的对照要点见 Playbook **§2.4**；类型/测试/业务变更门禁的条文见上文「TypeScript 优先」与「业务变更测试门禁」各节。

**构建**：根目录 `pnpm build` 为递归 `pnpm -r --if-present build`。若改动影响构建产物、对外入口或子包 `exports`，建议在 PR「验证结果」中说明是否已执行过 **`pnpm build`**（或相关子包 `build`），以便与 CI/发布预期对齐。

**其它仓库/无脚本场景**（若从本模板迁出或子包单独配置）：可临时使用 `npx eslint`、`npx prettier --check`、`npx ruff` 等，以该子包 `package.json` 与 CI 约定为准。
